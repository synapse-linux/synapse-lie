# DS4 shared policy GPU qualification — R9

Source checkpoint f11ab7f. Prepend RAM capture after128 greedy decoded tokens,
then three independent replay/restore pairs with exact logits and subsequent
tokens. This explicitly covers the old adapter guard that failed R8. Same HIP executable compares legacy and DS4 capture
policies: exact physical 8192-token C1/C2 and 131072-token C1 workloads, plus
raw-text approximately8K C1. Context262144/chunk2048/TG128; one cold warmup and
three measured repetitions, RAM4GiB. Default DS4 checkpoints deliberately trim
or retain intermediate frontiers: expect6144 and122880 reused physical tokens,
not full prompt reuse. Record the remaining prefill, capture and latency cost.
Require all output IDs to match the same-executable legacy control. This is a
policy comparison, not independent model quality or DS4 binary interoperability.

SSD state producer at context131072 and restarted reader at262144 use one8192
checkpoint; reader requires three exact full-logit/token pairs (greedy, seeded,
independent clone). Core SSD producer/reader additionally exercise nativev3
policy metadata and automatic captures with RAMoff. Those receive separate8GiB
private quotas and4GiB staging/index caps; all heavyweight identity hashes stay
inside four leases. They never read another project's store or cache.

Each arm obtains fresh EX|NB leases, model stat/DSO/resource admission and owned
cleanup. Preserve errors and stop on any failure. No remote GPU build, model
conversion, DS4 mutation or device tuning. Owner-requested CPU/GPU thermal
observation retains exposed hardware bounds and the NVMe guard; independent
1Hz sensor samples persist on .155. No qualification of KVC, cross-quantization,
MTP, vision or high-ratio active KV compression is implied.
