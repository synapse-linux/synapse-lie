# SPDX-License-Identifier: MIT
# One declared campaign; per-arm supervisors own four leases and device children.
import datetime,fcntl,hashlib,json,os,pathlib,runpy,signal,subprocess,sys,tarfile,shutil
root=pathlib.Path(__file__).resolve().parent
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
ticks=lambda p:int(pathlib.Path(f'/proc/{p}/stat').read_text().rsplit(')',1)[1].split()[19])
m=json.loads((root/'suite-manifest.json').read_text())
state={'state':'CHECKING','started_at':now(),'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'runs':[]}
child=None;stopped=False

def save():
 (root/'state.tmp').write_text(json.dumps(state,indent=2));(root/'state.tmp').replace(root/'state.json')
def stop(sig,frame):
 global stopped
 stopped=True
 if child is not None and child.poll() is None:child.terminate()
for sig in [signal.SIGINT,signal.SIGTERM,signal.SIGHUP]:signal.signal(sig,stop)

def pack():
 final={'at':now(),'owned_processes':[],'locks':[]}
 for item in state['runs']:
  path=root/item['arm']/'results/result.json'
  if not path.exists():continue
  r=json.loads(path.read_text())
  for key,identity in [('supervisor_pid','supervisor_start_ticks'),('child_pid','child_start_ticks'),('server_pid','server_start_ticks')]:
   if r.get(key):
    try:live=ticks(r[key])
    except FileNotFoundError:live=None
    final['owned_processes'].append({'pid':r[key],'expected_start_ticks':r.get(identity),'live_start_ticks':live,'owned_identity_absent':live!=r.get(identity)})
 for name in m['lock_order']:
  fd=os.open(name,os.O_RDONLY|os.O_CLOEXEC);s=os.fstat(fd);live=os.stat(name)
  row={'path':name,'device':s.st_dev,'inode':s.st_ino,'unchanged':(s.st_dev,s.st_ino)==(live.st_dev,live.st_ino) and m['lock_identities'][name]==[s.st_dev,s.st_ino]}
  try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);row['free']=True
  except BlockingIOError:row['free']=False
  finally:os.close(fd)
  final['locks'].append(row)
 final['kfd']=[p.name for p in pathlib.Path('/sys/class/kfd/kfd/proc').iterdir() if p.name.isdigit()]
 (root/'postflight.json').write_text(json.dumps(final,indent=2))
 files=[p for p in root.iterdir() if p.is_file() and p.suffix in ('.json','.py','.log')]
 for item in state['runs']:
  arm=root/item['arm'];files += [p for p in arm.iterdir() if p.is_file() and p.suffix in ('.json','.log')]
  if (arm/'results').exists():files += [p for p in (arm/'results').rglob('*') if p.is_file()]
 (root/'collection-sha256.json').write_text(json.dumps({str(p.relative_to(root)):sha(p) for p in files},indent=2))
 with tarfile.open(root.parent/(root.name+'-evidence.tar'),'w') as t:
  for p in files+[root/'collection-sha256.json']:t.add(p,arcname=str(p.relative_to(root)))

save()
try:
 cpu=root/'cpu-receipt.json';receipt=json.loads(cpu.read_text());capsule=root/'source.tar'
 passed={x['path']:x['result']['exit_code'] for x in receipt['commands']}
 for name in ('ctest','ctest-off','ctest-key'):assert passed[receipt['successful_suites'][name]]==0,name
 assert receipt['source_sha256']==m['source_files']
 with tarfile.open(capsule) as t:
  for name,h in m['source_files'].items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h,name
 for name,h in m['files'].items():assert sha(root/name)==h,name
 handover=root.parent/'ds4-policy-handover.json';h=json.loads(handover.read_text())
 assert not h['kfd'] and all(x['free'] and x['identity']==x['expected'] for x in h['locks']) and all(x['unchanged'] for x in h['models'])
 (root/'handover.json').write_text(handover.read_text())
 report=runpy.run_path(str(root/'bench-report.py'))
 for arm in m['arms']:
  if stopped:raise RuntimeError('operator interrupted')
  run=root/arm['id'];run.mkdir(mode=0o700);kind=arm['kind'];http=kind=='http-ssd'
  names=['run-bench.py','smoke-model.py','bench-report.py',arm['input']]
  if http:names.append('bench-ssd-http.py')
  for name in names:shutil.copy2(root/name,run/name)
  binary_name='synapse-lie-server' if http else 'synapse-lie-bench'
  binary=run/binary_name;shutil.copy2(root/(arm['variant']+'-'+binary_name),binary);binary.chmod(0o700);names.append(binary_name)
  probe_argv=[str(binary),*(['--suite',kind] if not http else []),'--build-info']
  probe=subprocess.run(probe_argv,env=dict(os.environ,ROCR_VISIBLE_DEVICES='-1',HIP_VISIBLE_DEVICES='-1'),capture_output=True,text=True,timeout=30)
  (run/'build-info-probe.json').write_text(json.dumps({'argv':probe_argv,'exit_code':probe.returncode,'stdout':probe.stdout,'stderr':probe.stderr},indent=2))
  if probe.returncode:raise RuntimeError('build-info probe failure')
  manifest={k:m[k] for k in ('authorization','models','lock_order','lock_identities')}
  manifest.update(schema='synapse-lie.simplified-bench-run.v1',source_commit=m['variants'][arm['variant']]['commit'],source_state=m['variants'][arm['variant']],source_files=m['source_files'],prepared_at=now(),build_info=json.loads(probe.stdout),cpu_receipt_sha256=sha(cpu),source_capsule_sha256=sha(capsule),ram_cache_reserve_bytes=arm['ram_cache_reserve_bytes'],thermal_limit_c=98,thermal_observe_cpu_gpu=True,benchmark_args=arm['args'],files={n:sha(run/n) for n in names},protocol='protocol.md',timeout_seconds=3600,benchmark_input={'path':arm['input'],'bytes':(run/arm['input']).stat().st_size,'sha256':sha(run/arm['input'])})
  if arm.get('ssd_store'):
   manifest['ssd_store']=dict(arm['ssd_store'])
   if manifest['ssd_store']['mode']=='reuse':manifest['ssd_store']['source_result_sha256']=sha(root/manifest['ssd_store']['source_run']/'results/result.json')
  if http:manifest.update(http_model_id='qwen3.8-flash-next',api_port=8000,management_port=19880)
  (run/'manifest.json').write_text(json.dumps(manifest,indent=2))
  state.update(state='RUNNING',current_arm=arm['id']);save()
  log=(run/'supervisor.log').open('xb')
  child=subprocess.Popen([sys.executable,'-B',str(run/'run-bench.py'),str(run)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  item={'arm':arm['id'],'pid':child.pid,'start_ticks':ticks(child.pid),'started_at':now()};state['runs'].append(item);save()
  try:child.wait(timeout=3800)
  except subprocess.TimeoutExpired:
   child.terminate()
   try:child.wait(timeout=180)
   except subprocess.TimeoutExpired:state['cleanup_unresolved']=True;raise RuntimeError('cleanup unresolved; no next arm')
   raise RuntimeError('helper deadline')
  item.update(exit_code=child.returncode,finished_at=now());log.close();save()
  if child.returncode:raise RuntimeError('arm failed: '+arm['id'])
  if http:
   result=json.loads((run/'results/http.jsonl.summary.json').read_text());assert result['state']=='PASS'
   if manifest['ssd_store']['mode']=='reuse':assert result['overlap']['state']=='PASS' and result['slow_client']['state']=='PASS'
   item['sample_count']=len(result['samples'])
  else:
   data=report['read_result'](run/'results/measurements.jsonl')
   if kind=='core':
    p=data['input'] if 'input' in data else data['configurations'][0]
    n=data['configurations'][0]['prompt_tokens']
    cold=(min(n,30000)-32)//2048*2048
    periodic=n//10240*10240
    expected=n if arm['policy']=='legacy' else max(cold,periodic)
    selected=[j for j in data['jobs'] if not j['warmup']]
    if arm.get('ssd_store',{}).get('mode')=='create':expected=0
    assert all(j['cached_tokens']==expected and j['prefill_tokens']==n-expected for j in selected), (expected,[(j['cached_tokens'],j['prefill_tokens']) for j in selected])
    assert all(j['output_tokens']==128 for j in selected)
    if arm.get('ssd_store',{}).get('mode')=='reuse':assert all(j['ssd_cached_tokens']==expected for j in selected)
    if arm.get('reference_arm'):
     reference=report['read_result'](root/arm['reference_arm']/'results/measurements.jsonl')
     item['comparison']=report['compare'](data,reference,True);assert item['comparison'][0]['eligible']
   else:
    if arm.get('ssd_store',{}).get('mode')=='create':assert len(data['pairs'])==0
    else:
     assert len(data['pairs'])==3
     if arm.get('ssd_store'):
      prior=report['read_result'](root/arm['ssd_store']['source_run']/'results/measurements.jsonl')
      assert data['ssd']['stable_identity_sha256']==prior['ssd']['stable_identity_sha256']
  save()
 state.update(state='COMPLETED_PENDING_OFFLINE_REGRESSION_ANALYSIS',finished_at=now());save()
except BaseException as ex:
 state.update(state='FAILED',error=repr(ex),finished_at=now());save();print(json.dumps(state,indent=2),flush=True)
finally:
 if not state.get('cleanup_unresolved'):pack()
print(json.dumps(state,indent=2),flush=True)
if state['state']=='FAILED':raise SystemExit(1)
