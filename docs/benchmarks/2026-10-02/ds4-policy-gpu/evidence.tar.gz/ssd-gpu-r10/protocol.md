# DS4 shared policy continuation — R10

Same frozen f11ab7f / ds4-policy-linked-r2 binary and source capsule as R9.
Retain R9's 4GiB/128K pressure result: its GPU child completed successfully,
but the postprocessor assumed 122880 tokens reused and observed 28672 instead.
No source/runtime failure is hidden by this continuation. Validate all output
IDs independently offline against the completed legacy control.

Complete the four unlaunched raw-text and core SSD producer/restarted-reader
arms exactly as prepared in R9. Add matched legacy/DS4 131072-token C1 controls
with RAM budget8GiB, context262144, chunk2048, TG128, one cold and three warm
cohorts. The larger budget tests retention pressure, not a new model or codec.
Report different executed PP work separately; no inferred reactive speedup.

Fresh four EX|NB leases, model stat/DSO/resource admission and owned cleanup
per arm. Same CPU/GPU observation and NVMe guards. No device tuning, remote
build, model conversion, DS4 mutation or foreign process termination.
