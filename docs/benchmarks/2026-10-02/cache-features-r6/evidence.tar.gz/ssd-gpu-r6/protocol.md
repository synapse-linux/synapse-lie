# Numeric-byte lossless cache protocol — R6

Source8932c5f, same pinned numerical engine as R5, independent OFF/ON builds.
Core8K/C1 uses context262144 and4GiB RAM cap; core128K/C1 uses context133120
and8GiB RAM cap for source+compressed+codec/restore workspace. Compare only
matched ON/OFF configurations inside R6, never mix its128K numbers with R5's
capacity/budget. Active KV staysF16. TG128, one preserved cold warmup and
three measured warm cohorts. Require identical output tokens, exact cache/PP
accounting and an actual accepted compression in each ON arm. Report retained
versus expanded bytes and the capture/restore cost, without a fixed ratio claim.

128K SSD producer/restarted reader use the ON executable, context133120,
quota8GiB/staging8GiB plus80MiB explicit witness reserve. Require compressed
state and same stable identity. Reader checks every logit/token for greedy,
seeded and independent greedy clones; no lossy precision or active-KV change.

Every arm obtains fresh four-lease admission, model/binary/DSO checks and owned
cleanup. Owner thermal observation continues with hardware limits and NVMe85C;
independent1Hz observer saves records on .155. Stop on failed arm; preserve all
failures. No remote build/install/tuning/model writes or DS4 mutation.
