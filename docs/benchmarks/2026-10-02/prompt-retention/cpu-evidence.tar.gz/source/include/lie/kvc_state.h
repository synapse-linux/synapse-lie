/* SPDX-License-Identifier: MIT */
#ifndef LIE_KVC_STATE_H
#define LIE_KVC_STATE_H
#include "lie/kvc_qwen.h"
#ifdef __cplusplus
extern "C" {
#endif
/* Direct retained DS4 payload, separate from the older detached QF1 converter.
 * The provider supplies a trusted live domain and loaded model geometry.
 * No tensor conversion, allocation, device call or hidden identity inference. */
lie_status lie_kvc_qwen_state_plan(const lie_kvc_qwen_geometry *,const lie_kvc_qwen_frontier *,
                                   uint64_t domain,uint8_t model_id,uint8_t quant_bits,
                                   lie_state_layout *,lie_error *);
/* Called after the provider has copied every numerical component. Generates
 * framing, physical text positions and eight ngram slots from TOKENS. Bounds
 * and token validation precede all writes. The caller discards output on error. */
lie_status lie_kvc_qwen_state_finish(const lie_kvc_qwen_geometry *,const lie_state_layout *,
                                     uint32_t eos,void *,size_t,const lie_kvc_limits *,lie_error *);
/* Completed read/restore admission: checks exact descriptor, payload framing,
 * geometry, canonical text positions and EOS history before device mutation. */
lie_status lie_kvc_qwen_state_check(const lie_kvc_qwen_geometry *,const lie_state_layout *,
                                    uint32_t eos,lie_kvc_span,const lie_kvc_limits *,lie_error *);
#ifdef __cplusplus
}
#endif
#endif
