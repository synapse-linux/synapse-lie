# Benefit admission GPU regression — R7

Source 71a4599. Same matched 8K/128K contexts, budgets and TG/repetition settings
as R6. Independent ON/OFF executables, same unchanged numerical engine. Require
exact output tokens, accounting and raw fallback on these known low-benefit
Qwen prefixes. Measure cold capture, warm restore/TTFT/TG and retained memory;
no high-ratio or zero-overhead claim. One cold observation, three warm repeats.
Fresh four leases, model/DSO checks and owned cleanup every arm. CPU/GPU thermal
observation and NVMe guard unchanged; independent 1 Hz observer on .155.
