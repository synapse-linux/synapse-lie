# SPDX-License-Identifier: MIT
"""One-shot sequential campaign; child failure stops, never retries."""
import datetime, fcntl, json, os, pathlib, signal, subprocess, sys
root = pathlib.Path(__file__).resolve().parent
plan = json.loads((root / 'PLAN.json').read_text())
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
ticks = lambda pid: int(pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()[19])
report = dict(state='RUNNING', started_at=now(), controller_pid=os.getpid(),
              controller_start_ticks=ticks(os.getpid()), arms=[])
child = None
interrupted = False
def save():
    p = root / 'driver-result.tmp'
    p.write_text(json.dumps(report, indent=2) + '\n')
    p.replace(root / 'driver-result.json')
def register(event):
    fd = os.open('/tmp/synapse-lie-ds4-coordination/runs.jsonl', os.O_WRONLY | os.O_APPEND | os.O_NOFOLLOW)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        data = (json.dumps(dict(owner='synapse-lie', event=event, at=now(),
                 campaign=plan['campaign'], pid=os.getpid(), start_ticks=report['controller_start_ticks'],
                 state=report['state'], source_commit=plan['source_checkpoint'])) + '\n').encode()
        assert os.write(fd, data) == len(data)
        os.fsync(fd)
    finally:
        os.close(fd)
def stop(sig, frame):
    global interrupted
    interrupted = True
    report['signal'] = sig
    if child is not None and child.poll() is None:
        child.send_signal(signal.SIGTERM)
for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
    signal.signal(sig, stop)
assert plan['state'] == 'FRESH_HANDOVER_ADMITTED_NOT_YET_RUN'
assert not (root / 'driver-result.json').exists()
save()
register('campaign_start')
code = 0
try:
    for name in plan['arms']:
        if interrupted:
            code = 1
            break
        arm = root / name
        with (arm / 'supervisor.log').open('xb') as log:
            child = subprocess.Popen([sys.executable, str(root / 'capsule/supervise.py'), str(arm)],
                                     stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            row = dict(arm=name, started_at=now(), supervisor_pid=child.pid,
                       supervisor_start_ticks=ticks(child.pid))
            report['arms'].append(row)
            save()
            row.update(exit_code=child.wait(), finished_at=now())
            print(json.dumps(row), flush=True)
        code = row['exit_code']
        save()
        child = None
        if code or interrupted:
            code = code or 1
            break
except BaseException as exc:
    report['error'] = repr(exc)
    code = 1
    if child is not None:
        if child.poll() is None:
            child.send_signal(signal.SIGTERM)
        child.wait()
finally:
    report.update(state='COMPLETE' if code == 0 and len(report['arms']) == len(plan['arms']) else 'FAILED',
                  exit_code=code, finished_at=now())
    save()
    register('campaign_end')
sys.exit(code)
