# SPDX-License-Identifier: MIT
"""Original-weight core evidence checks backed by the native C reporter."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

def validate(output, manifest, capsule, *, synthetic_fixture=False):
    output, capsule = Path(output), Path(capsule)
    raw = output / 'measurements.jsonl'
    rows = [json.loads(line) for line in raw.read_text().splitlines()]
    identity = rows[0]
    if synthetic_fixture:
        assert identity['synthetic'] is True
        assert identity['ownership'] == 'synthetic-test-fixture'
    else:
        assert identity['synthetic'] is False
        assert identity['ownership'] == 'delegated'
        assert identity['source_pin'] == 'f783fedb9bea2ec7de941f6da4e02f4a4596b29e'
        assert identity['dense_sampling'] == ('lie-c17-dense' if manifest['variant'] == 'on' else 'gufo')
    assert identity['schema'] == 'synapse-lie.core-bench.v1' and identity['suite'] == 'core'
    assert identity['mode'] == 'ar' and identity['cache_policy'] == 'off'
    assert identity['prefix_cache_bytes'] == identity['ssd_quota_bytes'] == identity['ssd_staging_bytes'] == 0
    assert identity['generation'] == manifest['generation']
    for field, value in manifest['core_settings'].items():
        assert identity[field] == value, (field, identity[field], value)
    assert rows[-1]['event'] == 'complete' and rows[-1]['exit_code'] == 0
    input_row = next(r for r in rows if r['event'] == 'input')
    assert input_row['prompt_tokens'] == manifest['physical_input_tokens']
    assert input_row['physical_ids_sha256'] == manifest['physical_input_sha256']
    jobs = [r for r in rows if r['event'] == 'job']
    assert len(jobs) == identity['warmups'] + identity['repetitions']
    for r in jobs:
        assert r['prompt_tokens'] == r['prefill_tokens'] == input_row['prompt_tokens']
        assert r['cached_tokens'] == r['ssd_cached_tokens'] == 0
        assert r['mtp_drafted_tokens'] == r['mtp_accepted_tokens'] == 0
        assert r['output_tokens'] == len(r['output_ids']) == identity['output_limit']
        assert r['finish'] == 'length'
    env = dict(os.environ, LC_ALL='C', ROCR_VISIBLE_DEVICES='-1', HIP_VISIBLE_DEVICES='-1', CUDA_VISIBLE_DEVICES='-1')
    argv = [str(capsule / 'synapse-lie-bench-report'), '--suite', 'report',
            str(raw), '--output', str(output / 'native-validation')]
    command = subprocess.run(argv, text=True, capture_output=True, env=env, timeout=30)
    record = {'argv': argv, 'exit_code': command.returncode, 'stdout': command.stdout, 'stderr': command.stderr,
              'input_sha256': hashlib.sha256(raw.read_bytes()).hexdigest(),
              'scope': 'SYNTHETIC_NOT_INFERENCE' if synthetic_fixture else 'Original weights, same-provider functional/performance evidence'}
    (output / 'native-validation-command.json').write_text(json.dumps(record, indent=2) + '\n')
    assert command.returncode == 0, command.stderr
    summary_path = output / 'native-validation/summary.json'
    summary = json.loads(summary_path.read_text())
    assert summary['primary']['configurations'][0]['full_output_budget']
    return {'native_summary_sha256': hashlib.sha256(summary_path.read_bytes()).hexdigest(),
            'jobs': len(jobs), 'measured_jobs': identity['repetitions'], 'output_budget': identity['output_limit'],
            'physical_input_tokens': input_row['prompt_tokens'], 'generation': identity['generation'],
            'synthetic': identity['synthetic']}
