# SPDX-License-Identifier: MIT
"""Read-only optional sysfs telemetry; missing values are explicit."""
import pathlib,time
def read(p):
 try:return p.read_text().strip()
 except OSError as e:return {"unavailable":type(e).__name__,"errno":e.errno}
def snapshot():
 begin=time.monotonic_ns();wall=time.time_ns();device=pathlib.Path('/sys/class/drm/card1/device')
 r={"begin_monotonic_ns":begin,"wall_time_ns":wall,"device_path":str(device),"gpu":{},"cpu_frequency_khz":{},"loadavg":read(pathlib.Path('/proc/loadavg'))}
 for name in ['pp_dpm_sclk','pp_dpm_mclk','gpu_busy_percent','mem_info_gtt_used','mem_info_vram_used','power_dpm_force_performance_level']:
  r['gpu'][name]=read(device/name)
 r['amdgpu_hwmon']={}
 for folder in pathlib.Path('/sys/class/hwmon').glob('hwmon*'):
  if read(folder/'name')!='amdgpu':continue
  for p in folder.iterdir():
   if (p.name.startswith('freq') and p.name.endswith('_input')) or (p.name.startswith('power') and p.name.endswith(('_average','_input','_label'))):r['amdgpu_hwmon'][str(p)]=read(p)
 for p in pathlib.Path('/sys/devices/system/cpu/cpufreq').glob('policy*/scaling_cur_freq'):r['cpu_frequency_khz'][p.parent.name]=read(p)
 r['end_monotonic_ns']=time.monotonic_ns();return r
