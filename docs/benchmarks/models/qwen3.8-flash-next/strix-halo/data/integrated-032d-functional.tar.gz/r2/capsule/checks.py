# SPDX-License-Identifier: MIT
"""Original-weight functional checks. Supervisor owns admission and server."""
import base64,http.client,json,math,pathlib,threading,time
def run(m,out,live):
    model='qwen3.8-flash-next';events=out/'http.jsonl'
    def record(obj):
        with events.open('a') as f:f.write(json.dumps(obj,ensure_ascii=False)+'\n')
    def request(path,body=None,method=None,port=8000,status=200):
        assert live(),'owned server retired'
        c=http.client.HTTPConnection('127.0.0.1',port,timeout=180);start=time.monotonic()
        try:
            c.request(method or ('GET' if body is None else 'POST'),path,None if body is None else json.dumps(body).encode(),{} if body is None else {'Content-Type':'application/json'})
            r=c.getresponse();raw=r.read(8*1024**2+1);assert len(raw)<=8*1024**2
            text=raw.decode();record(dict(event='http',path=path,method=method,status=r.status,request=body,response=text,elapsed_seconds=time.monotonic()-start))
            assert r.status==status,(path,r.status,text[:2000])
            return text if 'text/event-stream' in r.getheader('Content-Type','') else json.loads(text)
        finally:c.close()
    def check(name,condition):
        record(dict(event='assertion',name=name,pass_=bool(condition)));assert condition,name
    deadline=time.monotonic()+300
    while True:
        assert live()
        try:
            if request('/actuator/health/readiness',port=19880)['status']=='UP':break
        except (OSError,AssertionError):
            try: backend=request('/actuator/llm',port=19880,status=200)['backend']
            except OSError: backend={}
            assert backend.get('state')!='FAILED',backend.get('error',backend)
            assert time.monotonic()<deadline,'readiness deadline';time.sleep(.25)
    state=request('/actuator/llm',port=19880)
    check('C17 dense sampler identity',state['backend']['dense_sampling']==m['build_info']['dense_sampling'])
    check('real model list',request('/v1/models')['data'][0]['id']==model)
    check('model detail',request('/v1/models/'+model)['object']=='model')
    def chat(text='What is 2 + 2? Reply with only the digit.',**extra):
        q=dict(model=model,messages=[dict(role='user',content=text)],temperature=0,max_tokens=16)
        q.update(extra);return request('/v1/chat/completions',q)
    def content(j):return j['choices'][0]['message']['content']
    def response_text(j):return ''.join(p.get('text','') for x in j.get('output',[]) for p in x.get('content',[]))
    def frames(raw,responses=False):
        result=[];done=0
        for frame in raw.strip().split('\n\n'):
            lines=frame.splitlines();data=[x[6:] for x in lines if x.startswith('data: ')]
            assert len(data)==1
            if data[0]=='[DONE]':done+=1;continue
            item=json.loads(data[0]);assert 'error' not in item;result.append(item)
        assert done==(0 if responses else 1)
        if responses:assert all(x['sequence_number']==i for i,x in enumerate(result))
        return result
    j=chat();check('original-weight arithmetic',content(j).strip()=='4')
    check('physical input/output usage',j['usage']['total_tokens']==j['usage']['prompt_tokens']+j['usage']['completion_tokens'])
    raw=chat(stream=True,stream_options={'include_usage':True});f=frames(raw)
    check('AR JSON/SSE equivalence',''.join(x['choices'][0]['delta'].get('content','') for x in f if x.get('choices'))==content(j))
    if m['http_checks']=='openai':
        q=dict(temperature=.8,top_p=.9,seed=123,max_tokens=24,frequency_penalty=.2,presence_penalty=.1)
        a=chat('Write a short sentence about the sea.',**q);b=chat('Write a short sentence about the sea.',**q)
        check('seeded filtered sampling repeatability',content(a)==content(b) and a['usage']['completion_tokens']==b['usage']['completion_tokens'])
        biased=chat(logit_bias={'32':100},max_tokens=4,logprobs=True,top_logprobs=3)
        check('dense token bias',content(biased)=='AAAA')
        logs=biased['choices'][0]['logprobs']['content']
        check('finite confirmed logprobs',len(logs)==4 and all(math.isfinite(x['logprob']) and len(x['top_logprobs'])==3 for x in logs))
        stopped=chat(logit_bias={'32':100},stop='AA',max_tokens=8,logprobs=True)
        check('stop token suppression',content(stopped)=='' and stopped['choices'][0]['finish_reason']=='stop' and (stopped['choices'][0]['logprobs'] is None or not stopped['choices'][0]['logprobs']['content']))
        multi=chat(n=3,store=True,metadata={'task':'gpu-f0'})
        check('three actual choices',len(multi['choices'])==3 and all(x['message']['content'].strip()=='4' for x in multi['choices']))
        cid=multi['id'];stored=request('/v1/chat/completions/'+cid)
        check('stored completion retrieval',stored['choices']==multi['choices'])
        updated=request('/v1/chat/completions/'+cid,{'metadata':{'task':'gpu-updated'}})
        check('completion metadata mutation',updated['metadata']=={'task':'gpu-updated'})
        listed=request('/v1/chat/completions?metadata%5Btask%5D=gpu-updated&limit=1')
        check('stored completion filter',listed['data'][0]['id']==cid)
        sf=frames(chat(n=3,stream=True,stream_options={'include_usage':True}))
        check('multi-choice SSE terminals',sum(x['choices'][0]['finish_reason'] is not None for x in sf if x.get('choices'))==3 and len([x for x in sf if not x.get('choices')])==1)
        schema={'type':'object','properties':{'answer':{'type':'string','enum':['4']}},'required':['answer'],'additionalProperties':False}
        structured=chat('Return the answer of 2+2 as the requested JSON.',max_tokens=128,response_format={'type':'json_schema','json_schema':{'name':'answer','strict':True,'schema':schema}})
        check('constrained JSON schema',json.loads(content(structured))=={'answer':'4'})
        tool={'type':'function','function':{'name':'get_answer','description':'Report the answer to 2+2.','strict':True,'parameters':schema}}
        tc=chat('Call get_answer with answer 4.',tools=[tool],tool_choice={'type':'function','function':{'name':'get_answer'}},max_tokens=256)
        call=tc['choices'][0]['message']['tool_calls'][0]
        check('strict complete function arguments',call['function']['name']=='get_answer' and json.loads(call['function']['arguments'])=={'answer':'4'})
        history=[{'role':'user','content':'Call get_answer with answer 4.'},tc['choices'][0]['message'],{'role':'tool','tool_call_id':call['id'],'content':'The verified answer is 4.'},{'role':'user','content':'What is the verified answer? Reply with only the digit.'}]
        follow=request('/v1/chat/completions',dict(model=model,messages=history,tools=[tool],temperature=0,max_tokens=16))
        check('correlated tool result continuation',content(follow).strip()=='4')
        base=dict(model=model,input='What is 2+2? Reply with only the digit.',temperature=0,max_output_tokens=16)
        resp=request('/v1/responses',base);rid=resp['id'];check('stored Responses original inference',response_text(resp).strip()=='4')
        check('Responses retrieval',request('/v1/responses/'+rid)['output']==resp['output'])
        replay=request('/v1/responses/'+rid+'?stream=true');rf=frames(replay,True);check('Responses immutable replay',rf[-1]['type']=='response.completed')
        resumed=request('/v1/responses/'+rid+'?stream=true&starting_after=1')
        seq=[json.loads(line[6:])['sequence_number'] for line in resumed.splitlines() if line.startswith('data: ')]
        check('Responses cursor',seq==list(range(2,rf[-1]['sequence_number']+1)))
        live_frames=frames(request('/v1/responses',dict(base,stream=True,store=False)),True)
        check('Responses live semantic text',''.join(x.get('delta','') for x in live_frames if x['type']=='response.output_text.delta').strip()=='4')
        next_resp=request('/v1/responses',dict(base,previous_response_id=rid,input='Add 1 to that answer. Reply with only the digit.'))
        check('retained conversation continuation',response_text(next_resp).strip()=='5')
        bg=request('/v1/responses',dict(base,background=True,max_output_tokens=128,input='List the integers from 1 to 10000, separated by spaces. Continue immediately with no introduction.'))
        bid=bg['id'];cancel=request('/v1/responses/'+bid+'/cancel',{})
        check('background cancellation',cancel['status']=='cancelled')
        check('idempotent cancellation',request('/v1/responses/'+bid+'/cancel',{})['status']=='cancelled')
        auto=dict(base,input=[{'role':'user','content':'x '*6000},{'role':'assistant','content':'old material acknowledged'},{'role':'user','content':'What is 2+2? Reply with only the digit.'}],store=False)
        request('/v1/responses',auto,status=400)
        check('automatic oldest-turn truncation',response_text(request('/v1/responses',dict(auto,truncation='auto'))).strip()=='4')
        check('completion delete',request('/v1/chat/completions/'+cid,method='DELETE')['deleted'])
        request('/v1/chat/completions/'+cid,status=404)
        check('response delete',request('/v1/responses/'+rid,method='DELETE')['deleted']);request('/v1/responses/'+rid,status=404)
    elif m['http_checks'] in ('mtp','combined'):
        mtp=chat('List the integers from 1 to 10000, separated by spaces. Start with 1 and do not add an introduction.',max_tokens=128)
        record(dict(event='mtp_witness',body=mtp))
        after=request('/actuator/llm',port=19880);record(dict(event='mtp_state',body=after))
        check('MTP complete output',mtp['usage']['completion_tokens']==128 and mtp['choices'][0]['finish_reason']=='length')
        check('MTP has drafted and accepted tokens',after['scheduler']['executor']['mtp_drafted_tokens']>0 and after['scheduler']['executor']['mtp_accepted_tokens']>0)
        # Explicit stop/bias/logprob requests intentionally use target AR.
        biased=chat(logit_bias={'32':100},max_tokens=4,logprobs=True,top_logprobs=2)
        check('MTP provider controlled AR fallback',content(biased)=='AAAA' and len(biased['choices'][0]['logprobs']['content'])==4)
    if m['http_checks']=='combined':
        img='data:image/png;base64,'+base64.b64encode((pathlib.Path(__file__).parent/'red.png').read_bytes()).decode()
        messages=[{'role':'user','content':[{'type':'image_url','image_url':{'url':img}},{'type':'text','text':'What color is the image? Reply with only the color name.'}]}]
        q=dict(model=model,messages=messages,temperature=0,max_tokens=32)
        a=request('/v1/chat/completions',q);b=request('/v1/chat/completions',q)
        check('vision color semantics','red' in content(a).lower())
        check('vision repeated output/usage',content(a)==content(b) and a['usage']['prompt_tokens']==b['usage']['prompt_tokens'])
        before=request('/actuator/llm',port=19880);record(dict(event='vision_cache_state',body=before))
        check('vision valid usage',a['usage']['prompt_tokens']>0 and a['usage']['completion_tokens']>0)
        reference='Reference material.\n'+('The quick brown fox jumps over the lazy dog.\n'*240)+'\nWhat color is the image? Reply with only the color name.'
        def color(name):
            data='data:image/png;base64,'+base64.b64encode((pathlib.Path(__file__).parent/(name+'.png')).read_bytes()).decode()
            parts=[{'type':'image_url','image_url':{'url':data}},{'type':'text','text':reference}]
            return request('/v1/chat/completions',dict(model=model,messages=[{'role':'user','content':parts}],temperature=0,max_tokens=32))
        red1=color('red');red2=color('red');blue1=color('blue');blue2=color('blue');red3=color('red')
        check('vision scoped cache red/blue semantics',all('red' in content(x).lower() for x in [red1,red2,red3]) and all('blue' in content(x).lower() for x in [blue1,blue2]))
        check('different images equal physical prompt lengths',red1['usage']['prompt_tokens']==blue1['usage']['prompt_tokens'])
        def cached(x):
            usage=x['usage'];tokens=usage.get('prompt_tokens_details',{}).get('cached_tokens',0)
            assert type(tokens) is int and 0<=tokens<=usage['prompt_tokens']
            timing=x['lie_timings'];assert timing['cached_tokens']==tokens
            assert timing['prefill_tokens']+tokens==usage['prompt_tokens']
            return tokens
        check('different image refuses shared token cache',cached(blue1)==0)
        check('same image RAM checkpoint reuse',cached(red2)>0 and cached(blue2)>0 and cached(red3)>0)
        check('image restore output exact',content(red1)==content(red2)==content(red3) and content(blue1)==content(blue2))

    # A cache-enabled model needs a long enough aligned prefix, and output
    # observations must distinguish restore from actual prefill work.
    if m.get('cache_check'):
        prompt='Reference material.\n'+('The quick brown fox jumps over the lazy dog.\n'*240)+'\nWhat is 2+2? Reply with only the digit.'
        a=chat(prompt);b=chat(prompt)
        check('RAM prefix exact output',content(a)==content(b))
        cached=b['usage']['prompt_tokens_details']['cached_tokens']
        check('RAM reuse actual accounting',cached>0 and b['lie_timings']['prefill_tokens']+cached==b['usage']['prompt_tokens'])
    final=request('/actuator/llm',port=19880);record(dict(event='final_state',body=final))
    check('healthy device owner',final['ready'] and final['scheduler']['failed']==(1 if m['http_checks']=='openai' else 0) and final['scheduler']['active']==0)
    record(dict(event='complete',exit_code=0,scope='original weights; same delegated model provider; functional checks, no independent numerical oracle'))
