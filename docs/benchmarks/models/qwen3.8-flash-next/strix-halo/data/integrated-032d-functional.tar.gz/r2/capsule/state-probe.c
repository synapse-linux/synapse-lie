/* SPDX-License-Identifier: MIT */
/* Private original-weight integrated state probe; admission is external. */
#include "lie/executor.h"
#include "lie/mtp.h"
#include "lie/vision.h"
#include "lie/state.h"
#include "lie/store.h"
#include <poll.h>
#include <time.h>
#include <json-c/json.h>
#include <openssl/evp.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CALLS 24u
#define CONTEXT 4096u
static lie_error error;
static FILE *output;
static void require(int yes,const char *why){if(!yes){fprintf(stderr,"%s: %s\n",why,error.message);exit(1);}}
static void text(json_object *j,const char *k,const char *v){json_object_object_add(j,k,json_object_new_string(v));}
static void number(json_object *j,const char *k,uint64_t v){json_object_object_add(j,k,json_object_new_uint64(v));}
static json_object *event(const char *s){json_object *j=json_object_new_object();text(j,"event",s);return j;}
static void emit(json_object *j){require(fprintf(output,"%s\n",json_object_to_json_string_ext(j,JSON_C_TO_STRING_PLAIN))>0&&!fflush(output),"output");json_object_put(j);}
static void digest(const void *p,size_t n,char hash[65]){unsigned char bytes[32];unsigned used=0;require(EVP_Digest(p,n,bytes,&used,EVP_sha256(),NULL)&&used==32,"SHA256");for(unsigned i=0;i<32;++i)snprintf(hash+2*i,3,"%02x",bytes[i]);}
static void frontier(lie_sequence *s,float *row,size_t vocab){size_t n=0;require(lie_sequence_logits(s,row,vocab,&n,&error)==LIE_OK&&n==vocab,"complete logits");for(size_t i=0;i<n;++i)require(isfinite(row[i]),"finite logits");}
static lie_sequence *prepare(lie_model *model,const lie_vision_prompt *image,const int32_t *tokens,size_t n,const lie_generation_options *controls){
 lie_sequence *s=NULL;require(lie_sequence_create(model,&s,&error)==LIE_OK,"sequence create");
 require(lie_sequence_configure(s,controls,&error)==LIE_OK,"sampling configure");
 if(image)require(lie_sequence_attach_vision(s,image,&error)==LIE_OK,"image attach");
 for(size_t at=0;at<n;){at+=n-at>2048?2048:n-at;require(lie_sequence_prefill(s,tokens,at,&error)==LIE_OK,"chunked prefill");}
 return s;
}
static void await_store(lie_store *store,lie_store_result *result){
 time_t begin=time(NULL);
 while(!lie_store_take(store,result)){
  require(time(NULL)-begin<300,"SSD completed operation deadline");
  struct pollfd fd={lie_store_fd(store),POLLIN,0};
  require(poll(&fd,1,100)>=0,"SSD notification");
 }
}
int main(int argc,char **argv){
 if(argc==2&&!strcmp(argv[1],"--build-info")){
  printf("{\"ownership\":\"%s\",\"dense_sampling\":\"%s\",\"synthetic\":false,\"scope\":\"integrated-state-probe\"}\n",lie_backend_ownership(),lie_backend_dense_sampling());return 0;
 }
 require(argc>=5&&(!strcmp(argv[4],"mtp")||!strcmp(argv[4],"combined")),"probe mode");
 bool vision=!strcmp(argv[4],"combined");int ordinary=vision?7:5;
 require(argc==ordinary||argc==ordinary+2,"Usage: state-probe MODEL MTP OUTPUT mtp|combined [PROJECTOR IMAGE] [write|read PRIVATE-DIR]");
 bool disk=argc==ordinary+2,read_disk=disk&&!strcmp(argv[ordinary],"read");
 require(!disk||read_disk||!strcmp(argv[ordinary],"write"),"SSD mode");
 output=fopen(argv[3],"wx");require(output!=NULL,"new output");
 lie_model_options options={LIE_EXECUTOR_ABI,sizeof(options),CONTEXT,2048};lie_model *model=NULL;
 require((vision?lie_backend_open_mtp_vision(argv[1],&options,1,argv[2],3,argv[5],&model,&error):lie_backend_open_mtp(argv[1],&options,1,argv[2],3,&model,&error))==LIE_OK,"admit model");
 lie_model_info info={0};require(lie_model_get_info(model,&info,&error)==LIE_OK,"model info");
 size_t vocab=info.vocab_tokens;require(vocab>0&&vocab<=1048576,"vocab bound");
 int32_t tokens[CONTEXT];size_t n=0;lie_vision_prompt *image=NULL;
 const char *prompt="List the integers from 1 to 10000, separated by spaces. Start with 1 and continue immediately without an introduction.";
 lie_chat_message message={LIE_CHAT_USER,prompt,strlen(prompt)};lie_chat_template chat={.messages=&message,.count=1};unsigned char *pixels=NULL;
 if(vision){
  FILE *f=fopen(argv[6],"rb");require(f!=NULL,"image input");require(!fseek(f,0,SEEK_END),"image seek");long count=ftell(f);require(count>0&&count<8*1024*1024,"image bound");rewind(f);pixels=malloc((size_t)count);require(pixels&&fread(pixels,1,(size_t)count,f)==(size_t)count,"read image");fclose(f);
  lie_image_input input={pixels,(size_t)count,LIE_IMAGE_PNG,0,0};require(lie_model_prepare_vision(model,&chat,&input,1,tokens,CONTEXT,&n,&image,&error)==LIE_OK,"prepare physical image prompt");free(pixels);
 }else require(lie_model_chat_tokens_ex(model,&chat,tokens,CONTEXT,&n,&error)==LIE_OK,"chat tokens");
 require(n>0&&n+CALLS*4<CONTEXT,"input/output bound");
 json_object *j=event("identity");text(j,"scope","same-provider full logits and confirmed MTP burst witnesses; not independent oracle");text(j,"source_checkpoint","032d847");text(j,"dense_sampling",lie_backend_dense_sampling());number(j,"vision",vision);number(j,"prompt_tokens",n);number(j,"vocab",vocab);emit(j);
 lie_store *store=NULL;
 if(disk){
  lie_state_identity id;uint64_t domain=0;
  require(lie_model_state_identity(model,&id,&domain,&error)==LIE_OK,"full bound model identity under GPU lease");
  lie_store_options store_options={argv[ordinary+1],UINT64_C(4)*1024*1024*1024,UINT64_C(4)*1024*1024*1024};
  require(lie_store_open(&store_options,&id,domain,&store,&error)==LIE_OK,"private SSD store");
  lie_store_info si;lie_store_snapshot(store,&si);require(read_disk?si.entries==1:si.entries==0,"SSD process restart/empty writer");
  char id_hash[65];for(unsigned i=0;i<32;++i)snprintf(id_hash+2*i,3,"%02x",id.bytes[i]);
  j=event("ssd_identity");text(j,"mode",read_disk?"read":"write");text(j,"sha256",id_hash);number(j,"entries",si.entries);emit(j);
 }
 float *witness=malloc((CALLS+1)*vocab*sizeof(float)),*row=malloc(vocab*sizeof(float));require(witness&&row,"bounded host witnesses");
 lie_mtp_outcome expected[CALLS];memset(expected,0,sizeof(expected));
 for(unsigned sample=0;sample<2;++sample){
  lie_generation_options controls={.abi_version=LIE_GENERATION_ABI,.struct_bytes=sizeof(controls),.temperature=sample?.8:0,.top_p=.9,.seed=123,.frequency_penalty=sample?.2:0,.presence_penalty=sample?.1:0};
  lie_sequence *source=prepare(model,image,tokens,n,&controls);frontier(source,witness,vocab);
  lie_state_layout layout;uint64_t bytes=0;lie_state *state=NULL;
  require(lie_state_plan(source,&layout,&bytes,&error)==LIE_OK&&lie_state_capture(source,&layout,UINT64_C(4)*1024*1024*1024,&state,&error)==LIE_OK,"complete predictor/image checkpoint");
  lie_store_result result_disk={0};
  if(store){
   if(read_disk){
    unsigned char scope[32]={0};if(image)require(lie_vision_prompt_cache_scope(image,scope,&error)==LIE_OK,"prepared image scope");
    uint64_t ticket=lie_store_read_scoped_key(store,tokens,n,2048,0,image?scope:NULL);
    require(ticket!=0,"SSD read admission");await_store(store,&result_disk);
    require(result_disk.read&&result_disk.ticket==ticket&&result_disk.state,"SSD exact imported predictor/image state");
    lie_state_destroy(&state);state=result_disk.state;layout=*lie_state_description(state);
    require(layout.token_count==n&&!memcmp(lie_state_tokens(state),tokens,n*sizeof(*tokens)),"SSD token frontier exact");
    j=event("ssd_read");number(j,"sample",sample);number(j,"read_ns",result_disk.read_ns);number(j,"bytes",lie_state_bytes(state));emit(j);
   }else if(sample==0){
    char *decoded=NULL;size_t text_bytes=0,text_capacity=0;
    for(size_t i=0;i<n;++i){
     char piece[256];size_t used=0;
     require(lie_model_token_text(model,tokens[i],piece,sizeof(piece),&used,&error)==LIE_OK&&used<=sizeof(piece)&&used<=LIE_CACHE_TEXT_MAX-text_bytes,"DS4 stored prefix text");
     if(text_bytes+used+1>text_capacity){
      size_t need=text_bytes+used+1,capacity=text_capacity?text_capacity*2:4096;if(capacity<need)capacity=need;
      char *grown=realloc(decoded,capacity);require(grown!=NULL,"bounded DS4 text staging");decoded=grown;text_capacity=capacity;
     }
     memcpy(decoded+text_bytes,piece,used);text_bytes+=used;decoded[text_bytes]=0;
    }
    require(text_bytes>0,"nonempty DS4 text metadata");
    lie_cache_metadata metadata={.text=decoded,.text_bytes=text_bytes,.reason=LIE_CACHE_COLD};
    require(lie_store_write_ex(store,state,&metadata),"SSD write admission with DS4 text metadata");free(decoded);await_store(store,&result_disk);
    require(!result_disk.read,"SSD write completion");lie_store_result_release(store,&result_disk);
    lie_store_info si;lie_store_snapshot(store,&si);require(si.writes==1&&!si.errors&&si.entries==1,"SSD durable predictor/image checkpoint");
    j=event("ssd_write");number(j,"bytes",si.written_bytes);number(j,"write_ns",si.write_ns);emit(j);
   }
  }
  require(layout.format==LIE_STATE_KVC_AUX&&layout.model_data[3]>0,"predictor auxiliary state admitted");
  char hash[65];digest(witness,vocab*sizeof(float),hash);j=event("capture");number(j,"sample",sample);number(j,"retained_bytes",lie_state_bytes(state));number(j,"hidden_rows",layout.model_data[3]);number(j,"mtp_tokens",layout.model_data[1]);text(j,"logits_sha256",hash);emit(j);
  unsigned calls=0;uint64_t drafted=0,accepted=0;uint32_t position=(uint32_t)n;
  for(;calls<CALLS;++calls){
   uint32_t limit=calls%3?4:1;lie_sequence *rows[]={source};lie_mtp_outcome result={0};
   require(lie_sequences_decode_mtp(rows,&limit,1,&result,&error)==LIE_OK&&result.status==LIE_OK,"fresh MTP completed dispatch");
   require(result.emitted<=limit&&result.position==position+result.emitted,"confirmed burst/position");position=result.position;expected[calls]=result;drafted+=result.drafted;accepted+=result.accepted;
   frontier(source,witness+(calls+1)*vocab,vocab);digest(witness+(calls+1)*vocab,vocab*sizeof(float),hash);
   j=event("fresh");number(j,"sample",sample);number(j,"call",calls);number(j,"position",position);number(j,"emitted",result.emitted);number(j,"drafted",result.drafted);number(j,"accepted",result.accepted);text(j,"logits_sha256",hash);json_object *ids=json_object_new_array();for(unsigned t=0;t<result.emitted;++t)json_object_array_add(ids,json_object_new_int(result.tokens[t]));json_object_object_add(j,"tokens",ids);emit(j);
   if(result.stop){++calls;break;}
  }
  require(calls>0&&drafted>0,"actual speculative work");
  require(lie_sequence_close(&source,&error)==LIE_OK,"fresh sequence retirement");
  lie_sequence *restored=NULL;require(lie_sequence_create(model,&restored,&error)==LIE_OK&&lie_sequence_configure(restored,&controls,&error)==LIE_OK,"fresh destination sampler");
  if(image)require(lie_sequence_attach_vision(restored,image,&error)==LIE_OK,"destination image attach");
  require(lie_state_restore(restored,state,&error)==LIE_OK,"restore completed full state");frontier(restored,row,vocab);require(!memcmp(row,witness,vocab*sizeof(float)),"restored full prefill logits exact");
  for(unsigned call=0;call<calls;++call){
   uint32_t limit=call%3?4:1;lie_sequence *rows[]={restored};lie_mtp_outcome result={0};require(lie_sequences_decode_mtp(rows,&limit,1,&result,&error)==LIE_OK&&result.status==LIE_OK,"restored MTP dispatch");
   const lie_mtp_outcome *want=&expected[call];require(result.emitted==want->emitted&&result.stop==want->stop&&result.position==want->position&&result.drafted==want->drafted&&result.accepted==want->accepted&&!memcmp(result.tokens,want->tokens,result.emitted*sizeof(int32_t)),"restored confirmed burst/counters exact");
   frontier(restored,row,vocab);require(!memcmp(row,witness+(call+1)*vocab,vocab*sizeof(float)),"restored complete logits exact");j=event("restore");number(j,"sample",sample);number(j,"call",call);number(j,"exact",1);emit(j);
  }
  lie_sequence_cancel(restored);lie_sequence *rows[]={restored};uint32_t limit=4;lie_mtp_outcome cancelled={0};require(lie_sequences_decode_mtp(rows,&limit,1,&cancelled,&error)==LIE_OK&&cancelled.status==LIE_CANCELLED&&!cancelled.emitted,"cancelled proposal never emits");
  require(lie_sequence_close(&restored,&error)==LIE_OK,"restore retirement");if(result_disk.ticket){state=NULL;lie_store_result_release(store,&result_disk);}lie_state_destroy(&state);
  if(!sample){
   lie_sequence *ar=prepare(model,image,tokens,n,&controls);unsigned confirmed=0;
   for(unsigned call=0;call<calls;++call){
    for(unsigned t=0;t<expected[call].emitted;++t){
     lie_decode_result d={0};require(lie_sequence_decode(ar,&d,&error)==LIE_OK&&d.emitted==1&&!d.stop&&d.token==expected[call].tokens[t],"greedy MTP confirmed token equals fresh target AR");++confirmed;
    }
    frontier(ar,row,vocab);const float *want=witness+(call+1)*vocab;double error_square=0,reference_square=0,max_absolute=0;
    for(size_t v=0;v<vocab;++v){double d=(double)row[v]-want[v];error_square+=d*d;reference_square+=(double)want[v]*want[v];if(fabs(d)>max_absolute)max_absolute=fabs(d);}
    j=event("ar_greedy_frontier");number(j,"call",call);number(j,"confirmed",confirmed);number(j,"logits_bit_equal",!memcmp(row,want,vocab*sizeof(float)));
    json_object_object_add(j,"max_absolute",json_object_new_double(max_absolute));json_object_object_add(j,"relative_l2",json_object_new_double(reference_square?sqrt(error_square/reference_square):0));emit(j);
   }
   if(expected[calls-1].stop){lie_decode_result d={0};require(lie_sequence_decode(ar,&d,&error)==LIE_OK&&d.stop&&!d.emitted,"fresh target AR EOS equals MTP");}
   require(lie_sequence_close(&ar,&error)==LIE_OK,"target AR control retirement");
  }
  j=event("paired_complete");number(j,"sample",sample);number(j,"calls",calls);number(j,"drafted",drafted);number(j,"accepted",accepted);number(j,"rejected",drafted-accepted);emit(j);
 }
 lie_store_close(&store);
 if(image)require(lie_vision_prompt_close(&image,&error)==LIE_OK,"image retirement");
 require(lie_model_close(&model,&error)==LIE_OK,"model retirement");
 free(row);free(witness);j=event("complete");number(j,"exit_code",0);emit(j);require(!fclose(output),"output close");return 0;
}
