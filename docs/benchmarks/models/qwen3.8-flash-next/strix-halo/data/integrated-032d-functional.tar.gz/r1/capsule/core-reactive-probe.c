/* SPDX-License-Identifier: MIT */
/* Private original-weight demand/loan/cancellation qualification. */
#define _POSIX_C_SOURCE 200809L
#include "lie/core.h"
#include <json-c/json.h>
#include <openssl/evp.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static FILE *log_file;
static void require(int condition,const char *name) {
    if(!condition){fprintf(stderr,"Reactive probe failed: %s\n",name);exit(1);}
}
static double now(void){struct timespec t;require(!clock_gettime(CLOCK_MONOTONIC,&t),"clock");return t.tv_sec+t.tv_nsec*1e-9;}
static void pause_core(lie_core *core,int ms){struct pollfd fd={lie_core_fd(core),POLLIN,0};require(poll(&fd,1,ms)>=0,"core wait");lie_core_drain(core);}
static void record(const char *name,lie_core *core,lie_job *job){
    lie_core_info c;lie_core_snapshot(core,&c);lie_job_info j={0};if(job)lie_job_snapshot(job,&j);
    json_object *o=json_object_new_object();
    json_object_object_add(o,"event",json_object_new_string(name));
    json_object_object_add(o,"synthetic",json_object_new_boolean(lie_backend_is_synthetic()));
#define N(key,value) json_object_object_add(o,key,json_object_new_uint64(value))
    N("active",c.active);N("queued",c.queued);N("output_blocked",c.output_blocked);
    N("decode_batches",c.decode_batches);N("mtp_drafted",c.mtp_drafted);N("mtp_accepted",c.mtp_accepted);
    N("cancel_during_prefill",c.cancel_during_prefill);N("cancel_during_decode",c.cancel_during_decode);
    N("output_tokens",j.output_tokens);N("finish",j.finish);N("retired",j.retired);
#undef N
    require(fprintf(log_file,"%s\n",json_object_to_json_string_ext(o,JSON_C_TO_STRING_PLAIN))>0&&!fflush(log_file),"output");json_object_put(o);
}
static void state(lie_core *core,lie_core_state wanted){
    double deadline=now()+300;
    for(;;){lie_core_info c;lie_core_snapshot(core,&c);if(c.state==wanted)return;
        require(c.state!=LIE_FAILED&&now()<deadline,c.error[0]?c.error:"core state deadline");pause_core(core,10);}
}
static lie_flow_event next(lie_job *job){
    double deadline=now()+300;lie_flow *flow=lie_job_flow(job);
    for(;;){require(lie_flow_drain(flow,LIE_FLOW_OUTPUT_READY)==LIE_FLOW_OK,"output notification");
        lie_flow_event e;lie_flow_status status=lie_flow_next(flow,&e);if(status==LIE_FLOW_OK)return e;
        require(status==LIE_FLOW_WOULD_BLOCK&&now()<deadline,"output deadline/contract");
        struct pollfd fd={lie_flow_fd(flow,LIE_FLOW_OUTPUT_READY),POLLIN,0};require(poll(&fd,1,100)>=0,"output wait");}
}
static void consume(lie_job *job,lie_flow_end end,unsigned expected,unsigned offset){
    unsigned total=offset;
    for(;;){lie_flow_event e=next(job);if(e.end!=LIE_FLOW_ACTIVE){require(e.end==end,"terminal outcome");break;}
        require(e.token_offset==total&&e.tokens>0&&e.tokens<=4,"confirmed token order/burst bound");total+=(unsigned)e.tokens;
        require(lie_flow_release(lie_job_flow(job),e.ticket)==LIE_FLOW_OK,"retire output loan");
        if(end==LIE_FLOW_COMPLETE){lie_flow_status status=lie_flow_request(lie_job_flow(job),e.tokens);
            require(status==LIE_FLOW_OK||status==LIE_FLOW_CLOSED,"renew demand or drain completed producer");}}
    if(end==LIE_FLOW_COMPLETE)require(total==expected,"complete output budget");
}
static void retired(lie_core *core,lie_job *job){
    double deadline=now()+300;
    for(;;){lie_job_info j;lie_job_snapshot(job,&j);if(j.retired)return;require(now()<deadline,"job retirement");pause_core(core,10);}
}
static lie_job *submit(lie_core *core,const char *prompt){
    lie_core_request r;lie_core_request_init(&r);lie_chat_message m={LIE_CHAT_USER,prompt,strlen(prompt)};
    r.chat.messages=&m;r.chat.count=1;r.max_tokens=128;
    lie_job *job=NULL;require(lie_core_submit(core,&r,&job)==0,"job admission");return job;
}
static void hash(const void *data,size_t bytes,unsigned char digest[32]){
    unsigned n=0;require(EVP_Digest(data,bytes,digest,&n,EVP_sha256(),NULL)&&n==32,"loan digest");
}
int main(int argc,char **argv){
    if(argc==2&&!strcmp(argv[1],"--build-info")){
        printf("{\"ownership\":\"%s\",\"dense_sampling\":\"%s\",\"synthetic\":%s,\"scope\":\"core-reactive-probe\"}\n",lie_backend_ownership(),lie_backend_dense_sampling(),lie_backend_is_synthetic()?"true":"false");return 0;
    }
    int fixture=argc==5&&!strcmp(argv[4],"--fixture-loan-only");
    require(argc==4||fixture,"Usage: core-reactive-probe MODEL MTP NEW-JSONL [--fixture-loan-only]");
    require(!fixture||lie_backend_is_synthetic(),"fixture-only requires synthetic backend");log_file=fopen(argv[3],"wx");require(log_file!=NULL,"exclusive output");
    lie_core_options o;lie_core_options_init(&o);o.model_path=argv[1];o.mtp_model_path=argv[2];o.mtp_draft_tokens=3;
    o.context=16384;o.chunk=2048;o.max_active=2;o.prefix_cache_bytes=0;
    lie_core *core=lie_core_create(&o);require(core!=NULL,"core create");state(core,LIE_READY);
    const char *prompt="List the integers from 1 to 10000, separated by spaces. Start with 1 and do not add an introduction.";
    lie_job *a=submit(core,prompt),*b=submit(core,prompt);double deadline=now()+300;
    for(;;){lie_core_info c;lie_core_snapshot(core,&c);if(c.output_blocked==2)break;require(now()<deadline,"both rows demand-starved");pause_core(core,10);}
    lie_job_info before;lie_job_snapshot(a,&before);require(before.output_tokens==8,"initial confirmed-token demand ceiling");
    lie_flow_event loan=next(a);require(loan.end==LIE_FLOW_ACTIVE,"borrowed stalled output");unsigned char first[32],second[32];hash(loan.data,loan.bytes,first);
    consume(b,LIE_FLOW_COMPLETE,128,0);retired(core,b);
    lie_job_info after;lie_job_snapshot(a,&after);require(after.output_tokens==before.output_tokens,"stalled row never advances with peer demand");
    hash(loan.data,loan.bytes,second);require(!memcmp(first,second,32),"loan stable during peer progress");record("peer_complete_stalled_loan",core,a);
    lie_job_cancel(a);hash(loan.data,loan.bytes,second);require(!memcmp(first,second,32),"loan remains valid after cancellation");
    require(lie_flow_release(lie_job_flow(a),loan.ticket)==LIE_FLOW_OK,"cancelled loan retirement");consume(a,LIE_FLOW_CANCELLED,0,(unsigned)loan.tokens);retired(core,a);lie_job_release(a);lie_job_release(b);
    for(unsigned phase=0;!fixture&&phase<2;++phase){
        char *long_prompt=NULL;
        if(!phase){const char *line="The quick brown fox jumps over the lazy dog.\n";size_t size=strlen(line)*1000+strlen(prompt)+1;
            long_prompt=malloc(size);require(long_prompt!=NULL,"long input");long_prompt[0]=0;for(unsigned i=0;i<1000;++i)strcat(long_prompt,line);strcat(long_prompt,prompt);}
        a=submit(core,phase?prompt:long_prompt);free(long_prompt);deadline=now()+300;
        for(;;){lie_core_info c;lie_core_snapshot(core,&c);
            lie_flow_state flow;require(lie_flow_snapshot(lie_job_flow(a),&flow)==LIE_FLOW_OK,"dispatch observation");
            if(c.executor_phase==(phase?LIE_EXECUTOR_DECODE:LIE_EXECUTOR_PREFILL)&&
               (phase?flow.dispatch_started>0:c.prefill_started>c.prefill_returned))break;
            require(now()<deadline,"observed in-flight phase");pause_core(core,1);}
        lie_flow_state flow_before;require(lie_flow_snapshot(lie_job_flow(a),&flow_before)==LIE_FLOW_OK,"pre-cancel flow snapshot");
        lie_job_cancel(a);b=submit(core,prompt);consume(a,LIE_FLOW_CANCELLED,0,0);retired(core,a);
        lie_flow_state flow_after;require(lie_flow_snapshot(lie_job_flow(a),&flow_after)==LIE_FLOW_OK,"post-cancel flow snapshot");
        require(flow_after.published_tokens==flow_before.published_tokens,"in-flight cancellation publishes no new confirmed output");
        consume(b,LIE_FLOW_COMPLETE,128,0);retired(core,b);record(phase?"cancel_during_decode_peer_complete":"cancel_during_prefill_peer_complete",core,a);
        lie_job_release(a);lie_job_release(b);
    }
    lie_core_info final;lie_core_snapshot(core,&final);
    require((fixture||(final.cancel_during_prefill>0&&final.cancel_during_decode>0))&&final.failed_requests==0&&final.active==0&&final.queued==0&&final.mtp_drafted>0,"actual cancellation windows and healthy owner");
    record("qualified",core,NULL);lie_core_stop(core);state(core,LIE_STOPPED);lie_core_destroy(core);
    require(fputs("{\"event\":\"complete\",\"exit_code\":0}\n",log_file)>=0&&!fclose(log_file),"complete output");return 0;
}
