#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Private one-shot qualification supervisor; no installation/build/tuning."""
import datetime,fcntl,hashlib,json,os,pathlib,resource,runpy,signal,subprocess,sys,threading,time,traceback
P=pathlib.Path
base=P(__file__).resolve().parent
H=runpy.run_path(str(base/'smoke-model.py'))
T=runpy.run_path(str(base/'run-bench.py'))
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
    with P(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def atomic(p,v):
    q=p.with_suffix('.tmp');q.write_text(json.dumps(v,indent=2)+'\n');q.replace(p)
def main():
    arm=P(sys.argv[1]).resolve();m=json.loads((arm/'manifest.json').read_text());out=arm/'results';out.mkdir()
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    r=dict(state='PREFLIGHT',at=now(),manifest_sha256=sha(arm/'manifest.json'),supervisor_pid=os.getpid(),supervisor_start_ticks=H['ticks'](os.getpid()),commands=[],locks=[],ds4_ack_claimed=False,model_attempted=False)
    fds=[];child=None;registered=False;interrupted=False;worker=None;done=threading.Event();check_result={}
    def save():atomic(out/'result.json',r)
    def register(event):
        record=dict(owner='synapse-lie',event=event,at=now(),campaign=m['campaign'],run=str(arm),pid=os.getpid(),start_ticks=r['supervisor_start_ticks'],state=r['state'],source_commit=m['source_commit'],command=r.get('argv'),exit_code=r.get('child_exit_code'))
        fd=os.open('/tmp/synapse-lie-ds4-coordination/runs.jsonl',os.O_APPEND|os.O_WRONLY|os.O_NOFOLLOW)
        try:
            fcntl.flock(fd,fcntl.LOCK_EX);b=(json.dumps(record)+'\n').encode();assert os.write(fd,b)==len(b);os.fsync(fd)
        finally:os.close(fd)
    def stop(sig,frame):
        nonlocal interrupted
        interrupted=True;r['received_signal']=sig
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,stop)
    def temperatures():
        rows=T['temperatures'](ceiling=m['thermal_limit_c'],observe_cpu_gpu=m.get('thermal_observe_cpu_gpu',False));T['require_cool'](rows);return rows
    def command(argv,env):
        p=subprocess.run(argv,capture_output=True,text=True,env=env,timeout=30)
        r['commands'].append(dict(argv=argv,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr));save()
        if p.returncode:raise RuntimeError('preflight command failed')
        return p.stdout
    try:
        assert m['authorization']['gpu_test_authorized'] and m['authorization']['kind']=='operator-one-shot-window'
        for item in m['leases']:
            path=item['path'];fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
            try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BaseException:os.close(fd);raise
            fds.append(fd);s=os.fstat(fd);live=os.stat(path,follow_symlinks=False)
            assert [s.st_dev,s.st_ino]==[live.st_dev,live.st_ino]==[item['device'],item['inode']]
            r['locks'].append(item)
        r['models_before']=[H['model_stat'](x) for x in m['models']]
        r['preflight_memory']=H['memory']();r['preflight_kfd']=sorted(H['kfd']());dri,denied=H['dri_clients']()
        r['preflight_dri']=dict(pids=sorted(dri),permission_denied=denied)
        assert not r['preflight_kfd'],'foreign KFD client'
        assert r['preflight_memory']['MemAvailable']>sum(x['bytes'] for x in m['models'])+m['host_reserve_bytes'],'host memory admission, not fit proof'
        cooldown=[];cooldown_deadline=time.monotonic()+240
        while True:
            rows=temperatures();cpu=[x['value_c'] for x in rows if x['name'] in ('k10temp','coretemp')]
            assert cpu,'CPU sensor missing'
            cooldown.append(dict(at=now(),CPU_peak_C=max(cpu)))
            if max(cpu)<=60:break
            assert not interrupted and time.monotonic()<cooldown_deadline,'CPU cooldown deadline'
            time.sleep(1)
        r['CPU_cooldown']=cooldown;r['preflight_temperatures']=rows
        assert all(sha(base/name)==digest for name,digest in m['files'].items()),'capsule hash drift'
        env={k:v for k,v in os.environ.items() if not k.startswith(('GUFO_','DS4_','HIP_','ROCR_','HSA_','CUDA_')) and k not in ('LD_PRELOAD','LD_LIBRARY_PATH')}
        for key,name in [('XDG_CACHE_HOME','cache'),('TMPDIR','tmp')]:
            p=arm/name;p.mkdir(mode=0o700);env[key]=str(p)
        env.update(LC_ALL='C',LD_BIND_NOW='1',ROCR_VISIBLE_DEVICES='0',HIP_VISIBLE_DEVICES='0')
        masked=dict(env,ROCR_VISIBLE_DEVICES='-1',HIP_VISIBLE_DEVICES='-1')
        binary=base/m['binary'];info=json.loads(command([str(binary),*m.get('info_args',[]),'--build-info'],masked))
        assert info==m['build_info'] and info['ownership']=='delegated' and not info.get('synthetic',False),'build composition drift'
        command(['uname','-srmo'],masked);command(['readelf','-d',str(binary)],masked)
        linked=command(['ldd',str(binary)],masked);assert 'not found' not in linked
        r['dsos']={}
        for word in linked.split():
            if word.startswith('/') and P(word).is_file():
                p=P(word).resolve();assert str(p).startswith(('/usr/','/opt/rocm/'));r['dsos'][str(p)]=sha(p)
        paths=[p for p in P('/sys/devices/system/cpu/cpufreq').glob('policy*/*') if p.name in ('scaling_governor','energy_performance_preference')]
        paths += [P('/sys/class/drm/card1/device')/x for x in ('power_dpm_force_performance_level','pp_power_profile_mode')]
        r['power_settings']=T['read_power_settings'](paths)
        if m.get('http_checks'):H['probe_ports']((8000,19880))
        assert not interrupted and not H['kfd']();temperatures()
        argv=[str(binary),*[x.replace('@CAPSULE@',str(base)).replace('@ARM@',str(arm)).replace('@RESULTS@',str(out)) for x in m['argv']]]
        r.update(argv=argv,state='RUNNING',model_attempted=True);register('start');registered=True
        with (out/'stdout.log').open('xb') as log,(out/'stderr.log').open('xb') as err:
            child=subprocess.Popen(argv,cwd=arm,env=env,stdout=log,stderr=err,start_new_session=True)
        r.update(child_pid=child.pid,child_start_ticks=H['ticks'](child.pid));save()
        if m.get('http_checks'):
            def checks():
                try:
                    runpy.run_path(str(base/'checks.py'))['run'](m,out,lambda: child.poll() is None and not interrupted);check_result['exit_code']=0
                except BaseException as ex:check_result.update(exit_code=1,error=repr(ex),traceback=traceback.format_exc())
                finally:done.set()
            worker=threading.Thread(target=checks,name='private-gpu-checks');worker.start()
        deadline=time.monotonic()+m['deadline_seconds']
        with (out/'telemetry.jsonl').open('x') as log:
            while child.poll() is None:
                kfd=H['kfd']();active,denied=H['dri_clients']();foreign=(kfd-{child.pid})|(active-dri-{child.pid})
                rows=T['temperatures'](ceiling=m['thermal_limit_c'],observe_cpu_gpu=m.get('thermal_observe_cpu_gpu',False))
                row=dict(at=now(),memory=H['memory'](),gpu=H['gpu'](),kfd=sorted(kfd),dri=sorted(active),permission_denied=denied,temperatures=rows,process=H['process_status'](child.pid))
                row['fans']={str(p):p.read_text().strip() for p in P('/sys/class/hwmon').glob('hwmon*/fan*_input')}
                log.write(json.dumps(row)+'\n');log.flush()
                if any(x['limit_c'] is not None and x['value_c']>=x['limit_c'] for x in rows):r['thermal_stop']=True;raise RuntimeError('thermal operating/hardware ceiling')
                if foreign:r['foreign_gpu_clients']=sorted(foreign);raise RuntimeError('foreign GPU client')
                if interrupted or time.monotonic()>deadline:raise RuntimeError('owned-run interruption/deadline')
                if worker and done.is_set():
                    worker.join();r['checks']=check_result
                    child.terminate();child.wait(timeout=120)
                    assert check_result['exit_code']==0,'functional checks failed'
                    break
                time.sleep(.5)
        r['child_exit_code']=child.returncode;assert child.returncode==0,'child failed'
        if worker:assert done.is_set() and check_result.get('exit_code')==0
        else:
            if m.get('result_kind')=='core-reactive':
                rows=[json.loads(x) for x in (out/'measurements.jsonl').read_text().splitlines()]
                assert rows[-1]=={'event':'complete','exit_code':0}
                assert [x['event'] for x in rows]==['peer_complete_stalled_loan','cancel_during_prefill_peer_complete','cancel_during_decode_peer_complete','qualified','complete']
                assert rows[-2]['cancel_during_prefill']>0 and rows[-2]['cancel_during_decode']>0
                r['summary']={'reactive_original_weights':True,'raw_sha256':sha(out/'measurements.jsonl'),'events':rows}
            elif m.get('result_kind')=='integrated-state':
                rows=[json.loads(x) for x in (out/'measurements.jsonl').read_text().splitlines()]
                assert rows[-1]=={'event':'complete','exit_code':0},'incomplete state probe'
                pairs=[x for x in rows if x['event']=='paired_complete'];assert len(pairs)==2 and all(x['calls']>0 for x in pairs)
                r['summary']={'paired_configurations':pairs,'same_provider':True,'raw_sha256':sha(out/'measurements.jsonl')}
            else:
                report=runpy.run_path(str(base/'bench-report.py'))['read_result'](out/'measurements.jsonl');r['summary']=report
        r['state']='PASS_ORIGINAL_WEIGHTS_SAME_PROVIDER_NOT_INDEPENDENT_QUALIFICATION'
    except BaseException as ex:r.update(state='FAILED',error=repr(ex))
    finally:
        if child:
            if child.poll() is None:
                child.terminate()
                try:child.wait(timeout=5 if r.get('thermal_stop') else 120)
                except subprocess.TimeoutExpired:r['forced_owned_child_kill']=True;child.kill();child.wait()
            r['child_exit_code']=child.returncode
        if worker:worker.join(timeout=15);r['checker_retired']=not worker.is_alive()
        try:
            r['models_after']=[H['model_stat'](x) for x in m['models']]
            r['files_unchanged']=all(sha(base/name)==digest for name,digest in m['files'].items())
            r['postflight_kfd']=sorted(H['kfd']());r['postflight_memory']=H['memory']()
            r['owned_child_retired']=not child or not P(f'/proc/{child.pid}').exists()
            assert r['files_unchanged'] and r['owned_child_retired'] and not r['postflight_kfd']
            if worker:assert not worker.is_alive()
        except BaseException as ex:r.update(state='FAILED',closure_error=repr(ex))
        r['finished_at']=now();save()
        try:
            if registered:register('end')
        finally:
            for fd in reversed(fds):os.close(fd)
    print(json.dumps({k:r.get(k) for k in ('state','error','closure_error','child_exit_code','checks','finished_at')}),flush=True)
    return 0 if r['state'].startswith('PASS_') else 1
if __name__=='__main__':sys.exit(main())
