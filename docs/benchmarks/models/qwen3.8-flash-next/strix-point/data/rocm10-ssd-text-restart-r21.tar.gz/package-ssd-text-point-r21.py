# SPDX-License-Identifier: MIT
"""Validate and package closed original-weight SSD text restart windows."""
from pathlib import Path
import datetime
import gzip
import hashlib
import importlib.util
import io
import json
import subprocess
import tarfile


def bound(name):
    path = Path(name)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


spec = importlib.util.spec_from_file_location('gate', 'tools/strix-point-ssd-text-restart-gate.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
source = json.loads(Path('docs/development/validation/c17-binary64-point-gpu-2026-10-06.json').read_text())
for name, digest in source['compiled_provider_files'].items():
    assert bound(name)['sha256'] == digest, name
final = json.loads(Path('evidence/context-r21-final-161-r4.json').read_text())
assert final['actual_exit_code'] == 0
closure = final['result']
assert closure['state'] == 'FRESH_ALL_FOUR_WINDOWS_CLOSED_NO_STANDING_RESERVATION'
assert closure['original_lease']['free_briefly'] and closure['original_lease']['released']
assert not closure['foreign_compute_clients'] and not closure['guarded_hot'] and not closure['http8000_listeners']
files = set()
runs = []
for label, mode, passed, raw_exit in [('context-r21-ssd-text-ar-r1', 'ar', True, 0),
                            ('context-r21-ssd-text-mtp-r1', 'mtp', False, 1),
                            ('context-r21-ssd-text-mtp-r2', 'mtp', False, 1),
                            ('context-r21-ssd-text-mtp-r3', 'mtp', True, 1)]:
    root = Path('evidence') / label
    run = json.loads((root / 'result.json').read_text())
    collection = json.loads((root / 'collection.json').read_text())
    assert collection['exit_code'] == 0 and run['model_stat_unchanged'] and not run['cleanup_failures']
    assert run['exit_code'] == run['child_exit_code'] == raw_exit
    assert run['state'] == ('PASSED' if raw_exit == 0 else 'FAILED') and run['lease_released_at'] and run['ended_at']
    result = json.loads((root / 'ssd-text-restart-result.json').read_text())
    artifacts = []
    for name, identity in collection['inventory']['files'].items():
        entry = bound(root / name)
        assert entry['sha256'] == identity['sha256'] and entry['bytes'] == identity['bytes'], name
        artifacts.append(entry)
        files.add(entry['path'])
    for name in ('collection.json', 'controller-result.json', 'controller-stdout.log', 'controller-stderr.log', 'plan.json'):
        artifacts.append(bound(root / name))
        files.add(str(root / name))
    entry = {'label': label, 'mode': mode, 'state': run['state'], 'actual_exit_code': run['exit_code'],
             'child_exit_code': run['child_exit_code'], 'started_at': run['started_at'],
             'ended_at': run['ended_at'], 'lease_released_at': run['lease_released_at'],
             'supervisor_pid': run['pid'], 'supervisor_start_ticks': run['start_ticks'],
             'router_restored': run['service_after'], 'artifacts': artifacts,
             'raw_model_attempted_flag': run['model_attempted']}
    peaks = {}
    threads = gtt = 0
    for line in (root / 'telemetry.jsonl').read_text().splitlines():
        row = json.loads(line)
        for sensor in row['temperatures']:
            peaks[sensor['name']] = max(peaks.get(sensor['name'], -40), sensor['value_c'])
            if sensor['guarded']:
                assert sensor['value_c'] < sensor['limit_c']
        for proc in row['dri']:
            value = proc.get('status', {}).get('Threads', '')
            if value.isdecimal():
                threads = max(threads, int(value))
        gtt = max(gtt, row.get('gpu', {}).get('mem_info_gtt_used', 0))
    entry.update(temperature_peaks_c=peaks, whole_process_threads_max=threads, GTT_peak_bytes=gtt)
    if passed:
        phases = {phase: gate.parse_phase([json.loads(line) for line in (root / f'measurements-{phase}.jsonl').read_text().splitlines()], mode, phase, result.get('fixture') == 'question-suffix') for phase in gate.PHASES}
        compared = gate.compare_phases(phases, result.get('fixture') == 'question-suffix')
        if raw_exit == 0:
            for key, value in compared.items():
                assert result.get(key, 0) == value if key == 'physical_suffix_tokens' else result[key] == value, key
            assert result['state'] == 'PASSED'
        else:
            offline = json.loads(Path('evidence/context-r21-mtp-r3-offline-validation-r1.json').read_text())
            assert offline['state'] == 'PASSED_OFFLINE_REVALIDATION_RAW_GATE_EXIT_1'
            assert offline['validator_sha256'] == bound('tools/strix-point-ssd-text-restart-gate.py')['sha256']
            assert result['state'] == 'FAILED' and 'Incorrect restored' in result['error']
            assert all(proc['exit_code'] == 0 for proc in result['processes']) and len(result['processes']) == 4
            for key, value in compared.items():
                assert offline[key] == value, key
            entry['retained_validator_expectation_failure'] = result['error']
            entry['offline_revalidation'] = bound('evidence/context-r21-mtp-r3-offline-validation-r1.json')
        entry.update(compared, qualification_state='PASSED' if raw_exit == 0 else 'PASSED_OFFLINE_REVALIDATION_RAW_GATE_EXIT_1', processes=result['processes'], cold=phases['cold']['job'], hot=phases['hot']['job'],
                     cold_ssd_drained=next(row for row in map(json.loads, (root / 'measurements-cold.jsonl').read_text().splitlines()) if row['event'] == 'ssd_drained'))
    else:
        assert result['state'] == 'FAILED'
        if label.endswith('mtp-r1'):
            assert result['calibration_exit_code'] == 1
            failed = [json.loads(line) for line in (root / 'measurements-calibration.jsonl').read_text().splitlines()]
            assert failed[-1]['exit_code'] == 1 and 'Failed to open file: /mtp/' in failed[-1]['error']
            entry['retained_failure'] = failed[-1]
        else:
            assert result['calibration_exit_code'] == result['fresh_exit_code'] == result['cold_exit_code'] == 0
            cold_rows = [json.loads(line) for line in (root / 'measurements-cold.jsonl').read_text().splitlines()]
            cold_job = next(row for row in cold_rows if row['event'] == 'job')
            assert cold_rows[-1] == {'event':'complete','exit_code':0}
            assert cold_job['mtp_drafted_tokens'] == 7 and cold_job['mtp_accepted_tokens'] == 0
            assert 'did not accept a draft' in result['error']
            entry['retained_failure'] = result['error']
            entry['completed_cold_process'] = cold_job
        entry['numerical_failure_claim'] = False
    runs.append(entry)
assert closure['service']['MainPID'] == runs[-1]['router_restored']['MainPID']
extras = ['evidence/context-r21-final-161-r4.json', 'evidence/context-r21-final-161-r4.py',
          'evidence/context-r21-before-ar-r1.json', 'evidence/context-r21-before-ar-r2.json',
          'evidence/context-r21-before-ar-r1.py', 'evidence/context-r21-before-ar-r2.py',
          'evidence/context-r21-before-mtp-r1.json', 'evidence/context-r21-before-mtp-r2.json',
          'evidence/context-r21-before-mtp-r3.json', 'evidence/context-r21-before-mtp-r3.py',
          'evidence/context-r21-thread-handover.json', 'evidence/context-r21-code-binding-r1.json',
          'evidence/context-r21-discovery-diagnostics-r1.json', 'evidence/package-ssd-text-point-r21.py']
for folder in ('ssd-text-restart-host-r2', 'ssd-text-restart-host-r3', 'ssd-text-restart-host-r4', 'ssd-text-restart-host-r5', 'ssd-text-campaign-host-r1', 'ssd-text-campaign-host-r2', 'ssd-text-campaign-host-r3'):
    extras += ['evidence/' + folder + '/' + name for name in ('plan.json', 'result.json', 'command.log', 'temperatures.jsonl')]
extras += [str(path) for path in sorted(Path('evidence').glob('context-r21-*')) if path.is_file() and path.suffix in ('.json', '.py')]
extras = sorted(set(extras))
files.update(extras)
source_entries = {}
for commit, names in [('4d6dbc3f10155718760ab68e7a302c60ad994a4d', ['tools/strix-point-campaign.py','tools/strix-point-launch.py','tools/strix-point-bench-collect.py','tools/strix-point-ssd-text-restart-gate.py','tests/test_strix_point_ssd_text_restart.py']),
                       ('7ca0b0ad', ['tools/strix-point-campaign.py','tools/strix-point-launch.py','tools/strix-point-bench-collect.py','tools/strix-point-ssd-text-restart-gate.py','tests/test_strix_point_ssd_text_restart.py','tests/test_strix_point_campaign.py'])]:
    for name in names:
        raw = subprocess.run(['git', 'show', commit + ':' + name], capture_output=True, check=True).stdout
        source_entries['qa-source/' + commit[:8] + '/' + name] = raw
archive = Path('docs/benchmarks/models/qwen3.8-flash-next/strix-point/data/rocm10-ssd-text-restart-r21.tar.gz')
for name in files:
    assert Path(name).is_file() and not Path(name).is_symlink(), name
assert not archive.exists()
with archive.open('xb') as output, gzip.GzipFile(fileobj=output, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
    for name in sorted(files):
        path = Path(name)
        info = tar.gettarinfo(str(path), arcname=path.relative_to('evidence').as_posix())
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        info.mtime = 0
        with path.open('rb') as content:
            tar.addfile(info, content)
    for name, raw in sorted(source_entries.items()):
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        tar.addfile(info, io.BytesIO(raw))
index = archive.parent / 'archives.sha256'
old = index.read_bytes()
assert old.endswith(b'\n') and archive.name.encode() not in old
with index.open('ab') as out:
    out.write((bound(archive)['sha256'] + '  ' + archive.name + '\n').encode())
receipt = {'schema': 'synapse-lie.ssd-text-restart-point-original.v1',
           'state': 'SELECTED_CORE_CASES_QUALIFIED_WITH_RETAINED_GATE_FAILURES', 'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'source_commit': source['source_commit'], 'target': 'pop@192.168.5.161', 'GPU_architecture': 'gfx1150',
           'scope': 'Original-weight shared reactive core reconstructs exact saved physical token history from SSD text when that history is longer than fresh BPE, independently in AR/MTP. No HTTP, scheduled steering, general quality, independent numeric/probability or matched performance claim.',
           'previous_matching_GPU_receipt': bound('docs/development/validation/c17-binary64-point-gpu-2026-10-06.json'),
           'host_receipt': bound('docs/development/validation/ssd-text-restart-host-2026-10-06.json'),
           'host_receipt_source_commit': '4d6dbc3f10155718760ab68e7a302c60ad994a4d',
           'parser_rejection_tests': 12, 'campaign_host_tests': 59, 'runs': runs,
           'final_closure': bound('evidence/context-r21-final-161-r4.json'), 'coordination_and_host': [bound(name) for name in extras],
           'portable_archive': bound(archive), 'portable_archive_members': len(files) + len(source_entries),
           'archive_index_previous_bytes_sha256': hashlib.sha256(old).hexdigest(),
           'archive_index_baseline_commit': '7ca0b0ad', 'archive_index_appended_only': True,
           'observer_metadata_fix': 'AR actual model_attempted=False is retained: its new helper originally omitted the standard supervisor marker. Four complete original-weight measurements are bound. The marker is added at b01fe66d, observed true in MTP. Missing MTP volume r1 is retained and corrected at0fffefd1. Plain MTP r2 drafts7/accepts0; its completed cold process and test refusal are retained. The distinct r3 question suffix is independently tokenized and physically prefilled after the saved prefix, with the same real draft acceptance gate. All four r3 core processes exit0: the raw gate/supervisor exit1 is retained because its2048 expectation omitted the complete2064 prompt checkpoint. Strict offline revalidation at7ca0b0ad requires that full persisted prompt, PP0 and exact IDs/draft acceptance. No GPU replay, inference code or validator relaxation.',
           'runtime_ABI_format_or_dependency_changed': False, 'new_inference_threads': 0,
           'root_157_non_use': True, 'Terminal_Bench': 'Stopped/closed/deferred until modifications and qualification finish; no reservation.',
           'pending': ['Scheduled physical-token-index regression', 'Individual numeric/format branches and independent probability/fault/private allocation-exact/matched cost', 'Remaining typed containers/lexer/predicate/model/controller ownership', '1M recall quality and matched Gufo/Halogen benchmark methods'],
           'all_six_owned_tasks_open': True, 'goal_complete': False, 'publication': False}
out = Path('docs/development/validation/ssd-text-restart-point-gpu-2026-10-06.json')
with out.open('x') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
print(json.dumps({'receipt': bound(out), 'archive': receipt['portable_archive'],
                  'members': receipt['portable_archive_members'], 'runs': [(r['mode'], r['actual_exit_code']) for r in runs],
                  'closure_at': closure['at_utc']}))
