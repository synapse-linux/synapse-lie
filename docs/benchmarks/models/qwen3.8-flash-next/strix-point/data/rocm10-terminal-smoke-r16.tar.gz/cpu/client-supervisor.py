# SPDX-License-Identifier: MIT
"""Persistent CPU-only coordinator for the unchanged external Terminal suite."""
from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,signal,subprocess,sys,time

root=Path(sys.argv[1]);assert root.resolve()==root and root.stat().st_uid==os.getuid()
plan=json.loads((root/'client-plan.json').read_text());source=Path(plan['source_directory'])
assert source.resolve()==source and source.stat().st_uid==os.getuid()
assert plan['endpoint']=='http://192.168.5.161:8000/v1'
assert plan['source_commit'] in ('1bff953c779b7ccdbef387020f9362fa9fd725a7','23594881f406adcaf47e156d4f8e880aa735b081')
assert plan['suite']=='core19' and plan['tier'] in ('smoke','full')
assert plan['attempts']==2 and plan['concurrency']==1 and plan['agent_timeout_seconds']==10800
assert plan['gpus']==0 and not (root/'client-result.json').exists()
assert hashlib.sha256((source/'SOURCE.json').read_bytes()).hexdigest()==plan['source_receipt_sha256']
manifest=json.loads((source/'SOURCE.json').read_text())
assert manifest['revision']=='07034484346dc724d0e2c47c821fd196add1d6fb'
fixture=bool(plan.get('infrastructure_fixture',False))
assert not fixture or manifest['repository']=='fixture://NOT_EXTERNAL_BENCHMARK'
lock_path=root.parent/'client.lock'
lease_fd=os.open(lock_path,os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
lease_stat=os.fstat(lease_fd);assert lease_stat.st_uid==os.getuid()
fcntl.flock(lease_fd,fcntl.LOCK_EX|fcntl.LOCK_NB)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identity(pid):
 try:
  t=Path('/proc')/str(pid)/'stat';s=t.read_text();tail=s[s.rindex(')')+2:].split()
  return {'pid':pid,'start_ticks':int(tail[19]),'pgrp':int(tail[2]),'state':tail[0]}
 except FileNotFoundError:return None

def verify_source():
 for name,expected in manifest['files'].items():
  p=source/name
  assert p.resolve().is_relative_to(source) and not p.is_symlink() and p.is_file()
  assert sha(p)==expected,('Benchmark source drift',name)
 return len(manifest['files'])

env=dict(os.environ,LC_ALL='C',PYTHONDONTWRITEBYTECODE='1',ROCR_VISIBLE_DEVICES='-1',HIP_VISIBLE_DEVICES='-1',CUDA_VISIBLE_DEVICES='-1',XDG_CACHE_HOME=str(root/'cache'))
harbor=Path(plan['harbor_executable']);assert harbor.is_file()
env['PATH']=str(harbor.parent)+os.pathsep+env.get('PATH','')
result={'schema':'synapse-lie.terminal-eval-client.v1','state':'PREPARING','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'supervisor':identity(os.getpid()),'plan_sha256':sha(root/'client-plan.json'),'commands':[],'known_child_identities':[],'scope':'Existing pinned CPU client only; actual GPU endpoint is separately admitted on .161'}
result['cpu_lease']={'path':str(lock_path),'device':lease_stat.st_dev,'inode':lease_stat.st_ino,'scope':'Own CPU client only; no foreign GPU lock held'}
thermal=[]
for device in Path('/sys/class/hwmon').iterdir():
 name=(device/'name').read_text().strip()
 if name not in ('k10temp','coretemp','nvme'):continue
 for p in device.glob('temp*_input'):
  limit=85.0 if name=='nvme' else 98.0
  for suffix in ('max','crit'):
   bound=p.with_name(p.name[:-6]+'_'+suffix)
   if bound.exists():
    value=int(bound.read_text())/1000
    if 30<=value<=150:limit=min(limit,value)
  thermal.append({'name':name,'path':str(p),'limit_c':limit})
assert any(x['name'] in ('k10temp','coretemp') for x in thermal)
result['thermal_policy']={'scope':'CPU98/NVMe85 and lower exposed limits; no fan/power/clock changes','sensors':thermal,'peak_c':{}}
interrupted=None;child=None;child_group=None;seen={}

def stop_requested(signum,_frame):
 global interrupted
 interrupted=signum
for s in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):signal.signal(s,stop_requested)
def save():
 tmp=root/'client-result.tmp';tmp.write_text(json.dumps(result,indent=2)+'\n');tmp.replace(root/'client-result.json')
def thermal_sample():
 readings=[]
 for sensor in thermal:
  value=int(Path(sensor['path']).read_text())/1000;assert -40<=value<=150
  readings.append(dict(sensor,value_c=value))
  peaks=result['thermal_policy']['peak_c'];peaks[sensor['path']]=max(peaks.get(sensor['path'],value),value)
  if value>=sensor['limit_c']:result['thermal_failure']=dict(sensor,value_c=value)
 with (root/'client-temperatures.jsonl').open('a') as f:
  f.write(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'temperatures':readings})+'\n')
def members(group):
 found=[]
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   try:
    row=identity(int(p.name))
    if row and row['pgrp']==group:
     assert p.stat().st_uid==os.getuid(),('Foreign UID in owned group',row)
     found.append(row);seen[(row['pid'],row['start_ticks'])]=row
   except FileNotFoundError:pass
 return found

def retire_owned_group():
 global child
 if child is None:return
 # Members of the originally created session/group are owned. Revalidate UID
 # and PGID/start identities before each signal; never scan by executable name.
 for signum,budget in [(signal.SIGINT,30),(signal.SIGTERM,10),(signal.SIGKILL,10)]:
  live=members(child_group)
  if not live:break
  for row in live:
   current=identity(row['pid'])
   if current and current['start_ticks']==row['start_ticks'] and current['pgrp']==child_group:
    os.kill(row['pid'],signum)
  deadline=time.monotonic()+budget
  while time.monotonic()<deadline:
   child.poll()
   if not members(child_group):break
   time.sleep(.2)
 if child.poll() is not None:child.wait()
 assert not members(child_group),('Owned group failed to retire',child_group)

def owned_jobs():
 jobs=[];directory=source/'jobs'
 if not directory.exists():return jobs
 for job in directory.iterdir():
  if not job.is_dir() or job.is_symlink():continue
  meta=job/'runner-meta.json'
  if not meta.is_file():continue
  value=json.loads(meta.read_text())
  if (value.get('attempt_group') or value.get('job_name') or job.name)==plan['job_name']:
   assert job.resolve().parent==directory.resolve()
   jobs.append(job)
 return jobs

def container_closure(cleanup=False):
 if fixture:
  return {'scope':'CPU_INFRASTRUCTURE_FIXTURE_NOT_REAL_DOCKER','all_owned_trial_containers_absent':True}
 jobs=owned_jobs();projects=set();configs=[]
 for job in jobs:
  config_path=job/'config.json'
  if not config_path.is_file():config_path=source/'.runner/configs'/(job.name+'.json')
  if config_path.is_file():
   config=json.loads(config_path.read_text());assert config['job_name']==job.name
   assert (config.get('environment') or {}).get('delete',True)
   configs.append(config)
  for trial in job.iterdir():
   if trial.is_dir() and not trial.is_symlink() and '__' in trial.name:
    projects.add(trial.name.casefold()+'__env')
 if cleanup and configs:
  verify_source()
  spec=importlib.util.spec_from_file_location('official_terminal_runner',source/'terminal_bench.py')
  module=importlib.util.module_from_spec(spec);sys.path.insert(0,str(source))
  spec.loader.exec_module(module)
  module.cleanup_interrupted_containers(configs,runtime='docker')
 argv=['docker','ps','-a','--format','{{.ID}}\t{{.Label "com.docker.compose.project"}}']
 listed=subprocess.run(argv,cwd=source,env=env,text=True,capture_output=True,timeout=30)
 assert listed.returncode==0,('Owned container closure query failed',listed.returncode,listed.stderr)
 live=[{'container_id':line.split('\t',1)[0],'project':line.split('\t',1)[1]} for line in listed.stdout.splitlines() if '\t' in line and line.split('\t',1)[1].casefold() in projects]
 return {'scope':'Exact Compose project labels derived from owned official job trial directories only','argv':argv,'exit_code':listed.returncode,'owned_jobs':[str(x) for x in jobs],'owned_projects':sorted(projects),'owned_trial_containers_present':live,'all_owned_trial_containers_absent':not live,'official_interrupted_cleanup_requested':cleanup}

def execute(name,argv):
 global child,child_group
 with (root/(name+'.log')).open('xb') as log:
  child=subprocess.Popen(argv,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  own=identity(child.pid);assert own and own['pgrp']==child.pid;child_group=child.pid
  entry={'phase':name,'argv':argv,'pid':child.pid,'start_ticks':own['start_ticks'],'pgrp':child_group}
  result['commands'].append(entry);seen[(own['pid'],own['start_ticks'])]=own;result['state']=name.upper();save()
  while child.poll() is None:
   thermal_sample()
   members(child_group)
   if interrupted or result.get('thermal_failure'):
    current=identity(child.pid)
    if current and current['start_ticks']==own['start_ticks']:
     os.killpg(child_group,signal.SIGINT)
    try:child.wait(timeout=30)
    except subprocess.TimeoutExpired:
     current=identity(child.pid)
     if current and current['start_ticks']==own['start_ticks']:os.killpg(child_group,signal.SIGTERM)
     try:child.wait(timeout=30)
     except subprocess.TimeoutExpired:
      current=identity(child.pid)
      if current and current['start_ticks']==own['start_ticks']:os.killpg(child_group,signal.SIGKILL)
      child.wait()
    break
   time.sleep(1)
  entry['exit_code']=child.wait();entry['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
  live=members(child_group)
  assert not live,('Owned client group not retired',live)
  assert entry['exit_code']==0,('Client phase refused',name,entry['exit_code'])

try:
 thermal_sample();assert not result.get('thermal_failure'),('Thermal admission refused',result.get('thermal_failure'))
 result['source_files_verified_before']=verify_source();save()
 execute('doctor',['python3','-B',str(source/'terminal_bench.py'),'doctor','--tier',plan['tier'],'--endpoint',plan['endpoint'],'--model','qwen3.8-flash-next'])
 argv=['python3','-B',str(source/'terminal_bench.py'),'run','--tier',plan['tier'],'--endpoint',plan['endpoint'],'--model','qwen3.8-flash-next','--platform','strix-point','--model-name','Qwen3.8-Flash-Next','--engine','synapse-lie','--engine-version',plan['source_commit'],'--backend','rocm','--backend-version','10.0','--quant','UD-Q4_K_XL','--inference-profile','ar','--job-name',plan['job_name']]
 result['runner_argv']=argv;save();execute('runner',argv)
 result['source_files_verified_after']=verify_source()
 # Export contents are exclusively created by the unchanged official runner.
 job=source/'jobs'/plan['job_name'];assert job.is_dir() and (job/'runner-meta.json').is_file()
 result['job_directory']=str(job);result['runner_meta_sha256']=sha(job/'runner-meta.json')
 result['known_child_identities']=list(seen.values())
 result['container_closure']=container_closure()
 result['all_client_children_retired']=all(not (row:=identity(p)) or row['start_ticks']!=start for p,start in seen) and result['container_closure']['all_owned_trial_containers_absent']
 assert result['all_client_children_retired']
 result['state']='CLIENT_CLOSED';result['exit_code']=0
except BaseException as e:
 result.update(state='FAILED',exit_code=1,error=repr(e))
 try:retire_owned_group()
 except BaseException as cleanup:result['cleanup_error']=repr(cleanup)
 result['known_child_identities']=list(seen.values())
 try:result['container_closure']=container_closure(cleanup=True)
 except BaseException as cleanup:result['container_cleanup_error']=repr(cleanup)
 result['all_client_children_retired']=all(not (row:=identity(p)) or row['start_ticks']!=start for p,start in seen) and result.get('container_closure',{}).get('all_owned_trial_containers_absent',False)
finally:
 result['interrupted_signal']=interrupted
 result['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 os.close(lease_fd)
print(json.dumps({k:result.get(k) for k in ['state','exit_code','job_directory','all_client_children_retired','error']}),flush=True)
raise SystemExit(result['exit_code'])
