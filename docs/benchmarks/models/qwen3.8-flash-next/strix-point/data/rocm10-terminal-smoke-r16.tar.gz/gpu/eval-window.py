# SPDX-License-Identifier: MIT
"""Reuse the established Point admission/thermal/retirement implementation."""
from pathlib import Path
import importlib.util
import json
import os
import signal
import sys

root=Path(sys.argv[1])
spec=importlib.util.spec_from_file_location('point_campaign',root/'runner.py')
point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
root=point.checked_path(root)
assert os.getuid()==1000 and os.environ.get('SSH_CONNECTION','').split()[2:3]==['192.168.5.161']
assert not (root/'result.json').exists()
m=json.loads((root/'manifest.json').read_text())
assert m['authorization']=={'kind':'operator-one-shot-window','service':point.SERVICE,
                           'stop_restore_authorized':True,'quote':'llama si può stoppaare'}
assert m['decode_mode']=='ar' and m['bench_profile']=='modern-http'
c=point.Campaign(root,m)
for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):
    signal.signal(sig,lambda signum,frame:setattr(c,'interrupted',signum))
rows=None
try:
    c.enter()
    model,rows=c.verified_model()
    assert point.sha(root/'eval-server.py')==m['eval_server_sha256']
    c.run_container(['/usr/bin/python3','-B','/work/eval-server.py',
                     '/bundle/runtime/bin/synapse-lie-server',
                     '/model/'+m['model_plan']['files'][0]['name']],m['bundle'],m['eval_window_seconds'],model)
    result=json.loads((root/'eval-server-result.json').read_text())
    assert result['state']=='CLOSED' and result['server_exit_code']==0 and result['server_absent']
    c.r.update(state='PASSED',exit_code=0,eval_server_result=result)
except BaseException as error:
    c.r.update(state='FAILED',exit_code=1,error=repr(error))
finally:
    if rows is not None:c.check_model_after(rows)
    c.finish()
print(json.dumps(c.r),flush=True)
raise SystemExit(c.r['exit_code'])
