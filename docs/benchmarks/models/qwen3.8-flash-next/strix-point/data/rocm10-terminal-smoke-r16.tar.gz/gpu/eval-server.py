# SPDX-License-Identifier: MIT
"""Owned original-weight eval server; enclosing Point campaign owns admission."""
from pathlib import Path
import http.client
import json
import signal
import socket
import subprocess
import sys
import time

root=Path('/work')
manifest=json.loads((root/'manifest.json').read_text())
assert manifest['source_commit'] in ('1bff953c779b7ccdbef387020f9362fa9fd725a7','23594881f406adcaf47e156d4f8e880aa735b081')
assert manifest['eval_port']==8000 and manifest['eval_context']==262144
with socket.socket() as sock:
    sock.bind(('127.0.0.1',0));management=sock.getsockname()[1]
assert management!=8000
command=[sys.argv[1],'--model',sys.argv[2],'--model-id','qwen3.8-flash-next',
         '--host','0.0.0.0','--port','8000','--management-host','127.0.0.1',
         '--management-port',str(management),'--context','262144','--max-active','1',
         '--prefill-chunk','2048','--kv-cache-ram-mb','0','--request-timeout-ms','10800000']
result={'schema':'synapse-lie.terminal-eval-server.v1','state':'STARTING',
        'server_argv':command,'api_port':8000,'management_port':management,
        'scope':'Original-weight eval endpoint; task rewards are separate client evidence'}
interrupted=None
def interrupt(signum,_frame):
    global interrupted
    interrupted=signum
for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):signal.signal(sig,interrupt)
def save():
    temporary=root/'eval-server-result.tmp'
    temporary.write_text(json.dumps(result,indent=2)+'\n')
    temporary.replace(root/'eval-server-result.json')
def get(port,path):
    connection=http.client.HTTPConnection('127.0.0.1',port,timeout=3)
    try:
        connection.request('GET',path);response=connection.getresponse()
        data=response.read(1048577)
        if response.status!=200 or len(data)>1048576:raise RuntimeError('Endpoint not ready')
        return json.loads(data)
    finally:connection.close()
def sample_threads():
    for line in Path(f'/proc/{server.pid}/status').read_text().splitlines():
        if line.startswith('Threads:'):
            result['observed_process_threads_max']=max(result.get('observed_process_threads_max',0),int(line.split()[1]))
            result['thread_scope']='Whole server process including runtime helpers; does not identify reactive workers or establish speedup'
            return
server=None
try:
    with (root/'server.log').open('xb') as log:
        server=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
        result['server_pid']=server.pid
        result['server_start_ticks']=int(Path(f'/proc/{server.pid}/stat').read_text().rsplit(')',1)[1].split()[19])
        (root/'http-started.marker').write_text(str(server.pid)+'\n');save()
        deadline=time.monotonic()+900
        while True:
            if interrupted:raise RuntimeError('Server coordinator interrupted')
            if server.poll() is not None:raise RuntimeError('Server retired during load')
            sample_threads()
            try:
                get(management,'/actuator/health/readiness')
                models=get(8000,'/v1/models')
                assert models['data'][0]['id']=='qwen3.8-flash-next'
                break
            except (OSError,http.client.HTTPException,RuntimeError):
                if time.monotonic()>=deadline:raise RuntimeError('Readiness deadline')
                time.sleep(.5)
        result.update(state='READY',models=models);save()
        with (root/'eval-ready.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
        while not (root/'eval-release.json').exists():
            if interrupted:raise RuntimeError('Server coordinator interrupted')
            if server.poll() is not None:raise RuntimeError('Server retired during evaluation')
            sample_threads()
            save()
            time.sleep(1)
        release=json.loads((root/'eval-release.json').read_text())
        assert release['nonce']==manifest['eval_release_nonce'] and release['all_client_children_retired'] is True
        result.update(state='CLOSING',client_closure=release);save()
except BaseException as error:
    result['error']=repr(error)
finally:
    result['interrupted_signal']=interrupted
    if server is not None:
        if server.poll() is None:server.terminate()
        try:server.wait(timeout=30)
        except subprocess.TimeoutExpired:server.kill();server.wait()
        result['server_exit_code']=server.returncode
        try:
            current=Path(f'/proc/{server.pid}/stat').read_text()
            ticks=int(current.rsplit(')',1)[1].split()[19])
            result['server_absent']=ticks!=result['server_start_ticks']
        except FileNotFoundError:result['server_absent']=True
    result['state']='CLOSED' if result.get('state')=='CLOSING' and result.get('server_exit_code')==0 else 'FAILED'
    save()
raise SystemExit(0 if result['state']=='CLOSED' else 1)
