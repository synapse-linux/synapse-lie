#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Update current status only from completed source-bound GPU qualification."""
from pathlib import Path
import json
r=json.loads(Path('docs/development/validation/c17-schema-compile-point-gpu-2026-10-06.json').read_text())
assert r['source_commit']=='33d12a028140d66dcc2d861fe513d537b5f565f3'
assert r['state']=='PASSED_WITH_STATED_SCOPE' and len(r['compiled_provider_files'])==102
assert len(r['runs'])==3 and all(x['actual_window_retired'] for x in r['runs'])
assert [x['checks'] for x in r['runs'] if x['mode']!='build']==[37,37]
assert not r['official_Gufo_HTTP_frontend_built']
c=json.loads(Path(r['final_fresh_closure']['path']).read_text())['result']
assert c['state']=='FRESH_BUILD_AR_MTP_WINDOWS_CLOSED_NO_STANDING_RESERVATION'
ar,mtp=r['runs'][1:]
updates={}
def replace(name,old,new):
    text=updates.get(name,Path(name).read_text())
    assert text.count(old)==1,(name,old)
    updates[name]=text.replace(old,new,1)
replace('README.md',
'''The current [C17 schema build](docs/development/C17-SAMPLING.md#derived-schema-value-ownership)
passes [37 OpenAI controls in both AR and MTP on Strix Point](docs/development/validation/c17-schema-store-point-gpu-2026-10-06.json).''',
'''The current [C17 schema publication build](docs/development/C17-SAMPLING.md#schema-compilation-and-prompt-publication)
passes [37 OpenAI controls in both AR and MTP on Strix Point](docs/development/validation/c17-schema-compile-point-gpu-2026-10-06.json).''')
replace('README.md',
'''The newer [C17 schema publication workflow](docs/development/C17-SAMPLING.md#schema-compilation-and-prompt-publication)
passes HOST sanitizer checks; its matching GPU qualification is pending.''',
'''The shared [C17 schema publication workflow](docs/development/C17-SAMPLING.md#schema-compilation-and-prompt-publication)
and immutable prompt ownership pass HOST and selected matching GPU controls.''')
replace('CHANGELOG.md',
'''  Matching GPU qualification is pending; typed construction and model/controller
  remain transitional.''',
'''  The matching HIP build passes 37 selected original-weight OpenAI controls in
  both AR and MTP on Strix Point. Typed construction/bootstrap/errors and
  model/controller remain transitional; broader quality and cost stay open.''')
replace('docs/development/C17-SAMPLING.md',
'''This increment awaits a freshly admitted matching HIP ON/OFF build and selected
original-weight controls on `.161`. The `72e9e831`/r30 GPU receipt excludes it.
Broader numerical, fault, quality, resource and matched-cost acceptance stays
open.''',
'''The matching `33d12a02` sealed build verifies coherent 102-file HIP ON/OFF
providers and private LIE/model/reference consumers. It passes the unchanged
37 selected original-weight OpenAI controls in each AR/MTP mode on `.161`
([GPU receipt](validation/c17-schema-compile-point-gpu-2026-10-06.json)).
The official Gufo HTTP frontend remains copied-source coverage only and is not
compiled in this gate. The earlier `72e9e831`/r30 receipt retains its identity.
Broader numerical, fault, quality, resource and matched-cost acceptance stays
open.''')
replace('docs/BACKEND.md',
'''   still awaits matching `.161` HIP ON/OFF provider/frontend qualification.
   Typed construction/initialization/callback-error facades and model/controller''',
'''   now has matching sealed `33d12a02` HIP ON/OFF providers and private
   LIE/model/reference consumers passing AR37/MTP37
   ([GPU receipt](development/validation/c17-schema-compile-point-gpu-2026-10-06.json)).
   The official Gufo HTTP frontend is not built in this gate. Integer-bound
   interval construction remains an identified C++ algorithm for the next port.
   Typed construction/initialization/callback-error facades and model/controller''')
replace('docs/reference/ABI.md',
'''ON/OFF providers and frontend consumers to rebuild together. HOST checks pass;
matching HIP/original-weight qualification is pending. See''',
'''ON/OFF providers and frontend consumers to rebuild together. HOST checks and
matching selected HIP/original-weight AR37/MTP37 controls pass for private
LIE/model/reference consumers; the official Gufo HTTP frontend is not built.
See''')
replace('docs/benchmarks/models/qwen3.8-flash-next/strix-point/README.md',
'''The current matching `72e9e831` build adds C17 ownership of derived schema''',
'''The current matching `33d12a02` build adds the C17 schema publication workflow
and independent immutable prompt ownership shared by reasoning/tools. It passes
the unchanged **37 controls in AR and MTP**. The
[source-bound receipt](../../../../development/validation/c17-schema-compile-point-gpu-2026-10-06.json)
and [portable raw evidence](data/rocm10-schema-compile-openai-r31.tar.gz) record
coherent 102-file HIP ON/OFF providers, private LIE/model/reference consumers,
telemetry and actual closure. The official Gufo HTTP frontend is not built in
this gate. These are selected functional controls; no new performance graph or
throughput comparison is implied.

The preceding matching `72e9e831` build adds C17 ownership of derived schema''')
telemetry=(f"AR/MTP CPU maxima are {ar['peak_c']['k10temp']}/{mtp['peak_c']['k10temp']} C; "
           f"GPU {ar['peak_c']['amdgpu']}/{mtp['peak_c']['amdgpu']} C; NVMe "
           f"{ar['peak_c']['nvme']}/{mtp['peak_c']['nvme']} C. Whole-process thread "
           f"maxima are {ar['observed_process_threads_max']}/{mtp['observed_process_threads_max']}; "
           "the source adds no inference worker.")
replace('docs/PROGRESS.md','# Development progress\n\n',f'''# Development progress

## C17 schema publication passes matching GPU controls — 2026-10-06 UTC

The sealed `33d12a02` source builds coherent 102-file HIP ON/OFF providers and
private LIE/model/reference consumers. Actual Ninja compiler/linker blocks
verify the complete OFF reference selection. The unchanged 37 original-weight
OpenAI controls pass in each AR/MTP mode on `.161`, with server/child/controller/
supervisor exits 0. [GPU receipt](development/validation/c17-schema-compile-point-gpu-2026-10-06.json)
and [portable raw evidence](benchmarks/models/qwen3.8-flash-next/strix-point/data/rocm10-schema-compile-openai-r31.tar.gz)
retain source identity, telemetry and actual closure. HOST56 and all 29 previous
complete witness groups keep their separate scope. The official Gufo HTTP
frontend is retained source only, not built or qualified by this gate.
Typed construction/bootstrap/callback-error and model/controller remain
transitional. Integer-bound interval construction is a remaining C++ algorithm.
Broader branch/fault/probability/quality/private-resource/matched-cost and 1M
recall gates remain open. No new performance or reactive C1 gain is claimed.

{telemetry}
CPU98/NVMe85/lower guards and GPU observation remain unchanged. The local
read-location failure exits 2; the initial closure observer exits 1 because it
expected bundle absence after bundle creation. Both are retained; corrected
fresh closure passes, with no build/inference restart.
Fresh {c['at_utc']} closure verifies all three exact supervisor/container-init
identities retired, owned containers removed, HTTP8000 unbound, original lease
free then released, and router {c['service']['MainPID']} active/only KFD. Model/
predictor stats stay unchanged. All actual handles are collected. Root has no
remote job/client/build/lease/waiter/reservation; `.157/.158` remain unused.
No tuning, install, deployment or push occurs. All six owned tasks remain open;
Terminal Bench stays stopped/collected/closed/deferred last.

''')
replace('docs/COORDINATION.md','# DS4 / synapse-lie coordination\n\n',f'''# DS4 / synapse-lie coordination

## R31 schema publication build and selected GPU controls closed — 2026-10-06

Fresh peer own non-use and separate global preflights admit `33d12a02` on `.161`.
Device-free build and original-weight AR/MTP windows each hold the original
device66307/inode105946405 lease. Coherent HIP ON/OFF providers/private consumers
compile; AR37/MTP37 pass. All actual exits are 0; exact logs are collected and
SHA verified. [Receipt](development/validation/c17-schema-compile-point-gpu-2026-10-06.json).
The official Gufo HTTP frontend is not built; these controls do not qualify
independent numerical branches, quality, faults or performance.

Fresh {c['at_utc']} closure verifies all three exact supervisor/container-init
identities gone, owned containers removed, HTTP8000 unbound, lease free then
released and router {c['service']['MainPID']} restored/only KFD. Models retain
their stat identities. CPU98/NVMe85/lower guards and GPU observation stay intact.
Root has no remaining remote job/client/build/lease/waiter/reservation/handle;
`.157/.158` remain unused. This dated closure is not future admission. All six
tasks remain open; Terminal Bench stays stopped/collected/closed/deferred last.

''')
path='docs/development/TEST-COVERAGE-LONG-CONTEXT.md'
text=Path(path).read_text();start=text.index('Current implementation:');end=text.index('## Historical audit')
text=text[:start]+'''Current implementation exposes native, YaRN2 and YaRN4 profiles through
1,048,576 total tokens. Strix Point completes **1,048,448 physical prefill tokens
and 128 fixed output tokens** with explicit YaRN4 and `--ignore-eos`. The
[capacity/function receipt](validation/physical1m-fixed-point-gpu-2026-10-05.json)
records actual work, telemetry and retirement. The older natural-EOS43 failure
remains evidence. Independent long-context recall quality and matched repeated
Gufo/Halogen performance comparisons remain open.

The [current Point results](../benchmarks/models/qwen3.8-flash-next/strix-point/README.md)
include served concurrency and cold prefill through near 256K. The native
benchmark client and graphs require no Python. Selected original-weight OpenAI
controls pass 37 checks in each AR/MTP mode on the source-bound checkpoints;
the newest [C17 publication receipt](validation/c17-schema-compile-point-gpu-2026-10-06.json)
identifies its scope. Terminal Bench smoke passes 1/1; full Core-19 remains
stopped and deferred until functional modifications and their qualification
finish. See the [current roadmap](../BACKEND.md#current-roadmap--2026-10-06-utc).

The estimates and matrix below describe earlier checkpoints. In particular,
the old allocation estimate omits raw index history and must not be used for
current 1M memory admission.

'''+text[end:]
text=text.replace('http://192.168.5.157:8000/v1','http://192.168.5.161:8000/v1',1)
text=text.replace('''**This invocation is not currently executable against LIE's 256K backend.**
To exercise only its native point after ordinary GPU admission, use
`--sizes 258794 --context-capacity 262144 --rope-scaling native`.
Neither declaration reconfigures or independently verifies the server.''','''The server must be started with the declared context and YaRN profile, and its
deadline must cover the complete prefill/generation work. Physical 1M capacity
is qualified by the separate direct-core gate above; this HTTP command and its
repetitions have not been measured as a full 1M comparison. For the native point
use `--sizes 258794 --context-capacity 262144 --rope-scaling native`.
Client declarations do not reconfigure or independently verify the server.''',1)
updates[path]=text
for path,text in updates.items():Path(path).write_text(text)
print(json.dumps({'updated':list(updates),'source':r['source_commit'],'GPU_checks':[37,37],
                  'all_six_owned_tasks_open':True}))
