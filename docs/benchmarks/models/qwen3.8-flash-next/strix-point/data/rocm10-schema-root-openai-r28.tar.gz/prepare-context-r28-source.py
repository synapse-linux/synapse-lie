# SPDX-License-Identifier: MIT
"""Seal current owned source and official pins locally; no remote/GPU action."""
from pathlib import Path
import datetime,gzip,hashlib,json,shutil,subprocess,tarfile
root=Path.cwd();out=root/'evidence/context-source-modern-r28';archive=out.with_suffix('.tar.gz')
assert not out.exists() and not archive.exists()
assert not subprocess.check_output(['git','status','--porcelain'])
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert commit=='3c4cac569724cd4ca6351d55400526b1e2faee6b'
code_commit='3c4cac569724cd4ca6351d55400526b1e2faee6b'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
proof_path=root/'evidence/schema-root-final-validation-r1.json'
proof=json.loads(proof_path.read_text())
assert proof['HOST_only'] and not proof['GPU_qualified'] and proof['artifact_bindings']==973 and proof['actual_exit_code']==0
receipt=root/'docs/development/validation/c17-schema-root-host-2026-10-06.json'
assert sha(receipt)=='ddb1fae1b1e4db7d331487f9d69840b58f0261fbf90c51ff7d47c09535bae457'
host=json.loads(receipt.read_text())
assert host['coverage']['Release_focused_checks']==4 and host['coverage']['core_ASan_UBSan_LSan_focused_checks']==3 and host['coverage']['host_unique_passed_cumulatively']==51
assert host['coverage']['complete_witness_groups']==29 and host['coverage']['previous_complete_groups_unchanged']==28 and len(host['private_provider_inventory'])==96
assert host['state']=='HOST_QUALIFIED_NOT_GPU_QUALIFIED'
for name,digest in host['private_provider_inventory'].items():assert sha(root/name)==digest
for binding in host['sources']:
 p=root/binding['path'];assert p.stat().st_size==binding['bytes'] and sha(p)==binding['sha256'],p
ryu=json.loads((root/'third_party/ryu-source.json').read_text())
for name,b in ryu['files'].items():assert sha(root/'third_party/ryu'/name)==b['sha256']
source_tar=root/'evidence/context-r28-git-source.tar'
assert not source_tar.exists()
subprocess.run(['git','archive','--format=tar','--output='+str(source_tar),commit],check=True)
with tarfile.open(source_tar) as t:
 for member in t.getmembers():
  p=Path(member.name);assert not p.is_absolute() and '..' not in p.parts
  assert member.isfile() or member.isdir(),member.name
 out.mkdir();t.extractall(out,filter='data')
manifest=json.loads((out/'third_party/gufo-source.json').read_text())
assert manifest['commit']=='f783fedb9bea2ec7de941f6da4e02f4a4596b29e'
upstream=root/'.deps/gufo-f783fedb';assert not upstream.is_symlink()
for name,expected in manifest['files'].items():
 p=upstream/name;assert p.resolve().is_relative_to(upstream.resolve()) and not p.is_symlink() and sha(p)==expected
 target=out/'.deps/gufo-f783fedb'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);assert sha(target)==expected
prior_path=root/'evidence/context-r11-build-r2/result.json';prior=json.loads(prior_path.read_text())['build_result']
names={'zstd.h':'zstd_header_sha256','zstd_errors.h':'zstd_errors_sha256','LICENSE':'zstd_license_sha256'}
for name,key in names.items():
 p=root/'evidence/context-source-modern-r11/third_party/point-zstd-dev'/name
 assert p.is_file() and not p.is_symlink() and sha(p)==prior[key]
 target=out/'third_party/point-zstd-dev'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
(out/'SOURCE-COMMIT.txt').write_text(commit+'\n')
files=sorted(p for p in out.rglob('*') if p.is_file());assert all(not p.is_symlink() for p in files)
inventory=''.join(sha(p)+'  ./'+str(p.relative_to(out))+'\n' for p in files)
(out/'SOURCE-FILES.sha256').write_text(inventory)
with archive.open('xb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as t:t.add(out,arcname='context-source-modern-r28')
record={'scope':'LOCAL_SEALED_SOURCE_NOT_REMOTE_BUILD_OR_GPU','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':commit,'code_checkpoint':code_commit,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'source_files_sha256':sha(out/'SOURCE-FILES.sha256'),'source_files':len(files),'compile_helper_sha256':sha(out/'cmake/point/Build.cmake'),'gufo_pin':manifest['commit'],'pristine_gufo_files_verified':len(manifest['files']),'root_schema_host_receipt_sha256':sha(receipt),'doc_scope_proof_sha256':sha(proof_path),'zstd_prior_receipt_sha256':sha(prior_path),'zstd_development_sha256':{name:prior[key] for name,key in names.items()},'ryu_pin':ryu['commit'],'unchanged_Ryu_files_verified':len(ryu['files']),'provider_inventory_files_verified':len(host['private_provider_inventory']),'remote_stage_build_or_GPU_run':False,'all_six_tasks_remain_open':True}
with (root/'evidence/context-r28-source-seal.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record))
