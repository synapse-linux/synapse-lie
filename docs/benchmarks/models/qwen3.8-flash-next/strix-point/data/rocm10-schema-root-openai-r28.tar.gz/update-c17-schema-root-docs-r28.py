# SPDX-License-Identifier: MIT
"""Update existing documentation only after matching actual GPU controls close."""
from pathlib import Path
import json
r=json.loads(Path('docs/development/validation/c17-schema-root-point-gpu-2026-10-06.json').read_text())
assert r['state']=='PASSED_WITH_STATED_SCOPE' and len(r['runs'])==3
assert all(x['actual_exit_code']==0 and x['actual_window_retired'] for x in r['runs'])
a,m=r['runs'][1:]
assert a['checks']==m['checks']==37
closure=json.loads(Path(r['final_fresh_closure']['path']).read_text())['result']
def edit(n,old,new):
 p=Path(n);s=p.read_text();assert s.count(old)==1,(n,old);p.write_text(s.replace(old,new))
edit('README.md',"""Checkpoint `117cbae6`, including C17 request grammar snapshots and independent
speculative copies, passes
[37 OpenAI controls in both AR and MTP on Strix Point](docs/development/validation/c17-request-state-point-gpu-2026-10-06.json).
The later [C17 root schema admission](docs/development/C17-SAMPLING.md#root-schema-admission)
passes host checks; its matching GPU qualification is pending.
""","""The current [C17 grammar and root schema build](docs/development/C17-SAMPLING.md#root-schema-admission)
passes [37 OpenAI controls in both AR and MTP on Strix Point](docs/development/validation/c17-schema-root-point-gpu-2026-10-06.json).
""")
edit('docs/development/C17-SAMPLING.md',"""This increment needs its own sealed HIP build and original-weight qualification
on `.161`; the earlier `117cbae6` receipt excludes it. Remaining construction
facades/template projections and the model/controller are transitional.
""","""The matching sealed `3c4cac56` HIP build verifies both complete 96-file ON/OFF
providers and passes the unchanged 37 original-weight OpenAI controls in each
AR/MTP mode on `.161`
([GPU receipt](validation/c17-schema-root-point-gpu-2026-10-06.json)).
The host receipt retains its host-only scope; individual root GPU branches,
faults, resources, quality and matched cost remain open. Remaining construction
facades/template projections and the model/controller are transitional.
""")
edit('docs/BACKEND.md',"""   The new 96-file provider needs a matching sealed HIP build and original-weight
   qualification on `.161`; `117cbae6` excludes it. Private construction facades,
""","""   The matching sealed `3c4cac56` 96-file HIP build verifies complete ON/OFF
   providers and passes the unchanged 37 original-weight OpenAI controls in each
   AR/MTP mode on `.161`
   ([GPU receipt](development/validation/c17-schema-root-point-gpu-2026-10-06.json)).
   Individual root GPU branches, faults and matched cost remain open. Private construction facades,
""")
edit('CHANGELOG.md',"""  compilation callbacks. Original/OFF behavior is retained; host qualification
  is recorded separately from the pending matching GPU build.
""","""  compilation callbacks. Original/OFF behavior is retained; the matching
  96-file HIP build passes 37 selected original-weight OpenAI controls in each
  AR/MTP mode on Strix Point. Broader qualification and performance remain open.
""")
bench='docs/benchmarks/models/qwen3.8-flash-next/strix-point/README.md'
edit(bench,'### Original-weight HTTP AR and MTP gates\n\n',"""### Original-weight HTTP AR and MTP gates

The current matching `3c4cac56` build adds C17 root schema admission and passes
these same **37 controls in AR and MTP**. The
[source-bound receipt](../../../../development/validation/c17-schema-root-point-gpu-2026-10-06.json)
and [portable raw archive](data/rocm10-schema-root-openai-r28.tar.gz)
record the complete coherent 96-file ON/OFF providers, actual compiler/linker
selections, telemetry and closure. These qualify selected functional paths;
individual root GPU branches and matched performance remain open. The earlier
`117cbae6` C1 correctness controls below retain their own source identity.

""")
edit('docs/PROGRESS.md','## Root schema admission passes host checks — 2026-10-06 UTC','## Root schema admission passes host and selected GPU checks — 2026-10-06 UTC')
old="""This code needs its own sealed HIP build and original-weight qualification on
`.161`; the earlier `117cbae6`/r27 GPU receipt excludes it. Broader branches,
faults, probabilities, quality, private resources and matched cost remain open.
All six owned roadmap tasks remain open. Root has no current/planned/admitted
remote job/client/CPU/GPU/build/lease/waiter/reservation or live local handle.
"""
new="""The matching sealed `3c4cac56` build on `.161` verifies both complete 96-file
HIP providers, ON primary/OFF reference private consumers and all three OFF
numerical/core archives. It passes the unchanged 37 original-weight OpenAI
controls in each AR/MTP mode. The
[GPU receipt](development/validation/c17-schema-root-point-gpu-2026-10-06.json)
and [portable raw evidence](benchmarks/models/qwen3.8-flash-next/strix-point/data/rocm10-schema-root-openai-r28.tar.gz)
retain this qualification separately from the unchanged host receipt and r27.
No new direct C1 or performance measurement is recorded. The host root witness
is not coverage of every root branch on GPU.

"""
new+=f"AR/MTP CPU peaks are {a['peak_c']['k10temp']:g}/{m['peak_c']['k10temp']:g} C, GPU peaks {a['peak_c']['amdgpu']:g}/{m['peak_c']['amdgpu']:g} C and NVMe peaks\n{a['peak_c']['nvme']:g}/{m['peak_c']['nvme']:g} C. Recorded whole-process thread maxima are\n{a['observed_process_threads_max']}/{m['observed_process_threads_max']}; no inference worker is added. Fresh {closure['at_utc'][11:19]} UTC closure verifies\nall three exact supervisors/container-init identities retired, owned containers\nremoved, the original lease free then released, router {closure['service']['MainPID']} active/only KFD\nand HTTP8000 unbound. All server/child/supervisor/controller exits are 0; model\nand predictor stats are unchanged. An observer's exclusive local output-name\nrefusal is preserved with actual exit 1; its correction never restarts inference.\nBroader branches, faults, probabilities, quality, private resources and matched\ncost remain open. All six owned roadmap tasks remain open. Root has no remote\njob/client/CPU/GPU/build/lease/waiter/reservation or live local handle.\n"
edit('docs/PROGRESS.md',old,new)
print('Updated six existing documents after actual matching qualification; no new benchmark page/curve.')
