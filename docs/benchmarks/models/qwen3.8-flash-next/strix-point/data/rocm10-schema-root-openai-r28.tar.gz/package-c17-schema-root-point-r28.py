#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Package collected functional evidence; never weights, binaries or cache data."""
from pathlib import Path
import gzip
import hashlib
import json
import tarfile

def sha(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def bound(p):
    p = Path(p)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))

p = Path('docs/development/validation/c17-schema-root-point-gpu-2026-10-06.json')
r = json.loads(p.read_text())
assert r['source_commit'] == '3c4cac569724cd4ca6351d55400526b1e2faee6b'
assert r['state'] == 'PASSED_WITH_STATED_SCOPE' and len(r['compiled_provider_files']) == 96
assert [x['checks'] for x in r['runs'] if x['mode'] in ('ar', 'mtp')] == [37, 37]
assert all(x['actual_window_retired'] for x in r['runs'])
initial = Path('evidence/c17-schema-root-point-initial-receipt-r28.json')
with initial.open('xb') as f:
    f.write(p.read_bytes())
extras = [str(initial)] + [str(q) for q in sorted(Path('evidence/context-r28-build-observer-output-name-failure-r1').iterdir()) if q.is_file()]
for pattern in ('context-r28-*.json', 'context-r28-*.py', 'prepare-context-r28-source.py', 'stage-context-r28.py', 'collect-context-r28-compile.py', 'collect-context-r28-coherence.py', 'seal-context-r28-bundle.py', 'make-c17-schema-root-point-receipt-r28.py', 'package-c17-schema-root-point-r28.py', 'validate-c17-schema-root-point-r28-r1.py', 'update-c17-schema-root-docs-r28.py'):
    extras.extend(str(q) for q in sorted(Path('evidence').glob(pattern)) if q.is_file() and not q.is_symlink())
final = json.loads(Path('evidence/context-r28-mtp-closure-r1.json').read_text())
assert final['actual_exit_code'] == 0
f = final['result']
assert f['state'] == 'FRESH_BUILD_AR_MTP_WINDOWS_CLOSED_NO_STANDING_RESERVATION'
assert f['original_lease']['free_briefly'] and f['original_lease']['released']
assert not f['foreign_compute_clients'] and not f['http8000_listeners'] and not f['guarded_hot']
assert f['service']['MainPID'] == r['runs'][-1]['router_restored']['MainPID']
assert f['service']['ActiveState'] == 'active'
r['final_readonly_observation'] = [bound(name) for name in sorted(set(extras))]
r['initial_receipt_before_portable_packaging'] = bound(initial)
files = set(extras)
for run in r['runs']:
    files.update(a['path'] for a in run['artifacts'])
files.update(a['path'] for a in r['build_artifacts'])
for field in ('source_capsule', 'bundle', 'provider_build_receipt', 'reference_provider_build_receipt', 'actual_compiler_linker_coherence', 'build_closure'):
    files.add(r[field]['path'])
files.update(a['path'] for a in r['coordination'])
archive = Path('docs/benchmarks/models/qwen3.8-flash-next/strix-point/data/rocm10-schema-root-openai-r28.tar.gz')
assert not archive.exists()
with archive.open('xb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', mtime=0) as z:
        with tarfile.open(fileobj=z, mode='w') as t:
            for name in sorted(files):
                q = Path(name)
                assert q.is_file() and not q.is_symlink()
                info = t.gettarinfo(str(q), arcname=q.relative_to('evidence').as_posix())
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                with q.open('rb') as content:
                    t.addfile(info, content)
index = archive.parent / 'archives.sha256'
old = index.read_bytes()
assert old.endswith(b'\n') and archive.name.encode() not in old
with index.open('ab') as out:
    out.write((sha(archive) + '  ' + archive.name + '\n').encode())
r['portable_archive'] = bound(archive)
r['portable_archive_members'] = len(files)
r['archive_index_previous_bytes_sha256'] = hashlib.sha256(old).hexdigest()
r['archive_index_baseline_commit'] = '3c4cac569724cd4ca6351d55400526b1e2faee6b'
r['archive_index_appended_only'] = True
p.write_text(json.dumps(r, indent=2) + '\n')
print(json.dumps(dict(receipt_sha256=sha(p), archive=str(archive), archive_sha256=sha(archive),
                      archive_bytes=archive.stat().st_size, files=len(files),
                      GPU_checks=[37,37], final_closure_at=f['at_utc'])))
