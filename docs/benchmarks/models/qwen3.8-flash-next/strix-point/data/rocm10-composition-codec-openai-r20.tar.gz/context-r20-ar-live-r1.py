# SPDX-License-Identifier: MIT
"""Read-only observation of the exact already launched AR supervisor."""
from pathlib import Path
import hashlib,json,subprocess
program='''from pathlib import Path
import datetime,importlib.util,json,subprocess
root=Path('/home/pop/workspace/synapse-lie/context-r20-openai-auto-ar-r1')
r=json.loads((root/'result.json').read_text())
spec=importlib.util.spec_from_file_location('point',root/'runner.py');point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
try:atry:live=point.ticks(r['pid'])==r['start_ticks']
except FileNotFoundError:live=False
except FileNotFoundError:alive=False
fds=[]
if alive:
 for p in Path('/proc').joinpath(str(r['pid']),'fd').iterdir():
  try:
   s=p.stat()
   if (s.st_dev,s.st_ino)==(66307,105946405):fds.append(int(p.name))
  except FileNotFoundError:pass
p=root/'http-result.json';h=json.loads(p.read_text()) if p.exists() else None
row=point.observe(98,gpu_observation_only=True)
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'supervisor_pid':r['pid'],'supervisor_start_ticks':r['start_ticks'],'live_exact_supervisor':alive,'original_lease_fds':fds,'state':r['state'],'model_attempted':r.get('model_attempted'),'http_state':h.get('state') if h else None,'passed':h.get('passed',[]) if h else [],'observation':row,'new_GPU_job_build_or_restart':False}
result['active_owner_observed']=bool(alive and fds and r['state']=='ADMITTED')
print(json.dumps(result))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
p=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
r={'argv':argv,'actual_exit_code':p.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':p.stdout,'stderr':p.stderr}
try:r['result']=json.loads(p.stdout)
except ValueError:pass
with Path('evidence/context-r20-ar-live-r1.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in r.get('result',r).items() if k not in ('observation','stdout')}))
raise SystemExit(p.returncode)
