# SPDX-License-Identifier: MIT
"""Bind completed r20 original-weight gates and actual retirement, not task/performance scores."""
from pathlib import Path
import datetime,hashlib,json,subprocess

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def bound(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
commit='2077700583a7a129d17b36dbf7aa2ffbbdd7c994'
provider_path=Path('evidence/context-r20-build-r1/compile-evidence/build/rocm10-point-modern-r20-provider/BUILD-RECEIPT.json')
provider=json.loads(provider_path.read_text())
host_path=Path('docs/development/validation/c17-binary64-host-2026-10-06.json');host=json.loads(host_path.read_text())
assert provider['owned_sampling_files']==host['private_provider_inventory'] and len(provider['owned_sampling_files'])==83
runs=[]
for mode in ('build','ar','mtp'):
 label='context-r20-build-r1' if mode=='build' else f'context-r20-openai-auto-{mode}-r1'
 p=Path('evidence')/label;r=json.loads((p/'result.json').read_text());c=json.loads((p/'collection.json').read_text())
 m=json.loads((p/'manifest.json').read_text())
 assert r['state']=='PASSED' and r['exit_code']==r['child_exit_code']==c['exit_code']==0
 assert r['ended_at'] and r['lease_released_at'] and not r['cleanup_failures']
 assert m['source_commit']==commit and r['service_after']['ActiveState']=='active'
 assert all(c['inventory'][k] for k in ('supervisor_absent','gpu_child_absent','owned_child_absent','lease_free'))
 assert (r['lease']['device'],r['lease']['inode'])==(66307,105946405)
 assert set(r['postflight_before_restore']['kernel_kfd'])==set()
 rows=[json.loads(x) for x in (p/'telemetry.jsonl').read_text().splitlines()]
 peaks={}
 for row in rows:
  for t in row['temperatures']:peaks[t['name']]=max(peaks.get(t['name'],-100),t['value_c'])
 entry={'label':label,'mode':mode,'source_commit':commit,'started_at':r['started_at'],'ended_at':r['ended_at'],
        'supervisor_pid':r['pid'],'supervisor_start_ticks':r['start_ticks'],'original_lease':r['lease'],
        'lease_released_at':r['lease_released_at'],'actual_exit_code':0,'child_exit_code':0,
        'actual_owned_processes_retired':True,'KFD_empty_before_named_router_restore':True,
        'router_restored':r['service_after'],'peak_c':peaks,'files_sha_verified':len(c['inventory']['files']),
        'artifacts':[bound(p/name) for name in sorted(c['inventory']['files'])]+[bound(p/'collection.json'),bound(p/'controller-result.json')]}
 if mode!='build':
  h=json.loads((p/'http-result.json').read_text())
  assert h['state']=='PASSED' and h['server_exit_code']==0 and len(set(h['passed']))==len(h['passed'])==37
  assert r['model_stat_unchanged']
  entry.update(checks=37,passed=h['passed'],model_stat_unchanged=True,
               gtt_peak_bytes=max(row['gpu']['mem_info_gtt_used'] for row in rows if row['gpu']['mem_info_gtt_used'] is not None),
               observed_process_threads_max=max((int(proc['status']['Threads']) for row in rows for proc in row['dri'] if proc.get('status',{}).get('Threads')),default=None))
 else:assert not r['model_attempted']
 runs.append(entry)
source=json.loads(Path('evidence/context-r20-source-seal.json').read_text());assert source['source_commit']==commit
bundle=json.loads(Path('evidence/context-r20-bundle-result.json').read_text());assert bundle['exit_code']==0 and bundle['result']['metadata']['source_commit']==commit
receipt={'schema':'synapse-lie.c17-binary64-point-original-qualification.v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'PASSED_WITH_STATED_SCOPE','source_commit':commit,'code_checkpoint':commit,'target':'pop@192.168.5.161','gpu_target':'gfx1150',
 'model':'Qwen3.8-Flash-Next UD-Q4_K_XL','upstream_pin':provider['source_pin'],
 'scope':'Matching sealed default-ON 83-file shared C17 reasoning/tool grammar composition and binary64 JSON conversion provider/application build (71 first-party + 12 vendor/provenance files) followed by unchanged37 original-weight OpenAI wire/lifecycle/tool/grammar/output controls in AR/MTP. Selected integrated paths only: these controls do not cover individual numeric/format branches, new SSD BPE or independent probability/fault/quality/allocation-exact/matched-cost gates. No CPU model forward or Terminal Bench score.',
 'host_receipts':[bound(host_path),bound('docs/development/validation/c17-composition-host-2026-10-06.json'),bound('docs/development/validation/c17-schema-number-host-2026-10-06.json'),bound('docs/development/validation/c17-schema-format-host-2026-10-06.json'),bound('docs/development/validation/release-cache-host-2026-10-05.json'),bound('docs/development/validation/c17-schema-body-host-2026-10-05.json'),bound('docs/development/validation/c17-schema-visit-host-2026-10-05.json'),bound('docs/development/validation/c17-schema-dispatch-host-2026-10-05.json'),bound('docs/development/validation/c17-schema-memo-host-2026-10-05.json')],
 'source_capsule':bound('evidence/context-r20-source-seal.json'),'bundle':bound('evidence/context-r20-bundle-result.json'),
 'provider_build_receipt':bound(provider_path),'compiled_provider_files':provider['owned_sampling_files'],'compiled_first_party_file_count':71,'compiled_vendor_and_provenance_file_count':12,'Ryu_pin':'4c0618b0e44f7ef027ebae05d2cc7812048f7c8f',
 'build_closure':bound('evidence/context-r20-build-closure-r2.json'),'coordination':bound('evidence/context-r20-thread-handover.json'),
 'runs':runs,'build_artifacts':[bound(p) for p in sorted(Path('evidence/context-r20-build-r1/compile-evidence').rglob('*')) if p.is_file()],
 'binaries':bundle['result']['metadata']['artifacts'],'new_inference_threads':0,'KV_cache_payload_format_changed':False,'existing_public_ABI_breaking_change':False,'new_contracts':['lie/grammar_composition.h ABI1','lie/binary64.h ABI1'],
 'thermal_policy':'CPU98/NVMe85/lower exposed guards; GPU temperature observed only. No fan/clock/power tuning.',
 'root_157_non_use':True,'Terminal_Bench':'Stopped/collected/closed; deferred until functional modifications and matching qualification finish. No restart/reservation.',
 'retained_failed_build':bound('evidence/context-r17-build-r1/result.json'),
 'retained_historical_observer_failures':[bound('evidence/context-r19-build-closure-r1.json'),bound('evidence/context-r19-ar-live-r1.json')],
 'retained_receipt_bookkeeping_failures':[bound('evidence/context-r20-receipt-packaging-failure-r1.json')],
 'retained_current_observer_failures':[bound('evidence/context-r20-ar-live-r1.json'),bound('evidence/context-r20-ar-live-r1.py')],
 'corrected_same_AR_owner_observation':[bound('evidence/context-r20-ar-live-r2.json'),bound('evidence/context-r20-ar-live-r2.py')],
 'previous_matching_GPU_receipt':bound('docs/development/validation/c17-schema-policy-point-gpu-2026-10-06.json'),
 'retained_unresolved_failure':host['retained_unresolved_failure'],
 'all_six_owned_tasks_open':True,
 'pending':['Deferred full TerminalBench final task rewards/transcripts/closure after functional changes.',
            '1M recall quality and matched Gufo/Halogen physical-work depth/concurrency/cache/thread/resource/graphs.',
            'Nonzero original-weight steering graph/correction/invalidation/AR-MTP-vision/cache quality/cost and later mixed-history lookup.',
            'Independent GPU sampling probability/filter/tool-transition coverage and matched cost beyond seeded replay.',
            'Typed JSON/key/value containers, full lexer/predicates/model/controller extraction; individual numeric/format GPU branches/faults/allocation-exact resources and matched cost.',
            'New original-weight SSD BPE saved-token reconstruction and scheduled-token-index regression.'],
 'final_fresh_closure':bound('evidence/context-r20-final-161-r1.json'),'publication':False,'goal_complete':False}
p=Path('docs/development/validation/c17-binary64-point-gpu-2026-10-06.json')
with p.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'receipt':str(p),'sha256':sha(p),'GPU_controls':[37,37],'compiled_provider_file_count':83,'actual_runs_collected_and_retired':len(runs)}))
