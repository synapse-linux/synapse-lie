#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Package only completed original-weight steering runs and their actual witnesses."""
import datetime
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile


def load(path):
    return json.loads(Path(path).read_bytes())


def bound(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


spec = importlib.util.spec_from_file_location('gate', 'tools/strix-point-steering-restart-gate.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
qa_commit = '353ab973fc6bdabd0937f75ed0485d4b0bd6c6b4'
source = load('docs/development/validation/c17-binary64-point-gpu-2026-10-06.json')
for name, sha in source['compiled_provider_files'].items():
    assert bound(name)['sha256'] == sha, name
closure = load('evidence/context-r22-final-161-r1.json')
assert closure['actual_exit_code'] == 0
closed = closure['result']
assert len(closed['owned_window_closures']) == 2
assert closed['original_lease']['free_briefly'] and closed['original_lease']['released']
assert not any(closed[key] for key in ('foreign_compute_clients', 'guarded_hot', 'http8000_listeners',
                                     'standing_lease_waiter_reservation'))
files, runs = set(), []
for mode in ('ar', 'mtp'):
    root = Path('evidence/context-r22-steering-' + mode + '-r1')
    run, result, collection = (load(root / name) for name in ('result.json', 'steering-restart-result.json', 'collection.json'))
    assert run['state'] == result['state'] == 'PASSED' and run['exit_code'] == run['child_exit_code'] == 0
    assert run['ended_at'] and run['lease_released_at'] and run['model_stat_unchanged'] and not run['cleanup_failures']
    assert collection['exit_code'] == 0 and all(collection['inventory'][key] for key in
           ('supervisor_absent', 'gpu_child_absent', 'owned_child_absent', 'lease_free'))
    assert [proc['phase'] for proc in result['processes']] == list(gate.PHASES)
    assert all(proc['exit_code'] == 0 for proc in result['processes'])
    assert result['mode'] == mode
    bank = result['bank']
    assert (root / 'steering.f32').read_bytes() == gate.bank_bytes(bank['layers'], bank['width'])
    assert bound(root / 'steering.f32')['sha256'] == bank['sha256']
    observations = {}
    for phase in gate.PHASES:
        raw = (root / ('measurements-' + phase + '.jsonl')).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == result[phase + '_sha256']
        observations[phase] = gate.parse([json.loads(line) for line in raw.splitlines()], mode, phase, bank, result['steps'])
    compared = gate.compare(observations)
    assert all(result[key] == value for key, value in compared.items())
    peaks, threads, gtt = {}, 0, 0
    for line in (root / 'telemetry.jsonl').read_text().splitlines():
        row = json.loads(line)
        for sensor in row['temperatures']:
            peaks[sensor['name']] = max(peaks.get(sensor['name'], -40), sensor['value_c'])
            if sensor['guarded']:
                assert sensor['value_c'] < sensor['limit_c']
        for process in row['dri']:
            value = process.get('status', {}).get('Threads', '')
            if value.isdecimal():
                threads = max(threads, int(value))
        gtt = max(gtt, row.get('gpu', {}).get('mem_info_gtt_used', 0))
    artifacts = []
    for name, identity in collection['inventory']['files'].items():
        entry = bound(root / name)
        assert entry['sha256'] == identity['sha256'] and entry['bytes'] == identity['bytes']
        artifacts.append(entry)
        files.add(entry['path'])
    for name in ('plan.json', 'controller-result.json', 'controller-stdout.log', 'controller-stderr.log', 'collection.json'):
        entry = bound(root / name)
        files.add(entry['path'])
        artifacts.append(entry)
    runs.append({'label': root.name, 'mode': mode, 'actual_exit_code': run['exit_code'],
                 'child_exit_code': run['child_exit_code'], 'started_at': run['started_at'], 'ended_at': run['ended_at'],
                 'lease_released_at': run['lease_released_at'], 'supervisor_pid': run['pid'],
                 'supervisor_start_ticks': run['start_ticks'], 'router_restored': run['service_after'],
                 'model_predictor_stats_unchanged': run['model_stat_unchanged'], 'artifacts': artifacts,
                 'bank': bank, 'processes': result['processes'], 'steps': result['steps'],
                 'scheduled_jobs': result['scheduled_jobs'], 'comparison': compared,
                 'temperature_peaks_c': peaks, 'whole_process_threads_max': threads, 'GTT_peak_bytes': gtt,
                 'load_to_ready_ns': {phase: observations[phase]['core_ready']['load_to_ready_ns'] for phase in gate.PHASES}})
assert closed['service']['MainPID'] == runs[-1]['router_restored']['MainPID']
cross_mode = load('evidence/context-r22-cross-mode-r1.json')
for phase in gate.SCHEDULED:
    assert all(cross_mode['cases'][phase].values())
    assert runs[0]['scheduled_jobs'][phase]['output_ids'] == runs[1]['scheduled_jobs'][phase]['output_ids']
    assert runs[0]['scheduled_jobs'][phase]['steering_schedule'] == runs[1]['scheduled_jobs'][phase]['steering_schedule']
host_receipt = Path('docs/development/validation/steering-restart-host-2026-10-06.json')
host = load(host_receipt)
for entry in host['bindings']:
    assert bound(entry['path']) == entry
files.update(entry['path'] for entry in host['bindings'] if entry['path'].startswith('evidence/'))
extras = sorted(str(path) for path in Path('evidence').glob('context-r22-*') if path.is_file() and path.suffix in ('.json', '.py'))
extras += ['evidence/package-steering-point-r22.py', 'evidence/observe-context-r22-steering.py']
files.update(extras)
source_entries = {}
for entry in host['bindings']:
    if not entry['path'].startswith(('tools/', 'tests/')):
        continue
    raw = subprocess.run(['git', 'show', qa_commit + ':' + entry['path']], capture_output=True, check=True).stdout
    assert hashlib.sha256(raw).hexdigest() == entry['sha256']
    source_entries['qa-source/' + qa_commit[:8] + '/' + entry['path']] = raw
archive = Path('docs/benchmarks/models/qwen3.8-flash-next/strix-point/data/rocm10-steering-physical-index-r22.tar.gz')
assert not archive.exists()
with archive.open('xb') as output, gzip.GzipFile(fileobj=output, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
    for name in sorted(files):
        path = Path(name)
        assert path.is_file() and not path.is_symlink()
        info = tar.gettarinfo(name, arcname=path.relative_to('evidence').as_posix())
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        info.mtime = 0
        with path.open('rb') as content:
            tar.addfile(info, content)
    for name, raw in sorted(source_entries.items()):
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        tar.addfile(info, io.BytesIO(raw))
index = archive.parent / 'archives.sha256'
old_index = index.read_bytes()
baseline = subprocess.run(['git', 'show', qa_commit + ':' + index.as_posix()], capture_output=True, check=True).stdout
assert baseline == old_index and old_index.endswith(b'\n') and archive.name.encode() not in old_index
with index.open('ab') as output:
    output.write((bound(archive)['sha256'] + '  ' + archive.name + '\n').encode())
receipt = {'schema': 'synapse-lie.steering-physical-index-point-original.v1',
           'state': 'SELECTED_STEERING_PHYSICAL_INDEX_CASES_QUALIFIED',
           'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'target': 'pop@192.168.5.161', 'GPU_architecture': 'gfx1150', 'source_commit': source['source_commit'],
           'QA_source_commit': qa_commit,
           'scope': 'Original-weight AR/MTP shared core keeps fresh physical input indices with a declared nonzero sparse-fixture plan, refuses divergent SSD spelling and restores only the compatible128-token prefix before the first unapplied step. Three exact prefill/generation changes, exact cold/SSD confirmed outputs and final policy histories. Not learned DS4 direction quality, independent numeric/graph invalidation/correction oracle, vision, later mixed-history lookup or matched performance.',
           'previous_matching_GPU_receipt': bound('docs/development/validation/c17-binary64-point-gpu-2026-10-06.json'),
           'previous_SSD_text_receipt': bound('docs/development/validation/ssd-text-restart-point-gpu-2026-10-06.json'),
           'host_receipt': bound(host_receipt), 'host_receipt_source_commit': qa_commit,
           'host_gate_tests': 18, 'campaign_host_tests': 60, 'runs': runs,
           'selected_greedy_AR_MTP_output_and_policy_equal': True,
           'offline_cross_mode_comparison': bound('evidence/context-r22-cross-mode-r1.json'),
           'coordination_and_observations': [bound(path) for path in extras],
           'final_closure': bound('evidence/context-r22-final-161-r1.json'),
           'portable_archive': bound(archive), 'portable_archive_members': len(files) + len(source_entries),
           'archive_index_baseline_commit': qa_commit, 'archive_index_previous_bytes_sha256': hashlib.sha256(old_index).hexdigest(),
           'archive_index_appended_only': True, 'new_GPU_build': False, 'new_inference_threads': 0,
           'runtime_ABI_format_or_product_dependency_changed': False,
           'root_157_non_use': True, 'Terminal_Bench': 'Stopped/closed/deferred until modifications and qualification finish; no reservation.',
           'all_six_owned_tasks_open': True, 'goal_complete': False, 'publication': False}
path = Path('docs/development/validation/steering-physical-index-point-gpu-2026-10-06.json')
assert not path.exists()
path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt': bound(path), 'archive': bound(archive), 'members': receipt['portable_archive_members'],
                  'states': [receipt['state'], *[run['actual_exit_code'] for run in runs]]}))
