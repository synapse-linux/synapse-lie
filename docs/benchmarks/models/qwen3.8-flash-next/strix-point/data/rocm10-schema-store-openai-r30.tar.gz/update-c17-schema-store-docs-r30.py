#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Publish only the scope proved by the collected r30 GPU receipt."""
from pathlib import Path
import json

receipt_path = Path('docs/development/validation/c17-schema-store-point-gpu-2026-10-06.json')
r = json.loads(receipt_path.read_text())
assert r['source_commit'] == '72e9e831d50781ff1f87f522cdf7f9e673f3c8c4'
assert r['state'] == 'PASSED_WITH_STATED_SCOPE'
assert len(r['compiled_provider_files']) == 99
assert len(r['runs']) == 3 and all(x['actual_window_retired'] for x in r['runs'])
assert [x['checks'] for x in r['runs'] if x['mode'] != 'build'] == [37, 37]
assert r['all_six_owned_tasks_open'] and not r['goal_complete']
c = json.loads(Path(r['final_fresh_closure']['path']).read_text())['result']
assert c['state'] == 'FRESH_BUILD_AR_MTP_WINDOWS_CLOSED_NO_STANDING_RESERVATION'
ar, mtp = r['runs'][1:]
gpu = 'development/validation/c17-schema-store-point-gpu-2026-10-06.json'
raw = 'benchmarks/models/qwen3.8-flash-next/strix-point/data/rocm10-schema-store-openai-r30.tar.gz'
assert Path('docs', raw).is_file()

updates = {}
def replace(path, old, new):
    text = updates.get(path, Path(path).read_text())
    assert text.count(old) == 1, (path, old)
    updates[path] = text.replace(old, new, 1)

replace('README.md',
'''The current [C17 grammar build](docs/development/C17-SAMPLING.md#immutable-grammar-table-ownership)
passes [37 OpenAI controls in both AR and MTP on Strix Point](docs/development/validation/c17-grammar-storage-point-gpu-2026-10-06.json).''',
'''The current [C17 schema build](docs/development/C17-SAMPLING.md#derived-schema-value-ownership)
passes [37 OpenAI controls in both AR and MTP on Strix Point](docs/development/validation/c17-schema-store-point-gpu-2026-10-06.json).''')
replace('README.md',
'''Derived schema values and transformation staging also have
[C17 ownership with HOST validation](docs/development/C17-SAMPLING.md#derived-schema-value-ownership);
their matching GPU qualification is pending.''',
'''Derived schema values and transformation staging also have
[C17 ownership](docs/development/C17-SAMPLING.md#derived-schema-value-ownership),
with matching HOST and selected original-weight GPU controls.''')
replace('CHANGELOG.md',
'''  retirement. HOST lifetime and complete original/default-ON/OFF comparisons pass;
  matching GPU qualification is pending. Existing C17 option preserves the
  original OFF compiler path.''',
'''  retirement. HOST lifetime and complete original/default-ON/OFF comparisons pass;
  the matching HIP build passes 37 selected original-weight OpenAI controls in
  both AR and MTP on Strix Point. Existing C17 option preserves the original
  OFF compiler path; broader quality, resource and cost gates remain open.''')
replace('docs/development/C17-SAMPLING.md',
'''GPU speed nor a complete C17 frontend/model executor. The older `ad53e681`/r29
GPU receipt excludes this increment; matching HIP/original-weight checks remain
pending. Existing reactive worker/thread counts and default dependencies remain
unchanged. Terminal Bench is deferred until functional modifications and
qualification finish.''',
'''GPU speed nor a complete C17 frontend/model executor. The matching `72e9e831`
build verifies coherent 99-file HIP ON/OFF providers and private model/frontend
consumers. It passes the unchanged 37 selected original-weight OpenAI controls
in each AR/MTP mode on `.161`
([GPU receipt](validation/c17-schema-store-point-gpu-2026-10-06.json)).
The older `ad53e681`/r29 receipt retains its separate identity. Broader compiler
branches, faults, quality, private resource accounting and matched cost remain
open. Existing reactive workers and default dependencies are unchanged;
Terminal Bench is deferred until functional modifications and qualification finish.''')
replace('docs/BACKEND.md',
'''   guarded. Matching HIP/original-weight qualification for this increment is
   pending; compiler orchestration/typed facades/model ownership remain open.''',
'''   guarded. Matching sealed `72e9e831` coherent 99-file HIP ON/OFF providers
   and private consumers pass unchanged AR37/MTP37 original-weight controls
   ([GPU receipt](development/validation/c17-schema-store-point-gpu-2026-10-06.json)).
   Compiler orchestration/typed facades/model ownership and broader branch,
   fault, quality, private-resource and matched-cost gates remain open.''')
replace('docs/development/protocols/DS4-SAMPLING-GPU-PROTOCOL.md',
'''records parser, ABI, retained options and report compatibility. Actual GPU
qualification remains pending until `.161` is available and a new source/binary
identity is sealed and admitted.''',
'''records parser, ABI, retained options and report compatibility. The integrated
`1bff953` runtime completes two seeded PP1500/TG128 sessions for greedy AR and
the declared profile in AR/MTP on `.161`
([selected GPU evidence](../validation/c17-sampling-point-gpu-2026-10-05.json)).
That proves selected fixed-output/replay and actual MTP draft/acceptance controls.
Independent probability/filter/tool-transition and matched-cost gates above
remain open; the recorded source does not qualify later binaries automatically.''')

replace('docs/benchmarks/models/qwen3.8-flash-next/strix-point/README.md',
'''The current matching `ad53e681` build removes duplicate C++ grammar rule/class''',
'''The current matching `72e9e831` build adds C17 ownership of derived schema
values and transformation staging. It passes the unchanged **37 controls in AR
and MTP**. The
[source-bound receipt](../../../../development/validation/c17-schema-store-point-gpu-2026-10-06.json)
and [portable raw evidence](data/rocm10-schema-store-openai-r30.tar.gz)
record coherent 99-file HIP ON/OFF providers, matching private consumers,
telemetry and actual closure. These are selected functional controls, with no
new throughput measurement or graph. HOST lifetime and complete grammar
witnesses retain their separate scope.

The preceding matching `ad53e681` build removes duplicate C++ grammar rule/class''')

telemetry = (f"AR/MTP CPU maxima are {ar['peak_c']['k10temp']}/{mtp['peak_c']['k10temp']} C, "
             f"GPU {ar['peak_c']['amdgpu']}/{mtp['peak_c']['amdgpu']} C and NVMe "
             f"{ar['peak_c']['nvme']}/{mtp['peak_c']['nvme']} C. Whole-process thread "
             f"maxima are {ar['observed_process_threads_max']}/{mtp['observed_process_threads_max']}; "
             "no inference worker is added.")
progress = f'''## C17 derived schema roots pass matching GPU controls — 2026-10-06 UTC

The sealed `72e9e831` source compiles coherent 99-file HIP ON/OFF providers and
matching private model/frontend consumers. Actual Ninja commands verify the
whole OFF reference linkage. The new build passes the unchanged 37
original-weight OpenAI controls in each AR/MTP mode on `.161`, with all
server/child/controller/supervisor exits 0. The
[GPU receipt]({gpu}) and [portable raw evidence]({raw}) retain actual runs,
source identities and closure. These selected controls complement the frozen
HOST54 and 29 complete unchanged witness groups; they do not prove every
compiler branch, quality, faults, private resources or performance. Remaining
compiler orchestration, typed construction/errors/prompt and model/controller
are transitional.

{telemetry}
CPU98/NVMe85/lower guards and GPU observation remain intact. The initial
build-log collector selected the wrong kind and exits 1; its metadata is
retained and the corrected collection exits 0. No build or inference rerun
results from that collection error.

Fresh {c['at_utc']} closure verifies all three exact supervisor/container-init
identities retired, owned containers removed, HTTP8000 unbound, original lease
free then released and router {c['service']['MainPID']} active/only KFD.
Model/predictor stats remain unchanged. Root has no remote job/client/build/
lease/waiter/reservation or live local handle; `.157/.158` remain unused.
No tuning, install, deployment or push occurs. All six owned tasks remain open;
Terminal Bench stays stopped/collected/closed/deferred last until functional
modifications and matching qualification finish.

'''
replace('docs/PROGRESS.md', '# Development progress\n\n', '# Development progress\n\n' + progress)
coordination = f'''## R30 derived schema root build and selected controls closed — 2026-10-06

Fresh peer own non-use and separate global preflights admit sealed `72e9e831`
on `.161`. The device-free build verifies coherent 99-file HIP ON/OFF providers,
matching private consumers and whole OFF reference linkage. Original-weight
AR/MTP each pass 37 unchanged OpenAI controls. All three windows have actual
server/child/controller/supervisor exits 0 and SHA-verified collected files.
[Receipt]({gpu}). The initial wrong-kind log collection exits 1 and is retained;
corrected collection exits 0, without a build/inference restart.

Fresh {c['at_utc']} closure independently verifies exact supervisor/container-init
retirement, owned containers removed, HTTP8000 unbound, original lease device
66307/inode105946405 briefly free then released, and router
{c['service']['MainPID']} restored/only KFD. No foreign client or hot guard is
observed. Models remain stat-bound unchanged. CPU98/NVMe85/lower guards and GPU
observation remain active; no tuning, install, deployment or root `.157/.158`
work occurs. Root has no standing remote job/client/build/lease/waiter/
reservation or live local handle. This dated closure is not future admission.
Peer work stays separately owned. All six tasks remain open; Terminal Bench
stays stopped/collected/closed/deferred last, without restart or reservation.

'''
replace('docs/COORDINATION.md', '# DS4 / synapse-lie coordination\n\n',
        '# DS4 / synapse-lie coordination\n\n' + coordination)
for path, text in updates.items():
    Path(path).write_text(text)
print(json.dumps({'updated': list(updates), 'source': r['source_commit'],
                  'GPU_checks': [37, 37], 'all_six_owned_tasks_open': True}))
