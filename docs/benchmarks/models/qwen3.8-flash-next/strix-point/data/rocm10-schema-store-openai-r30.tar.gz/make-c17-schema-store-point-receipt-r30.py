#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Bind actual collected matching GPU controls; never fabricate terminal state."""
from pathlib import Path
import datetime
import hashlib
import json

COMMIT = '72e9e831d50781ff1f87f522cdf7f9e673f3c8c4'
BASE = Path('evidence')
HOST = Path('docs/development/validation/c17-schema-store-host-2026-10-06.json')

def load(path):
    return json.loads(Path(path).read_text())

def sha(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

def bound(path):
    p = Path(path)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))

host = load(HOST)
assert sha(HOST) == '0ba676e49636fbff25473bbdc41582b4af7ff802b3a6057f316b430bab93708c'
build = BASE/'context-r30-build-r1'
provider_paths = [build/f'compile-evidence/build/rocm10-point-modern-r30-{selector}/BUILD-RECEIPT.json'
                  for selector in ('provider', 'reference-provider')]
providers = [load(p) for p in provider_paths]
for provider, selected in zip(providers, (True, False)):
    assert provider['owned_sampling_files'] == host['private_provider_inventory']
    assert len(provider['owned_sampling_files']) == 99
    assert provider['c17_sampling'] is selected and provider['hip_architecture'] == 'gfx1150'
    assert provider['grammar_storage_edits_sha256'] == sha('adapters/gufo-state/grammar-storage-edits.json')
    assert provider['schema_store_edits_sha256'] == sha('adapters/gufo-state/schema-store-edits.json')
assert load(build/'compile-evidence/collection.json')['exit_code'] == 0
assert load(build/'compile-evidence/collection.json')['reference_control_coherent_off']
coherence = load(build/'coherence-evidence/collection.json')
assert coherence['exit_code'] == 0 and coherence['whole_OFF_reference_archives']
assert coherence['compiled_frontend_primary_C17_ON'] and coherence['compiled_frontend_reference_C17_OFF']

labels = [('build', 'context-r30-build-r1'), ('ar', 'context-r30-openai-auto-ar-r1'),
          ('mtp', 'context-r30-openai-auto-mtp-r1')]
runs = []
direct = {}
for mode, label in labels:
    p = BASE/label
    r, c, m = load(p/'result.json'), load(p/'collection.json'), load(p/'manifest.json')
    controller = load(p/'controller-result.json')
    assert r['state'] == 'PASSED' and r['exit_code'] == r['child_exit_code'] == c['exit_code'] == controller['exit_code'] == 0
    assert r['ended_at'] and r['lease_released_at'] and not r['cleanup_failures']
    assert m['source_commit'] == COMMIT and r['service_after']['ActiveState'] == 'active'
    assert (r['lease']['device'], r['lease']['inode']) == (66307, 105946405)
    assert not r['postflight_before_restore']['kernel_kfd']
    rows = [json.loads(x) for x in (p/'telemetry.jsonl').read_text().splitlines()]
    peaks = {}
    for row in rows:
        for t in row['temperatures']:
            peaks[t['name']] = max(peaks.get(t['name'], -100), t['value_c'])
            if t['guarded']:
                assert t['value_c'] < t['limit_c']
    for name, identity in c['inventory']['files'].items():
        assert sha(p/name) == identity['sha256'] and (p/name).stat().st_size == identity['bytes']
    entry = dict(label=label, mode=mode, source_commit=COMMIT,
                 started_at=r['started_at'], ended_at=r['ended_at'],
                 supervisor_pid=r['pid'], supervisor_start_ticks=r['start_ticks'],
                 original_lease=r['lease'], lease_released_at=r['lease_released_at'],
                 actual_exit_code=r['exit_code'], child_exit_code=r['child_exit_code'],
                 controller_exit_code=controller['exit_code'],
                 KFD_empty_before_named_router_restore=True,
                 router_restored=r['service_after'], peak_c=peaks,
                 container_name=r['container'], files_sha_verified=len(c['inventory']['files']),
                 artifacts=[bound(p/name) for name in sorted(c['inventory']['files'])]
                           + [bound(p/'collection.json'), bound(p/'controller-result.json')])
    if mode == 'build':
        assert not r['model_attempted']
        assert r['build_result']['reference_control_coherent_off']
    else:
        assert r['model_attempted'] and r['model_stat_unchanged']
        entry.update(model_stat_unchanged=True,
                     gtt_peak_bytes=max(row['gpu']['mem_info_gtt_used'] for row in rows
                                        if row['gpu']['mem_info_gtt_used'] is not None),
                     observed_process_threads_max=max((int(proc['status']['Threads'])
                         for row in rows for proc in row['dri']
                         if proc.get('status', {}).get('Threads')), default=None))
        if mode in ('ar', 'mtp'):
            h = load(p/'http-result.json')
            assert h['state'] == 'PASSED' and h['server_exit_code'] == 0
            assert len(set(h['passed'])) == len(h['passed']) == 37
            entry.update(checks=37, passed=h['passed'], server_exit_code=0)
        else:
            measurements = [json.loads(x) for x in (p/'measurements.jsonl').read_text().splitlines()]
            assert measurements[-1] == dict(event='complete', exit_code=0)
            inputs = [x for x in measurements if x.get('event') == 'input']
            samples = [x for x in measurements if x.get('event') == 'sample']
            assert len(inputs) == len(samples) == 2
            assert [x['depth'] for x in samples] == [0, 4096]
            assert all(x['users'] == 1 and x['rep'] == x['warmup'] == 0
                       and x['finite_frontiers'] and x['prefill_ns'] > 0 and x['decode_ns'] > 0
                       and x['output_tokens_per_user'] == len(x['output_ids']) for x in samples)
            direct[mode] = dict(identity=measurements[0], inputs=inputs, samples=samples)
            entry.update(direct_control=direct[mode], checks=None, performance_qualification=False)
    runs.append(entry)
assert runs[1]['passed'] == runs[2]['passed']
pair = []

final_path = BASE/'context-r30-mtp-closure-r1.json'
final = load(final_path)
assert final['actual_exit_code'] == 0
f = final['result']
assert f['state'] == 'FRESH_BUILD_AR_MTP_WINDOWS_CLOSED_NO_STANDING_RESERVATION'
assert f['original_lease']['free_briefly'] and f['original_lease']['released']
assert not f['foreign_compute_clients'] and not f['http8000_listeners'] and not f['guarded_hot']
assert len(f['owned_window_closures']) == len(runs) == 3
for entry, closure in zip(runs, f['owned_window_closures']):
    assert closure['label'] == entry['label'] and closure['supervisor_identity_absent']
    assert closure['container_absent'] and closure['label_listing_exit'] == 0 and closure['label_listing_empty']
    assert closure['container_init_identity_recorded'] and closure['container_init_identity_absent'] is True
    entry.update(actual_window_retired=True, actual_supervisor_identity_absent=True,
                 container_init_identity_recorded=True, container_init_identity_absent=True,
                 container_init_pid=closure['container_init_pid'],
                 container_init_start_ticks=closure['container_init_start_ticks'],
                 container_init_identity_source=closure['container_identity_source'])

source = load(BASE/'context-r30-source-seal.json')
bundle = load(BASE/'context-r30-bundle-result.json')
assert source['source_commit'] == COMMIT and bundle['exit_code'] == 0
assert bundle['result']['metadata']['source_commit'] == COMMIT
receipt = dict(
    schema='synapse-lie.c17-schema-store-point-original-qualification.v1',
    at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), state='PASSED_WITH_STATED_SCOPE',
    source_commit=COMMIT, code_checkpoint=COMMIT, target='pop@192.168.5.161', gpu_target='gfx1150',
    model='Qwen3.8-Flash-Next UD-Q4_K_XL', upstream_pin=providers[0]['source_pin'],
    scope='Matching sealed99-file shared C17 derived schema root collection for per-compilation values and transformation/normalization staging. Two exact OFF guards preserve original compiler Store/member algorithms; full HIP ON/OFF providers/model/frontend consumers rebuilt coherently. Unchanged37 original-weight OpenAI controls in each AR/MTP mode. HOST54 sanitizer tests, 29 complete unchanged witness groups/258files and zero-clone lifecycle/refusal controls remain separate, not complete GPU branch/throughput proof. Remaining compiler orchestration/typed construction/errors/prompt and model/controller are transitional. No new direct/performance, fault/independent probability/learned quality/private allocation cost/1M recall/whole autonomous C engine claim.',
    host_receipts=[bound(HOST)], source_capsule=bound(BASE/'context-r30-source-seal.json'),
    bundle=bound(BASE/'context-r30-bundle-result.json'),
    provider_build_receipt=bound(provider_paths[0]), reference_provider_build_receipt=bound(provider_paths[1]),
    actual_compiler_linker_coherence=bound(build/'coherence-evidence/collection.json'),
    compiled_provider_files=providers[0]['owned_sampling_files'], compiled_first_party_file_count=87,
    compiled_vendor_and_provenance_file_count=12,
    grammar_storage_recipe_sha256=providers[0]['grammar_storage_edits_sha256'],
    schema_store_recipe_sha256=providers[0]['schema_store_edits_sha256'],
    reference_control_coherent_off=True, selected_complete_direct_controls=pair,
    build_closure=bound(BASE/'context-r30-build-closure-r1.json'),
    coordination=[bound(p) for p in sorted(BASE.glob('context-r30-peer-*.json'))],
    runs=runs,
    build_artifacts=[bound(p) for folder in ('compile-evidence', 'coherence-evidence')
                     for p in sorted((build/folder).rglob('*')) if p.is_file()],
    binaries=bundle['result']['metadata']['artifacts'],
    new_inference_threads=0, KV_cache_payload_format_changed=False, existing_public_ABI_breaking_change=False,
    new_contracts=['Independent model-neutral json_store ABI1 and additive json_value root query; existing public layouts/versions and persisted/cache state unchanged. C17 owns native derived/staging root collection, cumulative budgets and retirement; adopt/take do not clone trees. Root domains retain own allocator/view contexts; views survive collection growth and taken results survive collection retirement. Private compiler Store/member original OFF behavior retained. Compiler orchestration/typed construction/errors/prompt/model ownership remains transitional.'],
    thermal_policy='CPU98/NVMe85/lower exposed guards; GPU observe-only. No fan/clock/power tuning.',
    root_157_non_use=True,
    Terminal_Bench='Stopped/collected/closed/deferred until functional modifications and matching qualification finish; no restart/migration/reservation.',
    retained_current_observer_failures=[],
    observer_failure_scope='No failed current GPU observer or replay; actual collected observations only.',
    retained_collection_failures=[bound(BASE/'context-r30-build-collector-kind-failure-r1.json')],
    collection_failure_scope='Initial gufo-build kind requires a helper absent from the modern CMake build and exits1; unchanged six actual files collect as diagnostic with exit0. The build itself passed, with no compile/inference restart.',
    corrected_readonly_observations=[bound(p) for p in sorted(BASE.glob('context-r30-*.json')) if any(x in p.name for x in ('-live-', '-closure-', '-fresh-'))],
    previous_matching_GPU_receipt=bound('docs/development/validation/c17-grammar-storage-point-gpu-2026-10-06.json'),
    retained_unresolved_failure=False, all_six_owned_tasks_open=True,
    pending=['Deferred full Terminal Bench final rewards/transcripts/closure after functional changes and qualification.',
             '1M recall quality and matched Gufo/Halogen physical work/depth/concurrency/cache/thread/resource/graphs.',
             'Broader learned DS4 steering quality, independent graph/correction/GPU faults/vision/matched cost.',
             'Independent GPU probability/filter/tool-transition coverage and matched sampling cost.',
             'Remaining compiler orchestration/typed construction/error/prompt/model/controller ownership extraction; broader branch/fault/private-resource/cost qualification.'],
    final_fresh_closure=bound(final_path), publication=False, goal_complete=False)
out = Path('docs/development/validation/c17-schema-store-point-gpu-2026-10-06.json')
with out.open('x') as destination:
    json.dump(receipt, destination, indent=2)
    destination.write('\n')
print(json.dumps(dict(receipt=str(out), sha256=sha(out), GPU_controls=[37,37],
                     selected_complete_direct_controls=0, compiled_provider_file_count=99,
                     actual_runs_collected_and_retired=len(runs))))
