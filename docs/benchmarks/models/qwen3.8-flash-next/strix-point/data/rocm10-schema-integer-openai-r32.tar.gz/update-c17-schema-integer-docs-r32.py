# SPDX-License-Identifier: MIT
"""Update current status only after the actual selected GPU gates are closed."""
from pathlib import Path
import json

path = Path('docs/development/validation/c17-schema-integer-point-gpu-2026-10-06.json')
r = json.loads(path.read_text())
assert r['state'] == 'PASSED_WITH_STATED_SCOPE'
assert r['source_commit'] == '9a4f45b11133df71a4f4b0e9a0dbcffd94ae04ef'
assert len(r['compiled_provider_files']) == 105
assert all(x['actual_window_retired'] and x['actual_exit_code'] == 0 for x in r['runs'])
ar, mtp = r['runs'][1:]
assert ar['checks'] == mtp['checks'] == 37

def replace(name, old, new):
    p = Path(name)
    s = p.read_text()
    assert s.count(old) == 1, (name, old)
    p.write_text(s.replace(old, new))

replace('README.md',
        'now uses C17 and passes HOST parity; matching GPU qualification is pending.',
        'now uses C17, passes HOST parity and matching selected AR/MTP GPU controls.')
replace('CHANGELOG.md',
        '  witnesses agree; matching GPU qualification remains pending.',
        '  witnesses agree; matching HIP ON/OFF builds and selected original-weight\n'
        '  AR37/MTP37 controls pass on Strix Point. Individual branch and cost\n'
        '  qualification remain open.')
replace('docs/development/C17-SAMPLING.md',
        'The earlier `33d12a02`/r31 GPU receipt excludes this new source. Matching coherent\n'
        'HIP ON/OFF providers and private consumers require a fresh `.161` qualification.\n'
        'Typed construction/bootstrap/errors and model/controller remain transitional;\n'
        'broader branch/fault/quality/resource and matched-cost gates remain open.',
        'The matching sealed `9a4f45b1` source builds coherent 105-file HIP ON/OFF\n'
        'providers and private LIE/model/reference consumers. Unchanged selected\n'
        'original-weight AR37/MTP37 controls pass on `.161` under separate admissions\n'
        '([GPU receipt](validation/c17-schema-integer-point-gpu-2026-10-06.json)).\n'
        'The official Gufo HTTP frontend is retained source only. These controls\n'
        'qualify the integrated API/lifecycle paths; their enum schemas do not\n'
        'independently exercise every new bounded-integer branch. Typed construction/\n'
        'initialization/errors and model/controller remain transitional. Broader\n'
        'branch/fault/quality/resource and matched-cost gates remain open.')
replace('docs/BACKEND.md',
        '   all 29 preceding complete witness groups unchanged. Matching new-source\n'
        '   HIP ON/OFF/private-consumer and `.161` original-weight controls remain pending.',
        '   all 29 preceding complete witness groups unchanged. The matching sealed\n'
        '   `9a4f45b1` 105-file HIP ON/OFF/private-consumer build now passes unchanged\n'
        '   selected AR37/MTP37 on `.161`\n'
        '   ([GPU receipt](development/validation/c17-schema-integer-point-gpu-2026-10-06.json)).\n'
        '   Individual bounded-integer GPU branches are not independently exercised\n'
        '   by these enum-based OpenAI schemas and remain open.')
replace('docs/BACKEND.md',
        'New signed integer-bound compilation passes independent HOST parity and awaits matching GPU controls.',
        'Signed integer-bound compilation passes independent HOST parity and matching selected AR/MTP GPU controls.')

finding = json.loads(Path('evidence/long-context-sparse-dispatch-source-r1.json').read_text())
assert finding['state'] == 'SOURCE_FINDING_NOT_GPU_DISPATCH_OR_PERFORMANCE_QUALIFICATION'
destination = Path('docs/development/validation/long-context-sparse-dispatch-source-2026-10-06.json')
assert not destination.exists()
destination.write_text(json.dumps(finding, indent=2) + '\n')
replace('docs/BACKEND.md',
        '   decline above 256K and separate batching from reactive responsiveness.',
        '   decline above 256K and separate batching from reactive responsiveness.\n'
        '   [Pinned-source dispatch analysis](development/validation/long-context-sparse-dispatch-source-2026-10-06.json)\n'
        '   identifies a 2,048-word sparse-WMMA limit: configured capacity above\n'
        '   262,144 tokens can select the per-token fallback even at shallower\n'
        '   visible depth. Capture actual dispatch before attributing timings to\n'
        '   reactive scheduling; this finding is not measured causality or a\n'
        '   constant-prefill guarantee.')
replace('docs/development/TEST-COVERAGE-LONG-CONTEXT.md',
        'Independent long-context recall quality and matched repeated\n'
        'Gufo/Halogen performance comparisons remain open.',
        'Independent long-context recall quality and matched repeated\n'
        'Gufo/Halogen performance comparisons remain open.\n\n'
        '[Pinned-source analysis](validation/long-context-sparse-dispatch-source-2026-10-06.json)\n'
        'also identifies a sparse-attention dispatch confounder: a mask pitch\n'
        'above 2,048 words refuses the WMMA path. With the pinned ratio of four,\n'
        'this corresponds to configured capacity above 262,144 tokens; 1M uses\n'
        '8,192 words. The frozen 1M run did not record dispatch. New profiling must\n'
        'separate this fallback from reactive scheduling, physical work and YaRN.\n'
        'Removing the guard alone would exceed the current kernel workspaces.')
replace('docs/development/TEST-COVERAGE-LONG-CONTEXT.md',
        'the newest [C17 publication receipt](validation/c17-schema-compile-point-gpu-2026-10-06.json)',
        'the newest [C17 signed integer receipt](validation/c17-schema-integer-point-gpu-2026-10-06.json)')

closure = json.loads(Path(r['final_fresh_closure']['path']).read_text())['result']
stamp = closure['at_utc']
router = closure['service']['MainPID']
temps = ' / '.join(
    f"{x['mode'].upper()} CPU {x['peak_c']['k10temp']} C, GPU {x['peak_c']['amdgpu']} C, NVMe {x['peak_c']['nvme']} C"
    for x in (ar, mtp))
threads = f"{ar['observed_process_threads_max']}/{mtp['observed_process_threads_max']}"
progress = f'''## Signed integer-bound source passes matching GPU controls — 2026-10-06 UTC

The sealed `9a4f45b1` source builds coherent 105-file HIP ON/OFF providers and
private LIE/model/reference consumers on `.161`. Actual compiler blocks verify
the model/frontend flags and the complete OFF archive linkage. Unchanged
original-weight AR37/MTP37 pass under separate fresh admissions; all server,
child, controller and supervisor exits are 0. The official Gufo HTTP frontend
is retained source only. [GPU receipt](development/validation/c17-schema-integer-point-gpu-2026-10-06.json)
binds the source, binaries, complete logs and retirement. Independent HOST58,
focused C1, Release4 and 30 complete witnesses retain their separate scope.
The existing enum-based GPU schemas do not independently exercise each new
bounded-integer branch; broader branches, faults, quality, resources and cost
remain open. No inference worker is added.

{temps}. Whole-process thread maxima are {threads}.
CPU98/NVMe85/lower guards and GPU observation remain intact. Fresh closure at
{stamp} verifies all three supervisor/container-init identities gone,
containers removed, HTTP8000 unbound, original lease free then released and
router {router} restored/only KFD. Model stat identities stay unchanged.
No remote job/client/build/lease/waiter/reservation or live local handle remains;
`.157/.158` stay unused. No tuning, dependency installation or push occurs.

Independent pinned-source analysis identifies the 2,048-word sparse-WMMA
dispatch guard and 8,192-word pitch at configured 1M capacity. This is a
source finding, not a measured cause of the frozen prefill decline or proof
of a speedup. Actual dispatch/quality/resource profiling remains in item 4.
All six owned tasks stay open; Terminal Bench remains stopped, collected,
closed and deferred last until functional changes and qualification finish.

'''
replace('docs/PROGRESS.md', '# Development progress\n\n', '# Development progress\n\n' + progress)
coord = f'''## R32 signed integer bounds build and selected GPU controls closed — 2026-10-06

Fresh peer own non-use and separate global preflights admit sealed `9a4f45b1`
on `.161`. Device-free HIP ON/OFF/private-consumer build and original-weight
AR37/MTP37 hold the original device66307/inode105946405 lease in separate
windows. All actual exits are 0; complete collected files are SHA verified.
[Receipt](development/validation/c17-schema-integer-point-gpu-2026-10-06.json).
The official Gufo HTTP frontend is not built. These selected controls do not
independently qualify all bounded-integer branches, faults, quality or cost.

Fresh {stamp} closure verifies all three exact supervisor/container-init
identities gone, containers removed, HTTP8000 unbound, original lease free then
released and router {router} restored/only KFD. Model stats remain unchanged.
CPU98/NVMe85/lower guards and GPU observation stay active. Root has no remaining
remote job/client/build/lease/waiter/reservation/handle and does not use `.157/.158`.
This dated closure is not future admission. All six tasks remain open; Terminal
Bench stays stopped/collected/closed/deferred last. No tuning or push occurs.

'''
replace('docs/COORDINATION.md', '# DS4 / synapse-lie coordination\n\n',
        '# DS4 / synapse-lie coordination\n\n' + coord)
print('Updated current qualification and source-dispatch finding; all six tasks remain open.')
