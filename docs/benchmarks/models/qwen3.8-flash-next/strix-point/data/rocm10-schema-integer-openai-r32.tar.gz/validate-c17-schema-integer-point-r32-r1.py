#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Verify source-bound collected evidence without any device/network activity."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import tarfile

root = Path.cwd()
receipt_path = root / 'docs/development/validation/c17-schema-integer-point-gpu-2026-10-06.json'
receipt = json.loads(receipt_path.read_text())
commit = '9a4f45b11133df71a4f4b0e9a0dbcffd94ae04ef'
assert receipt['source_commit'] == commit
assert receipt['state'] == 'PASSED_WITH_STATED_SCOPE'
assert receipt['all_six_owned_tasks_open'] and not receipt['goal_complete']
assert not receipt['publication'] and receipt['root_157_non_use']
assert receipt['new_inference_threads'] == 0
assert 'deferred' in receipt['Terminal_Bench']

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

bindings = []
def verify(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and 'sha256' in value:
            path = root / value['path']
            assert path.is_file() and not path.is_symlink(), path
            assert sha(path) == value['sha256'], path
            if 'bytes' in value:
                assert path.stat().st_size == value['bytes'], path
            bindings.append(value['path'])
        for child in value.values():
            verify(child)
    elif isinstance(value, list):
        for child in value:
            verify(child)
verify(receipt)
assert len(receipt['compiled_provider_files']) == 105
host = json.loads((root / 'docs/development/validation/c17-schema-integer-host-2026-10-06.json').read_text())
assert receipt['compiled_provider_files'] == host['private_provider_inventory']
historical_sources = 0
historical_git_sources = 0
historical_ignored_fixture_sources = 0
for source in host['sources']:
    result = subprocess.run(['git','show',commit+':'+source['path']],capture_output=True)
    if result.returncode == 0:
        blob = result.stdout
        historical_git_sources += 1
    else:
        # Optional HOST fixtures are intentionally ignored, never Git source.
        assert result.returncode == 128 and Path(source['path']).parts[0]=='evidence',source['path']
        fixture = root / source['path']
        assert fixture.is_file() and not fixture.is_symlink(),fixture
        blob = fixture.read_bytes()
        historical_ignored_fixture_sources += 1
    assert hashlib.sha256(blob).hexdigest()==source['sha256'],source['path']
    assert len(blob)==source['bytes'],source['path']
    historical_sources += 1
assert historical_sources == 210
for name, digest in receipt['compiled_provider_files'].items():
    assert sha(root / name) == digest, name
assert sha(root / 'adapters/gufo-state/grammar-storage-edits.json') == receipt['grammar_storage_recipe_sha256']
assert sha(root / 'adapters/gufo-state/schema-store-edits.json') == receipt['schema_store_recipe_sha256']
assert sha(root / 'adapters/gufo-state/schema-compile-edits.json') == receipt['schema_compile_recipe_sha256']
assert sha(root / 'adapters/gufo-state/schema-integer-edits.json') == receipt['schema_integer_recipe_sha256']
assert receipt['official_Gufo_HTTP_frontend_built'] is False
primary=json.loads((root / receipt['provider_build_receipt']['path']).read_text())
reference=json.loads((root / receipt['reference_provider_build_receipt']['path']).read_text())
assert primary['c17_sampling'] is True and reference['c17_sampling'] is False
assert primary['owned_sampling_files']==reference['owned_sampling_files']==host['private_provider_inventory']
coherent=json.loads((root / receipt['actual_compiler_linker_coherence']['path']).read_text())
assert coherent['exit_code']==0 and coherent['compiled_frontend_primary_C17_ON'] and coherent['compiled_frontend_reference_C17_OFF'] and coherent['whole_OFF_reference_archives']
assert len(receipt['runs'])==3 and len(receipt['selected_complete_direct_controls'])==0

for run in receipt['runs']:
    assert run['actual_window_retired'] and run['actual_supervisor_identity_absent']
    assert run['container_init_identity_recorded'] and run['container_init_identity_absent'] is True
    assert run['container_init_pid']>0 and run['container_init_start_ticks']>0
    assert run['actual_exit_code'] == run['child_exit_code'] == 0
    if run['mode'] in ('ar', 'mtp'):
        assert run['checks'] == len(set(run['passed'])) == 37
        assert run['model_stat_unchanged']
assert receipt['runs'][1]['passed'] == receipt['runs'][2]['passed']
# Independently verify actual private compiler blocks and coherent OFF archives.
def ninja_block(contents,prefix):
    lines=contents.splitlines();indices=[i for i,line in enumerate(lines) if line.startswith(prefix)]
    assert len(indices)==1
    start=indices[0];end=start+1
    while end<len(lines) and lines[end].strip():end+=1
    return '\n'.join(lines[start:end])
coherence_root=root/'evidence/context-r32-build-r1/coherence-evidence'
frontend=(coherence_root/'build/rocm10-point-modern-r32-runtime/build.ninja').read_text()
for name,selected in (('CMakeFiles/lie_gufo.dir/adapters/gufo.cpp.o',1),
                       ('CMakeFiles/synapse-lie-bench-gufo-reference.dir/adapters/gufo_reference_bench.cpp.o',0)):
    block=ninja_block(frontend,'build '+name+':')
    assert '-DLIE_C17_SAMPLING='+str(selected) in block
    assert '-DLIE_C17_SAMPLING='+str(1-selected) not in block
link=ninja_block(frontend,'build synapse-lie-bench-gufo-reference:')
assert 'rocm10-point-modern-r32-provider/' not in link
for name in ('libgufo_core.a','libgufo_qwen38_flash_next.a','libgufo_qwen38_flash_next_mmq.a'):
    assert name in link and 'rocm10-point-modern-r32-reference-provider/' in link
for selector,selected in (('provider',1),('reference-provider',0)):
    ninja=(coherence_root/('build/rocm10-point-modern-r32-'+selector+'/build.ninja')).read_text()
    block=ninja_block(ninja,'build src/models/qwen38_flash_next/CMakeFiles/gufo_qwen38_flash_next.dir/engine.cpp.o:')
    assert '-DLIE_C17_SAMPLING='+str(selected) in block
    assert '-DLIE_C17_SAMPLING='+str(1-selected) not in block

closure = json.loads((root / receipt['final_fresh_closure']['path']).read_text())
assert closure['actual_exit_code'] == 0
c = closure['result']
assert c['original_lease']['free_briefly'] and c['original_lease']['released']
assert (c['original_lease']['device'], c['original_lease']['inode']) == (66307, 105946405)
assert not c['foreign_compute_clients'] and not c['guarded_hot'] and not c['http8000_listeners']
assert c['service']['ActiveState'] == 'active'

archive = root / receipt['portable_archive']['path']
with tarfile.open(archive) as t:
    members = t.getmembers()
    assert len(members) == len({m.name for m in members}) == receipt['portable_archive_members']
    for m in members:
        assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
        assert not any(x in m.name for x in ('.gguf', '.kvc', 'runtime/bin/'))
        local = root / 'evidence' / m.name
        assert local.is_file() and hashlib.sha256(t.extractfile(m).read()).hexdigest() == sha(local), m.name
QA_members=[]
index = archive.parent / 'archives.sha256'
old = subprocess.run(['git', 'show', commit + ':' + str(index.relative_to(root))], capture_output=True, check=True).stdout
current = index.read_bytes()
assert current == old + (sha(archive) + '  ' + archive.name + '\n').encode()
assert hashlib.sha256(old).hexdigest() == receipt['archive_index_previous_bytes_sha256']
indexed = 0
for line in current.decode().splitlines():
    digest, name = line.split(None, 1)
    target = root / name
    if not target.is_file():
        target = archive.parent / name
    assert target.is_file() and sha(target) == digest, name
    indexed += 1

links = 0
missing = []
for doc in [root / 'README.md', root / 'CHANGELOG.md', *sorted((root / 'docs').rglob('*.md'))]:
    for target in re.findall(r'\]\(([^)]+)\)', doc.read_text()):
        if '://' in target or target.startswith(('#', 'mailto:')):
            continue
        target = target.split('#', 1)[0].strip('<>')
        if not target:
            continue
        links += 1
        if not (doc.parent / target).exists():
            missing.append({'document': str(doc.relative_to(root)), 'target': target})
assert not missing, missing
record = {'schema': 'synapse-lie.collected-qualification-validator.v1',
          'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'state': 'PASS_SOURCE_BOUND_SELECTED_GPU_RECEIPT', 'actual_exit_code': 0,
          'source_commit': commit, 'receipt_sha256': sha(receipt_path),
          'artifact_bindings_verified': len(bindings), 'provider_files_verified': 105, 'frozen_host_source_bindings_verified': historical_sources, 'frozen_git_sources': historical_git_sources, 'unchanged_ignored_HOST_fixture_sources': historical_ignored_fixture_sources,
          'archive_members_verified': len(members), 'archive_entries_verified': indexed, 'offline_QA_correction_members_verified': len(QA_members),
          'relative_markdown_links_verified': links, 'missing_links': missing,
          'new_GPU_run_build_or_network_activity': False, 'terminal_bench_deferred': True,
          'all_six_owned_tasks_open': True, 'publication': False,
          'raw_complete_direct_input_output_frontier_pairs_verified': 0,
          'actual_ninja_CPP_model_flags_and_whole_OFF_link_independently_verified': True}
with (root / 'evidence/c17-schema-integer-point-final-validation-r32-r1.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps(record))
