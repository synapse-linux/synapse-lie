# SPDX-License-Identifier: MIT
"""Collect exact finished owned compile logs, never model payloads."""
from pathlib import Path
import hashlib,json,subprocess
label='context-r32-build-r1';root=Path('evidence')/label
result=json.loads((root/'result.json').read_text());assert result['ended_at'] and result['lease_released_at']
assert result['state']=='PASSED' and result['exit_code']==result['child_exit_code']==0
previous=Path('evidence/context-r19-build-r1/compile-evidence')
names=sorted(str(p.relative_to(previous)).replace('r19','r32') for p in previous.rglob('*') if p.is_file() and p.name!='collection.json')
assert len(names)==17
additional=[name.replace('-provider/','-reference-provider/') for name in names if '-provider/' in name]
additional.extend('evidence/rocm10-point-modern-r32-compile/reference-provider.'+suffix for suffix in ('command','stdout','stderr','exit'))
names=sorted(names+additional)
assert len(names)==len(set(names))==25
remote='/home/pop/workspace/synapse-lie/rocm10-fedora-161/source-modern-r32'
ssh=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161']
scp=['scp','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8']
program='NAMES='+repr(names)+'\n'+'''from pathlib import Path
import hashlib,json,os
base=Path('/home/pop/workspace/synapse-lie/rocm10-fedora-161/source-modern-r32')
assert base.resolve()==base and base.stat().st_uid==os.getuid()
r=json.loads((base/'evidence/rocm10-point-modern-r32-compile/result.json').read_text())
assert r['state']=='BUILT_NOT_GPU_TESTED' and r['exit_code']==0 and r['source_commit']=='9a4f45b11133df71a4f4b0e9a0dbcffd94ae04ef'
files={}
for n in NAMES:
 p=base/n;assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(base)
 with p.open('rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest()
 files[n]={'bytes':p.stat().st_size,'sha256':digest}
print(json.dumps(files))
'''
p=subprocess.run(ssh+['python3 -B -'],input=program,text=True,capture_output=True,timeout=60)
out=root/'compile-evidence';out.mkdir(exist_ok=False)
r={'schema':'synapse-lie.point-compile-collection.v1','scope':'Own compile logs/receipt only; no binaries/models copied','argv':ssh+['python3 -B -'],'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'inventory_exit_code':p.returncode,'stderr':p.stderr,'commands':[],'exit_code':1}
(out/'collection.json').write_text(json.dumps(r,indent=2)+'\n');assert p.returncode==0
r['files']=json.loads(p.stdout)
for name,identity in r['files'].items():
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True)
 cmd=scp+['pop@192.168.5.161:'+remote+'/'+name,str(target)]
 p=subprocess.run(cmd,text=True,capture_output=True,timeout=60)
 r['commands'].append({'argv':cmd,'actual_exit_code':p.returncode,'stderr':p.stderr})
 (out/'collection.json').write_text(json.dumps(r,indent=2)+'\n')
 assert p.returncode==0 and target.stat().st_size==identity['bytes'] and hashlib.sha256(target.read_bytes()).hexdigest()==identity['sha256']
provider=json.loads((out/'build/rocm10-point-modern-r32-provider/BUILD-RECEIPT.json').read_text())
host=json.loads(Path('docs/development/validation/c17-schema-integer-host-2026-10-06.json').read_text())
assert provider['owned_sampling_files']==host['private_provider_inventory'] and len(provider['owned_sampling_files'])==105
reference=json.loads((out/'build/rocm10-point-modern-r32-reference-provider/BUILD-RECEIPT.json').read_text())
assert reference['owned_sampling_files']==host['private_provider_inventory'] and len(reference['owned_sampling_files'])==105
assert provider['c17_sampling'] is True and reference['c17_sampling'] is False
storage_sha=hashlib.sha256(Path('adapters/gufo-state/grammar-storage-edits.json').read_bytes()).hexdigest()
assert provider['grammar_storage_edits_sha256']==reference['grammar_storage_edits_sha256']==storage_sha
store_sha=hashlib.sha256(Path('adapters/gufo-state/schema-store-edits.json').read_bytes()).hexdigest()
assert provider['schema_store_edits_sha256']==reference['schema_store_edits_sha256']==store_sha
compile_sha=hashlib.sha256(Path('adapters/gufo-state/schema-compile-edits.json').read_bytes()).hexdigest()
assert provider['schema_compile_edits_sha256']==reference['schema_compile_edits_sha256']==compile_sha
compiled=json.loads((out/'evidence/rocm10-point-modern-r32-compile/result.json').read_text())
integer_sha=hashlib.sha256(Path('adapters/gufo-state/schema-integer-edits.json').read_bytes()).hexdigest()
assert provider['schema_integer_edits_sha256']==reference['schema_integer_edits_sha256']==integer_sha
assert compiled['reference_control_coherent_off'] is True
assert hashlib.sha256((out/'build/rocm10-point-modern-r32-provider/BUILD-RECEIPT.json').read_bytes()).hexdigest()==compiled['provider_receipt_sha256']
assert hashlib.sha256((out/'build/rocm10-point-modern-r32-reference-provider/BUILD-RECEIPT.json').read_bytes()).hexdigest()==compiled['reference_provider_receipt_sha256']
for stage in ('provider','reference-provider','configure','link'):
 assert (out/('evidence/rocm10-point-modern-r32-compile/'+stage+'.exit')).read_text().strip()=='0'
r['exit_code']=0;r['compiled_provider_files']=105;r['coherent_reference_provider_files']=105;r['reference_control_coherent_off']=True
(out/'collection.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'files':len(names),'compiled_provider_files':105,'actual_exit_code':0}))
