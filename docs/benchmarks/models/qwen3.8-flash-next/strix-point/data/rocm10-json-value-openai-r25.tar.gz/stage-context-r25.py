# SPDX-License-Identifier: MIT
from pathlib import Path
import json
import subprocess

root=Path.cwd()
seal=json.loads((root/'evidence/context-r25-source-seal.json').read_text())
ssh=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161']
record={'source_seal':seal,'commands':[]}
def run(argv, program=None, timeout=90):
    result=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=timeout)
    record['commands'].append({'argv':argv,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    (root/'evidence/context-r25-source-stage.json').write_text(json.dumps(record,indent=2)+'\n')
    if result.returncode: raise SystemExit(result.returncode)
    return result
preflight="""from pathlib import Path
import json,os
base=Path('/home/pop/workspace/synapse-lie/rocm10-fedora-161')
assert base.resolve()==base and base.stat().st_uid==os.getuid()
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='c82c90ed-7f94-4212-bc52-681c63eac395'
for name in ('source-modern-r25','source-modern-r25.tar.gz','bundle-modern-r25'):
 assert not (base/name).exists(),name
s=os.statvfs(base)
assert s.f_bavail*s.f_frsize>4*1024**3
print(json.dumps({'free_disk_bytes':s.f_bavail*s.f_frsize,'exclusive_destinations_absent':True}))
"""
run(ssh+['python3 -B -'],preflight)
run(['scp','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',str(root/'evidence/context-source-modern-r25.tar.gz'),'pop@192.168.5.161:/home/pop/workspace/synapse-lie/rocm10-fedora-161/source-modern-r25.tar.gz'],timeout=240)
extract="""from pathlib import Path
import hashlib,json,os,tarfile
base=Path('/home/pop/workspace/synapse-lie/rocm10-fedora-161')
archive=base/'source-modern-r25.tar.gz'
with archive.open('rb') as f: actual=hashlib.file_digest(f,'sha256').hexdigest()
assert actual==EXPECTED
destination=base/'source-modern-r25'
destination.mkdir()
with tarfile.open(archive) as t:
 for m in t.getmembers():
  assert m.name=='context-source-modern-r25' or m.name.startswith('context-source-modern-r25/')
  m.name=m.name.removeprefix('context-source-modern-r25').lstrip('/')
  if m.name: t.extract(m,destination,filter='data')
inventory=destination/'SOURCE-FILES.sha256'
with inventory.open('rb') as f: inv=hashlib.file_digest(f,'sha256').hexdigest()
assert inv==INVENTORY
print(json.dumps({'archive_sha256':actual,'inventory_sha256':inv,'source_commit':(destination/'SOURCE-COMMIT.txt').read_text().strip(),'GPU_build_or_run':False}))
"""
extract='EXPECTED='+repr(seal['archive_sha256'])+'\nINVENTORY='+repr(seal['source_files_sha256'])+'\n'+extract
run(ssh+['python3 -B -'],extract,timeout=90)
record['exit_code']=0
(root/'evidence/context-r25-source-stage.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'exit_code':0,'remote_source_commit':seal['source_commit'],'archive_bytes':seal['archive_bytes']}))
