# SPDX-License-Identifier: MIT
"""Collect exact finished owned compile logs, never model payloads."""
from pathlib import Path
import hashlib,json,subprocess
label='context-r25-build-r1';root=Path('evidence')/label
result=json.loads((root/'result.json').read_text());assert result['ended_at'] and result['lease_released_at']
assert result['state']=='PASSED' and result['exit_code']==result['child_exit_code']==0
previous=Path('evidence/context-r19-build-r1/compile-evidence')
names=sorted(str(p.relative_to(previous)).replace('r19','r25') for p in previous.rglob('*') if p.is_file() and p.name!='collection.json')
assert len(names)==17
remote='/home/pop/workspace/synapse-lie/rocm10-fedora-161/source-modern-r25'
ssh=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161']
scp=['scp','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8']
program='NAMES='+repr(names)+'\n'+'''from pathlib import Path
import hashlib,json,os
base=Path('/home/pop/workspace/synapse-lie/rocm10-fedora-161/source-modern-r25')
assert base.resolve()==base and base.stat().st_uid==os.getuid()
r=json.loads((base/'evidence/rocm10-point-modern-r25-compile/result.json').read_text())
assert r['state']=='BUILT_NOT_GPU_TESTED' and r['exit_code']==0 and r['source_commit']=='5227bf4f5c2f0d95cc246b2a739fc0de9f24515d'
files={}
for n in NAMES:
 p=base/n;assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(base)
 with p.open('rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest()
 files[n]={'bytes':p.stat().st_size,'sha256':digest}
print(json.dumps(files))
'''
p=subprocess.run(ssh+['python3 -B -'],input=program,text=True,capture_output=True,timeout=60)
out=root/'compile-evidence';out.mkdir(exist_ok=False)
r={'schema':'synapse-lie.point-compile-collection.v1','scope':'Own compile logs/receipt only; no binaries/models copied','argv':ssh+['python3 -B -'],'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'inventory_exit_code':p.returncode,'stderr':p.stderr,'commands':[],'exit_code':1}
(out/'collection.json').write_text(json.dumps(r,indent=2)+'\n');assert p.returncode==0
r['files']=json.loads(p.stdout)
for name,identity in r['files'].items():
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True)
 cmd=scp+['pop@192.168.5.161:'+remote+'/'+name,str(target)]
 p=subprocess.run(cmd,text=True,capture_output=True,timeout=60)
 r['commands'].append({'argv':cmd,'actual_exit_code':p.returncode,'stderr':p.stderr})
 (out/'collection.json').write_text(json.dumps(r,indent=2)+'\n')
 assert p.returncode==0 and target.stat().st_size==identity['bytes'] and hashlib.sha256(target.read_bytes()).hexdigest()==identity['sha256']
provider=json.loads((out/'build/rocm10-point-modern-r25-provider/BUILD-RECEIPT.json').read_text())
host=json.loads(Path('docs/development/validation/c17-json-value-host-2026-10-06.json').read_text())
assert provider['owned_sampling_files']==host['private_provider_inventory'] and len(provider['owned_sampling_files'])==89
r['exit_code']=0;r['compiled_provider_files']=89
(out/'collection.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'files':len(names),'compiled_provider_files':89,'actual_exit_code':0}))
