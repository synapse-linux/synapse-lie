# SPDX-License-Identifier: MIT
"""Read-only observation of an exact already admitted SSD text supervisor."""
from pathlib import Path
import hashlib,json,subprocess,sys
mode,serial=sys.argv[1:]
assert mode in ('ar','mtp') and serial.isdecimal()
label='context-r23-steering-'+mode+'-r2'
program='ROOT_LABEL='+repr(label)+'\n'+"from pathlib import Path\nimport datetime,hashlib,importlib.util,json\nroot=Path('/home/pop/workspace/synapse-lie')/ROOT_LABEL\nr=json.loads((root/'result.json').read_text())\nmanifest=json.loads((root/'manifest.json').read_text())\nassert r['manifest_sha256']==hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()\nassert r['runner_sha256']==hashlib.sha256((root/'runner.py').read_bytes()).hexdigest()\nspec=importlib.util.spec_from_file_location('point',root/'runner.py');point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)\ntry:alive=point.ticks(r['pid'])==r['start_ticks']\nexcept FileNotFoundError:alive=False\nfds=[]\nif alive:\n for p in Path('/proc').joinpath(str(r['pid']),'fd').iterdir():\n  try:\n   st=p.stat()\n   if (st.st_dev,st.st_ino)==(66307,105946405):fds.append(int(p.name))\n  except FileNotFoundError:pass\nprogress=root/'admission-progress.json';gate=root/'steering-admission-result.json'\npr=json.loads(progress.read_text()) if progress.exists() else None\nchecked=json.loads(gate.read_text()) if gate.exists() else None\nrow=point.observe(98,gpu_observation_only=True)\nout={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':ROOT_LABEL,'supervisor_pid':r['pid'],'supervisor_start_ticks':r['start_ticks'],'live_exact_supervisor':alive,'original_lease_fds':fds,'state':r['state'],'model_attempted':r.get('model_attempted'),'phase':pr,'gate':checked,'observation':row,'new_GPU_job_build_or_restart':False}\nout['active_owner_observed']=bool(alive and fds and r['state'] in ('ADMITTED','RUNNING_DISTROBOX'))\nprint(json.dumps(out))\n"
compile(program,'remote-ssd-text-observer','exec')
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
p=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
r={'argv':argv,'actual_exit_code':p.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':p.stdout,'stderr':p.stderr}
try:r['result']=json.loads(p.stdout)
except ValueError:pass
with Path('evidence/'+label+'-live-'+serial+'.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
output={k:v for k,v in r.get('result',r).items() if k not in ('observation','stdout','gate')}
if r.get('result',{}).get('gate'):output['gate_state']=r['result']['gate']['state']
print(json.dumps(output))
raise SystemExit(p.returncode)
