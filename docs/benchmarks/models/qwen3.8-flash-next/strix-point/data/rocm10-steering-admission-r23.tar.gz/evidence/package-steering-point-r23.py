# SPDX-License-Identifier: MIT
"""Offline strict validation and portable archive; never starts an inference job."""
from pathlib import Path
import datetime
import gzip
import hashlib
import importlib.util
import io
import json
import stat
import subprocess
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parents[1]
QA = '6ea348af322a6a228087ddf208ef19d9a1b694ca'
ORIGINAL_QA = '05cf887470b4e31fa825c3e667af53eb9d5e2564'
RUNTIME = '2077700583a7a129d17b36dbf7aa2ffbbdd7c994'
DATA = ROOT / 'docs/benchmarks/models/qwen3.8-flash-next/strix-point/data'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def binding(path):
    return {'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def load(path):
    return json.loads(path.read_text())


spec = importlib.util.spec_from_file_location('gate', ROOT / 'tools/strix-point-steering-admission-gate.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
host_path = ROOT / 'docs/development/validation/steering-admission-draft-host-2026-10-06.json'
host = load(host_path)
assert host['state'] == 'HOST_ONLY_PREPARED_NOT_GPU_QUALIFIED'
for item in host['bindings']:
    path = ROOT / item['path']
    assert binding(path) == item
    if item['path'].startswith(('tools/', 'tests/')):
        historical = subprocess.check_output(['git', 'show', QA + ':' + item['path']], cwd=ROOT)
        assert historical == path.read_bytes()
provider = load(ROOT / 'docs/development/validation/c17-binary64-point-gpu-2026-10-06.json')['compiled_provider_files']
assert len(provider) == 83 and all(sha(ROOT / name) == digest for name, digest in provider.items())
files = [host_path] + [ROOT / item['path'] for item in host['bindings']]
windows, outputs, banks = {}, {}, {}
for mode in ('ar', 'mtp'):
    directory = ROOT / ('evidence/context-r23-steering-' + mode + ('-r1' if mode == 'ar' else '-r2'))
    mode_qa = ORIGINAL_QA if mode == 'ar' else QA
    result = load(directory / 'result.json')
    collected = load(directory / 'collection.json')
    raw = load(directory / 'steering-admission-result.json')
    manifest = load(directory / 'manifest.json')
    assert manifest['qa_source_commit'] == manifest['runner_commit'] == mode_qa
    assert manifest['source_commit'] == RUNTIME and manifest['decode_mode'] == mode
    assert collected['exit_code'] == result['exit_code'] == result['child_exit_code'] == 0
    assert result['state'] == raw['state'] == 'PASSED' and result['lease_released_at'] and result['ended_at']
    assert result['model_stat_unchanged'] and not result.get('cleanup_failures')
    assert sha(directory / 'runner.py') == result['runner_sha256']
    assert sha(directory / 'manifest.json') == result['manifest_sha256']
    for local, source in (('runner.py', 'tools/strix-point-campaign.py'),
                          ('steering-admission-gate.py', 'tools/strix-point-steering-admission-gate.py'),
                          ('steering-restart-gate.py', 'tools/strix-point-steering-restart-gate.py')):
        assert (directory / local).read_bytes() == subprocess.check_output(['git', 'show', mode_qa + ':' + source], cwd=ROOT)
    inventory = collected['inventory']
    assert len(inventory['files']) == 46
    for name, expected in inventory['files'].items():
        path = directory / name
        assert path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256']
    assert all(inventory[key] for key in ('supervisor_absent', 'gpu_child_absent', 'owned_child_absent', 'lease_free'))
    processes = raw['processes']
    assert [item['phase'] for item in processes] == ['absent', 'zero', *gate.CASES, 'recovery']
    successes, refusals = {}, []
    for process in processes:
        phase = process['phase']
        path = directory / ('measurements-' + phase + '.jsonl')
        assert sha(path) == raw[phase + '_sha256']
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        assert rows[0]['build_id'] == 'rocm10-point-modern-r20-runtime'
        assert rows[0]['source_pin'] == 'f783fedb9bea2ec7de941f6da4e02f4a4596b29e'
        if phase in gate.CASES:
            refusals.append(gate.parse_refusal(rows, process['exit_code'], mode, phase))
        else:
            successes[phase] = gate.parse_success(rows, process['exit_code'], mode, phase, raw['bank'])
    compared = gate.compare(successes, refusals)
    assert all(raw[key] == value for key, value in compared.items())
    assert raw['refusals'] == refusals
    valid = directory / 'valid.f32'
    assert valid.stat().st_size == raw['bank']['bytes'] and sha(valid) == raw['bank']['sha256']
    with tempfile.TemporaryDirectory() as temporary:
        cases = gate.create_cases(Path(temporary) / 'banks', valid.resolve())
        reconstructed = gate.case_metadata(cases)
        for case, expected in raw['case_inputs'].items():
            assert all(reconstructed[case][key] == expected[key] for key in ('kind', 'bytes', 'sha256')
                       if key in expected)
    observations = [json.loads(line) for line in (directory / 'telemetry.jsonl').read_text().splitlines()]
    assert observations and not any(t['guarded'] and t['value_c'] >= t['limit_c']
                                   for row in observations for t in row['temperatures'])
    peaks = {name: max(t['value_c'] for row in observations for t in row['temperatures'] if t['name'] == name)
             for name in ('k10temp', 'amdgpu', 'nvme')}
    assert peaks['k10temp'] < 98 and peaks['nvme'] < 85
    threads = [int(p['status']['Threads']) for row in observations for p in row.get('dri', [])
               if 'Threads' in p.get('status', {})]
    windows[mode] = {'label': directory.name, 'qa_source_commit': mode_qa, 'supervisor_pid': result['pid'],
                     'supervisor_start_ticks': result['start_ticks'],
                     'supervisor_exit_code': result['exit_code'], 'child_exit_code': result['child_exit_code'],
                     'started_at': result['started_at'], 'ended_at': result['ended_at'],
                     'lease_released_at': result['lease_released_at'],
                     'native_exits': [{'phase': item['phase'], 'actual_exit_code': item['exit_code']} for item in processes],
                     'peaks_C': peaks, 'whole_process_threads_max': max(threads),
                     'positive_jobs': {phase: successes[phase]['job'] for phase in gate.SUCCESS},
                     'refusals': refusals, 'comparison': compared,
                     'remote_files_collected': len(inventory['files']), 'model_stat_unchanged': True}
    outputs[mode] = successes
    banks[mode] = raw['bank']
    files.extend(path for path in directory.iterdir() if stat.S_ISREG(path.lstat().st_mode))
for phase in gate.SUCCESS:
    assert outputs['ar'][phase]['input']['physical_ids'] == outputs['mtp'][phase]['input']['physical_ids']
    assert outputs['ar'][phase]['job']['output_ids'] == outputs['mtp'][phase]['job']['output_ids']
assert banks['ar'] == banks['mtp']
failed_dir = ROOT / 'evidence/context-r23-steering-mtp-r1'
failed = load(failed_dir / 'result.json')
failed_collection = load(failed_dir / 'collection.json')
failed_gate = load(failed_dir / 'steering-admission-result.json')
assert failed['state'] == failed_gate['state'] == 'FAILED'
assert failed['exit_code'] == failed['child_exit_code'] == 1 and failed_collection['exit_code'] == 0
assert failed_gate['processes'][0]['phase'] == 'absent' and failed_gate['processes'][0]['exit_code'] == 0
assert len(failed_gate['processes']) == 1 and 'real draft acceptance' in failed_gate['error']
assert len(failed_collection['inventory']['files']) == 18
for name, expected in failed_collection['inventory']['files'].items():
    path = failed_dir / name
    assert path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256']
failed_rows = [json.loads(line) for line in (failed_dir / 'measurements-absent.jsonl').read_text().splitlines()]
failed_job = gate.parse_success(failed_rows, 0, 'mtp', 'absent', failed_gate['bank'])['job']
assert failed_job['mtp_drafted_tokens'] == 6 and failed_job['mtp_accepted_tokens'] == 0
files.extend(path for path in failed_dir.iterdir() if stat.S_ISREG(path.lstat().st_mode))
files += [ROOT / 'docs/development/validation/steering-admission-host-2026-10-06.json']
files += [ROOT / ('evidence/steering-admission-host-r1/' + name)
          for name in ('plan.json', 'result.json', 'command.log', 'temperatures.jsonl')]
closure_path = ROOT / 'evidence/context-r23-final-161-r2.json'
closure = load(closure_path)
assert closure['actual_exit_code'] == 0
assert closure['result']['state'] == 'FRESH_SELECTED_WINDOWS_CLOSED_NO_STANDING_RESERVATION'
assert len(closure['result']['owned_window_closures']) == 3
for path in ROOT.joinpath('evidence').glob('context-r23-*.json'):
    if path.is_file():
        files.append(path)
for path in ROOT.joinpath('evidence').glob('context-r23-*.py'):
    files.append(path)
files += [ROOT / 'evidence/observe-context-r23-steering.py', ROOT / 'evidence/observe-context-r23-steering-r2.py', Path(__file__).resolve()]
files = sorted(set(files))
assert all(stat.S_ISREG(path.lstat().st_mode) for path in files)
archive = DATA / 'rocm10-steering-admission-r23.tar.gz'
with archive.open('xb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', mtime=0, filename='') as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for path in files:
                raw = path.read_bytes()
                info = tarfile.TarInfo(str(path.relative_to(ROOT)))
                info.size = len(raw); info.mode = 0o644
                tar.addfile(info, io.BytesIO(raw))
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(files)
    for path in files:
        assert tar.extractfile(str(path.relative_to(ROOT))).read() == path.read_bytes()
receipt = {'schema': 'synapse-lie.steering-admission-point-gpu.v1',
           'state': 'SELECTED_STEERING_ADMISSION_CASES_QUALIFIED_WITH_RETAINED_QA_FAILURE',
           'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'runtime_source_commit': RUNTIME, 'qa_source_commit': QA,
           'scope': 'Original-model loader refusal before readiness and numerical work; original-weight absent/zero/fresh-core recovery equivalence in separate AR/MTP windows. Not learned-vector quality, same-core reconfiguration, arbitrary GPU faults, independent graph/correction oracles, vision or matched performance.',
           'bank': banks['ar'],
           'windows': windows, 'within_and_across_mode_physical_inputs_and_32_outputs_equal': True,
           'fresh_final_closure': closure['result'], 'host_gate_tests': 16, 'campaign_tests': 61,
           'retained_first_MTP_failure': {'label': failed_dir.name, 'actual_native_exit_code': 0,
              'actual_QA_supervisor_child_exit_codes': [1, 1, 1], 'drafted': 6, 'accepted': 0,
              'error': failed_gate['error'], 'remote_files_collected': 18,
              'scope': 'Superfluous positive acceptance predicate refused valid zero-acceptance equivalence; original raw evidence unchanged.'},
           'MTP_scope': 'Positive real drafting and exact confirmed output parity; zero acceptance valid. No accepted-burst qualification.',
           'compiled_provider_files_unchanged': len(provider),
           'runtime_ABI_format_dependency_or_inference_threads_changed': False,
           'GPU_rebuild_conversion_or_heavy_model_hash': False,
           'root_157_activity': False, 'all_six_owned_tasks_open': True,
           'Terminal_Bench': 'Stopped/closed/deferred until modifications and matching qualification finish; no reservation.',
           'bindings': [binding(path) for path in files], 'portable_archive': dict(binding(archive), members=len(files))}
receipt_path = ROOT / 'docs/development/validation/steering-admission-point-gpu-2026-10-06.json'
with receipt_path.open('x') as output:
    json.dump(receipt, output, indent=2); output.write('\n')
index = DATA / 'archives.sha256'
baseline = subprocess.check_output(['git', 'show', QA + ':' + str(index.relative_to(ROOT))], cwd=ROOT)
assert index.read_bytes() == baseline
with index.open('ab') as output:
    output.write((sha(archive) + '  ' + archive.name + '\n').encode())
print(json.dumps({'state': receipt['state'], 'receipt': binding(receipt_path),
                  'archive': receipt['portable_archive'], 'modes': list(windows),
                  'CPU_peaks_C': {mode: row['peaks_C']['k10temp'] for mode, row in windows.items()},
                  'native_successes': 6, 'expected_native_refusals': 24}))
