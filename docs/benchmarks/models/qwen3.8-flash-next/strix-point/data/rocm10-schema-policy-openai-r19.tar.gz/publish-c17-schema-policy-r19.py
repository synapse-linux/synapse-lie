# SPDX-License-Identifier: MIT
"""Package collected r19 evidence locally; no push or external publication."""
from pathlib import Path
import gzip,hashlib,json,tarfile

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def bound(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
p=Path('docs/development/validation/c17-schema-policy-point-gpu-2026-10-06.json')
assert sha(p)=='4a76d8f7d91aa9c51f277efa89aa5f1bed51df34bf07833081ff59f472da0cbb'
r=json.loads(p.read_text());initial=Path('evidence/c17-body-point-initial-receipt-r19.json')
with initial.open('xb') as f:f.write(p.read_bytes())
extras=['evidence/context-r19-final-161-r1.json','evidence/context-r19-fresh-161-r1.json',
 'evidence/context-r19-before-ar-r1.json','evidence/context-r19-before-mtp-r1.json',
 'evidence/context-r19-source-stage.json','evidence/context-r19-local-source-seal-r1/result.json',
 'evidence/context-r19-build-live-r1.json','evidence/make-c17-point-gpu-receipt-r19.py',
 'evidence/publish-c17-schema-policy-r19.py',
 'evidence/context-r19-build-closure-r1.json','evidence/context-r19-build-closure-r1.py',
 'evidence/context-r19-build-closure-r2.py','evidence/context-r19-ar-live-r1.json',
 'evidence/context-r19-ar-live-r1.py','evidence/context-r19-ar-live-r2.json',
 'evidence/context-r19-ar-live-r2.py','evidence/context-r19-mtp-live-r1.json',
 'evidence/context-r19-mtp-live-r1.py','evidence/context-r19-final-161-r1.py',
 'evidence/collect-context-r19-compile.py','evidence/prepare-context-r19-source.py']
final=json.loads(Path(extras[0]).read_text());assert final['actual_exit_code']==0
f=final['result'];assert f['original_lease']['free_briefly'] and f['original_lease']['released']
assert not f['foreign_compute_clients'] and not f['http8000_listeners'] and not f['guarded_hot']
assert f['service']['MainPID']=='84458' and f['service']['ActiveState']=='active'
r['final_readonly_observation']=[bound(x) for x in extras]
r['initial_receipt_before_portable_packaging']=bound(initial)
files=set(extras)
for run in r['runs']:files.update(a['path'] for a in run['artifacts'])
files.update(a['path'] for a in r['build_artifacts'])
for field in ('source_capsule','bundle','provider_build_receipt','build_closure','coordination','retained_failed_build'):files.add(r[field]['path'])
archive=Path('docs/benchmarks/models/qwen3.8-flash-next/strix-point/data/rocm10-schema-policy-openai-r19.tar.gz')
assert not archive.exists()
with archive.open('xb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as t:
   for name in sorted(files):
    q=Path(name);assert q.is_file() and not q.is_symlink()
    info=t.gettarinfo(str(q),arcname=q.relative_to('evidence').as_posix())
    info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with q.open('rb') as content:t.addfile(info,content)
index=archive.parent/'archives.sha256';old=index.read_bytes();assert old.endswith(b'\n')
assert archive.name.encode() not in old
with index.open('ab') as out:out.write((sha(archive)+'  '+archive.name+'\n').encode())
r['portable_archive']=bound(archive)
r['portable_archive_members']=len(files)
r['archive_index_previous_bytes_sha256']=hashlib.sha256(old).hexdigest()
r['archive_index_appended_only']=True
p.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'receipt_sha256':sha(p),'archive':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'files':len(files),'GPU_checks':[37,37],'final_closure_at':f['at_utc']}))
