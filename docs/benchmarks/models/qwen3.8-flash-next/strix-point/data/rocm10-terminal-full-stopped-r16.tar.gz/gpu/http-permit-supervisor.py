# SPDX-License-Identifier: MIT
"""Own temporary HTTP permit, bound to one actual LIE eval supervisor."""
from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,sys,time
root=Path(sys.argv[1]);assert root.resolve()==root and root.stat().st_uid==os.getuid()==1000
assert root==Path('/home/pop/workspace/synapse-lie/context-r16-terminal-full-r1')
owner=json.loads((root/'launch.json').read_text());assert (owner['pid'],owner['start_ticks'])==(65159,9972757)
record={'schema':'synapse-lie.owned-temporary-http-permit.v1','state':'PREPARING','pid':os.getpid(),'owner':owner,'source':'192.168.5.157','destination':'192.168.5.161','port':8000,'scope':'Only the explicitly requested LIE HTTP endpoint, one client and one live supervised window; no global firewall disable or foreign rule removal','commands':[]}
rule=['allow','proto','tcp','from','192.168.5.157','to','192.168.5.161','port','8000','comment','synapse-lie-terminal-r16-65159']
interrupted=False;created=False

def save():
 p=root/'http-permit-result.tmp';p.write_text(json.dumps(record,indent=2)+'\n');p.replace(root/'http-permit-result.json')
def live():
 try:
  p=Path('/proc')/str(owner['pid']);raw=(p/'stat').read_text();t=raw[raw.rindex(')')+2:].split()
  return p.stat().st_uid==os.getuid() and int(t[19])==owner['start_ticks'] and t[0] not in ('Z','X')
 except FileNotFoundError:return False

def command(args):
 argv=['sudo','-n','ufw',*args];p=subprocess.run(argv,env=dict(os.environ,LC_ALL='C'),text=True,capture_output=True,timeout=20)
 record['commands'].append({'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});save()
 assert p.returncode==0,(args,p.returncode,p.stderr)
 return p.stdout

def stop(signum,_frame):
 global interrupted
 interrupted=True
 record['interrupted_signal']=signum
for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):signal.signal(sig,stop)
try:
 assert live(), 'Original eval supervisor is retired'
 before=command(['status','numbered']);assert 'Status: active' in before and '8000' not in before
 record['before_sha256']=hashlib.sha256(before.encode()).hexdigest()
 command(['--dry-run',*rule]);command(['--dry-run','--force','delete',*rule])
 assert live()
 command(rule);created=True
 after=command(['status','numbered']);assert 'synapse-lie-terminal-r16-65159' in after
 record.update(state='HTTP_PERMIT_ACTIVE',activated_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 budget=json.loads((root/'manifest.json').read_text())['eval_window_seconds'];assert budget==482760
 deadline=time.monotonic()+budget+600
 while live() and not interrupted:
  assert time.monotonic()<deadline,'Owned HTTP permit deadline'
  time.sleep(1)
except BaseException as error:record.update(state='FAILED',error=repr(error))
finally:
 if created:
  try:
   current=command(['status','numbered'])
   assert 'synapse-lie-terminal-r16-65159' in current,'Own permit identity changed; no foreign rule removed'
   command(['--force','delete',*rule])
   after=command(['status','numbered']);assert 'synapse-lie-terminal-r16-65159' not in after
   record['own_rule_retired']=True;record['after_sha256']=hashlib.sha256(after.encode()).hexdigest()
  except BaseException as error:record['cleanup_error']=repr(error);record['own_rule_retired']=False
 if record['state']=='HTTP_PERMIT_ACTIVE':record['state']='CLOSED' if record.get('own_rule_retired') else 'FAILED'
 record['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(record))
raise SystemExit(0 if record['state']=='CLOSED' else 1)
