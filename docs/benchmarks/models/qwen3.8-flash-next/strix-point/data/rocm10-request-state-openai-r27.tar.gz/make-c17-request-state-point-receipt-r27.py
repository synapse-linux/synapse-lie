#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Bind actual collected matching GPU controls; never fabricate terminal state."""
from pathlib import Path
import datetime
import hashlib
import json

COMMIT = '117cbae6fb7b9a34b5b76d5eb66e41158d28116e'
BASE = Path('evidence')
HOST = Path('docs/development/validation/c17-request-state-host-2026-10-06.json')

def load(path):
    return json.loads(Path(path).read_text())

def sha(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

def bound(path):
    p = Path(path)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))

host = load(HOST)
assert sha(HOST) == 'f9873e1320079133723ad889fdd9d88562481714a6a69ea7a4f187015706ba0a'
build = BASE/'context-r27-build-r1'
provider_paths = [build/f'compile-evidence/build/rocm10-point-modern-r27-{selector}/BUILD-RECEIPT.json'
                  for selector in ('provider', 'reference-provider')]
providers = [load(p) for p in provider_paths]
for provider, selected in zip(providers, (True, False)):
    assert provider['owned_sampling_files'] == host['private_provider_inventory']
    assert len(provider['owned_sampling_files']) == 93
    assert provider['c17_sampling'] is selected and provider['hip_architecture'] == 'gfx1150'
    assert provider['grammar_state_edits_sha256'] == sha('adapters/gufo-state/grammar-state-edits.json')
assert load(build/'compile-evidence/collection.json')['exit_code'] == 0
assert load(build/'compile-evidence/collection.json')['reference_control_coherent_off']
coherence = load(build/'coherence-evidence/collection.json')
assert coherence['exit_code'] == 0 and coherence['whole_OFF_reference_archives']
assert coherence['compiled_frontend_primary_C17_ON'] and coherence['compiled_frontend_reference_C17_OFF']

labels = [('build', 'context-r27-build-r1'), ('ar', 'context-r27-openai-auto-ar-r1'),
          ('mtp', 'context-r27-openai-auto-mtp-r1'), ('direct-lie', 'context-r27-direct-lie-r1'),
          ('direct-gufo', 'context-r27-direct-gufo-r1')]
runs = []
direct = {}
for mode, label in labels:
    p = BASE/label
    r, c, m = load(p/'result.json'), load(p/'collection.json'), load(p/'manifest.json')
    controller = load(p/'controller-result.json')
    assert r['state'] == 'PASSED' and r['exit_code'] == r['child_exit_code'] == c['exit_code'] == controller['exit_code'] == 0
    assert r['ended_at'] and r['lease_released_at'] and not r['cleanup_failures']
    assert m['source_commit'] == COMMIT and r['service_after']['ActiveState'] == 'active'
    assert (r['lease']['device'], r['lease']['inode']) == (66307, 105946405)
    assert not r['postflight_before_restore']['kernel_kfd']
    rows = [json.loads(x) for x in (p/'telemetry.jsonl').read_text().splitlines()]
    peaks = {}
    for row in rows:
        for t in row['temperatures']:
            peaks[t['name']] = max(peaks.get(t['name'], -100), t['value_c'])
            if t['guarded']:
                assert t['value_c'] < t['limit_c']
    for name, identity in c['inventory']['files'].items():
        assert sha(p/name) == identity['sha256'] and (p/name).stat().st_size == identity['bytes']
    entry = dict(label=label, mode=mode, source_commit=COMMIT,
                 started_at=r['started_at'], ended_at=r['ended_at'],
                 supervisor_pid=r['pid'], supervisor_start_ticks=r['start_ticks'],
                 original_lease=r['lease'], lease_released_at=r['lease_released_at'],
                 actual_exit_code=r['exit_code'], child_exit_code=r['child_exit_code'],
                 controller_exit_code=controller['exit_code'],
                 KFD_empty_before_named_router_restore=True,
                 router_restored=r['service_after'], peak_c=peaks,
                 container_name=r['container'], files_sha_verified=len(c['inventory']['files']),
                 artifacts=[bound(p/name) for name in sorted(c['inventory']['files'])]
                           + [bound(p/'collection.json'), bound(p/'controller-result.json')])
    if mode == 'build':
        assert not r['model_attempted']
        assert r['build_result']['reference_control_coherent_off']
    else:
        assert r['model_attempted'] and r['model_stat_unchanged']
        entry.update(model_stat_unchanged=True,
                     gtt_peak_bytes=max(row['gpu']['mem_info_gtt_used'] for row in rows
                                        if row['gpu']['mem_info_gtt_used'] is not None),
                     observed_process_threads_max=max((int(proc['status']['Threads'])
                         for row in rows for proc in row['dri']
                         if proc.get('status', {}).get('Threads')), default=None))
        if mode in ('ar', 'mtp'):
            h = load(p/'http-result.json')
            assert h['state'] == 'PASSED' and h['server_exit_code'] == 0
            assert len(set(h['passed'])) == len(h['passed']) == 37
            entry.update(checks=37, passed=h['passed'], server_exit_code=0)
        else:
            measurements = [json.loads(x) for x in (p/'measurements.jsonl').read_text().splitlines()]
            assert measurements[-1] == dict(event='complete', exit_code=0)
            inputs = [x for x in measurements if x.get('event') == 'input']
            samples = [x for x in measurements if x.get('event') == 'sample']
            assert len(inputs) == len(samples) == 2
            assert [x['depth'] for x in samples] == [0, 4096]
            assert all(x['users'] == 1 and x['rep'] == x['warmup'] == 0
                       and x['finite_frontiers'] and x['prefill_ns'] > 0 and x['decode_ns'] > 0
                       and x['output_tokens_per_user'] == len(x['output_ids']) for x in samples)
            direct[mode] = dict(identity=measurements[0], inputs=inputs, samples=samples)
            entry.update(direct_control=direct[mode], checks=None, performance_qualification=False)
    runs.append(entry)
assert runs[1]['passed'] == runs[2]['passed']
assert direct['direct-lie']['inputs'] == direct['direct-gufo']['inputs']
matched_fields = ('point', 'rep', 'warmup', 'depth', 'users', 'prompt_tokens', 'cache_tokens',
                  'prefill_tokens_per_user', 'output_tokens_per_user', 'output_tokens', 'stop',
                  'finite_frontiers', 'prefill_logits_sha256', 'decode_logits_sha256', 'output_ids')
pair = []
for lhs, rhs in zip(direct['direct-lie']['samples'], direct['direct-gufo']['samples']):
    for field in matched_fields:
        assert lhs[field] == rhs[field], (lhs['point'], field)
    pair.append(dict(point=lhs['point'], depth=lhs['depth'], complete_physical_inputs_equal=True,
                     full_output_ids_equal=True, full_prefill_and_decode_frontier_hashes_equal=True,
                     output_tokens=lhs['output_tokens'], scope='Selected AR greedy C1 control only; warmup0/rep1, not performance qualification'))

final_path = BASE/'context-r27-final-161-r1.json'
final = load(final_path)
assert final['actual_exit_code'] == 0
f = final['result']
assert f['state'] == 'FRESH_ALL_FIVE_WINDOWS_CLOSED_NO_STANDING_RESERVATION'
assert f['original_lease']['free_briefly'] and f['original_lease']['released']
assert not f['foreign_compute_clients'] and not f['http8000_listeners'] and not f['guarded_hot']
assert len(f['owned_window_closures']) == len(runs) == 5
for entry, closure in zip(runs, f['owned_window_closures']):
    assert closure['label'] == entry['label'] and closure['supervisor_identity_absent']
    assert closure['container_absent'] and closure['label_listing_exit'] == 0 and closure['label_listing_empty']
    assert closure['container_init_identity_recorded'] and closure['container_init_identity_absent'] is True
    entry.update(actual_window_retired=True, actual_supervisor_identity_absent=True,
                 container_init_identity_recorded=True, container_init_identity_absent=True,
                 container_init_pid=closure['container_init_pid'],
                 container_init_start_ticks=closure['container_init_start_ticks'],
                 container_init_identity_source=closure['container_identity_source'])

source = load(BASE/'context-r27-source-seal.json')
bundle = load(BASE/'context-r27-bundle-result.json')
assert source['source_commit'] == COMMIT and bundle['exit_code'] == 0
assert bundle['result']['metadata']['source_commit'] == COMMIT
receipt = dict(
    schema='synapse-lie.c17-request-state-point-original-qualification.v1',
    at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), state='PASSED_WITH_STATED_SCOPE',
    source_commit=COMMIT, code_checkpoint=COMMIT, target='pop@192.168.5.161', gpu_target='gfx1150',
    model='Qwen3.8-Flash-Next UD-Q4_K_XL', upstream_pin=providers[0]['source_pin'],
    scope='Matching sealed93-file shared C17 request grammar snapshots, independent copies and direct borrowed handoffs, complete coherent HIP ON/OFF providers and their actual private compiler/linker selections. Unchanged37 original-weight OpenAI controls in each AR/MTP mode, plus selected common ARgreedy C1 physical-input/output/full-frontier equality in two direct LIE/Gufo controls. Private C++ value/error/view/legacy-transfer glue, schema/regex/template construction and model/controller remain transitional. No claim of all branches, faults, probabilities, learned quality, exact private allocation cost, matched performance, 1M recall or complete autonomous C engine.',
    host_receipts=[bound(HOST)], source_capsule=bound(BASE/'context-r27-source-seal.json'),
    bundle=bound(BASE/'context-r27-bundle-result.json'),
    provider_build_receipt=bound(provider_paths[0]), reference_provider_build_receipt=bound(provider_paths[1]),
    actual_compiler_linker_coherence=bound(build/'coherence-evidence/collection.json'),
    compiled_provider_files=providers[0]['owned_sampling_files'], compiled_first_party_file_count=81,
    compiled_vendor_and_provenance_file_count=12,
    grammar_state_recipe_sha256=providers[0]['grammar_state_edits_sha256'],
    reference_control_coherent_off=True, selected_complete_direct_controls=pair,
    build_closure=bound(BASE/'context-r27-build-closure-r1.json'),
    coordination=[bound(p) for p in sorted(BASE.glob('context-r27-peer-*.json'))],
    runs=runs,
    build_artifacts=[bound(p) for folder in ('compile-evidence', 'coherence-evidence')
                     for p in sorted((build/folder).rglob('*')) if p.is_file()],
    binaries=bundle['result']['metadata']['artifacts'],
    new_inference_threads=0, KV_cache_payload_format_changed=False, existing_public_ABI_breaking_change=False,
    new_contracts=['Additive lie_grammar_state_duplicate; owned independent saved-allocator/saved-limit snapshots, ABI structs unchanged'],
    thermal_policy='CPU98/NVMe85/lower exposed guards; GPU observe-only. No fan/clock/power tuning.',
    root_157_non_use=True,
    Terminal_Bench='Stopped/collected/closed/deferred until functional modifications and matching qualification finish; no restart/migration/reservation.',
    retained_current_observer_failures=[bound(BASE/'context-r27-build-live-r6.json'), bound(BASE/'context-r27-build-live-r6.py')],
    observer_failure_scope='Read-only observer assumed ADMITTED while the successful build was restoring its router; actual observer1 retained, same supervisor observed terminal without restart.',
    corrected_readonly_observations=[bound(p) for p in sorted(BASE.glob('context-r27-*.json'))
                                    if any(x in p.name for x in ('-live-', '-before-', '-closure-', '-fresh-')) and p.name != 'context-r27-build-live-r6.json'],
    previous_matching_GPU_receipt=bound('docs/development/validation/c17-lexeme-point-gpu-2026-10-06.json'),
    retained_offline_QA_refusals=[bound(BASE/'context-r27-offline-closure-syntax-failure-r1.json'), bound(BASE/'context-r27-direct-lie-closure-r1.py')],
    retained_unresolved_failure=False, all_six_owned_tasks_open=True,
    pending=['Deferred full Terminal Bench final rewards/transcripts/closure after functional changes and qualification.',
             '1M recall quality and matched Gufo/Halogen physical work/depth/concurrency/cache/thread/resource/graphs.',
             'Broader learned DS4 steering quality, independent graph/correction/GPU faults/vision/matched cost.',
             'Independent GPU probability/filter/tool-transition coverage and matched sampling cost.',
             'Remaining model/controller/schema/regex/template ownership extraction; broader branch/fault/private-resource/cost qualification.'],
    final_fresh_closure=bound(final_path), publication=False, goal_complete=False)
out = Path('docs/development/validation/c17-request-state-point-gpu-2026-10-06.json')
with out.open('x') as destination:
    json.dump(receipt, destination, indent=2)
    destination.write('\n')
print(json.dumps(dict(receipt=str(out), sha256=sha(out), GPU_controls=[37,37],
                     selected_complete_direct_controls=2, compiled_provider_file_count=93,
                     actual_runs_collected_and_retired=len(runs))))
