# SPDX-License-Identifier: MIT
"""Read-only current identity/lease/container observation for own r24 build."""
from pathlib import Path
import hashlib,json,subprocess
program="""from pathlib import Path
import datetime,importlib.util,json,os,subprocess
base=Path('/home/pop/workspace/synapse-lie');root=base/'context-r24-build-r1'
r=json.loads((root/'result.json').read_text())
spec=importlib.util.spec_from_file_location('point',root/'runner.py');point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
try:live=point.ticks(r['pid'])==r['start_ticks']
except FileNotFoundError:live=False
fds=[]
if live:
 for p in Path('/proc').joinpath(str(r['pid']),'fd').iterdir():
  try:
   s=p.stat()
   if (s.st_dev,s.st_ino)==(66307,105946405):fds.append(int(p.name))
  except OSError:pass
state={}
if r.get('container'):
 q=subprocess.run(['docker','inspect','--format','{{json .State}}',r['container']],capture_output=True,text=True,timeout=15)
 state={'exit_code':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
compile_path=base/'rocm10-fedora-161/source-modern-r24/evidence/rocm10-point-modern-r24-compile/result.json'
compile_result=json.loads(compile_path.read_text()) if compile_path.exists() else None
out={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'live_exact_supervisor':live,'pid':r['pid'],'start_ticks':r['start_ticks'],'state':r['state'],'lease':r.get('lease'),'original_lease_fds':fds,'container':state,'compile_result':compile_result,'model_attempted':r.get('model_attempted'),'observation':point.observe(98,gpu_observation_only=True)}
if live:assert fds and r['state']=='ADMITTED' and not r['model_attempted']
print(json.dumps(out))
"""
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
r=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':r.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':r.stdout,'stderr':r.stderr}
try:record['result']=json.loads(r.stdout)
except ValueError:pass
with Path('evidence/context-r24-build-live-r1.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
if 'result' in record:
 print(json.dumps({k:record['result'][k] for k in ('at_utc','live_exact_supervisor','pid','start_ticks','state','original_lease_fds','compile_result','model_attempted')}))
else:print(json.dumps(record))
raise SystemExit(r.returncode)
