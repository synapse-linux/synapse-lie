#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Bind completed sealed build, selected model controls and actual closure."""
from pathlib import Path
import datetime
import hashlib
import json

def load(p):
    return json.loads(Path(p).read_text())

def sha(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def bound(p):
    p = Path(p)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))

commit = '904774da942a98b906458fb0f2a50081a9a8ddf1'
host_path = Path('docs/development/validation/c17-json-parser-host-2026-10-06.json')
host = load(host_path)
provider_path = Path('evidence/context-r24-build-r1/compile-evidence/build/rocm10-point-modern-r24-provider/BUILD-RECEIPT.json')
provider = load(provider_path)
assert provider['owned_sampling_files'] == host['private_provider_inventory']
assert len(provider['owned_sampling_files']) == 86
assert provider['json_parser_edits_sha256'] == sha('adapters/gufo-state/json-parser-edits.json')
runs = []
for mode in ('build', 'ar', 'mtp'):
    label = 'context-r24-build-r1' if mode == 'build' else f'context-r24-openai-auto-{mode}-r1'
    p = Path('evidence') / label
    r, c, m = load(p / 'result.json'), load(p / 'collection.json'), load(p / 'manifest.json')
    assert r['state'] == 'PASSED' and r['exit_code'] == r['child_exit_code'] == c['exit_code'] == 0
    assert r['ended_at'] and r['lease_released_at'] and not r['cleanup_failures']
    assert m['source_commit'] == commit and r['service_after']['ActiveState'] == 'active'
    assert (r['lease']['device'], r['lease']['inode']) == (66307, 105946405)
    assert not r['postflight_before_restore']['kernel_kfd']
    rows = [json.loads(x) for x in (p / 'telemetry.jsonl').read_text().splitlines()]
    peaks = {}
    for row in rows:
        for t in row['temperatures']:
            peaks[t['name']] = max(peaks.get(t['name'], -100), t['value_c'])
    entry = dict(label=label, mode=mode, source_commit=commit,
                 started_at=r['started_at'], ended_at=r['ended_at'],
                 supervisor_pid=r['pid'], supervisor_start_ticks=r['start_ticks'],
                 original_lease=r['lease'], lease_released_at=r['lease_released_at'],
                 actual_exit_code=r['exit_code'], child_exit_code=r['child_exit_code'],
                 KFD_empty_before_named_router_restore=True,
                 router_restored=r['service_after'], peak_c=peaks,
                 container_name=r['container'],
                 container_init_identity_recorded=all(type(r.get(k)) is int and r[k] > 0
                                                     for k in ('container_host_pid', 'container_start_ticks')),
                 container_init_pid=r.get('container_host_pid'),
                 container_init_start_ticks=r.get('container_start_ticks'),
                 files_sha_verified=len(c['inventory']['files']),
                 artifacts=[bound(p / name) for name in sorted(c['inventory']['files'])]
                           + [bound(p / 'collection.json'), bound(p / 'controller-result.json')])
    if mode != 'build':
        h = load(p / 'http-result.json')
        assert h['state'] == 'PASSED' and h['server_exit_code'] == 0
        assert len(set(h['passed'])) == len(h['passed']) == 37
        assert r['model_stat_unchanged']
        entry.update(checks=37, passed=h['passed'], model_stat_unchanged=True,
                     gtt_peak_bytes=max(row['gpu']['mem_info_gtt_used'] for row in rows
                                        if row['gpu']['mem_info_gtt_used'] is not None),
                     observed_process_threads_max=max((int(proc['status']['Threads'])
                         for row in rows for proc in row['dri']
                         if proc.get('status', {}).get('Threads')), default=None))
    else:
        assert not r['model_attempted']
    runs.append(entry)

assert runs[1]['passed'] == runs[2]['passed']
source = load('evidence/context-r24-source-seal.json')
bundle = load('evidence/context-r24-bundle-result.json')
assert source['source_commit'] == commit and bundle['exit_code'] == 0
assert bundle['result']['metadata']['source_commit'] == commit
final_path = Path('evidence/context-r24-final-161-r1.json')
final = load(final_path)
assert final['actual_exit_code'] == 0
f = final['result']
assert f['state'] == 'FRESH_ALL_THREE_WINDOWS_CLOSED_NO_STANDING_RESERVATION'
assert f['original_lease']['free_briefly'] and f['original_lease']['released']
assert not f['foreign_compute_clients'] and not f['http8000_listeners'] and not f['guarded_hot']
assert len(f['owned_window_closures']) == 3
for entry, closure in zip(runs, f['owned_window_closures']):
    assert closure['label'] == entry['label'] and closure['supervisor_identity_absent']
    assert closure['container_absent'] and closure['label_listing_exit'] == 0 and closure['label_listing_empty']
    assert closure['container_init_identity_absent'] is not False
    entry['actual_window_retired'] = True
    entry['actual_supervisor_identity_absent'] = True
    entry['container_init_identity_absent'] = closure['container_init_identity_absent']

receipt = dict(
    schema='synapse-lie.c17-json-parser-point-original-qualification.v1',
    at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), state='PASSED_WITH_STATED_SCOPE',
    source_commit=commit, code_checkpoint=commit, target='pop@192.168.5.161', gpu_target='gfx1150',
    model='Qwen3.8-Flash-Next UD-Q4_K_XL', upstream_pin=provider['source_pin'],
    scope='Matching sealed default-ON86-file C17 complete JSON syntax/UTF8/escape/duplicate-key provider/application build (74 first-party +12 vendor/provenance), followed by unchanged37 original-weight OpenAI wire/lifecycle/tool/grammar/output controls in AR/MTP. Selected integrated paths only; typed JSON/key/value/predicate containers and model/controller remain private. These controls do not qualify every parser/numeric/format branch, independent probabilities/faults/quality/private allocation-exact resources/matched cost. No CPU model forward, speedup or Terminal Bench score.',
    host_receipts=[bound(host_path), bound('docs/development/validation/c17-binary64-host-2026-10-06.json')],
    source_capsule=bound('evidence/context-r24-source-seal.json'),
    bundle=bound('evidence/context-r24-bundle-result.json'), provider_build_receipt=bound(provider_path),
    compiled_provider_files=provider['owned_sampling_files'], compiled_first_party_file_count=74,
    compiled_vendor_and_provenance_file_count=12,
    json_parser_recipe_sha256=provider['json_parser_edits_sha256'],
    build_closure=bound('evidence/context-r24-build-closure-r1.json'),
    coordination=[bound('evidence/context-r24-peer-nonuse-r1.json'),
                  bound('evidence/context-r24-peer-nonuse-ar-r1.json'),
                  bound('evidence/context-r24-peer-nonuse-mtp-r1.json')],
    runs=runs,
    build_artifacts=[bound(p) for p in sorted(Path('evidence/context-r24-build-r1/compile-evidence').rglob('*'))
                     if p.is_file()], binaries=bundle['result']['metadata']['artifacts'],
    new_inference_threads=0, KV_cache_payload_format_changed=False, existing_public_ABI_breaking_change=False,
    new_contracts=['lie/json_parse.h ABI1 / lie_json_parse_events'],
    thermal_policy='CPU98/NVMe85/lower exposed guards; GPU observe-only. No fan/clock/power tuning.',
    root_157_non_use=True,
    Terminal_Bench='Stopped/collected/closed/deferred until functional modifications and matching qualification finish. No restart/reservation.',
    retained_current_observer_failures=[bound('evidence/context-r24-fresh-161-r1.json'),
                                       bound('evidence/context-r24-fresh-161.py'),
                                       bound('evidence/context-r24-observer-display-failure-r1.json'),
                                       bound('evidence/context-r24-before-ar-r1.py')],
    corrected_readonly_observations=[bound('evidence/context-r24-fresh-161-r2.json'),
                                    bound('evidence/context-r24-before-ar-r1.json'),
                                    bound('evidence/context-r24-before-ar-r2.json'),
                                    bound('evidence/context-r24-before-mtp-r1.json')],
    previous_matching_GPU_receipt=bound('docs/development/validation/c17-binary64-point-gpu-2026-10-06.json'),
    retained_peer_status_correction=bound('evidence/context-r24-peer-status-correction-r1.json'),
    retained_unresolved_failure=False, all_six_owned_tasks_open=True,
    pending=['Deferred full TerminalBench final rewards/transcripts/closure after functional changes.',
             '1M recall quality; matched Gufo/Halogen physical-work depth/concurrency/cache/thread/resource/graphs.',
             'Learned DS4 steering quality, independent graph/correction/GPUfault/vision/later mixed-history lookup/matched cost.',
             'Independent GPU probability/filter/tool-transition coverage and matched sampling cost.',
             'Typed JSON/key/value/predicate containers and model/controller extraction; broader branch/fault/private resource/cost qualification.'],
    final_fresh_closure=bound(final_path), publication=False, goal_complete=False)
p = Path('docs/development/validation/c17-json-parser-point-gpu-2026-10-06.json')
with p.open('x') as out:
    json.dump(receipt, out, indent=2)
    out.write('\n')
print(json.dumps(dict(receipt=str(p), sha256=sha(p), GPU_controls=[37,37],
                     compiled_provider_file_count=86, actual_runs_collected_and_retired=len(runs))))
