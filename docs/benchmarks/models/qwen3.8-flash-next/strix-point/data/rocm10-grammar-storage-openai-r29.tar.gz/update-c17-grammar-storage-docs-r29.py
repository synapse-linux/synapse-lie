# SPDX-License-Identifier: MIT
"""Update existing docs only after matching actual GPU controls and closure."""
from pathlib import Path
import json

r = json.loads(Path('docs/development/validation/c17-grammar-storage-point-gpu-2026-10-06.json').read_text())
assert r['state'] == 'PASSED_WITH_STATED_SCOPE' and len(r['runs']) == 3
assert r['source_commit'] == 'ad53e681c5c84e98ccc4c6024b0694e9a41f3cd5'
assert all(row['actual_exit_code'] == 0 and row['actual_window_retired'] for row in r['runs'])
ar, mtp = r['runs'][1:]
assert ar['checks'] == mtp['checks'] == 37
closure = json.loads(Path(r['final_fresh_closure']['path']).read_text())['result']


def edit(name, old, new):
    path = Path(name)
    text = path.read_text()
    assert text.count(old) == 1, (name, old)
    path.write_text(text.replace(old, new))


edit('README.md', '''The qualified [C17 grammar and root schema build](docs/development/C17-SAMPLING.md#root-schema-admission)
passes [37 OpenAI controls in both AR and MTP on Strix Point](docs/development/validation/c17-schema-root-point-gpu-2026-10-06.json).
The later removal of C++ grammar table copies passes host checks; its matching
GPU qualification is pending.
''', '''The current [C17 grammar build](docs/development/C17-SAMPLING.md#immutable-grammar-table-ownership)
passes [37 OpenAI controls in both AR and MTP on Strix Point](docs/development/validation/c17-grammar-storage-point-gpu-2026-10-06.json).
''')
edit('docs/development/C17-SAMPLING.md', '''This increment needs its own sealed HIP ON/OFF build and original-weight gates
on `.161`; the earlier `3c4cac56`/r28 receipt excludes it. Broader faults,
probabilities, quality, private resources and matched performance remain open.
''', '''The matching sealed `ad53e681` HIP build verifies both complete 96-file
ON/OFF providers, numerical archives and private model/frontend selections. It
passes the unchanged 37 original-weight OpenAI controls in each AR/MTP mode on
`.161` ([GPU receipt](validation/c17-grammar-storage-point-gpu-2026-10-06.json)).
The HOST storage/lifetime probes retain their separate scope. These selected
GPU paths do not establish whole grammar branch/fault/probability/quality/private
resource coverage or a throughput gain; those gates remain open.
''')
edit('docs/development/C17-SAMPLING.md', '''The selected provider compiler now calls this C builder for these operations;
its original construction and validation bodies execute only with
`LIE_C17_SAMPLING=OFF`. The adapter translates typed inputs/errors and copies
private templates needed by the still-transitional reasoning/tool composition.
The base grammar creates its runtime program directly from the C tables.
''', '''The selected provider compiler calls this C builder for these operations;
its original construction and validation bodies execute only with
`LIE_C17_SAMPLING=OFF`. At the builder checkpoint the adapter also copied private
templates for reasoning/tool composition. The newer
[immutable storage slice](#immutable-grammar-table-ownership) removes those copies;
the base and composed grammars create their programs directly from C tables.
Typed construction/error views remain adapter glue.
''')
edit('docs/BACKEND.md', '''   witnesses. Matching HIP builds and original-weight gates remain pending;
   the qualified `3c4cac56` runtime excludes this later increment. Private
   construction/value/error/prompt facades and model/controller remain transitional.
''', '''   witnesses. Matching sealed `ad53e681` HIP ON/OFF providers and private
   consumers pass unchanged AR37/MTP37 original-weight controls on `.161`
   ([GPU receipt](development/validation/c17-grammar-storage-point-gpu-2026-10-06.json)).
   Broader grammar branches/faults/quality/resources and matched cost stay open.
   Private construction/value/error/prompt facades and model/controller remain transitional.
''')
edit('CHANGELOG.md', '''  rule/class containers. HOST state/mask and lifetime checks pass; matching GPU
  qualification is pending. Existing public ABI, reactive workers and cache
''', '''  rule/class containers. HOST state/mask and lifetime checks pass; matching HIP
  ON/OFF builds pass 37 selected GPU OpenAI controls in both AR and MTP on Strix
  Point. Existing public ABI, reactive workers and cache
''')
bench = 'docs/benchmarks/models/qwen3.8-flash-next/strix-point/README.md'
edit(bench, '### Original-weight HTTP AR and MTP gates\n\n', '''### Original-weight HTTP AR and MTP gates

The current matching `ad53e681` build removes duplicate C++ grammar rule/class
payloads and passes the same **37 controls in AR and MTP**. The
[source-bound receipt](../../../../development/validation/c17-grammar-storage-point-gpu-2026-10-06.json)
and [portable raw evidence](data/rocm10-grammar-storage-openai-r29.tar.gz)
retain coherent 96-file HIP ON/OFF providers, matching private model/frontends,
telemetry and actual closure. This is functional qualification; no new
throughput comparison or graph is claimed.

''')
edit(bench, 'The current matching `3c4cac56` build adds C17 root schema admission',
     'The preceding matching `3c4cac56` build adds C17 root schema admission')
progress = '''## Immutable C17 grammar storage passes selected GPU controls — 2026-10-06 UTC

The matching sealed `ad53e681` source compiles complete 96-file HIP ON/OFF
providers and all matching private model/frontend consumers. Both providers
bind the six-edit storage recipe, and the reference links whole OFF archives.
It passes the unchanged 37 original-weight OpenAI controls in each AR/MTP mode
on `.161`; every server/child/controller/supervisor exits 0. The
[GPU receipt](development/validation/c17-grammar-storage-point-gpu-2026-10-06.json)
and [portable raw evidence](benchmarks/models/qwen3.8-flash-next/strix-point/data/rocm10-grammar-storage-openai-r29.tar.gz)
preserve these selected integrated controls separately from the frozen HOST52,
29 complete language/state/mask witnesses and nine untimed handoff probes.
There is no new direct or throughput comparison. Remaining typed construction/
value/error/prompt facades and model/controller are transitional.

'''
progress += (f"AR/MTP CPU maxima are {ar['peak_c']['k10temp']:g}/{mtp['peak_c']['k10temp']:g} C, "
             f"GPU {ar['peak_c']['amdgpu']:g}/{mtp['peak_c']['amdgpu']:g} C, and NVMe\n"
             f"{ar['peak_c']['nvme']:g}/{mtp['peak_c']['nvme']:g} C. Whole-process thread maxima are "
             f"{ar['observed_process_threads_max']}/{mtp['observed_process_threads_max']};\n"
             "no inference thread is added. CPU98/NVMe85/lower guards and GPU observation\n"
             f"remain intact. Fresh {closure['at_utc'][11:19]} UTC closure verifies all three exact\n"
             "supervisor/container-init identities retired, owned containers removed,\n"
             f"original lease free then released, router {closure['service']['MainPID']} active/only KFD and\n"
             "HTTP8000 unbound. Model/predictor stats are unchanged. Root has no remaining\n"
             "remote job/client/build/lease/waiter/reservation or live local handle;\n"
             "`.157/.158` remain unused. No tuning/install/deployment/push occurs. Broader\n"
             "branch/fault/probability/quality/private-resource and matched-cost gates\n"
             "stay open. All six owned tasks remain open; Terminal Bench stays stopped,\n"
             "collected and deferred last until functional changes and qualification finish.\n\n")
edit('docs/PROGRESS.md', '# Development progress\n\n', '# Development progress\n\n' + progress)
coordination = '''## R29 immutable grammar storage build and selected controls closed — 2026-10-06

Fresh peer own non-use and independent global preflights admit sealed `ad53e681`
on `.161`. The device-free build verifies complete 96-file HIP ON/OFF providers,
matching private model/frontend layouts and whole OFF reference linkage. AR/MTP
each pass the unchanged 37 original-weight OpenAI controls. All three windows
have server/child/controller/supervisor exits 0 and collected hash-bound files.
[Receipt](development/validation/c17-grammar-storage-point-gpu-2026-10-06.json).

'''
coordination += (f"Fresh {closure['at_utc']} closure independently verifies exact\n"
                 "supervisor/container-init retirement, owned containers removed, HTTP8000\n"
                 "unbound, original lease device66307/inode105946405 free then released,\n"
                 f"and router {closure['service']['MainPID']} restored/only KFD. No foreign client or hot\n"
                 "guard is observed. Models remain stat-bound unchanged; no tuning, install,\n"
                 "deployment or root `.157/.158` work occurs. Root has no standing job/build/\n"
                 "client/lease/waiter/reservation/handle. This dated closure is not future\n"
                 "admission. Broader gates and all six tasks remain open; Terminal Bench is\n"
                 "stopped/collected/closed/deferred last, without restart or reservation.\n\n")
edit('docs/COORDINATION.md', '# DS4 / synapse-lie coordination\n\n',
     '# DS4 / synapse-lie coordination\n\n' + coordination)
print('Updated seven existing documents after matching source/binaries and actual GPU closure.')
