# SPDX-License-Identifier: MIT
"""Collect exact finished owned compile logs, never model payloads."""
from pathlib import Path
import hashlib,json,subprocess
label='context-r29-build-r1';root=Path('evidence')/label
result=json.loads((root/'result.json').read_text());assert result['ended_at'] and result['lease_released_at']
assert result['state']=='PASSED' and result['exit_code']==result['child_exit_code']==0
names=['build/rocm10-point-modern-r29-'+sel+'/build.ninja' for sel in ('provider','reference-provider','runtime')]
assert len(names)==3
remote='/home/pop/workspace/synapse-lie/rocm10-fedora-161/source-modern-r29'
ssh=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161']
scp=['scp','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8']
program='NAMES='+repr(names)+'\n'+'''from pathlib import Path
import hashlib,json,os
base=Path('/home/pop/workspace/synapse-lie/rocm10-fedora-161/source-modern-r29')
assert base.resolve()==base and base.stat().st_uid==os.getuid()
r=json.loads((base/'evidence/rocm10-point-modern-r29-compile/result.json').read_text())
assert r['state']=='BUILT_NOT_GPU_TESTED' and r['exit_code']==0 and r['source_commit']=='ad53e681c5c84e98ccc4c6024b0694e9a41f3cd5'
files={}
for n in NAMES:
 p=base/n;assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(base)
 with p.open('rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest()
 files[n]={'bytes':p.stat().st_size,'sha256':digest}
print(json.dumps(files))
'''
p=subprocess.run(ssh+['python3 -B -'],input=program,text=True,capture_output=True,timeout=60)
out=root/'coherence-evidence';out.mkdir(exist_ok=False)
r={'schema':'synapse-lie.point-compile-collection.v1','scope':'Own compile logs/receipt only; no binaries/models copied','argv':ssh+['python3 -B -'],'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'inventory_exit_code':p.returncode,'stderr':p.stderr,'commands':[],'exit_code':1}
(out/'collection.json').write_text(json.dumps(r,indent=2)+'\n');assert p.returncode==0
r['files']=json.loads(p.stdout)
for name,identity in r['files'].items():
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True)
 cmd=scp+['pop@192.168.5.161:'+remote+'/'+name,str(target)]
 p=subprocess.run(cmd,text=True,capture_output=True,timeout=60)
 r['commands'].append({'argv':cmd,'actual_exit_code':p.returncode,'stderr':p.stderr})
 (out/'collection.json').write_text(json.dumps(r,indent=2)+'\n')
 assert p.returncode==0 and target.stat().st_size==identity['bytes'] and hashlib.sha256(target.read_bytes()).hexdigest()==identity['sha256']
def block(content, prefix):
 rows=content.splitlines(); hits=[i for i,line in enumerate(rows) if line.startswith(prefix)]
 assert len(hits)==1,(prefix,hits)
 start=hits[0];end=start+1
 while end<len(rows) and rows[end].strip():end+=1
 return '\n'.join(rows[start:end])
frontend=(out/'build/rocm10-point-modern-r29-runtime/build.ninja').read_text()
ref_object=block(frontend,'build CMakeFiles/synapse-lie-bench-gufo-reference.dir/adapters/gufo_reference_bench.cpp.o:')
assert '-DLIE_C17_SAMPLING=0' in ref_object and '-DLIE_C17_SAMPLING=1' not in ref_object
primary_object=block(frontend,'build CMakeFiles/lie_gufo.dir/adapters/gufo.cpp.o:')
assert '-DLIE_C17_SAMPLING=1' in primary_object and '-DLIE_C17_SAMPLING=0' not in primary_object
ref_link=block(frontend,'build synapse-lie-bench-gufo-reference:')
assert 'rocm10-point-modern-r29-provider/' not in ref_link
for archive in ('libgufo_core.a','libgufo_qwen38_flash_next.a','libgufo_qwen38_flash_next_mmq.a'):
 assert 'rocm10-point-modern-r29-reference-provider/' in ref_link and archive in ref_link
witness={}
for sel,value in (('provider',1),('reference-provider',0)):
 content=(out/('build/rocm10-point-modern-r29-'+sel+'/build.ninja')).read_text()
 model=block(content,'build src/models/qwen38_flash_next/CMakeFiles/gufo_qwen38_flash_next.dir/engine.cpp.o:')
 assert '-DLIE_C17_SAMPLING='+str(value) in model
 assert '-DLIE_C17_SAMPLING='+str(1-value) not in model
 witness[sel+'_model_object']=model
r.update(exit_code=0,compiled_frontend_primary_C17_ON=True,compiled_frontend_reference_C17_OFF=True,whole_OFF_reference_archives=True,actual_selected_blocks={'primary_frontend_object':primary_object,'reference_frontend_object':ref_object,'reference_link':ref_link,**witness})
(out/'collection.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'files':len(names),'actual_exit_code':0,'reference_CPP_consumer_OFF':True,'whole_OFF_archives':True,'model_ON_OFF_flags_verified':True}))
