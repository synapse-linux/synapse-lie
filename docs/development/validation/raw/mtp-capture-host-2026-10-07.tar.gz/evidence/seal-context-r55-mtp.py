# SPDX-License-Identifier: MIT
"""Seal finished native MTP HOST checks; no test/model/GPU/remote work."""
from pathlib import Path
import datetime,hashlib,json,re,stat,subprocess,tarfile
root=Path.cwd(); dest=root/'docs/development/validation'; name='mtp-capture-host-2026-10-07'
receipt=dest/(name+'.json'); archive=dest/'raw'/(name+'.tar.gz')
assert not receipt.exists() and not archive.exists()
def read(p): return json.loads((root/p).read_text())
def ident(p):
    assert p.is_file() and not p.is_symlink()
    with p.open('rb') as stream: digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'bytes':p.stat().st_size,'sha256':digest}
final=read('evidence/context-r55-mtp-host-r4/result.json')
guard=read('evidence/context-r55-mtp-host-r4-guard/result.json')
assert final['actual_exit_code']==guard['exit_code']==guard['child_exit_code']==0 and guard['reason'] is None
assert len(final['commands'])==13 and all(c['actual_exit_code']==0 for c in final['commands'])
failed=[]
for suffix,needle in (('', 'MTP text REFERENCE replay exit 1'),('-r2','expected an index less than 0')):
    commands=read('evidence/context-r55-mtp-host'+suffix+'/commands.json')
    old_guard=read('evidence/context-r55-mtp-host'+suffix+'-guard/result.json')
    assert commands[-1]['actual_exit_code']==old_guard['exit_code']==old_guard['child_exit_code']==8
    assert needle in (root/('evidence/context-r55-mtp-host'+suffix+'/release-provider-tests.log')).read_text()
    failed.append({'commands':commands,'guard':old_guard,'reason':needle})
owned=['CMakeLists.txt','include/lie/sampling_observer.h','adapters/gufo_sampling_observer.hpp',
       'tools/sampling-capture.c','tools/sampling-capture-mtp.h','tools/sampling-capture-format.h',
       'tools/strix-point-campaign.py','tools/strix-point-bench-collect.py',
       'tests/sampling_capture_executor.c','tests/test_sampling_capture.c','tests/test_sampling_capture_mtp.c',
       'tests/test_sampling_capture_campaign.py','tests/sampling/observer.cpp','tests/sampling/replay.cpp',
       'tests/sampling/mtp_replay.hpp','tests/sampling/mtp_replay_contract.cmake',
       'tests/sampling/replay_contract.cmake','tests/sampling/tools_replay_contract.cmake','tests/sampling/CMakeLists.txt',
       'adapters/gufo-state/sampling-observer-edits.json','cmake/provider/Source.cmake',
       'cmake/provider/Build.cmake','cmake/provider/Verify.cmake','third_party/gufo-source.json',
       'include/lie/executor.h','include/lie/mtp.h','include/lie/sampling.h','include/lie/sampling_distribution.h']
files={rel:root/rel for rel in owned}; omitted={}
def add(p):
    if p.is_symlink(): omitted[str(p.relative_to(root))]={'type':'symlink','target':str(p.readlink())}
    elif p.is_file(): files[str(p.relative_to(root))]=p
    elif stat.S_ISFIFO(p.stat().st_mode): omitted[str(p.relative_to(root))]={'type':'owned-negative-fixture-FIFO'}
def tree(folder):
    for p in folder.rglob('*'):
        if not p.is_dir(): add(p)
for folder in root.glob('evidence/context-r55-mtp-host*'):
    if folder.is_dir(): tree(folder)
    elif folder.is_file(): add(folder)
tests=[]; binaries={}; witnesses=[]; variant=None
for mode in ('release','asan'):
    native=root/('build/mtp-capture-native-r55-'+mode)
    provider=root/('build/mtp-capture-sampling-r55-'+mode)
    for folder,count,scope in ((native,6,'native-capture-ABI-provider-refusals'),(provider,5,'ON-OFF-observer-AR-tools-MTP-replay')):
        log=folder/'Testing/Temporary/LastTest.log'; text=log.read_text()
        assert text.count('Test Passed.')==count and 'Test Failed.' not in text
        add(log); tests.append({'configuration':mode,'scope':scope,'passed':count,'failed':0})
        add(folder/'CMakeCache.txt'); add(folder/'CTestTestfile.cmake')
    for executable in ('test-executor-abi','test-sampling-capture','test-sampling-capture-contract','test-sampling-capture-mtp-contract'):
        binaries[str((native/executable).relative_to(root))]=ident(native/executable)
    for executable in ('reference-sampling-replay','candidate-sampling-replay','fallback-sampling-replay',
                       'candidate-sampling-observer','fallback-sampling-observer'):
        binaries[str((provider/executable).relative_to(root))]=ident(provider/executable)
    current=read(str((provider/'variant-files.json').relative_to(root))); assert len(current)==1019
    if variant is None: variant=current
    assert current==variant; add(provider/'variant-files.json')
    for rel in ('src/core/sampling.hpp','src/core/sampling.cpp','src/models/qwen38_flash_next/engine.cpp'):
        p=provider/'variant'/rel; assert ident(p)['sha256']==current[rel]; add(p)
    for line in (provider/'CTestTestfile.cmake').read_text().splitlines():
        match=re.match(r'add_test\("(replay|tools_replay|mtp_replay)-native-capture-contract"',line)
        if not match: continue
        folder=Path(re.search(r'"-DOUTPUT=([^\"]+)"',line).group(1)); assert folder.is_dir(); tree(folder)
        negative=[p for p in folder.glob('*.exit') if p.read_text().strip()=='1']
        assert len(negative)=={'replay':9,'tools_replay':10,'mtp_replay':22}[match[1]]
        if match[1]!='mtp_replay': continue
        for workload in ('text','tools','boundary'):
            data=[(folder/(workload+'-'+arm+'.txt')).read_bytes() for arm in ('REFERENCE','CANDIDATE','FALLBACK')]
            assert data[0]==data[1]==data[2]
            numbers=re.search(rb'MTP_ROWS=(\d+) PROPOSALS=(\d+) ACCEPTED=(\d+) REJECTED=(\d+) DEFERRED=(\d+) ',data[0])
            assert numbers and all(int(v)>0 for v in numbers.groups())
            capture=[json.loads(v) for v in (folder/workload/'capture.jsonl').read_text().splitlines()]
            assert capture[0]['synthetic'] is True and capture[-1]['event']=='complete'
            assert capture[-1]['rows']==int(numbers[1])
            witnesses.append({'configuration':mode,'workload':workload,'sha256':hashlib.sha256(data[0]).hexdigest(),
                **dict(zip(('rows','proposals','accepted_verifications','rejected_verifications','deferred_draws'),
                           map(int,numbers.groups())))})
    native_log=(native/'Testing/Temporary/LastTest.log').read_text()
    for directory in re.findall(r'(?:SAMPLING_CAPTURE_FORMAT_LIFETIME_PASS_NOT_INFERENCE|MTP_CAPTURE_NATIVE_BOUNDS_LIFETIME_PASS_NOT_INFERENCE) path=([^\s]+)',native_log):
        tree(Path(directory))
mocked=(root/'evidence/context-r55-mtp-host-r4/optional-supervisor-controls.log').read_text()
assert 'Ran 18 tests' in mocked and mocked.rstrip().endswith('OK')
for rel in ('tools/thermal-run.py','evidence/seal-context-r55-mtp.py','third_party/gufo-NOTICE','third_party/gufo-LICENSE'):
    add(root/rel)
members={rel:ident(p) for rel,p in sorted(files.items())}
with tarfile.open(archive,'x:gz') as packed:
    for rel in members: packed.add(files[rel],arcname=rel,recursive=False)
with tarfile.open(archive,'r:gz') as packed:
    entries=packed.getmembers(); assert len(entries)==len(members)
    for e in entries:
        assert e.isfile() and 'sealing-guard' not in e.name and 'postseal-guard' not in e.name
        with packed.extractfile(e) as stream: digest=hashlib.file_digest(stream,'sha256').hexdigest()
        assert {'bytes':e.size,'sha256':digest}==members[e.name]==ident(files[e.name])
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
r={'schema':'synapse-lie.mtp-capture-host.v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
   'state':'NATIVE_MTP_CAPTURE_REPLAY_HOST_PASSED_NEW_HIP_AND_ORIGINAL_WEIGHT_ACCEPTANCE_PENDING',
   'classification':'HOST-NOT-INFERENCE','base_commit':head,'source_pin':'f783fedb9bea2ec7de941f6da4e02f4a4596b29e',
   'implementation_sources':{rel:members[rel] for rel in owned},'observer_ABI':1,
   'source_recipe_edits':5,'owned_sampling_file_inventory':122,'variant_files_verified':1019,
   'release_and_sanitizer_tests':tests,'final_unsuppressed_host_checks':final,'final_host_guard':guard,
   'initial_fixture_failures':failed,'optional_mocked_supervisor_collector_checks':18,
   'complete_MTP_witness_groups':witnesses,'refusals_per_configuration':{'AR':9,'AR-tools':10,'MTP':22},
   'qualified_host_binary_inventory':binaries,'omitted_nonregular_owned_negative_fixtures':omitted,
   'native_capture_schema':3,'limits':{'output_per_profile':128,'traces_per_profile':1152,'trace_bytes':4*2**30,'metadata_bytes':128*2**20},
   'greedy_scope':'Host-head baseline with one output reservation; GPU greedy verification has no host witness',
   'independent_oracles':['long-double complete mass','integer24 proposal quantization/draw','acceptance/residual draw/RNG',
                          'grammar full-mask byte walk','history/penalties','committed cycles and deferred correction'],
   'copied_callback_configuration':True,'borrowed_data_only_in_callback':True,'numerical_algorithm_changed':False,
   'AR_v1_v2_wire_fieldsets_preserved':True,'MTP_capture_writer_replay_complete':True,
   'adapter_entry_point_HIP_compilation_qualified':False,'GPU_original_weight_probabilities_qualified':False,
   'new_GPU_model_remote_operation':False,'Python_product_dependency_added':False,'new_thread_or_HTTP_option':False,
   'next_gate':'Freshly coordinated coherent HIP build and original-weight MTP target/proposal/controller capture/replay on .161.',
   'open_task_numbers':[2,3,4,5,6,7],'goal_complete':False,'publication':False,
   'portable_raw_archive':{'path':'raw/'+archive.name,**ident(archive),'members':len(members)},'raw_artifacts':members}
with receipt.open('x') as f: json.dump(r,f,indent=2); f.write('\n')
print(json.dumps({'receipt':str(receipt.relative_to(root)),'archive':r['portable_raw_archive'],'state':r['state']}),flush=True)
