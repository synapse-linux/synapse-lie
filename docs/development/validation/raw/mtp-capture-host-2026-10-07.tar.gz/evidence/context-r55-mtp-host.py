# SPDX-License-Identifier: MIT
"""Owned HOST-only MTP capture/replay qualification; no GPU/model/remote work."""
from pathlib import Path
import datetime, json, os, subprocess

root=Path.cwd(); output=root/'evidence/context-r55-mtp-host'
output.mkdir(exist_ok=False); commands=[]
def run(name,argv,env=None):
    with (output/(name+'.log')).open('x') as log:
        child=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,env=env)
    record={'name':name,'argv':argv,'actual_exit_code':child.returncode}
    commands.append(record)
    (output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if child.returncode: raise SystemExit(child.returncode)

for mode in ('release','asan'):
    native=root/('build/mtp-capture-native-r55-'+mode)
    provider=root/('build/mtp-capture-sampling-r55-'+mode)
    flags=['-DCMAKE_BUILD_TYPE='+('Release' if mode=='release' else 'Debug'),
           '-DLIE_SANITIZERS='+('OFF' if mode=='release' else 'ON')]
    env=os.environ.copy()
    if mode=='asan':
        env['ASAN_OPTIONS']='detect_leaks=1:halt_on_error=1'
        env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
    run(mode+'-native-configure',['cmake','-S','.', '-B',str(native),*flags])
    run(mode+'-native-build',['cmake','--build',str(native),'--parallel','2','--target',
        'test-executor-abi','test-sampling-capture','test-sampling-capture-contract','test-sampling-capture-mtp-contract'])
    run(mode+'-provider-configure',['cmake','-S','tests/sampling','-B',str(provider),*flags,
        '-DLIE_CAPTURE_FIXTURE='+str(native/'test-sampling-capture'),
        '-DLIE_CAPTURE_FILE_FIXTURE='+str(native/'test-sampling-capture-contract')])
    run(mode+'-provider-build',['cmake','--build',str(provider),'--parallel','2','--target',
        'candidate-sampling-observer','fallback-sampling-observer',
        'reference-sampling-replay','candidate-sampling-replay','fallback-sampling-replay'])
    run(mode+'-native-tests',['ctest','--test-dir',str(native),'--output-on-failure','-R',
        '^(sampling-capture(-mtp)?-native-contract|executor-c-layout|native-provider-verification|hip-provider-target-verification|native-provider-source-paths)$'],env)
    run(mode+'-provider-tests',['ctest','--test-dir',str(provider),'--output-on-failure','-R',
        '^((candidate|fallback)-sampling-observer|(replay|tools_replay|mtp_replay)-native-capture-contract)$'],env)
run('optional-supervisor-controls',['python3','tests/test_sampling_capture_campaign.py'])
result={'schema':'synapse-lie.mtp-capture-host.v1','actual_exit_code':0,
        'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commands':commands,
        'classification':'HOST-NOT-INFERENCE','GPU_model_remote_work':False,
        'previous_goal_turn':'NO_PROGRESS_STATUS_ONLY',
        'next_original_weight_gate':'New coherent HIP build then independent original MTP capture/replay on .161'}
(output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
