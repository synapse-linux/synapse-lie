# SPDX-License-Identifier: MIT
"""Seal only closed native results, actual coordination and offline checks."""
import datetime
import hashlib
import json
from pathlib import Path
import tarfile

ROOT=Path.cwd();B=ROOT/'evidence/halo-r70-functional-20261008-r2'
P=ROOT/'docs/development/validation/halo-r70-functional-2026-10-08.json'
A=P.parent/'raw/halo-r70-functional-2026-10-08.tar.gz'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def rows(name):return [json.loads(l) for l in (B/'collected'/name).read_text().splitlines()]
def one(rr,name):
    r=[v for v in rr if v.get('event')==name];assert len(r)==1;return r[0]
assert not P.exists() and not A.exists()
plan=read(B/'manifest.json');strong=read(B/'strong-closure.json');review=read(B/'review-result.json')
assert sha(B/'manifest.json')==strong['manifest_sha256']==review['manifest_sha256']=='5be814797c2b21ee4e3de80e1026432570b08db344090da523a531498d987dfa'
assert read(B/'run-controller-result.json')['actual_exit_code']==0
assert read(B/'collect-controller-result.json')['actual_exit_code']==0
guard=read(B/'offline-review-guard-r1.json');assert guard['exit_code']==guard['child_exit_code']==0
assert review['state']=='CURRENT_R70_HALO_FUNCTIONAL_AND_PARITY_PASSED'
notice=read(B/'release-notifications-r1.json')['notifications']
assert len(notice)==4 and {r['threadId'] for r in notice}==set(plan['peer_ids'])
assert all(not r['result'].get('isError',False) for r in notice)
result=read(B/'collected/result.json');reactive=one(rows('reactive-probe.jsonl'),'reactive')
assert reactive['scope']=='direct-c-core-held-loan-peer-cancel' and not reactive['synthetic']
assert reactive['peer_output_tokens']==32 and reactive['held_output_blocked']==1 and reactive['held_borrowed_tokens']>=1
assert reactive['completed_delta']==reactive['cancelled_delta']==1 and reactive['decode_batches_delta']>0
timing={}
for name in ['primary-direct','reference-direct','core-c1','core-c2']:
    rr=rows(name+'.jsonl');sample=one(rr,'sample')
    if name.endswith('direct'):
        assert sample['finite_frontiers'] and sample['full_output_budget']
        assert sample['prefill_begin_monotonic_ns']<sample['prefill_end_monotonic_ns']<=sample['decode_begin_monotonic_ns']<sample['decode_end_monotonic_ns']
        assert sample['prefill_ns']==sample['prefill_end_monotonic_ns']-sample['prefill_begin_monotonic_ns']
        assert sample['decode_ns']==sample['decode_end_monotonic_ns']-sample['decode_begin_monotonic_ns']
    timing[name]={'sample':sample,'jobs':[r for r in rr if r.get('event')=='job']}
members={}
def add(name,path):
    assert name not in members and path.is_file() and not path.is_symlink()
    members[name]=path
for name,row in strong['files'].items():
    p=B/'collected'/name;assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
    add('native/'+name,p)
for name in ['manifest.json','window.py','control.py','q2_process.py','review.py',
             'review-result.json','strong-closure.json','run-controller-result.json',
             'collect-controller-result.json','fresh-controller-result.json',
             'peer-declarations.json','peer-proposals-r1.json','admission-notifications-r1.json',
             'release-notifications-r1.json','observe-live-r1.json','observe-live-r2.json',
             'stage-create-result.json','stage-copy-result.json','declarations-upload-result.json',
             'offline-review-guard-r1.json','offline-review-guard-r1.log']:
    add('control/'+name,B/name)
old=ROOT/'evidence/halo-r70-functional-20261008-r1'
for p in sorted(old.iterdir()):
    if p.is_file():add('superseded-r1/'+p.name,p)
build=ROOT/'evidence/halo-r70-build-20261008-r1'
for name in ['manifest.json','strong-closure.json','controller-result.json','collect-close-result-r1.json','release-notifications-r1.json']:
    add('build/'+name,build/name)
for name in ['compiler-result.json','source/build/halo-r70-provider-r1/BUILD-RECEIPT.json',
             'source/build/halo-r70-reference-r1/BUILD-RECEIPT.json','source/build/halo-r70-linked-r1/CMakeCache.txt']:
    add('build/native/'+name,build/'collected'/name)
for name in ['LICENSE','tools/lie-bench.c','tools/core-bench.c','tools/hip-probe.c',
             'tools/qualification/attention_main.c','tools/qualification/attention_plan.c','tools/qualification/attention.h']:
    add('source/'+name,ROOT/name)
add('recipe/seal.py',Path(__file__))
inventory=[{'path':name,'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in sorted(members.items())]
A.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(A,'x:gz',compresslevel=6) as archive:
    for name,p in sorted(members.items()):
        with p.open('rb') as stream:
            info=tarfile.TarInfo(name);info.size=p.stat().st_size;info.mode=0o600;info.mtime=0
            archive.addfile(info,stream)
for row in inventory:assert sha(members[row['path']])==row['sha256']
telemetry=rows('telemetry.jsonl');peaks={}
for r in telemetry:
    for s in r['temperatures']:
        if s['limit_c'] is not None:assert s['value_c']<s['limit_c']
        peaks[s['name']]=max(peaks.get(s['name'],s['value_c']),s['value_c'])
receipt={'schema':'synapse-lie.halo-r70-functional.v1','state':review['state'],'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Native original-weight selected functional/parity qualification; no matched performance, general task-quality or model long-context claim.',
 'host':plan['binaries']['synapse-lie-bench']['path'].split('/run/')[0],'target':'gfx1151','sdk':plan['sdk'],
 'source_commit':plan['source_commit'],'runtime_source':plan['runtime_source'],'manifest_sha256':sha(B/'manifest.json'),
 'binaries':plan['binaries'],'source_models_stat_only':plan['models'],'original_model_payload_hash_or_conversion':False,
 'commands':result['commands'],'review':review,'measurements':timing,'reactive_probe':reactive,
 'thermal_sample_count':len(telemetry),'peak_C':peaks,'cpu_guard_C':98,'GPU_temperature_observe_only':True,
 'original_controller_actual_exit':0,'independent_offline_review_actual_exit':0,'collection_actual_exit':0,
 'lease_release_at':result['lease_released_at'],'strong_closure':strong,'release_notifications':notice,
 'superseded_preparation':read(old/'local-preflight-size-refusal.json'),
 'raw':{'path':'raw/'+A.name,'bytes':A.stat().st_size,'sha256':sha(A),'member_count':len(members),'inventory':inventory},
 'limitations':['One physical2048/TG32 greedy workload, C1 and C2 only; cache/MTP/vision/steering disabled.',
  '13 generated WMMA cases are component evidence through1M geometry, not original model1M qualification.',
  'Primary/reference are same-pinned in-process adapters, not independently served Gufo or Halogen.',
  'One sample per arm, zero warmup and sequential unbalanced order; throughput observations do not establish performance parity or reactive speedup.',
  'UD-Q4 byte parity does not qualify the other Q2 numerical provider or its divergent batch outputs.'],
 'current_root_remote_job_handle_lease_waiter_reservation':False,'future_grant':False,'all_six_root_roadmap_tasks_remain_open':True}
with P.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps({'state':receipt['state'],'public':str(P.relative_to(ROOT)),'raw_bytes':A.stat().st_size,'raw_members':len(members),'peak_C':peaks,'actual_exit_code':0}))
