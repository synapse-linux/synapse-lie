# SPDX-License-Identifier: MIT
"""Local controller; exact private recipes, retained actual SSH/SCP exits."""
import argparse
import ast
import base64
import datetime
import hashlib
import json
from pathlib import Path
import shlex
import subprocess

HERE=Path(__file__).resolve().parent
HOST='paperboy@192.168.5.157'
REMOTE='/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run/'+HERE.name
SSH=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',HOST]
SCP=['scp','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8']
EXPECTED='da0b6566120a76179a386d05b55c8a8ff7f35dd5ffc828711177aa4c78a80f6a'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
    with (HERE/name).open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
def run(argv,timeout=90,data=None):
    r=subprocess.run(argv,input=data,text=True,capture_output=True,timeout=timeout)
    return {'argv':argv,'actual_exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,
            'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}

parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=('stage','declarations','fresh','run','collect'),required=True)
args=parser.parse_args()
plan=json.loads((HERE/'manifest.json').read_text())
assert sha(HERE/'manifest.json')==EXPECTED
for name,row in plan['inputs'].items():assert (HERE/name).stat().st_size==row['bytes'] and sha(HERE/name)==row['sha256']
ast.parse((HERE/'window.py').read_text());ast.parse((HERE/'q2_process.py').read_text())
if args.mode=='stage':
    program="from pathlib import Path\nimport os\nassert os.getuid()==1000\nb=Path('/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run')\nassert b.resolve()==b and b.stat().st_uid==1000\nassert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=="+repr(plan['boot_id'])+"\np=b/"+repr(HERE.name)+"\np.mkdir(mode=0o700)\nprint(str(p))\n"
    record=run([*SSH,'python3 -B -'],data=program);save('stage-create-result.json',record);assert record['actual_exit_code']==0
    results=[]
    for name in ('window.py','q2_process.py','manifest.json'):
        r=run([*SCP,str(HERE/name),HOST+':'+REMOTE+'/'+name]);results.append(r)
        if r['actual_exit_code']:save('stage-copy-result.json',results);raise SystemExit(r['actual_exit_code'])
    save('stage-copy-result.json',results);print(json.dumps({'state':'STAGED_NO_GPU_OR_LEASE_OPERATION','actual_exit_codes':[r['actual_exit_code'] for r in results]}))
elif args.mode=='declarations':
    declarations=json.loads((HERE/'peer-declarations.json').read_text())
    assert declarations['manifest_sha256']==EXPECTED and set(declarations['specific_nonuse_peer_ids'])==set(plan['peer_ids'])
    record=run([*SCP,str(HERE/'peer-declarations.json'),HOST+':'+REMOTE+'/peer-declarations.json'])
    save('declarations-upload-result.json',record);print(json.dumps({'actual_exit_code':record['actual_exit_code']}));raise SystemExit(record['actual_exit_code'])
elif args.mode=='run':
    fresh=json.loads((HERE/'fresh-controller-result.json').read_text())
    assert fresh['actual_exit_code']==0 and fresh['result']['manifest_sha256']==EXPECTED
    age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(fresh['result']['at_utc'])).total_seconds()
    assert 0<=age<=120 and not (HERE/'run-controller-result.json').exists()
    argv=[*SSH,shlex.join(['python3','-B',REMOTE+'/window.py','--mode','run'])]
    with (HERE/'controller-stdout.log').open('xb') as out,(HERE/'controller-stderr.log').open('xb') as err:
        r=subprocess.run(argv,stdout=out,stderr=err)
    record={'argv':argv,'actual_exit_code':r.returncode,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    save('run-controller-result.json',record)
    print(json.dumps({**record,'remote_summary':(HERE/'controller-stdout.log').read_text()}));raise SystemExit(r.returncode)
else:
    if args.mode=='collect':
        assert (HERE/'run-controller-result.json').is_file()
    record=run([*SSH,shlex.join(['python3','-B',REMOTE+'/window.py','--mode',args.mode])],timeout=180)
    if record['actual_exit_code']==0:
        data=json.loads(record.pop('stdout'))
        if args.mode=='collect':
            output=HERE/'collected';output.mkdir();strong=data['strong']
            for name,row in data['files'].items():
                rel=Path(name);assert not rel.is_absolute() and '..' not in rel.parts
                content=base64.b64decode(row['base64'],validate=True)
                assert len(content)==row['bytes'] and hashlib.sha256(content).hexdigest()==row['sha256']
                target=output/rel;target.parent.mkdir(parents=True,exist_ok=True);target.open('xb').write(content)
            save('strong-closure.json',strong)
            record.update(state=strong['state'],files_verified=len(strong['files']),strong_at_utc=strong['at_utc'])
        else:record['result']=data
    save(args.mode+'-controller-result.json',record)
    print(json.dumps({k:v for k,v in record.items() if k not in ('stdout','result')},indent=2))
    if 'result' in record:print(json.dumps(record['result']))
    raise SystemExit(record['actual_exit_code'])
