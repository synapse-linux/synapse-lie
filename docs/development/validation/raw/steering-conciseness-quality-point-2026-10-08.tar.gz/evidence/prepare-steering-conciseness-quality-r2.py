# SPDX-License-Identifier: MIT
"""Freeze original held-out steering inputs against the complete100-pair proof."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import subprocess
import types

root = Path.cwd().resolve()
label = 'steering-conciseness-quality-point-20261008-r2'
out = root/'evidence'/label
assert not out.exists() and not out.is_symlink()

def identity(payload):
    return {'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

checkpoint = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert checkpoint == '6deadec66355433b576fff0e51a6bb5e7611864a'
source = subprocess.run(['git', 'diff', '--quiet', '4c703b3d604c6c877d6a2214d7aee0b15a013f61', '--',
    'src', 'include', 'adapters', 'cmake', 'CMakeLists.txt', 'tools/native', 'tools/steering-build.c'])
assert source.returncode == 0
public = root/'docs/development/validation/steering-conciseness-original100-point-2026-10-08.json'
training_bytes = public.read_bytes()
assert identity(training_bytes)['sha256'] == '6367619cb08765ccc39395f05023cc69b13a3f0dfedba406bba45c338035ac12'
training = json.loads(training_bytes)
postseal = json.loads((root/'evidence/steering-conciseness-original100-postseal-r1.json').read_text())
assert postseal['actual_exit_code'] == 0 and postseal['all_archived_and_current_members_match'] is True
trained = root/'evidence'/training['job_label']
manifest = json.loads((trained/'manifest.json').read_text())
bank_bytes = (trained/'steering-build/direction.ffn.f32').read_bytes()
assert identity(bank_bytes) == {key: training['capture']['banks']['direction.ffn.f32'][key] for key in ('bytes', 'sha256')}
profile = module('frozen_original_steering_profile', root/'tools/strix-point-steering-quality-profile.py')
supervisor = module('frozen_original_steering_supervisor', root/'tools/strix-point-steering-quality-run.py')
config = supervisor.quality.settings({
    'model_id': 'qwen3.8-flash-next', 'fingerprint': training['capture']['native_identity']['engine'],
    'context': 8192, 'chunk': 256, 'seed': 77, 'output_tokens': 256,
    'request_timeout_seconds': 120, 'bank_sha256': identity(bank_bytes)['sha256']})
corpus = (root/'tests/fixtures/steering-conciseness-v1.json').read_bytes()
assert identity(corpus) == training['training_corpus']
data = supervisor.quality.corpus(supervisor.quality.strict(corpus))
settings_bytes = (json.dumps(config, indent=2)+'\n').encode()
load_bound = 900
deadline = supervisor.container_timeout(config, load_bound)
assert deadline == 10800
for key in ('steering_build', 'steering_build_inputs', 'steering_build_gate_sha256',
            'steering_quality_training_corpus', 'canonical_capture_window_timeout_seconds',
            'steering_build_collector_sha256', 'previous_prepared_only_manifest_sha256'):
    manifest.pop(key, None)
helpers = {name: (root/'tools'/name).read_bytes() for name in profile.HELPERS}
manifest.update({
    'root_checkpoint': checkpoint, 'fixture_commit': checkpoint, 'runner_commit': checkpoint,
    'bench_profile': 'modern-steering-quality', 'decode_mode': 'ar',
    'distrobox_name': 'lie-steering-concise-quality-r2',
    'steering_quality': config, 'steering_quality_settings_sha256': identity(settings_bytes)['sha256'],
    'steering_quality_corpus': identity(corpus), 'steering_quality_training_receipt': identity(training_bytes),
    'steering_quality_load_timeout_seconds': load_bound,
    'steering_quality_helpers': {name: identity(payload)['sha256'] for name, payload in helpers.items()},
    'qualified_original_bank_receipt': str(public.relative_to(root)),
    'qualified_original_bank_receipt_sha256': identity(training_bytes)['sha256'],
    'purpose': 'Original70 held-out arithmetic/conciseness responses: ten absent-bank controls and '
        'ten each at frozen FFN scales[-1,-.5,0,.5,1,2], attention0. Require complete saved SSE, '
        'actual stored applied position0 and final policy, natural stop, exact arithmetic and '
        'zero/absent parity before frozen length-effect scoring. Retain QUALITY_FAILED scores. '
        'No threshold/corpus tuning, MTP, vision, performance, remote build/model hash/conversion/install/publication.',
    'memory_estimate_scope': 'Same original Q4/native8192/chunk256 server runtime; two model servers '
        'run serially with C1 and RAM/SSD prefix cache off. GTT100GiB remains an admission estimate; '
        'RAMfloor1GiB, stored responses128/256MiB, TTL10800s. Native client/output/time bounds fixed.',
    'prepared_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'prepared_manifest_not_admission': True,
    'canonical_response_window_timeout_seconds': deadline})
capacity = root/'docs/development/validation/steering-quality-response-capacity-host-2026-10-08.json'
capacity_proof = json.loads(capacity.read_text())
assert capacity_proof['actual_exit_code'] == 0 and capacity_proof['response_store_bound_mib'] == 256
assert json.loads((root/'evidence/steering-quality-response-capacity-postseal-r1.json').read_text())['actual_exit_code'] == 0
previous = root/'docs/development/validation/steering-conciseness-quality-failed-point-2026-10-08.json'
assert json.loads(previous.read_text())['state'] == 'PARTIAL_ORIGINAL_STEERING_RESPONSES_FAILED_COLLECTED_STRONGLY_CLOSED'
assert json.loads((root/'evidence/steering-conciseness-quality-failed-postseal-r1.json').read_text())['actual_exit_code'] == 0
manifest['qualified_response_capacity_HOST_receipt'] = str(capacity.relative_to(root))
manifest['qualified_response_capacity_HOST_receipt_sha256'] = identity(capacity.read_bytes())['sha256']
manifest['preceding_failed_response_receipt'] = str(previous.relative_to(root))
manifest['preceding_failed_response_receipt_sha256'] = identity(previous.read_bytes())['sha256']
manifest['correction_scope'] = 'Only response-store bound64MiB to256MiB; same native runtime, bank, corpus, questions, scales, output256, seed77, deadlines and acceptance criteria. No old-job replay or relabeling.'

files = {**helpers, 'runner.py': (root/'tools/strix-point-campaign.py').read_bytes(),
    'steering-quality-settings.json': settings_bytes, 'corpus.json': corpus,
    'steering-training-receipt.json': training_bytes, 'direction.ffn.f32': bank_bytes}
assert identity(files['runner.py'])['sha256'] == manifest['runner_sha256']
files['manifest.json'] = (json.dumps(manifest, indent=2)+'\n').encode()
out.mkdir(mode=0o700)
for name, payload in files.items():
    with (out/name).open('xb') as stream:
        stream.write(payload)
preflight = profile.preflight(types.SimpleNamespace(root=out, m=manifest))
assert preflight['bank_source']['training_pairs'] == 100 and preflight['deadline'] == deadline
assert len(supervisor.quality.requests(data, config, 'absent')) == 10
assert len(supervisor.quality.requests(data, config, 'bank')) == 60
record = {'state': 'ORIGINAL_BANK_BOUND70_RESPONSE_INPUTS_LOCAL_PREFLIGHT_PASSED_NOT_ADMITTED',
    'at_utc': manifest['prepared_at_utc'], 'label': label, 'root_checkpoint': checkpoint,
    'manifest_sha256': identity(files['manifest.json'])['sha256'], 'bundle_sha256': manifest['bundle_manifest_sha256'],
    'files': {name: identity(payload) for name, payload in files.items()},
    'bank_source': preflight['bank_source'], 'container_deadline_seconds': deadline,
    'request_bound_seconds': 120, 'load_bound_seconds': load_bound,
    'GPU_remote_operation_or_new_build': False, 'root_current_own_all_hosts': 'NONE',
    'fresh_four_peer_boot_FS_global_original_lease_admission_required': True,
    'actual_native_source_comparison_exit_code': source.returncode, 'actual_exit_code': 0}
with (root/'evidence/steering-conciseness-quality-prepared-r2.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in record.items() if key != 'files'}))
