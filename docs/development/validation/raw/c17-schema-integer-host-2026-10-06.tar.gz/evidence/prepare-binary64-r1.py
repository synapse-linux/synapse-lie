# SPDX-License-Identifier: MIT
from pathlib import Path
import json
source=Path('.deps/gufo-f783fedb/src/core/json.hpp').read_text()
serialize='''        const auto [end, error] =
            std::to_chars(buffer, buffer + sizeof(buffer), num_);
        if (error != std::errc{}) {
          throw std::runtime_error("JSON number serialization failed");
        }
        os.write(buffer, end - buffer);
'''
parse='''    const auto [end, error] =
        std::from_chars(tok.data(), tok.data() + tok.size(), value);
    if (error != std::errc{} || end != tok.data() + tok.size() ||
        !std::isfinite(value)) {
      fail("bad number");
    }
'''
new_ser='''        size_t length = 0;
        if (lie_binary64_format(num_, buffer, sizeof(buffer), &length) != LIE_BINARY64_OK)
          throw std::runtime_error("JSON number serialization failed");
        os.write(buffer, static_cast<std::streamsize>(length));
'''
new_parse='''    if (lie_binary64_parse(tok.data(), tok.size(), nullptr, &value) != LIE_BINARY64_OK)
      fail("bad number");
'''
edits=[{'path':'src/core/json.hpp','old':'#include <vector>\n','new':'#include <vector>\n#if LIE_C17_SAMPLING\n#include "lie/binary64.h"\n#endif\n'}]
for old,new in [(serialize,new_ser),(parse,new_parse)]:
 assert source.count(old)==1
 edits.append({'path':'src/core/json.hpp','old':old,'new':'#if LIE_C17_SAMPLING\n'+new+'#else\n'+old+'#endif\n'})
Path('adapters/gufo-state/binary64-edits.json').write_text(json.dumps({'source_pin':'f783fedb9bea2ec7de941f6da4e02f4a4596b29e','purpose':'Default-ON C17 binary64 spelling/parsing in all provider JSON number conversion; typed JSON storage and full lexer remain private. Both exact original OFF conversion bodies retained.','license':'MIT','edits':edits},indent=2)+'\n')
def replace(name,old,new):
 p=Path(name);s=p.read_text();assert s.count(old)==1,(name,old);p.write_text(s.replace(old,new))
for name in ('CMakeLists.txt','cmake/gufo-runtime/CMakeLists.txt','tests/sampling/CMakeLists.txt'):
 token='src/grammar_composition.c' if name=='CMakeLists.txt' else '"${LIE_ROOT}/src/grammar_composition.c"' if name.startswith('cmake/') else '"${REPO}/src/grammar_composition.c"'
 append=' src/binary64.c' if name=='CMakeLists.txt' else ' "${LIE_ROOT}/src/binary64.c"' if name.startswith('cmake/') else ' "${REPO}/src/binary64.c"'
 replace(name,token,token+append)
replace('CMakeLists.txt','target_include_directories(lie_sampling PUBLIC include)','include(cmake/provider/Source.cmake)\nlie_verify_binary64_vendor("${CMAKE_CURRENT_SOURCE_DIR}")\ntarget_include_directories(lie_sampling PUBLIC include PRIVATE third_party/ryu)')
replace('cmake/gufo-runtime/CMakeLists.txt','target_include_directories(gufo_core PRIVATE "${LIE_ROOT}/adapters")','include("${LIE_ROOT}/cmake/provider/Source.cmake")\nlie_verify_binary64_vendor("${LIE_ROOT}")\ntarget_include_directories(gufo_core PRIVATE "${LIE_ROOT}/adapters" "${LIE_ROOT}/third_party/ryu")')
replace('tests/sampling/CMakeLists.txt','include("${REPO}/cmake/provider/Source.cmake")','include("${REPO}/cmake/provider/Source.cmake")\nlie_verify_binary64_vendor("${REPO}")')
replace('tests/sampling/CMakeLists.txt','target_include_directories(${arm} PUBLIC "${REPO}/adapters")','target_include_directories(${arm} PUBLIC "${REPO}/adapters" PRIVATE "${REPO}/third_party/ryu")')
manifest=json.loads(Path('third_party/ryu-source.json').read_text());names=['src/binary64.c','include/lie/binary64.h','third_party/ryu-source.json']+['third_party/ryu/'+f for f in manifest['files']]
assert len(names)==14
for name in ('cmake/provider/Build.cmake','cmake/provider/Verify.cmake','tests/provider_contract.cmake'):
 replace(name,'adapters/gufo_grammar_composition.hpp)','adapters/gufo_grammar_composition.hpp '+' '.join(names)+')')
replace('cmake/provider/Verify.cmake','owned_count EQUAL 69','owned_count EQUAL 83')
replace('cmake/provider/Source.cmake','composition-edits.json grammar-vocabulary-edits.json','composition-edits.json binary64-edits.json grammar-vocabulary-edits.json')
p=Path('cmake/provider/Source.cmake');p.write_text(p.read_text()+'''\n# Independent bundled numeric library; no system package or network discovery.
function(lie_verify_binary64_vendor root)
  file(READ "${root}/third_party/ryu-source.json" manifest)
  string(JSON pin GET "${manifest}" commit)
  if(NOT pin STREQUAL "4c0618b0e44f7ef027ebae05d2cc7812048f7c8f")
    message(FATAL_ERROR "Unexpected bundled Ryu source pin")
  endif()
  string(JSON entries GET "${manifest}" files)
  string(JSON count LENGTH "${entries}")
  if(NOT count EQUAL 11)
    message(FATAL_ERROR "Bundled Ryu source inventory mismatch")
  endif()
  set(hashes "{}")
  math(EXPR last "${count}-1")
  foreach(i RANGE 0 ${last})
    string(JSON name MEMBER "${entries}" ${i})
    string(JSON digest GET "${entries}" "${name}" sha256)
    string(JSON hashes SET "${hashes}" "${name}" "\\\"${digest}\\\"")
  endforeach()
  lie_verify_files("${root}/third_party/ryu" "${hashes}")
endfunction()
''')
replace('cmake/provider/Build.cmake','  file(SHA256 "${LIE_SOURCE_ROOT}/adapters/gufo-state/composition-edits.json" hash)','  file(SHA256 "${LIE_SOURCE_ROOT}/adapters/gufo-state/binary64-edits.json" hash)\n  string(JSON receipt SET "${receipt}" binary64_edits_sha256 "\\\"${hash}\\\"")\n  file(SHA256 "${LIE_SOURCE_ROOT}/adapters/gufo-state/composition-edits.json" hash)')
verify='    file(SHA256 "${LIE_SOURCE_ROOT}/adapters/gufo-state/binary64-edits.json" hash)\n    string(JSON expected GET "${receipt}" binary64_edits_sha256)\n    if(NOT hash STREQUAL expected)\n      message(FATAL_ERROR "Owned binary64 edit provenance mismatch")\n    endif()\n'
replace('cmake/provider/Verify.cmake','    file(SHA256 "${LIE_SOURCE_ROOT}/adapters/gufo-state/composition-edits.json" hash)',verify+'    file(SHA256 "${LIE_SOURCE_ROOT}/adapters/gufo-state/composition-edits.json" hash)')
replace('tests/provider_contract.cmake','foreach(pair IN ITEMS "composition-source|','foreach(pair IN ITEMS "binary64-source|src/binary64.c|Source/archive drift" "binary64-header|include/lie/binary64.h|Source/archive drift" "binary64-upstream|third_party/ryu/ryu/d2s.c|Source/archive drift" "binary64-upstream-parser|third_party/ryu/ryu/s2d.c|Source/archive drift" "binary64-upstream-table|third_party/ryu/ryu/d2s_full_table.h|Source/archive drift" "binary64-upstream-manifest|third_party/ryu-source.json|Source/archive drift" "composition-source|')
replace('tests/provider_contract.cmake','"composition|composition"','"composition|composition" "binary64|binary64"')
p=Path('tests/provider_contract.cmake');s=p.read_text();start=s.index('string(JSON changed SET "${selected}" composition_edits_sha256');end=s.index('file(WRITE "${root}/adapters/gufo-state/composition-edits.json" "${construction_recipe}")',start)+len('file(WRITE "${root}/adapters/gufo-state/composition-edits.json" "${construction_recipe}")');block=s[start:end].replace('composition','binary64').replace('construction_recipe','binary64_recipe');p.write_text(s[:end]+'\n\n'+block+s[end:])
replace('CMakeLists.txt','  add_executable(test-grammar-composition tests/test_grammar_composition.c)','  add_executable(test-binary64 tests/test_binary64.c)\n  target_link_libraries(test-binary64 PRIVATE lie_sampling)\n  add_test(NAME c17-binary64-contract COMMAND test-binary64)\n  set_tests_properties(c17-binary64-contract PROPERTIES TIMEOUT 120)\n  add_executable(test-grammar-composition tests/test_grammar_composition.c)')
print('Prepared exact original OFF numeric bodies, Ryu pin/hash gates and83-file provider inventory.')
