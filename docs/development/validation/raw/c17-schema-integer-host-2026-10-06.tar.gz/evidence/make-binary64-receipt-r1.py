# SPDX-License-Identifier: MIT
"""Bind actual host exits, complete witnesses and exact source; never GPU evidence."""
from pathlib import Path
import datetime, hashlib, json, re, shutil, subprocess

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()
def bound(path):
    p = Path(path)
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}

for arm, run in [('release', 'r2'), ('asan', 'r2'), ('host', 'r1')]:
    src = Path(f'build/binary64-{arm}/Testing/Temporary/LastTest.log')
    dst = Path(f'evidence/binary64-{arm}-test-{run}/CTest-LastTest.log')
    if dst.exists():
        assert sha(src) == sha(dst)
    else:
        shutil.copyfile(src, dst)

checks = []; peak = 0
for p in sorted(Path('evidence').glob('binary64-*')):
    if not p.is_dir() or not (p / 'result.json').exists():
        continue
    result = json.loads((p / 'result.json').read_text())
    plan = json.loads((p / 'plan.json').read_text())
    code = 1 if p.name == 'binary64-release-build-r1' else 0
    assert result['exit_code'] == result['child_exit_code'] == code and result['reason'] is None, p
    count = 42 if p.name == 'binary64-host-test-r1' else 17 if '-test-' in p.name and '-differential-' not in p.name else None
    if count:
        assert f'100% tests passed out of {count}' in (p / 'command.log').read_text(), p
    cpu = max(result['peak_c'][s['path']] for s in plan['sensors'] if s['name'] in ['k10temp', 'coretemp'])
    peak = max(peak, cpu)
    checks.append({'directory': str(p), 'argv': result['argv'], 'exit_code': code,
                   'child_exit_code': code, 'test_count': count, 'CPU_max_C': cpu,
                   'source_scope': 'preliminary codec/fixture before final source snapshot' if p.name in [
                       'binary64-strict-c-r1', 'binary64-differential-build-r1', 'binary64-differential-test-r1',
                       'binary64-release-test-r1', 'binary64-asan-test-r1'] else 'retained actual command',
                   'files': [bound(f) for f in sorted(p.rglob('*')) if f.is_file()]})
assert len(checks) == 22, len(checks)
for arm in ['release', 'asan']:
    log = Path(f'evidence/binary64-{arm}-test-r2/CTest-LastTest.log').read_text()
    assert 'C17 binary64: 77 independent bit/rounding oracles, 122 refusals; HOST_NOT_INFERENCE' in log
failure = Path('evidence/binary64-release-build-r1/command.log').read_text()
assert 'test_binary64.c:33:2: error:' in failure and '-Werror=misleading-indentation' in failure
env = json.loads(Path('evidence/binary64-sanitizer-environment-r1.json').read_text())
assert len(env) == 4 and all(v is None for v in env.values())
fetch_failure = json.loads(Path('evidence/binary64-upstream-fetch-failure-r1.json').read_text())
assert fetch_failure['actual_exit'] == 6 and 'Could not resolve host' in fetch_failure['stderr']

old_path = Path('docs/development/validation/c17-composition-host-2026-10-06.json')
old = json.loads(old_path.read_text()); build = Path('build/binary64-host')
assert len(old['complete_witnesses']) == 24
witnesses = []
for previous in old['complete_witnesses']:
    p = build / previous['suite']
    expected = next(f['sha256'] for f in previous['files'] if f['path'].endswith('/REFERENCE.txt'))
    texts = list(p.glob('*.txt'))
    assert len(texts) == (2 if previous['suite'] == 'biased-parity' else 3), previous['suite']
    assert all(sha(f) == expected for f in texts), previous['suite']
    assert all(f.read_text() == '0\n' for f in p.glob('*.exit'))
    witnesses.append({'suite': previous['suite'], 'previous_hash_unchanged': True,
                      'files': [bound(f) for f in sorted(p.iterdir()) if f.is_file()]})
p = build / 'binary64-parity'
assert len(list(p.glob('*.txt'))) == 3 and len({sha(f) for f in p.glob('*.txt')}) == 1
assert all(f.read_text() == '0\n' for f in p.glob('*.exit'))
summary = (p / 'REFERENCE.txt').read_text().splitlines()[-1]
match = re.fullmatch(r'BINARY64 CASES=(\d+) HOST_NOT_INFERENCE', summary); assert match
cases = int(match[1]); assert cases == 106273
witnesses.append({'suite': 'binary64-parity', 'previous_hash_unchanged': None,
                  'files': [bound(f) for f in sorted(p.iterdir()) if f.is_file()]})
host_log = Path('evidence/binary64-host-test-r1/CTest-LastTest.log').read_text()
match = re.search(r'BINARY64_ORACLE CHECKS=(\d+) MPFR=([^ ]+) CODEC_HEAP_CALLS=(\d+) HOST_NOT_INFERENCE', host_log)
assert match and match[1] == '1013356' and match[2] == '4.2.2' and match[3] == '0'
oracle_checks = int(match[1])

inventories = []
for name in ['cmake/provider/Build.cmake', 'cmake/provider/Verify.cmake', 'tests/provider_contract.cmake']:
    match = re.search(r'foreach\(name IN ITEMS (src/sampling\.c [^\n]+)\)', Path(name).read_text()); assert match
    names = match[1].split(); assert len(names) == len(set(names)) == 83
    inventories.append(names)
assert inventories[0] == inventories[1] == inventories[2]
vendor_names = [n for n in inventories[0] if n.startswith('third_party/')]
assert len(vendor_names) == 12
pristine = json.loads(Path('third_party/gufo-source.json').read_text())
for name, digest in pristine['files'].items():
    assert sha(Path('.deps/gufo-f783fedb') / name) == digest, name
assert len(pristine['files']) == 1019
ryu = json.loads(Path('third_party/ryu-source.json').read_text())
assert ryu['commit'] == '4c0618b0e44f7ef027ebae05d2cc7812048f7c8f' and len(ryu['files']) == 11
for name, binding in ryu['files'].items():
    p = Path('third_party/ryu') / name
    assert p.stat().st_size == binding['bytes'] and sha(p) == binding['sha256']
official = json.loads(Path('evidence/binary64-ryu-upstream-commit-r2.json').read_text())
assert official['sha'] == ryu['commit']
edits = json.loads(Path('adapters/gufo-state/binary64-edits.json').read_text())
assert edits['source_pin'] == pristine['commit'] and len(edits['edits']) == 3
original = Path('.deps/gufo-f783fedb/src/core/json.hpp').read_text()
for edit in edits['edits']:
    assert original.count(edit['old']) == 1
for edit in edits['edits'][1:]:
    assert edit['new'].split('#else\n', 1)[1] == edit['old'] + '#endif\n'
variant = json.loads((build / 'variant-files.json').read_text())
for name in ['src/core/json.hpp', 'src/core/json_constraint.cpp', 'src/core/json_schema_lexeme.cpp']:
    assert sha(build / 'variant' / name) == variant[name]
headers = sorted(Path('include/lie').glob('*.h')); assert len(headers) == 55

paths = set(inventories[0] + [str(p) for p in headers] + [
    'CMakeLists.txt', 'cmake/gufo-runtime/CMakeLists.txt', 'cmake/provider/Build.cmake',
    'cmake/provider/Verify.cmake', 'cmake/provider/Source.cmake', 'tests/provider_contract.cmake',
    'tests/sampling/CMakeLists.txt', 'tests/test_binary64.c', 'tests/sampling/binary64.cpp',
    'tests/sampling/binary64_oracle.cpp', 'adapters/gufo-state/binary64-edits.json',
    'third_party/gufo-source.json', 'third_party/gufo-NOTICE', 'third_party/README.md',
    'third_party/ryu-NOTICE', 'tools/thermal-run.py', 'evidence/binary64-public-headers-r1.c',
    'evidence/binary64-public-headers-r1.cpp', 'evidence/binary64-sanitizer-environment-r1.json',
    'evidence/binary64-upstream-fetch-failure-r1.json', 'evidence/binary64-ryu-upstream-commit-r2.json',
    'evidence/fetch-binary64-ryu-r1.py', 'evidence/prepare-binary64-r1.py',
    'evidence/make-binary64-receipt-r1.py', 'evidence/update-binary64-docs-r1.py',
    'evidence/binary64-differential-r1.cpp', 'evidence/binary64-receipt-generator-failure-r1.json'])
executables = sorted(p for p in build.iterdir() if p.is_file() and p.stat().st_mode & 0o111)
assert len(executables) == 87
binaries = [bound(p) for p in [
    Path('build/binary64-release/test-binary64'), Path('build/binary64-asan/test-binary64'),
    Path('evidence/binary64-strict-r2.o'), Path('evidence/binary64-public-headers-r1.o'),
    Path('evidence/binary64-public-headers-cpp-r1.o')]
    + executables + sorted(build.glob('lib*.a'))]
nm = subprocess.run(['nm', '-u', 'evidence/binary64-strict-r2.o'], capture_output=True, text=True)
assert nm.returncode == 0
imports = sorted(line.split()[-1] for line in nm.stdout.splitlines() if line.strip())
assert all(not name.startswith(('_Z', '__cxa', 'hip', 'cuda', 'pthread')) for name in imports)
assert 'malloc' in imports
warnings = []
for p in sorted(Path('evidence').glob('binary64-*-build-*')):
    for line in (p / 'command.log').read_text().splitlines():
        if 'warning:' in line:
            warnings.append(line)
assert not any(any(n in line for n in ['src/binary64.c', 'test_binary64.c', 'sampling/binary64.cpp',
                                       'sampling/binary64_oracle.cpp', 'gufo_schema_number.hpp']) for line in warnings)
build_inputs = []
for arm in ['release', 'asan', 'host']:
    d = Path('build/binary64-' + arm)
    for name in ['CMakeCache.txt', 'build.ninja', 'CMakeFiles/rules.ninja', 'CTestTestfile.cmake']:
        build_inputs.append(bound(d / name))
    if arm != 'host':
        cache = (d / 'CMakeCache.txt').read_text()
        assert 'LIE_LEGACY_PYTHON_TESTS:BOOL=OFF' in cache and 'MPFR' not in cache
        assert 'mpfr' not in (d / 'build.ninja').read_text().lower()
for name in ['variant-files.json', 'variant/src/core/json.hpp', 'variant/src/core/json_constraint.cpp',
             'variant/src/core/json_schema_lexeme.cpp', 'variant/src/core/json_schema_regex.cpp']:
    build_inputs.append(bound(build / name))
build_inputs += [bound(p) for p in sorted(build.glob('*-schema-constraint.cpp'))]

receipt = {
    'schema': 'synapse-lie.c17-binary64-host-qualification.v1',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'HOST_QUALIFIED_NOT_GPU_QUALIFIED',
    'source_pin': pristine['commit'], 'source_parent_commit': '682e28b05d25a02e0d3226aa7a78f141ba36bbd7',
    'scope': 'Shared C17 finite binary64 JSON formatting, strict full-span syntax, exact nearest-even parsing and default spelling. Pinned Ryu shortest/short C routines; first-party spelling/full-span long-decimal parser. No CPU model forward or original-weight inference/fault/fit/resource/cost claim.',
    'public_ABI': {'binary64': 1, 'existing_breaking_change': False},
    'defaults': {'max_text_bytes': 4294967295, 'max_work_units': 64000000,
                 'significant_prefix_digits': 800, 'sticky_tail': True, 'integer_uint32_limbs': 128},
    'default_selection': 'LIE_C17_SAMPLING=ON; both exact original OFF JSON conversion bodies retained',
    'KV_cache_payload_format_changed': False, 'shared_worker_event_RNG_changed': False,
    'new_inference_threads': 0,
    'allocation_scope': 'GNU QA allocator wrappers are active only during selected public C format/parse calls; actual heap call count0. Caller/MPFR/CPP/provider/ICU/process/GPU allocations excluded. Strict C object retains malloc from unused upstream Ryu convenience entry point; object-import absence is not claimed.',
    'dependencies': {'Ryu': {'manifest': bound('third_party/ryu-source.json'), 'pin': ryu['commit'],
                             'unchanged_files': 11, 'bytes': sum(x['bytes'] for x in ryu['files'].values()),
                             'license_selected': 'BSL-1.0; upstream dual license texts and notices retained'},
                     'MPFR': '4.2.2 installed QA only; combined decimal MPFR and standard shortest/bit probe',
                     'default_products_and_default_CTest_require_MPFR_or_Python': False,
                     'production_system_dependency_added': False},
    'coverage': {'independent_C_oracles': 77, 'selected_refusals': 122, 'floating_rounding_modes': 4,
                 'actual_binary64_cases': cases, 'independent_MPFR_and_shortest_checks': oracle_checks,
                 'selected_public_codec_heap_calls': 0, 'previous_complete_witness_hashes_unchanged': 24,
                 'public_C17_headers': 55, 'public_CPP17_headers': 55,
                 'provider_inventory_files': 83, 'first_party_inventory_files': 71,
                 'vendor_and_provenance_inventory_files': 12, 'unique_provider_recipe_edits': 3,
                 'focused_Release_checks': 17, 'focused_sanitizer_checks': 17, 'full_host_checks': 42,
                 'source_files_at_immutable_Gufo_pin_verified': 1019},
    'checks': checks, 'complete_witnesses': witnesses, 'sources': [bound(p) for p in sorted(paths)],
    'binaries': binaries, 'build_inputs': build_inputs,
    'private_provider_inventory': {n: sha(n) for n in inventories[0]},
    'previous_receipt': bound(old_path),
    'matching_previous_GPU_receipt': bound('docs/development/validation/c17-schema-policy-point-gpu-2026-10-06.json'),
    'strict_C_object_imports': imports, 'local_CPU_max_C': peak,
    'sanitizers': 'ASan/UBSan/LSan outside ptrace; all overrides unset; no suppression or disabled checks.',
    'GPU_visible_devices': 'ROCR/HIP/CUDA masked by source-bound thermal helper; no model forward.',
    'latest_original_weight_GPU_source': 'a24875fe42cd33410e3dcb93fee43a46695f8c67',
    'new_GPU_build_run_or_reservation': False, '157_root_non_use': True,
    'Terminal_Bench': old['Terminal_Bench'], 'all_six_owned_roadmap_tasks_open': True,
    'retained_failures': [
        {'check': 'binary64-receipt-generator-failure-r1.json', 'actual_exit': 1,
         'reason': 'Receipt command-directory cardinality miscounted23; actual22 results all bound. Bookkeeping corrected without changing source/tests/gates.'},
        {'check': 'binary64-release-build-r1', 'actual_exit': 1,
         'reason': 'New base10 midpoint fixture has for/terminator misleading indentation under Werror. Corrected line break; strict warnings retained; final tests pass.'},
        {'check': 'binary64-upstream-fetch-failure-r1.json', 'actual_exit': 6,
         'reason': 'Official-source DNS fails under restricted sandbox; same official source acquired through authorized network escalation, no GPU activity.'}],
    'retained_build_warnings': {'older_upstream_fixtures_and_private_inactive_helpers': len(warnings),
                               'new_or_changed_owned_source_warnings': 0, 'pristine_source_modified': False},
    'retained_unresolved_failure': old['retained_unresolved_failure'],
    'unqualified': [
        'Matching83-file sealed provider/application and original-weight composition/codec AR/MTP gates.',
        'Original-weight individual branches/faults/independent probabilities/allocation-exact private resources/matched cost, SSD BPE.',
        'Opaque typed JSON/key/value containers, full lexer/predicates/model/controller ownership.',
        'All six owned tasks remain open; full Terminal Bench stays deferred.'],
    'publication': False, 'goal_complete': False}
target = Path('docs/development/validation/c17-binary64-host-2026-10-06.json')
with target.open('x') as f:
    json.dump(receipt, f, indent=2); f.write('\n')
print(json.dumps({'receipt': str(target), 'sha256': sha(target), 'checks': [17, 17, 42],
                  'previous_hashes_unchanged': 24, 'cases': cases, 'oracle_checks': 1013356,
                  'CPU_max_C': peak, 'provider_files': [71, 12]}))
