# SPDX-License-Identifier: MIT
from pathlib import Path
import datetime,hashlib,json,urllib.request
record=Path('evidence/binary64-ryu-upstream-commit-r2.json');r=json.loads(record.read_text());pin=r['sha'];assert len(pin)==40 and all(c in '0123456789abcdef' for c in pin)
base='https://raw.githubusercontent.com/ulfjack/ryu/'+pin+'/'
paths=['LICENSE-Apache2','LICENSE-Boost','ryu/d2s.c','ryu/s2d.c','ryu/ryu.h','ryu/ryu_parse.h','ryu/common.h','ryu/digit_table.h','ryu/d2s_intrinsics.h','ryu/d2s_full_table.h','ryu/d2s_small_table.h']
root=Path('third_party/ryu');root.mkdir(exist_ok=False);files={}
for name in paths:
 req=urllib.request.Request(base+name,headers={'User-Agent':'synapse-lie-source-audit'})
 with urllib.request.urlopen(req,timeout=30) as response:data=response.read(2*1024*1024+1)
 assert len(data)<=2*1024*1024
 path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
 files[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
manifest={'schema':'synapse-lie.ryu-source.v1','repository':'https://github.com/ulfjack/ryu','commit':pin,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'license_selected':'BSL-1.0 (dual upstream Apache-2.0/Boost alternatives retained unchanged)','scope':'Bundled C binary64 shortest formatter and fast parser; no project CPU/GPU model code or sibling artifacts.','files':files}
Path('third_party/ryu-source.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'pin':pin,'files':len(files),'bytes':sum(v['bytes'] for v in files.values()),'manifest':'third_party/ryu-source.json'}))
