// SPDX-License-Identifier: MIT
#include "lie/binary64.h"
#include <bit>
#include <charconv>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
int main() {
 uint64_t seed=0x63da513853709d45ULL; size_t checked=0;
 for(size_t i=0;i<1000000;++i){seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;double v=std::bit_cast<double>(seed);if(!std::isfinite(v))continue;
 char a[64],b[64];auto r=std::to_chars(a,a+64,v);size_t n=0;auto rc=lie_binary64_format(v,b,64,&n);
 if(rc!=LIE_BINARY64_OK||size_t(r.ptr-a)!=n||std::memcmp(a,b,n)){std::printf("FORMAT %016llx ref=%.*s core=%.*s status=%d\n",(unsigned long long)seed,int(r.ptr-a),a,int(n),b,int(rc));return 1;}
 double parsed=0;auto pc=lie_binary64_parse(a,size_t(r.ptr-a),nullptr,&parsed);
 if(pc!=LIE_BINARY64_OK||std::bit_cast<uint64_t>(parsed)!=seed){std::printf("PARSE %016llx ref=%.*s core=%016llx status=%d\n",(unsigned long long)seed,int(r.ptr-a),a,(unsigned long long)std::bit_cast<uint64_t>(parsed),int(pc));return 2;}
 ++checked;
 }
 std::printf("BINARY64 DIFFERENTIAL %zu finite exact format/roundtrips; HOST_NOT_INFERENCE\n",checked);
}
