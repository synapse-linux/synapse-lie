# SPDX-License-Identifier: MIT
from pathlib import Path
import json

r = json.loads(Path('docs/development/validation/c17-binary64-host-2026-10-06.json').read_text())
c = r['coverage']
def replace(name, old, new):
    p = Path(name); text = p.read_text()
    assert text.count(old) == 1, (name, old)
    p.write_text(text.replace(old, new))

replace('README.md', '''Gufo still owns model/controller state, private containers and the binary64
codec; immutable reasoning/tool composition now uses
the shared C17 core with [host validation](docs/development/validation/c17-composition-host-2026-10-06.json).
The newer 69-file composition increment still needs matching GPU qualification.
''', '''Gufo still owns model/controller state and typed containers. Immutable
reasoning/tool composition and JSON binary64 conversion now use the shared C17
core, with [host validation](docs/development/validation/c17-binary64-host-2026-10-06.json).
This newer source still needs matching original-weight GPU qualification.
''')
replace('CHANGELOG.md', '## Unreleased\n', '''## Unreleased

- Shared C17 JSON binary64 formatting and parsing, preserving number spelling,
  negative zero and nearest-even rounding. Bundled pinned Ryu adds no system
  dependency; MPFR is used only by optional developer tests. Matching
  original-weight GPU qualification remains pending.
''')
entry = f'''## JSON binary64 conversion uses the shared C17 core — 2026-10-06 UTC

The model-neutral `lie/binary64.h` ABI now supplies shortest JSON number spelling
and full-span nearest-even parsing to the schema adapter and provider JSON
conversion. Pinned bundled Ryu supplies the C shortest formatter and short
parser; first-party C code owns spelling, strict JSON syntax and exact long
decimal conversion. The latter keeps 800 significant digits and a sticky tail,
so later nonzero digits still affect midpoint decisions. Caller text/work bounds
and refusal preserve outputs. No locale, floating environment, heap allocation,
mutable cache or inference thread is introduced by these public codec calls.

The [source-bound host receipt](development/validation/c17-binary64-host-2026-10-06.json)
records {c['focused_Release_checks']} focused Release, {c['focused_sanitizer_checks']} ASan/UBSan/LSan and
{c['full_host_checks']} pristine/default-ON/OFF host checks. The {c['actual_binary64_cases']:,} complete
JSON witnesses agree; all {c['previous_complete_witness_hashes_unchanged']} earlier witness hashes remain unchanged.
Independent C fixtures cover {c['independent_C_oracles']} bit/rounding oracles and {c['selected_refusals']} refusals,
including normal/subnormal midpoints and a nonzero digit beyond 17,000 zeros.
The MPFR decimal and independent shortest/bit QA probe reports
{c['independent_MPFR_and_shortest_checks']:,} combined checks; allocator hooks observe
zero heap calls during the selected public C calls only. All {c['public_C17_headers']} public
headers compile as C17/C++17. Provider binding grows to 83 files: 71 first-party
files and 12 vendor/provenance files. Ryu's eleven unchanged files retain their
upstream licenses, with BSL-1.0 selected; they are not first-party MIT source.
Default products and default CTest remain Python/MPFR-free.

The initial fixture build exits 1 on a strict indentation warning; it is fixed
without relaxing warnings, and the actual failure is retained. An initial
official-source DNS failure also retains curl exit 6. Final sanitizer checks
run outside ptrace with overrides unset and no disabled checks. CPU peaks
{r['local_CPU_max_C']} C under the CPU98/NVMe85/lower exposed guards. No GPU run,
remote build, lease or reservation is added. The latest matching original-weight
source remains `a24875f` (66 files); it does not qualify this composition/codec
increment. Typed containers/lexer/predicate storage and model/controller
ownership, matching provider/application and original-weight gates, individual
branches/faults/resources/cost and SSD BPE remain open. All six owned tasks stay
open; Terminal Bench remains stopped and deferred until modifications and their
qualification finish.

'''
replace('docs/PROGRESS.md', '# Development progress\n', '# Development progress\n\n' + entry)
replace('docs/BACKEND.md', '   Provider container views/staging and the binary64 codec remain private.',
        '   Provider container views/staging remain private; binary64 conversion now\n   uses the later shared C17 codec below.')
replace('docs/BACKEND.md', '''([receipt](development/validation/c17-schema-body-point-gpu-2026-10-05.json)). The binary64 codec
   still needs extraction within the same task. Numeric''',
        '''([receipt](development/validation/c17-schema-body-point-gpu-2026-10-05.json)). Numeric''')
replace('docs/BACKEND.md', '''   complete states/masks and allocation/refusal oracles. Its newer 69-file inventory
   requires matching provider/application and original-weight gates. Opaque
   key/value containers, typed predicate storage and binary64 codec remain private.''',
        '''   complete states/masks and allocation/refusal oracles. JSON binary64 number
   formatting/parsing now also uses C17 with bundled pinned Ryu and independent
   bit/rounding/refusal oracles
   ([host checks](development/validation/c17-binary64-host-2026-10-06.json)). This
   newer 83-file inventory (71 first-party + 12 vendor/provenance files) requires
   matching provider/application and original-weight gates. Typed JSON/key/value
   containers, lexer/predicate storage and model/controller remain private.''')
replace('docs/development/C17-SAMPLING.md', '''Binary64 serialization/parser
implementation and private composition/model/controller remain transitional.''',
        '''Binary64 conversion and immutable composition are extracted in the later
host-qualified increments below; typed storage/model/controller remain private.''')
replace('docs/development/C17-SAMPLING.md', '''controls; individual format GPU branches remain pending. The binary64 codec and
private composition/model/controller remain transitional.''',
        '''controls; individual format GPU branches remain pending. Later increments
below extract composition and the codec; typed storage/model/controller remain private.''')
replace('docs/development/C17-SAMPLING.md', 'Opaque typed key/value storage and binary64 codec remain private.',
        'Opaque typed key/value storage remains private; binary64 conversion is extracted below.')
replace('docs/development/C17-SAMPLING.md', '''receipt does not extend to it. Binary64 codec/model/controller ownership and
broader qualification remain open.''',
        '''receipt does not extend to it. Typed storage/model/controller ownership and
broader qualification remain open.

The later 83-file increment moves JSON binary64 conversion to `lie/binary64.h`.
Its [host receipt](validation/c17-binary64-host-2026-10-06.json) records 17 focused
Release, 17 sanitizer and 42 complete pristine/ON/OFF controls. All 24 previous
complete witness hashes are unchanged. Three exact recipe edits keep both
original OFF conversion bodies; the ON JSON and numeric schema paths call the
same C codec. The inventory includes 71 first-party files and 12 vendor/provenance
files. A fresh matching provider/application and original-weight GPU run is
still required; `a24875f` does not cover this increment.''')
replace('docs/development/C17-SAMPLING.md', '''The private adapter now supplies borrowed views, the existing locale-neutral
binary64 codec and typed exception translation.''',
        '''The private adapter supplies borrowed views, callbacks to the shared C17
binary64 codec and typed exception translation.''')
replace('docs/development/C17-SAMPLING.md', '''whole-engine qualification or a performance measurement. The codec's
implementation and composition/model/controller remain to
be extracted.''',
        '''whole-engine qualification or a performance measurement. The later C17
codec and composition increments are host-qualified; typed storage/model/controller
remain private.''')
replace('docs/development/C17-SAMPLING.md', 'Binary64 codec and private composition/model/controller extraction continue.',
        'Later host-qualified increments extract the codec/composition; typed storage/model/controller remain private.')
codec = '''## JSON binary64 codec

`lie/binary64.h` exposes separate ABI 1 with no model, HTTP, C++ container or
allocator type. Formatting writes no NUL and matches the pinned provider's
shortest default spelling, including fixed/scientific selection, exact closest
integer spelling, signed exponents and negative zero. Parsing validates the
entire JSON number span, with optional JSON whitespace, and rounds to nearest
with ties to even. Nonfinite overflow and nonzero underflow to zero refuse.
Refusal preserves bytes/length/value; output must be disjoint from inputs.

The bundled [Ryu provenance](../../third_party/ryu-source.json) fixes eleven
unchanged C/header/license files to `4c0618b0e44f7ef027ebae05d2cc7812048f7c8f`.
BSL-1.0 is selected and both upstream license alternatives are retained. The
short parser receives at most 17 significant digits; the independently written
exact fallback uses bounded base-2 integer workspaces, 800 significant decimal
digits and a sticky tail. Binary64 rounding midpoints have at most 768 significant
decimal digits, so later nonzero input still resolves exact ties. No locale or
floating-environment change, mutable cache or heap allocation occurs in the
public formatter/parser. Defaults admit at most UINT32_MAX text bytes and
64 million counted work units; these are refusal limits, not timings.

The [host receipt](validation/c17-binary64-host-2026-10-06.json) binds independent
bit/rounding and refusal fixtures, all four floating rounding modes, all 55 C17/
C++17 public headers, 106,273 actual pristine/ON/OFF JSON cases and all 24 earlier
unchanged witness hashes. The independent QA probe combines installed MPFR
decimal comparisons with shortest-spelling/bit roundtrips: 1,013,356 checks in
total, including exact subnormal midpoint tails. It observes
zero allocator calls while selected public codec calls execute. It is QA-only:
MPFR/GMP are required only by the optional `tests/sampling` developer project,
not by ordinary core/server/bench/default CTest. The codec object still contains
Ryu's unused allocating convenience entry point; its malloc import does not
describe the tested public paths. Typed JSON storage/full lexer, immutable
predicates and model/controller remain private. Matching original-weight
composition/codec, individual branches/faults/resources/cost and SSD BPE gates
are still pending; no inference speedup is claimed.

'''
replace('docs/development/C17-SAMPLING.md', '## Pinned string format expansion\n', codec + '## Pinned string format expansion\n')
abi = '''`lie/binary64.h` adds separate ABI 1. The synchronous, model-neutral C codec
formats finite IEEE754 binary64 into caller storage without a NUL and parses
full strict JSON number spans with nearest-even rounding. Signed zero survives;
overflow/nonzero underflow, invalid syntax, aliasing, insufficient capacity and
tagged text/work budgets refuse without publishing outputs. Defaults cap text
at UINT32_MAX bytes and work at 64 million units. No pointers are retained,
heap allocator is called, locale/FENV is changed or model/device/worker is
created by these public calls. Bundled pinned Ryu retains its separate license.
Existing engine/sampler/grammar/state/HTTP ABI and DS4 framing remain unchanged.
See [host validation](../development/validation/c17-binary64-host-2026-10-06.json).

'''
replace('docs/reference/ABI.md', '`lie/grammar_composition.h` adds independent composition ABI 1.',
        abi + '`lie/grammar_composition.h` adds independent composition ABI 1.')
replace('docs/reference/ABI.md', '''builds. Typed provider templates/predicates and the binary64 codec remain
transitional.''', 'builds. Typed provider templates/predicates remain transitional.')
replace('docs/reference/ABI.md', '''64-level reference budget. Typed JSON/storage and the binary64 codec stay
in the adapter.''', '64-level reference budget. Typed JSON/storage stays in the adapter.')
state = '''The shared C17 binary64 codec owns no persistent or request-local state. It
borrows text and writes caller storage synchronously; exact arithmetic and
digits use bounded stack scratch. Immutable Ryu lookup tables do not enter
model-prefix state, KV checkpoints or DS4 RAM/SSD framing. No locale/FENV/RNG,
reactive frontier, worker or cache identity changes. Typed JSON containers and
the full lexer remain private. [Host checks](../development/validation/c17-binary64-host-2026-10-06.json)
do not qualify new original-weight continuation or SSD restore.

'''
replace('docs/reference/STATE.md', 'Immutable reasoning/tool grammar composition now belongs to C17.',
        state + 'Immutable reasoning/tool grammar composition now belongs to C17.')
replace('docs/reference/STATE.md', 'supplies typed predicate/container storage and the remaining binary64 codec. Concrete',
        'supplies typed predicate/container storage. Concrete')
replace('docs/reference/STATE.md', 'Typed JSON/predicate/storage and the binary64 codec\nremain transitional.',
        'Typed JSON/predicate/storage remains transitional.')
metrics = '''C17 binary64 text/work bounds are admission limits, with no new HTTP timing,
counter or inference worker. Codec scratch is bounded stack storage; allocator
hooks in the [host oracle](../development/validation/c17-binary64-host-2026-10-06.json)
observe zero heap calls only during the selected public formatter/parser calls.
The complete QA process, provider containers, ICU, MPFR/GMP, model/device and
allocator-exact resources are outside that scope. No throughput or matched
original-weight cost improvement is inferred from host parity.

'''
replace('docs/reference/METRICS.md', 'C17 immutable grammar composition reports construction `work`, `owned_bytes`',
        metrics + 'C17 immutable grammar composition reports construction `work`, `owned_bytes`')
replace('docs/reference/METRICS.md', 'typed provider templates/predicates, leaf translation and binary64 codec. The independent',
        'typed provider templates/predicates and leaf translation. The independent')
print('Updated current README/changelog/roadmap/ABI/state/metrics; historical receipts retained.')
