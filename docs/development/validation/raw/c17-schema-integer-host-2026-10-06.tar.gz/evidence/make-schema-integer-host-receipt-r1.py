# SPDX-License-Identifier: MIT
"""Seal real HOST results, complete witnesses and immutable source snapshots."""
import gzip
import hashlib
import json
import re
import shutil
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert parent == '865af5f538b07bebf3b8e9b44928fa2cafdde79d'
previous_path = 'docs/development/validation/c17-schema-compile-host-2026-10-06.json'
previous = json.loads(Path(previous_path).read_text())
def bind(path):
    p = Path(path)
    with p.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=digest)
def read(path): return json.loads(Path(path).read_text())
lists = []
for name in ('cmake/provider/Build.cmake', 'cmake/provider/Verify.cmake', 'tests/provider_contract.cmake'):
    match = re.search(r'foreach\(name IN ITEMS (src/sampling\.c.*?)\)', Path(name).read_text(), re.S)
    entries = match.group(1).split()
    assert len(entries) == len(set(entries)) == 105
    lists.append(entries)
assert all(set(entries) == set(lists[0]) for entries in lists)
inventory = {path: bind(path)['sha256'] for path in lists[0]}
added = set(inventory) - set(previous['private_provider_inventory'])
assert added == {'src/schema_integer.c', 'include/lie/schema_integer.h', 'adapters/gufo_schema_integer.hpp'}
assert all(inventory[path] == digest for path, digest in previous['private_provider_inventory'].items())
gufo, ryu = read('third_party/gufo-source.json'), read('third_party/ryu-source.json')
for path, digest in gufo['files'].items(): assert bind(Path('.deps/gufo-f783fedb') / path)['sha256'] == digest
for path, identity in ryu['files'].items():
    current = bind(Path('third_party/ryu') / path)
    assert (current['bytes'], current['sha256']) == (identity['bytes'], identity['sha256'])
assert len(gufo['files']) == 1019 and len(ryu['files']) == 11
commands = []
for result_path in sorted(Path('evidence').glob('schema-integer-*/result.json')):
    directory = result_path.parent
    result, plan = read(result_path), read(directory / 'plan.json')
    expected = 8 if directory.name == 'schema-integer-core-ctest-r1' else 0
    assert result['exit_code'] == result['child_exit_code'] == expected and result['reason'] is None
    assert plan['cwd'] == str(root)
    cpus = [sensor for sensor in plan['sensors'] if sensor['name'] in ('k10temp', 'coretemp')]
    assert cpus and all(sensor['limit_c'] <= 98 for sensor in cpus)
    assert all(sensor['limit_c'] <= 85 for sensor in plan['sensors'] if sensor['name'] == 'nvme')
    assert all(sensor['limit_c'] is None and sensor['policy'] == 'observe-only'
               for sensor in plan['sensors'] if sensor['name'] == 'amdgpu')
    log = (directory / 'command.log').read_text()
    counts = re.findall(r'out of\s+(\d+)', log)
    files = [bind(directory / name) for name in ('plan.json', 'result.json', 'command.log', 'temperatures.jsonl')]
    if (directory / 'LastTest.log').exists(): files.append(bind(directory / 'LastTest.log'))
    commands.append(dict(directory=str(directory), argv=result['argv'], actual_exit_code=expected,
                         child_exit_code=result['child_exit_code'], reason=None,
                         test_count=int(counts[-1]) if counts else None,
                         CPU_max_C=max(result['peak_c'][sensor['path']] for sensor in cpus), files=files))
lookup = {command['directory']: command for command in commands}
for suffix, count in [('host-tests-r1', 58), ('core-ctest-r2', 1), ('release-tests-r1', 4)]:
    command = lookup['evidence/schema-integer-' + suffix]
    assert command['test_count'] == count and command['actual_exit_code'] == 0
assert len(commands) == 11
core_log = Path('evidence/schema-integer-core-ctest-r2/LastTest.log').read_text()
assert '16383 format, 4716 language oracles, 20 callback and 38 allocator refusals' in core_log
witnesses = []
for old in previous['complete_witnesses']:
    files = []
    for entry in old['files']:
        path = entry['path'].replace('build/schema-compile-host/', 'build/schema-integer-host/', 1)
        assert path != entry['path']
        current = bind(path)
        assert (current['bytes'], current['sha256']) == (entry['bytes'], entry['sha256'])
        if path.endswith('.exit'): assert Path(path).read_text().strip() == '0'
        if path.endswith('.stderr'): assert current['bytes'] == 0
        files.append(current)
    witnesses.append(dict(suite=old['suite'], previous_hash_unchanged=True, files=files))
assert len(witnesses) == 29 and sum(len(w['files']) for w in witnesses) == 258
new_files = [bind(Path('build/schema-integer-host/integer-parity') / (arm + suffix))
             for arm in ('REFERENCE', 'CANDIDATE', 'FALLBACK') for suffix in ('.txt', '.stderr', '.exit')]
assert len({entry['sha256'] for entry in new_files if entry['path'].endswith('.txt')}) == 1
for entry in new_files:
    if entry['path'].endswith('.stderr'): assert entry['bytes'] == 0
    if entry['path'].endswith('.exit'): assert Path(entry['path']).read_text().strip() == '0'
with Path('build/schema-integer-host/integer-parity/REFERENCE.txt').open('rb') as stream:
    stream.seek(-200, 2); tail = stream.read().decode()
assert 'INTEGER_COMPLETE cases=283 magnitudes=9226 states=4927 masks=574 HOST_NOT_INFERENCE' in tail
witnesses.append(dict(suite='integer-parity', previous_hash_unchanged=False, files=new_files))
sources = {entry['path'] for entry in previous['sources']} | set(inventory)
sources.update(subprocess.check_output(['git', 'diff', '--name-only'], text=True).splitlines())
sources.update(['tests/test_schema_integer.c', 'tests/sampling/integer.cpp',
                'adapters/gufo-state/schema-integer-edits.json',
                'evidence/prepare-schema-integer-wiring-r1.py',
                'evidence/make-schema-integer-host-receipt-r1.py'])
frozen = []
for path in sorted(sources):
    source = bind(path)
    destination = Path('evidence/schema-integer-host-frozen-sources-r1') / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as out, Path(path).open('rb') as stream: shutil.copyfileobj(stream, out)
    snapshot = bind(destination)
    assert (source['bytes'], source['sha256']) == (snapshot['bytes'], snapshot['sha256'])
    frozen.append(dict(source=source, snapshot=snapshot))
binaries, inputs = [], []
for build in ('build/schema-integer-host', 'build/schema-integer-core-asan', 'build/schema-integer-release'):
    directory = Path(build)
    for path in sorted(directory.iterdir()):
        if path.is_file() and (path.name.startswith(('candidate-', 'reference-', 'fallback-', 'test-')) or path.suffix == '.a') and path.suffix != '.cpp':
            binaries.append(bind(path))
    paths = set(directory.rglob('*.cmake')) | set(directory.glob('*-schema-constraint.cpp'))
    paths |= {directory / name for name in ('CMakeCache.txt', 'build.ninja', '.ninja_log', '.ninja_deps', 'variant-files.json') if (directory / name).exists()}
    paths |= set(directory.rglob('flags.make')) | set(directory.rglob('link.txt'))
    paths |= set(directory.rglob('rules.ninja'))
    inputs.extend(bind(path) for path in sorted(paths) if path.is_file())
assert len(binaries) == 122
failures = [bind('evidence/schema-integer-initial-fixture-failure-r1.json'),
            bind('evidence/schema-integer-read-discovery-failures-r1.json')]
recipe = bind('adapters/gufo-state/schema-integer-edits.json')
assert len(read(recipe['path'])['edits']) == 3
receipt = dict(schema='synapse-lie.c17-schema-integer-host.v1',
    at_utc=datetime.now(timezone.utc).isoformat(), state='HOST_QUALIFIED_NOT_GPU_QUALIFIED',
    source_parent_commit=parent, scope='Signed integer-bound compiler and exact represented binary64 magnitude; HOST fixtures only, no original-weight inference, GPU faults, memory fit, quality or performance qualification.',
    previous_host_receipt=bind(previous_path),
    previous_GPU_receipt=bind('docs/development/validation/c17-schema-compile-point-gpu-2026-10-06.json'),
    previous_GPU_excludes_new_source=True,
    private_provider_inventory=inventory, added_provider_files=sorted(added),
    previous_102_provider_hashes_unchanged=True,
    immutable_upstream=dict(gufo_pin=gufo['commit'], gufo_files=1019, ryu_files=11),
    compile_recipe=recipe, exact_guarded_edits=3,
    independent_C_oracles=dict(formats=16383, language=4716, callback_refusals=20, allocation_refusals=38),
    new_original_ON_OFF_witness=dict(cases=283, magnitude_calls=9226, states=4927, masks=574),
    unchanged_previous_groups=29, unchanged_previous_files=258,
    complete_witnesses=witnesses, actual_commands=commands,
    final_test_counts=dict(complete_sanitizer_HOST=58, focused_sanitizer_C=1, Release_C_and_provenance=4),
    sanitizer_execution='Outside sandbox ptrace; ASAN_OPTIONS/LSAN_OPTIONS/UBSAN_OPTIONS unset; no suppressions.',
    source_and_binary_scope='105-file owned provider inventory; 122 actual HOST binaries/archives; test-only compiler exposure compiled once per coherent arm and used by five fixtures. No official Gufo HTTP frontend or HIP model compiled.',
    sources=[entry['source'] for entry in frozen], frozen_sources=frozen,
    binaries=binaries, build_inputs=inputs, retained_failures=failures,
    maximum_observed_local_CPU_C=max(command['CPU_max_C'] for command in commands),
    guards='CPU98/NVMe85 and existing lower limits; GPU masked/observe-only; no tuning/install.',
    ABI_state_metrics=dict(existing_public_layouts_unchanged=True, DS4_framing_unchanged=True,
                          no_new_serving_metric_or_inference_worker=True),
    pending='Matching new-source coherent HIP ON/OFF/private consumers and .161 original-weight controls; broader branch/fault/probability/quality/resource/cost gates and fully owned model/controller.',
    root_157_158_nonuse=True, new_remote_job_client_build_lease_waiter_reservation=False,
    all_six_owned_tasks_open=True, Terminal_Bench='Stopped/collected/closed/deferred last',
    publication=False)

# Full witness data are retained once per identical SHA, with explicit path
# aliases for every actual capture. No output is truncated or regenerated.
raw_entries = []
for command in commands: raw_entries.extend(command['files'])
for witness in witnesses: raw_entries.extend(witness['files'])
raw_entries.extend(entry['source'] for entry in frozen)
raw_entries.extend(inputs)
raw_entries.extend(failures)
raw_entries.extend([receipt['previous_host_receipt'], receipt['previous_GPU_receipt']])
raw_entries = list({entry['path']: entry for entry in raw_entries}.values())
canonical, aliases, contents = {}, [], []
for entry in raw_entries:
    digest = entry['sha256']
    if digest in canonical:
        aliases.append(dict(**entry, canonical_path=canonical[digest]))
    else:
        canonical[digest] = entry['path']; contents.append(entry)
archive_path = Path('docs/development/validation/raw/c17-schema-integer-host-2026-10-06.tar.gz')
archive_path.parent.mkdir(parents=True, exist_ok=True)
manifest = dict(schema='synapse-lie.complete-raw-alias-manifest.v1', files=contents, aliases=aliases)
manifest_path = Path('evidence/schema-integer-portable-manifest-r1.json')
with manifest_path.open('x') as out: json.dump(manifest, out, indent=2); out.write('\n')
with archive_path.open('xb') as out:
    with gzip.GzipFile(fileobj=out, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for entry in contents:
                assert not Path(entry['path']).is_symlink()
                info = archive.gettarinfo(entry['path'], arcname=entry['path'])
                info.mtime = info.uid = info.gid = 0; info.uname = info.gname = ''
                with Path(entry['path']).open('rb') as stream: archive.addfile(info, stream)
            info = archive.gettarinfo(str(manifest_path), arcname='MANIFEST.json')
            info.mtime = info.uid = info.gid = 0; info.uname = info.gname = ''
            with manifest_path.open('rb') as stream: archive.addfile(info, stream)
receipt['portable_raw_archive'] = dict(**bind(archive_path), members=len(contents) + 1,
    actual_capture_paths=len(raw_entries), exact_duplicate_aliases=len(aliases),
    scope='Complete sources/build inputs/commands/logs/telemetry and untruncated witness bytes; identical full captures use explicit SHA-verified aliases. Binaries are hashed, not redistributed.')
receipt_path = Path('docs/development/validation/c17-schema-integer-host-2026-10-06.json')
with receipt_path.open('x') as out: json.dump(receipt, out, indent=2); out.write('\n')
print(json.dumps(dict(receipt=str(receipt_path), sources=len(frozen), binaries=len(binaries),
                     build_inputs=len(inputs), witness_groups=len(witnesses), actual_commands=len(commands),
                     archive_bytes=archive_path.stat().st_size, CPU_max_C=receipt['maximum_observed_local_CPU_C'])))
