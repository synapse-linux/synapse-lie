# SPDX-License-Identifier: MIT
"""Add an exact guarded recipe and coherent local C17 provider wiring."""
import json
from pathlib import Path

def replace(path, old, new):
    p = Path(path)
    s = p.read_text()
    assert s.count(old) == 1, (path, old[:100])
    p.write_text(s.replace(old, new))

recipe = {
  "schema": "synapse-lie.gufo-state-edits.v1",
  "source_pin": "f783fedb9bea2ec7de941f6da4e02f4a4596b29e",
  "license": "MIT",
  "scope": "Complete signed integer-bound policy and exact represented binary64 magnitude in shared C17; typed views/errors remain private. Original OFF algorithm is retained verbatim.",
  "edits": [
    {"path": "src/core/json_constraint.cpp",
     "old": '#include "gufo_schema_compile.hpp"',
     "new": '#include "gufo_schema_compile.hpp"\n#include "gufo_schema_integer.hpp"'},
    {"path": "src/core/json_constraint.cpp",
     "old": '  std::uint32_t Integer(const json::Value& schema) {\n    std::optional<double> minimum, maximum;',
     "new": '  std::uint32_t Integer(const json::Value& schema) {\n#if LIE_C17_SAMPLING\n    return lie_gufo::schema_integer(schema, builder_.get(), integer_);\n#else\n    std::optional<double> minimum, maximum;'},
    {"path": "src/core/json_constraint.cpp",
     "old": '    return Alt(choices);\n  }\n  void Keys(const json::Value& schema) {',
     "new": '    return Alt(choices);\n#endif\n  }\n  void Keys(const json::Value& schema) {'}
  ]
}
with Path('adapters/gufo-state/schema-integer-edits.json').open('x') as f:
    json.dump(recipe, f, indent=2); f.write('\n')
for name in ('CMakeLists.txt', 'cmake/gufo-runtime/CMakeLists.txt', 'tests/sampling/CMakeLists.txt'):
    prefix = 'src/' if name == 'CMakeLists.txt' else '${LIE_ROOT}/src/' if name.startswith('cmake/') else '${REPO}/src/'
    old = prefix + 'schema_number.c'
    if name == 'CMakeLists.txt': new = old + ' src/schema_integer.c'
    else: new = old + '" "' + prefix + 'schema_integer.c'
    replace(name, old, new)
for name in ('cmake/provider/Build.cmake', 'cmake/provider/Verify.cmake', 'tests/provider_contract.cmake'):
    old = 'src/schema_number.c include/lie/schema_number.h adapters/gufo_schema_number.hpp'
    replace(name, old, old + ' src/schema_integer.c include/lie/schema_integer.h adapters/gufo_schema_integer.hpp')
replace('cmake/provider/Verify.cmake', 'NOT owned_count EQUAL 102', 'NOT owned_count EQUAL 105')
replace('cmake/provider/Source.cmake', 'schema-compile-edits.json)', 'schema-compile-edits.json schema-integer-edits.json)')
replace('cmake/provider/Build.cmake',
  '  file(SHA256 "${LIE_SOURCE_ROOT}/adapters/gufo-state/schema-compile-edits.json" hash)',
  '  file(SHA256 "${LIE_SOURCE_ROOT}/adapters/gufo-state/schema-integer-edits.json" hash)\n  string(JSON receipt SET "${receipt}" schema_integer_edits_sha256 "\\"${hash}\\"")\n  file(SHA256 "${LIE_SOURCE_ROOT}/adapters/gufo-state/schema-compile-edits.json" hash)')
replace('cmake/provider/Verify.cmake',
  '    file(SHA256 "${LIE_SOURCE_ROOT}/adapters/gufo-state/schema-compile-edits.json" hash)',
  '    file(SHA256 "${LIE_SOURCE_ROOT}/adapters/gufo-state/schema-integer-edits.json" hash)\n    string(JSON expected GET "${receipt}" schema_integer_edits_sha256)\n    if(NOT hash STREQUAL expected)\n      message(FATAL_ERROR "Owned schema integer edit provenance mismatch")\n    endif()\n    file(SHA256 "${LIE_SOURCE_ROOT}/adapters/gufo-state/schema-compile-edits.json" hash)')
replace('tests/provider_contract.cmake', 'foreach(pair IN ITEMS "schema-compile-source|',
  'foreach(pair IN ITEMS "schema-integer-source|src/schema_integer.c|Source/archive drift" "schema-integer-header|include/lie/schema_integer.h|Source/archive drift" "schema-integer-glue|adapters/gufo_schema_integer.hpp|Source/archive drift" "schema-compile-source|')
replace('tests/provider_contract.cmake', '"schema-compile|schema_compile"', '"schema-compile|schema_compile" "schema-integer|schema_integer"')
block = '''string(JSON changed SET "${selected}" schema_integer_edits_sha256 "\\"wrong-hash\\"")
file(WRITE "${root}/build/fake/BUILD-RECEIPT.json" "${changed}\\n")
check(schema-integer-recipe-hash "Owned schema integer edit provenance mismatch" ON)
string(JSON changed REMOVE "${selected}" schema_integer_edits_sha256)
file(WRITE "${root}/build/fake/BUILD-RECEIPT.json" "${changed}\\n")
check(schema-integer-recipe-missing "schema_integer_edits_sha256" ON)
file(WRITE "${root}/build/fake/BUILD-RECEIPT.json" "${selected}")
file(READ "${root}/adapters/gufo-state/schema-integer-edits.json" integer_recipe)
file(APPEND "${root}/adapters/gufo-state/schema-integer-edits.json" "changed")
check(schema-integer-recipe-drift "Owned schema integer edit provenance mismatch" ON)
file(WRITE "${root}/adapters/gufo-state/schema-integer-edits.json" "${integer_recipe}")
'''
replace('tests/provider_contract.cmake', 'string(JSON changed SET "${selected}" schema_compile_edits_sha256', block + 'string(JSON changed SET "${selected}" schema_compile_edits_sha256')
print('Exact three-edit recipe, coherent 105-file inventory and HOST/HIP/reference source wiring prepared.')
