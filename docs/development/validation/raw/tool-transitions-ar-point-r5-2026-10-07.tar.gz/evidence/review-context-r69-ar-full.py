# SPDX-License-Identifier: MIT
"""Review the complete collected original-weight AR wire independently."""
from pathlib import Path
import datetime, hashlib, json

root = Path.cwd()
job = root / 'evidence/context-r69-tools-ar-r1'
def read(path):
    return json.loads(path.read_text())
def bound(path):
    assert path.is_file() and not path.is_symlink()
    return {'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

manifest, run, controller = [read(job / name) for name in
                            ('manifest.json', 'result.json', 'controller-result.json')]
http, tools = [read(job / name) for name in
               ('http-result.json', 'http-tool-transitions-result.json')]
assert manifest['source_commit'] == '90a884558c79ed696918e2ddfafefc3227659962'
assert manifest['decode_mode'] == 'ar'
assert run['state'] == http['state'] == tools['state'] == 'PASSED'
assert run['exit_code'] == run['child_exit_code'] == controller['exit_code'] == 0
assert http['server_exit_code'] == 0 and not run['cleanup_failures']
assert run['model_attempted'] and run['model_stat_unchanged']
assert run['models_before'] == run['models_after'] and len(run['models_before']) == 4
collection = read(job / 'collection.json')
assert collection['exit_code'] == 0 and len(collection['inventory']['files']) == 15
assert all(command['exit_code'] == 0 for command in collection['commands'])
for name, identity in collection['inventory']['files'].items():
    assert bound(job / name) == identity, name

profiles = [('greedy', (0, 1, 0, 0)), ('ds4', (1, 1, 0, .05)),
            ('filtered', (.8, .9, 32, .02))]
cases = ['auto-text', 'prose-call', 'parallel', 'single']
expected = []
for profile, _ in profiles:
    for api in ('chat', 'responses'):
        for case in cases:
            for streaming in ('json', 'sse'):
                expected.append(f'{profile}_{api}_{case}_{streaming}')
                if case == 'parallel':
                    if api == 'responses' and streaming == 'sse':
                        expected.append(f'{profile}_responses_parallel_replay')
                    expected.append(f'{profile}_{api}_correlated_results_{streaming}')
        if profile == 'greedy':
            expected.extend(f'{api}_refusal_{name}' for name in
                            ('orphan', 'missing', 'duplicate', 'unknown'))
assert len(expected) == len(set(expected)) == 71
assert tools['passed'] == expected and set(tools['witnesses']) == set(expected)
assert http['passed'] == ['models', 'chat_json', 'chat_sse', 'responses_json',
                          'responses_sse'] + expected
assert tools['current_check'] is None and tools['refusals_before_forward_verified']

wire = [json.loads(line) for line in (job / 'http-wire.jsonl').read_text().splitlines()]
posts = [row for row in wire if row['method'] == 'POST' and row['request'].get('tools')]
assert len(posts) == 68

def sse(body):
    payloads = [line[6:] for line in body.splitlines() if line.startswith('data: ')]
    return [json.loads(value) for value in payloads if value != '[DONE]'], payloads

def chat(row):
    if not row['request']['stream']:
        value = json.loads(row['body'])
        assert len(value['choices']) == 1 and value['choices'][0]['index'] == 0
        choice = value['choices'][0]
        message = choice['message']
        finish = choice['finish_reason']
        calls = message.get('tool_calls', [])
        text = message.get('content') or ''
        usage, timings = value['usage'], value['lie_timings']
    else:
        chunks, payloads = sse(row['body'])
        assert payloads[-1] == '[DONE]' and payloads.count('[DONE]') == 1
        finishes, usages, timing_rows, by_index, fragments = [], [], [], {}, []
        for chunk in chunks:
            if chunk.get('usage') is not None:
                usages.append(chunk['usage'])
            if chunk.get('lie_timings') is not None:
                timing_rows.append(chunk['lie_timings'])
            for choice in chunk['choices']:
                assert choice['index'] == 0
                if choice.get('finish_reason') is not None:
                    finishes.append(choice['finish_reason'])
                delta = choice['delta']
                fragments.append(delta.get('content') or '')
                for part in delta.get('tool_calls', []):
                    index = part['index']
                    call = by_index.setdefault(index, {'id': '', 'function': {'name': '', 'arguments': ''}})
                    if part.get('id'):
                        assert not call['id'] or call['id'] == part['id']
                        call['id'] = part['id']
                    for key in ('name', 'arguments'):
                        call['function'][key] += part.get('function', {}).get(key, '')
        assert len(finishes) == len(usages) == len(timing_rows) == 1
        finish, usage, timings = finishes[0], usages[0], timing_rows[0]
        calls, text = [by_index[index] for index in sorted(by_index)], ''.join(fragments)
    assert finish == ('tool_calls' if calls else 'stop')
    assert usage['total_tokens'] == usage['prompt_tokens'] + usage['completion_tokens']
    assert timings['valid'] and timings['decode_mode'] == 'ar'
    assert timings['mtp_drafted_tokens'] == timings['mtp_accepted_tokens'] == 0
    return text, [(call['id'], call['function']['name'],
                   json.loads(call['function']['arguments'])) for call in calls]

def response(row):
    if row['request']['stream']:
        chunks, payloads = sse(row['body'])
        assert '[DONE]' not in payloads
        assert [chunk['sequence_number'] for chunk in chunks] == list(range(len(chunks)))
        terminals = [chunk for chunk in chunks if chunk['type'] == 'response.completed']
        assert len(terminals) == 1 and chunks[-1] == terminals[0]
        value = terminals[0]['response']
    else:
        value = json.loads(row['body'])
    assert value['status'] == 'completed' and value['error'] is None
    assert value['incomplete_details'] is None
    for key in ('seed', 'temperature', 'top_p', 'top_k', 'min_p'):
        assert value[key] == row['request'][key]
    usage = value['usage']
    assert usage['total_tokens'] == usage['input_tokens'] + usage['output_tokens']
    text = ''.join(part['text'] for item in value['output'] if item['type'] == 'message'
                   for part in item['content'] if part['type'] == 'output_text')
    calls = [(item['call_id'], item['name'], json.loads(item['arguments']))
             for item in value['output'] if item['type'] == 'function_call']
    return value, text, calls

instruction = 'Return only one JSON object mapping alpha and beta to their returned integer values. Do not call functions.'
known_calls, response_calls, correlated, ordinary, refused, replayed = {}, {}, 0, 0, 0, 0
for row in posts:
    request = row['request']
    assert type(request['seed']) is int and request['seed'] == 123
    assert tuple(request[key] for key in ('temperature', 'top_p', 'top_k', 'min_p')) in [v for _, v in profiles]
    api = 'chat' if row['path'] == '/v1/chat/completions' else 'responses'
    assert row['path'] in ('/v1/chat/completions', '/v1/responses')
    assert request['max_tokens' if api == 'chat' else 'max_output_tokens'] == 512
    if row['status'] == 400:
        assert json.loads(row['body'])['error']['type'] == 'invalid_request_error'
        refused += 1
        continue
    assert row['status'] == 200
    if api == 'chat':
        text, calls = chat(row)
        history = request['messages']
        prompt = history[-1]['content']
    else:
        value, text, calls = response(row)
        response_calls[value['id']] = calls
        history = request['input']
        prompt = history if isinstance(history, str) else history[-1]['content']
    assert len({call[0] for call in calls}) == len(calls)
    assert all(call[0] and call[1] == 'get_value' and set(call[2]) == {'key'}
               and call[2]['key'] in ('alpha', 'beta') for call in calls)
    for identity, name, arguments in calls:
        assert identity not in known_calls
        known_calls[identity] = arguments['key']
    if prompt == instruction:
        assert not calls and json.loads(text) == {'alpha': 137, 'beta': 941}
        if api == 'chat':
            original = history[1]['tool_calls']
            ids = [call['id'] for call in original]
            outputs = [(item['tool_call_id'], json.loads(item['content'])['value'])
                       for item in history[2:-1]]
        else:
            original = [item for item in history if item.get('type') == 'function_call']
            parent = response_calls[request['previous_response_id']] if request.get('previous_response_id') else None
            ids = [call[0] for call in parent] if parent is not None else [item['call_id'] for item in original]
            outputs = [(item['call_id'], json.loads(item['output'])['value']) for item in history
                       if item.get('type') == 'function_call_output']
        assert len(ids) == 2 and [identity for identity, _ in outputs] == list(reversed(ids))
        assert {known_calls[identity]: value for identity, value in outputs} == {'alpha': 137, 'beta': 941}
        correlated += 1
    else:
        keys = sorted(call[2]['key'] for call in calls)
        if prompt == 'Do not call any function. Reply with only READY.':
            assert not keys and text.strip() == 'READY'
        elif prompt.startswith('First write the sentence Checking values.'):
            assert keys == ['alpha'] and text.strip()
        elif prompt.startswith('Call get_value exactly twice in this turn:'):
            assert keys == ['alpha', 'beta']
        else:
            assert prompt == 'Call get_value once with key alpha. Do not explain.'
            assert keys == ['alpha']
        ordinary += 1
        if api == 'responses' and request['stream'] and len(calls) == 2:
            replay = [item for item in wire if item['method'] == 'GET'
                      and item['path'] == '/v1/responses/' + value['id'] + '?stream=true']
            assert len(replay) == 1 and replay[0]['status'] == 200 and replay[0]['body'] == row['body']
            replayed += 1
assert (ordinary, correlated, refused, replayed) == (48, 12, 8, 3)
for api in ('chat', 'responses'):
    for name in ('orphan', 'missing', 'duplicate', 'unknown'):
        witness = tools['witnesses'][f'{api}_refusal_{name}']
        assert witness['http_status'] == 400 and witness['executor_before'] == witness['executor_after']
closed = read(root / 'evidence/context-r69-tools-ar-closure-r1.json')
assert closed['actual_exit_code'] == 0
result = {'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'actual_exit_code': 0,
          'scope': 'Independent collected-wire review of frozen AR gate; no GPU or rerun',
          'new_checks': 71, 'baseline_controls': 5, 'ordinary_requests': ordinary,
          'distinct_reversed_result_continuations': correlated, 'refusals_before_forward': refused,
          'byte_identical_Response_journal_replays': replayed,
          'supplied_Response_seed_and_filters_retained': True,
          'complete_Chat_JSON_SSE_native_AR_counters_checked': True,
          'all_collected_hashes_verified': 15, 'models_stat_unchanged': True,
          'current_source_original_weight_AR_gate_passed': True,
          'performance_or_wider_quality_claim': False}
with (root / 'evidence/context-r69-ar-independent-review.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
