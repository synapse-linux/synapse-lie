# SPDX-License-Identifier: MIT
"""Verify the finished passed AR run receipt and all current archive members once."""
from pathlib import Path
import datetime, hashlib, json, tarfile

root = Path.cwd()
receipt = root / 'docs/development/validation/tool-transitions-ar-point-r5-2026-10-07.json'
record = json.loads(receipt.read_text())
archive = root / record['portable_raw_archive']['path']
assert record['state'] == 'PASSED_AR_COLLECTED_AND_CLOSED'
assert [record['new_checks_passed'], record['new_checks_failed'], record['new_checks_unexecuted']] == [71, 0, 0]
assert record['new_checks_passed'] + record['new_checks_failed'] + record['new_checks_unexecuted'] == 71
assert record['baseline_controls_passed'] == 5 and record['original_weight_full_gate_passed'] is True
assert record['actual_exits'] == {'controller': 0, 'supervisor': 0, 'helper': 0,
                                 'server': 0, 'collector': 0, 'whole_container_closure': 0}
assert archive.stat().st_size == record['portable_raw_archive']['bytes']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == record['portable_raw_archive']['sha256']
assert record['MTP_prepared_but_not_admitted_or_run'] is True
assert record['selected_reversed_result_Chat_JSON_SSE_passed'] is True
assert record['frozen_workload_modified'] is False
with tarfile.open(archive) as package:
    members = package.getmembers()
    assert len(members) == record['portable_raw_archive']['regular_members'] == len(record['raw_artifacts'])
    assert len({member.name for member in members}) == len(members)
    for member in members:
        assert member.isreg() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        data = package.extractfile(member).read()
        expected = record['raw_artifacts'][member.name]
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
        current = root / member.name
        assert current.is_file() and not current.is_symlink()
        assert current.stat().st_size == expected['bytes']
        assert hashlib.sha256(current.read_bytes()).hexdigest() == expected['sha256']
result = {
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'actual_exit_code': 0,
    'scope': 'Independent local postseal verification of already-collected original-weight AR gate; no rerun',
    'all_archived_and_current_members_match': True,
    'regular_members': len(members),
    'receipt_sha256': hashlib.sha256(receipt.read_bytes()).hexdigest(),
    'archive_sha256': record['portable_raw_archive']['sha256'],
    'passed_failed_unexecuted_partition': [71, 0, 0],
    'new_GPU_model_remote_build_or_Terminal_Bench_run': False}
with (root / 'evidence/context-r69-tools-ar-postseal.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
