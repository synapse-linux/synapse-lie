# SPDX-License-Identifier: MIT
"""Seal streamed artifact collection HOST evidence; preserve failed setup."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import tarfile

root = Path.cwd().resolve()
public = root/'docs/development/validation/steering-build-collection-host-2026-10-08.json'
raw = public.parent/'raw/steering-build-collection-host-2026-10-08.tar.gz'
assert not public.exists() and not raw.exists()
def read(path): return json.loads(path.read_text())
def sha(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()

sources = ['tools/strix-point-steering-build-collect.py',
    'tests/test_strix_point_steering_build_collection.py',
    'tools/strix-point-steering-build-gate.py', 'tests/fixtures/steering-build-receipts.json',
    'tools/steering-build.c', 'tests/steering_build_executor.c', 'tests/test_steering_build.c',
    'docs/development/STEERING.md', 'LICENSE', 'CMakeLists.txt']
guards = {'steering-build-collection-host-debug-r1': (14, 1),
    'steering-build-collection-host-debug-r2': (14, 0),
    'steering-build-collection-host-asan-r1': (14, 0),
    'steering-build-collection-host-debug-r3': (16, 0),
    'steering-build-collection-host-asan-r2': (16, 0),
    'steering-build-collection-ctest-debug-r1': (2, 0),
    'steering-build-collection-ctest-asan-r1': (2, 0)}
peaks = {}
for name, (count, code) in guards.items():
    directory = root/'evidence'/name
    result, plan = read(directory/'result.json'), read(directory/'plan.json')
    assert result['exit_code'] == result['child_exit_code'] == code and result['reason'] is None
    log = (directory/'command.log').read_text()
    if '-ctest-' in name:
        assert '100% tests passed out of 2' in log
        assert all(value in log for value in ('steering-bank-format-identity-lifetimes', 'steering-build-native-contract'))
    else:
        assert f'Ran {count} tests' in log
        assert ('FAILED (failures=1)' in log) if code else ('\nOK\n' in log and '\nFAILED (' not in log)
        expected = 'test-steering-build-contract' if code else 'test-steering-build'
        assert any(arg.startswith('LIE_STEERING_GATE_NATIVE_CLIENT=') and arg.endswith('/'+expected) for arg in plan['argv'])
    if '-asan-' in name:
        assert 'ASAN_OPTIONS=detect_leaks=1:abort_on_error=1' in plan['argv']
        assert 'UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1' in plan['argv']
    for path, value in result['peak_c'].items(): peaks[path] = max(peaks.get(path, -1), value)
    for sensor in plan['sensors']:
        if sensor['limit_c'] is not None: assert result['peak_c'][sensor['path']] < sensor['limit_c']
    sources += [str(p.relative_to(root)) for p in sorted(directory.iterdir()) if p.is_file()]
for folder in ('steering-build-collection-initial-failure-r1', 'steering-build-collection-before-local-recheck-r1'):
    sources += [str(p.relative_to(root)) for p in sorted((root/'evidence'/folder).iterdir()) if p.is_file()]
failure = read(root/'evidence/steering-build-collection-initial-failure-r1/failure.json')
assert failure['actual_guard_exit_code'] == failure['actual_test_process_exit_code'] == 1
assert failure['actual_selected_native_child_exit_code'] == -6
for expected in failure['sources'].values():
    assert sha(root/expected['preserved_copy']) == expected['sha256']
sources += ['evidence/seal-steering-build-collection-host-r1.py']
assert len(sources) == len(set(sources))
source_commit = '4c703b3d604c6c877d6a2214d7aee0b15a013f61'
comparison = subprocess.run(['git', 'diff', '--quiet', source_commit, '--', 'src', 'include',
    'adapters', 'cmake', 'CMakeLists.txt', 'tools/native', 'tools/steering-build.c'])
assert comparison.returncode == 0
manifest = read(root/'evidence/recall-yarn4-523776-s77-ar-20261008-r1/manifest.json')
assert sha(root/'tools/strix-point-campaign.py') == manifest['runner_sha256']
live = read(root/'evidence/recall-yarn4-523776-s77-ar-20261008-r1-live-6.json')
assert live['actual_exit_code'] == 0 and live['result']['live_exact_supervisor'] is True
inventory = {}
for name in sources:
    path = root/name
    assert path.resolve() == path and path.is_file() and not path.is_symlink()
    inventory[name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
with tarfile.open(raw, 'x:gz') as tar:
    for name in sources: tar.add(root/name, arcname=name, recursive=False)
with tarfile.open(raw, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(inventory)
    for member in tar.getmembers():
        assert member.isfile() and member.name in inventory
        payload = tar.extractfile(member).read(); expected = inventory[member.name]
        assert len(payload) == expected['bytes'] and hashlib.sha256(payload).hexdigest() == expected['sha256']
receipt = {'schema': 'synapse-lie.steering-build-collection-host.v1',
    'state': 'HOST_STREAMED_COLLECTION_AND_SYNTHETIC_NATIVE_FFN_BUILD_VERIFIED_NOT_INFERENCE',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Stable bounded artifact transfer/inventory and synthetic C17 FFN-only bank construction; SSH/SCP are mocked. No original training, original model or GPU is executed by this checking work.',
    'tests': {'final_checks_per_debug_and_native_sanitizer_mode': 16, 'focused_CTest_per_mode': 2,
        'earlier_checks_per_mode_before_complete_local_recheck': 14,
        'actual_synthetic_native_builder_children_per_final_mode': 1,
        'synthetic_training_pairs': 100, 'synthetic_FFN_rows': 400},
    'bounds': {'stream_read_bytes': 2**20, 'raw_file_bytes': 512*2**20,
        'aggregate_bytes': 640*2**20, 'tested_synthetic_stream_bytes': 65*2**20,
        'frozen_capture_model_geometry': False},
    'covered': ['Selected FFN/attention/both banks; incomplete successful captures refuse.',
        'Terminal/released and manifest-bound source state; contradictory/bool exits refuse.',
        'Duplicate/nonfinite JSON, symlink/FIFO/directory/unknown-file refusal.',
        'Stable one-descriptor streaming and byte-identical inode replacement retirement.',
        'SCP/hash/timeout partial retention and destination race without overwrite.',
        'Complete local content recheck, recorded actual remote failures and exclusive replay refusal.',
        'Serialized inventory executes on private HOST fixtures; original-model hashing is absent.'],
    'preserved_initial_failure': {'guard_exit_code': 1, 'test_process_exit_code': 1,
        'selected_native_child_exit_code': -6, 'reason': failure['reason'],
        'correction': failure['correction'], 'criteria_weakened': False},
    'actual_guard_exits': {name: code for name, (_count, code) in guards.items()},
    'local_peak_C_by_sensor_path': peaks,
    'native_runtime_sources_byte_equal_to': source_commit,
    'actual_native_source_comparison_exit_code': comparison.returncode,
    'native_fixture_binaries': {name: {'path': 'build/'+name+'/test-steering-build',
        'sha256': sha(root/'build'/name/'test-steering-build')} for name in ('context-debug', 'tool-http-asan')},
    'frozen_campaign_sha256': manifest['runner_sha256'],
    'product_Python_dependency_or_CMake_ABI_state_metrics_change': False,
    'new_build_directories': [], 'remote_collector_invoked': False,
    'original_learning_response_quality_performance_or_strong_GPU_closure_qualified': False,
    'pending': ['Actual original100-pair training collection and independent reconstruction.',
        'Qualified model/corpus/bank receipt with full strong closure and four peer releases.',
        'Original held-out responses, wider MTP/graph/correction/fault/vision/model/platform and matched cost.'],
    'separate_current_GPU_job': {'label': 'recall-yarn4-523776-s77-ar-20261008-r1',
        'manifest_sha256': '72a4728832f961b91185e233a041635d549656a8916ce14d38ee0f9dd99812a7',
        'controller_handle': 95198, 'actual_live_observation': live['result']['at_utc'],
        'qualification_pending': True},
    'roadmap': {'open_items': [2, 3, 4, 5, 6, 7], 'terminal_bench_last': True, 'full_goal_complete': False},
    'raw': {'path': str(raw.relative_to(root)), 'bytes': raw.stat().st_size, 'sha256': sha(raw),
        'regular_members': len(inventory), 'members': inventory}, 'actual_exit_code': 0}
with public.open('x') as stream: json.dump(receipt, stream, indent=2); stream.write('\n')
print(json.dumps({'state': receipt['state'], 'raw_bytes': raw.stat().st_size,
    'members': len(inventory), 'tests': receipt['tests'], 'actual_exit_code': 0}))
