# SPDX-License-Identifier: MIT
"""Seal only native HOST and mocked ownership checks; no device/model acceptance."""
from pathlib import Path
import datetime, hashlib, json, re, stat, tarfile
root=Path.cwd()
public=root/'docs/development/validation/steering-build-host-2026-10-07.json'
raw=public.parent/'raw/steering-build-host-2026-10-07.tar.gz'
assert not public.exists() and not raw.exists()
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
guards=[]
for attempt in (1,2,3):
    guards+=sorted((root/f'evidence/steering-build-host-r{attempt}').glob('*/plan.json'))
guards+=[root/'evidence/steering-build-host-r4-ASan-ctest/plan.json',root/'evidence/steering-build-host-coordination-r1/plan.json']
success=[];failures=[];peaks={}
for plan in guards:
    result=read(plan.parent/'result.json')
    assert result['exit_code']==result['child_exit_code'] and result['reason'] is None
    record={'guard':str(plan.parent.relative_to(root)),**result}
    (failures if result['exit_code'] else success).append(record)
    for path,value in result['peak_c'].items():peaks[path]=max(peaks.get(path,-100),value)
assert len(success)==10 and [f['exit_code'] for f in failures]==[2,8,8]
assert 'sign-compare' in (root/'evidence/steering-build-host-r1/Debug-2/command.log').read_text()
assert '--components' in (root/'evidence/steering-build-host-r2/Debug-3/command.log').read_text()
assert 'LeakSanitizer does not work under ptrace' in (root/'evidence/steering-build-host-r3/ASan_UBSan_LSan-3/command.log').read_text()
for p in ('evidence/steering-build-host-r3/Debug-3/command.log','evidence/steering-build-host-r4-ASan-ctest/command.log'):
    log=(root/p).read_text()
    assert '100% tests passed out of 4' in log
    for name in ('steering-build-native-contract','steering-direction-learning-lifetimes','steering-activation-collection-lifetimes','steering-bank-format-identity-lifetimes'):
        assert any(name in line and 'Passed' in line for line in log.splitlines())
coord=(root/'evidence/steering-build-host-coordination-r1/command.log').read_text()
assert 'Ran 36 tests' in coord and coord.rstrip().endswith('OK')
assert 'test_modern_build_refuses_missing_steering_artifact' in coord and 'test_modern_build_refuses_changed_steering_artifact' in coord
sources=['CMakeLists.txt','cmake/point/Build.cmake','tools/steering-build.c','tools/strix-point-campaign.py','tools/strix-point-rocm10-compile.py','tests/steering_build_executor.c','tests/test_steering_build.c','tests/test_strix_point_campaign.py','include/lie/activation_observer.h','include/lie/steering_capture.h','include/lie/steering_direction.h','include/lie/steering.h','include/lie/executor.h','include/lie/rope.h','src/steering_capture.c','src/steering_direction.c','src/steering.c','src/rope.c','adapters/gufo.cpp','adapters/gufo_activation_observer.hpp','adapters/gufo-state/activation-observer-edits.json','cmake/provider/Source.cmake','cmake/provider/Build.cmake','cmake/provider/Verify.cmake','LICENSE','third_party/gufo-source.json','third_party/gufo-LICENSE','third_party/gufo-NOTICE']
docs=['README.md','CHANGELOG.md','docs/BACKEND.md','docs/PROGRESS.md','docs/development/STEERING.md','docs/reference/ABI.md','docs/guides/USAGE.md','docs/guides/BUILD.md']
parts=[(root/p,'source/'+p) for p in sources+docs]
for attempt in (1,2,3):
    base=root/f'evidence/steering-build-host-r{attempt}'
    parts +=[(p,'host/attempt-'+str(attempt)+'/'+str(p.relative_to(base))) for p in sorted(base.rglob('*')) if p.is_file() and not p.is_symlink()]
for key in ('steering-build-host-r4-ASan-ctest','steering-build-host-coordination-r1'):
    base=root/'evidence'/key
    parts +=[(p,'host/'+key+'/'+str(p.relative_to(base))) for p in sorted(base.rglob('*')) if p.is_file() and not p.is_symlink()]
objects=[];binaries={};case_count={}
for mode,build in [('Debug','build/context-debug'),('ASan_UBSan_LSan','build/tool-http-asan')]:
    base=root/build
    log=base/'Testing/Temporary/LastTest.log';data=log.read_text()
    cases=sum(data.count(text) for text in ('Steering banks prepared:','Steering build failed:','Usage: lie-steering-build'))
    assert cases==32;case_count[mode]=cases
    fixture=Path(re.search(r'STEERING_BUILD_INPUT_FORMAT_FAILURE_PASS_NOT_INFERENCE path=(.+)',data).group(1))
    assert fixture.parent==base and fixture.name.startswith('steering-build-')
    parts.append((log,'host/'+mode+'/LastTest.log'))
    parts.append((base/'CMakeCache.txt','host/'+mode+'/CMakeCache.txt'))
    for p in sorted(fixture.rglob('*')):
        if p.is_symlink():objects.append({'mode':mode,'path':str(p.relative_to(fixture)),'type':'symlink','target':str(p.readlink())})
        elif p.is_file():parts.append((p,'fixtures/'+mode+'/'+str(p.relative_to(fixture))))
        elif stat.S_ISFIFO(p.lstat().st_mode):objects.append({'mode':mode,'path':str(p.relative_to(fixture)),'type':'fifo'})
    for name in ('test-steering-build','test-steering-build-contract','test-steering-direction','test-steering-capture','test-steering'):
        p=base/name;binaries[str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':sha(p)}
        for file in ('flags.make','link.txt'):
            p=base/'CMakeFiles'/(name+'.dir')/file
            parts.append((p,'host/'+mode+'/build/'+name+'/'+file))
    flags=(base/'CMakeFiles/test-steering-build.dir/flags.make').read_text()
    assert '-std=c17' in flags and '-Werror' in flags
    assert ('-fsanitize=address,undefined' in flags)==(mode!='Debug')
obj=root/'evidence/steering-build-fixture-objects-r1.json'
with obj.open('x') as f:json.dump(objects,f,indent=2);f.write('\n')
parts.append((obj,'fixtures/objects.json'))
for file in ('run-steering-build-host-r1.py','run-steering-build-host-r2.py','run-steering-build-host-r3.py',Path(__file__).name):
    parts.append((root/'evidence'/file,'recipe/'+file))
parts.append((root/'tools/thermal-run.py','recipe/thermal-run.py'))
assert len({name for _,name in parts})==len(parts)
inventory=[{'path':name,'bytes':path.stat().st_size,'sha256':sha(path)} for path,name in parts]
with tarfile.open(raw,'x:gz') as t:
    for path,name in parts:t.add(path,arcname=name,recursive=False)
with tarfile.open(raw,'r:gz') as t:
    assert len(t.getmembers())==len(inventory)
    for item in inventory:
        data=t.extractfile(item['path']).read()
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
receipt={'schema':'synapse-lie.steering-build-host.v1','state':'HOST_NATIVE_C17_BANK_BUILDER_PASSED_HIP_AND_ORIGINAL_CAPTURES_UNQUALIFIED','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Native synthetic CLI, borrowed activation, DS4-format loader and bound/refusal/lifetime checks; mocked optional development build coordination. No CPU/GPU original-model forward.','actual_exit_code':0,'successful_commands':success,'preserved_failed_commands':failures,'failure_corrections':['Fixture compiler sign comparison and filename buffer bound corrected, with Werror retained.','Attention-only fixture previously assumed FFN-sized observer reservation; fixed to the selected component size.','LSan fails under sandbox tracing restriction; same compiled tests pass outside it with detect_leaks=1 and no suppression.'],'CTest_count':{'Debug':4,'ASan_UBSan_LSan':4},'owned_native_CLI_executions':case_count,'mocked_coordination_checks':36,'modern_build_inventory_checks':12,'sanitizer_options':['ASAN_OPTIONS=detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1'],'sanitizer_suppressions':[],'peak_C_by_sensor':peaks,'reused_build_directories':['build/context-debug','build/tool-http-asan'],'new_build_directories':[],'source':{p:sha(root/p) for p in sources},'documents':{p:sha(root/p) for p in docs},'binaries':binaries,'raw':{'path':'raw/'+raw.name,'bytes':raw.stat().st_size,'sha256':sha(raw),'members':len(inventory),'inventory':inventory},'upstream_pin':'f783fedb9bea2ec7de941f6da4e02f4a4596b29e','production_GPU_consumer_count_prepared':7,'new_GPU_or_remote_build_admitted':False,'remaining_gates':['Coherent full HIP provider/seven-consumer build','Original-weight last-token capture and uninstrumented parity','Learned-bank quality including held-out prompts','Independent graph/correction/fault/resource behavior and matched cost'],'all_root_roadmap_items_2_through_7':'OPEN','Terminal_Bench':'LAST','goal_complete':False}
with public.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'actual_exit_code':0,'receipt':str(public),'raw_bytes':raw.stat().st_size,'raw_members':len(inventory),'raw_sha256':sha(raw),'successful_commands':len(success),'preserved_failed_commands':len(failures),'CTest_count':receipt['CTest_count'],'native_CLI_executions':case_count,'mocked_coordination_checks':36}))
