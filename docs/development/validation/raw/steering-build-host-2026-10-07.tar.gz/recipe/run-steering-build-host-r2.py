# SPDX-License-Identifier: MIT
"""Optional development orchestration; native product/tests do not require Python."""
from pathlib import Path
import json, os, subprocess, sys
root=Path(__file__).resolve().parents[1]
os.chdir(root)
out=root/'evidence/steering-build-host-r2'
out.mkdir(exist_ok=False)
records=[]
pattern='^(steering-build-native-contract|steering-direction-learning-lifetimes|steering-activation-collection-lifetimes|steering-bank-format-identity-lifetimes)$'
for mode,build in [('Debug','build/context-debug'),('ASan_UBSan_LSan','build/tool-http-asan')]:
    commands=[['cmake','-S','.','-B',build],
      ['cmake','--build',build,'--parallel','2','--target','test-steering-build','test-steering-build-contract','test-steering-direction','test-steering-capture','test-steering'],
      ['ctest','--test-dir',build,'--output-on-failure','-R',pattern]]
    for i,command in enumerate(commands,1):
        guard=out/(mode+'-'+str(i))
        env=dict(os.environ,LC_ALL='C',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        argv=[sys.executable,'-B','tools/thermal-run.py','--output',str(guard),'--timeout','600','--limit-c','98','--',*command]
        run=subprocess.run(argv,capture_output=True,text=True,env=env,check=False)
        (out/(mode+'-'+str(i)+'.stdout')).write_text(run.stdout)
        (out/(mode+'-'+str(i)+'.stderr')).write_text(run.stderr)
        record={'mode':mode,'command':command,'actual_exit_code':run.returncode}
        if (guard/'result.json').is_file():record['result']=json.loads((guard/'result.json').read_text())
        records.append(record)
        (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
        print(json.dumps(record),flush=True)
        if run.returncode:raise SystemExit(run.returncode)
