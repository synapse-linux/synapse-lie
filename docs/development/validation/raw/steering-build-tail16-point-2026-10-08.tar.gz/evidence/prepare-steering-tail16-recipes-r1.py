# SPDX-License-Identifier: MIT
"""Derive exclusive per-cohort control recipes from the qualified capture commands."""
from pathlib import Path
import hashlib,json
old='steering-build-original-pairs-point-20261007-r1';new='steering-build-multichunk-tail-point-20261008-r1'
recipes={
 'steering-build-original-fresh-r1.py':'steering-build-tail16-fresh-r1.py',
 'launch-steering-build-original-r1.py':'launch-steering-build-tail16-r1.py',
 'read-steering-build-original-r1.py':'read-steering-build-tail16-r1.py',
 'collect-steering-build-original-r1.py':'collect-steering-build-tail16-r1.py',
 'prepare-steering-build-original-closure-r1.py':'prepare-steering-build-tail16-closure-r1.py',
 'review-steering-build-original-r2.py':'review-steering-build-tail16-r1.py'}
replacements=[(old,new),('5d1893e5ce53b82c38faaf8ca238f2e7a45625e889008c8dd76c09351a71888d','786510c89b53e873f37b84c7a8c07a7bfddca16d717dd0ce6bcf39fdc576043b'),
 ('steering-build-original-peer-coordination-r1.json','steering-build-tail16-peer-coordination-r1.json'),
 ('steering-build-original-pairs-stage-r1.json','steering-build-tail16-stage-r1.json'),
 ('steering-build-original-fresh-r1.json','steering-build-tail16-fresh-r1.json'),
 ('steering-build-original-live-','steering-build-tail16-live-'),
 ('steering-build-original-closure-r1.py','steering-build-tail16-closure-r1.py'),
 ('steering-build-original-closure-r1.json','steering-build-tail16-closure-r1.json'),
 ('steering-build-original-review-r2.json','steering-build-tail16-review-r1.json')]
records=[]
for prior,target in recipes.items():
 p=Path('evidence')/prior;before=p.read_text();after=before;assert old in before
 for src,dst in replacements:after=after.replace(src,dst)
 if prior=='review-steering-build-original-r2.py':
  marker="r={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()"
  assert after.count(marker)==1
  extra='''
parent=Path(m['parent_original_capture_receipt']);assert hashlib.sha256(parent.read_bytes()).hexdigest()==m['parent_original_capture_receipt_sha256']
prior=json.loads(parent.read_text())['capture']
observed=[{k:p[k] for k in ('pair','side','physical_tokens','physical_ids_sha256')} for p in review['prompts']]
assert observed==m['expected_parent_physical_inputs']
assert observed==[{k:p[k] for k in ('pair','side','physical_tokens','physical_ids_sha256')} for p in prior['prompts']]
assert settings['prefill_chunk']==16 and sum(p['one_token_tail'] for p in review['prompts'])==m['expected_one_token_tails_from_parent']==4
assert all(p['physical_tokens']>settings['prefill_chunk'] for p in review['prompts'])
assert sum((p['physical_tokens']+15)//16 for p in review['prompts'])==m['expected_chunk_calls_from_source_loop_and_parent_counts']==37
'''
  after=after.replace(marker,extra+'\n'+marker)
 with (Path('evidence')/target).open('x') as f:f.write(after)
 records.append({'source':str(p),'source_sha256':hashlib.sha256(before.encode()).hexdigest(),'target':'evidence/'+target,'sha256':hashlib.sha256(after.encode()).hexdigest()})
with Path('evidence/steering-build-tail16-control-recipes-r1.json').open('x') as f:json.dump({'recipes':records,'actual_prepare_exit_code':0,'remote_GPU_model_or_service_operation':False},f,indent=2);f.write('\n')
print(json.dumps({'exclusive_recipes_prepared':len(records),'no_remote_operation':True}))
