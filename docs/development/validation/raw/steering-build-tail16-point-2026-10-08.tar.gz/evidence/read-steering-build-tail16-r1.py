# SPDX-License-Identifier: MIT
"""Observe exact own controller, container and GPU identities; never restart work."""
from pathlib import Path
import hashlib,json,subprocess,sys
sequence=int(sys.argv[1]);assert 1<=sequence<=99
program='''
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess
base=Path('/home/pop/workspace/synapse-lie');root=base/'steering-build-multichunk-tail-point-20261008-r1'
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='7a966774-3424-46c3-8045-34f759ea58a1'
assert hashlib.sha256((root/'runner.py').read_bytes()).hexdigest()=='e5037ecd3ac15aa18b3871e8d4961854aad4089513330bcf641dc9da87df85c2'
spec=importlib.util.spec_from_file_location('point',root/'runner.py');point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
r=json.loads((root/'result.json').read_text())
def identity(pid,start):
 try:
  if point.ticks(pid)!=start:return None
  p=Path('/proc')/str(pid)
  return {'pid':pid,'start_ticks':start,'cgroup':(p/'cgroup').read_text(),'cmdline':(p/'cmdline').read_bytes().replace(b'\\0',b' ').decode(errors='replace')}
 except FileNotFoundError:return None
supervisor=identity(r['pid'],r['start_ticks']);fds=[]
if supervisor:
 for p in (Path('/proc')/str(r['pid'])/'fd').iterdir():
  try:
   s=p.stat()
   if (s.st_dev,s.st_ino)==(66308,105946405):fds.append(int(p.name))
  except OSError:pass
child=identity(r['child_pid'],r['child_start_ticks']) if r.get('child_pid') else None
container={};init=None
if r.get('container'):
 q=subprocess.run(['docker','inspect','--format','{{json .State}}',r['container']],capture_output=True,text=True,timeout=15)
 container={'exit_code':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
 if q.returncode==0:
  state=json.loads(q.stdout);pid=state.get('Pid',0)
  if pid>0:
   try:init=identity(pid,point.ticks(pid))
   except FileNotFoundError:pass
observation=point.observe(98,gpu_observation_only=True)
owned=[]
for row in observation['dri']:
 if r.get('container') and r['container'] in row['cgroup']:
  item=identity(row['pid'],row['start_ticks'])
  if item:owned.append({**item,'devices':row['devices']})
journal=root/'steering-build/build.jsonl';events=[]
if journal.is_file():
 assert journal.stat().st_size<=8*1024*1024
 for line in journal.read_text().splitlines():
  try:events.append(json.loads(line))
  except ValueError:pass
review=root/'steering-build-review.json'
out={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':r['state'],'live_exact_supervisor':supervisor is not None,
 'supervisor':supervisor,'original_lease_fds':fds,'launcher':child,'container':container,'container_id':r.get('container'),
 'container_init_observed_identity':init,'owned_device_identities':owned,'model_attempted':r.get('model_attempted'),
 'journal_events':len(events),'last_events':events[-4:],'accepted_pairs':sum(e.get('event')=='pair_accepted' for e in events),
 'review_exists':review.is_file(),'review':json.loads(review.read_text()) if review.is_file() else None,'observation':observation,
 'remote_terminal_result':r if r.get('ended_at') else None}
if supervisor and r['state'] in ('ADMITTED','RUNNING_DISTROBOX'):assert fds
print(json.dumps(out))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
r=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':r.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':r.stdout,'stderr':r.stderr}
try:record['result']=json.loads(r.stdout)
except ValueError:pass
with Path('evidence/steering-build-tail16-live-'+str(sequence)+'.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
if 'result' in record:
 v=record['result'];short={k:v[k] for k in ('at_utc','state','live_exact_supervisor','original_lease_fds','model_attempted','journal_events','accepted_pairs','review_exists','container_init_observed_identity','owned_device_identities','last_events')}
 short['temperatures']=v['observation']['temperatures'];short['memory']=v['observation']['memory'];print(json.dumps(short))
else:print(json.dumps(record))
raise SystemExit(r.returncode)
