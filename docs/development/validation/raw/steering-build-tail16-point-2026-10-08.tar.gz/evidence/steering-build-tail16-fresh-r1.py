# SPDX-License-Identifier: MIT
"""Fresh read-only global observation for the frozen original capture window."""
from pathlib import Path
import hashlib, json, subprocess

LABEL = 'steering-build-multichunk-tail-point-20261008-r1'
local = Path('evidence')/LABEL
manifest = json.loads((local/'manifest.json').read_text())
expected = {name: hashlib.sha256((local/name).read_bytes()).hexdigest() for name in
            ('manifest.json', 'runner.py', 'steering-build-gate.py',
             'target-prompts.txt', 'contrast-prompts.txt')}
assert expected['manifest.json'] == '786510c89b53e873f37b84c7a8c07a7bfddca16d717dd0ce6bcf39fdc576043b'
program = 'LABEL='+repr(LABEL)+'\nEXPECTED='+repr(expected)+'\n' + '''
from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,stat,subprocess
base=Path('/home/pop/workspace/synapse-lie');root=base/LABEL
assert os.getuid()==1000 and base.resolve()==base and base.stat().st_uid==os.getuid()
assert root.resolve()==root and root.stat().st_uid==os.getuid()
hashes={}
for name,expected in EXPECTED.items():
 p=root/name;fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
 with os.fdopen(fd,'rb') as f:
  before=os.fstat(f.fileno());assert stat.S_ISREG(before.st_mode) and before.st_uid==os.getuid() and before.st_size<=1048576
  actual=hashlib.file_digest(f,'sha256').hexdigest();after=os.fstat(f.fileno())
  assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
 assert actual==expected;hashes[name]=actual
m=json.loads((root/'manifest.json').read_text())
spec=importlib.util.spec_from_file_location('point_readonly',root/'runner.py')
point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert boot==m['verified_boot_id']
mount=json.loads(subprocess.check_output(['findmnt','--json','--target',str(base),'--output','UUID'],text=True,timeout=15))
assert mount.get('filesystems')==[{'uuid':'720d3f3a-db4b-4287-bf9c-77cc76bcb7cb'}] and base.stat().st_dev==66308
row=point.observe(98,gpu_observation_only=True)
q=subprocess.run(['systemctl','--user','show','llama-router.service','--property=ActiveState,SubState,MainPID'],capture_output=True,text=True,timeout=15)
assert q.returncode==0;service=dict(line.split('=',1) for line in q.stdout.splitlines())
pid=int(service['MainPID']);main_ticks=point.ticks(pid) if pid else None
path=base/'campaign.lock';fd=os.open(path,os.O_RDWR|os.O_NOFOLLOW|os.O_CLOEXEC);free=False
try:
 st=os.fstat(fd);live=path.stat();assert stat.S_ISREG(st.st_mode) and st.st_uid==os.getuid()
 assert (st.st_dev,st.st_ino)==(live.st_dev,live.st_ino)==(66308,105946405)
 try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);free=True
 except BlockingIOError:pass
finally:
 if free:fcntl.flock(fd,fcntl.LOCK_UN)
 os.close(fd)
q=subprocess.run(['docker','image','inspect',m['image'],'--format','{{.Id}}'],capture_output=True,text=True,timeout=15)
image={'exit_code':q.returncode,'id':q.stdout.strip(),'stderr':q.stderr}
bundle=Path(m['bundle']);assert bundle.resolve()==bundle and bundle.stat().st_uid==os.getuid()
bundle_sha=hashlib.sha256((bundle/'BUNDLE.json').read_bytes()).hexdigest();assert bundle_sha==m['bundle_manifest_sha256']
disk=os.statvfs(bundle);listeners=[]
for tcp in ('/proc/net/tcp','/proc/net/tcp6'):
 for line in Path(tcp).read_text().splitlines()[1:]:
  fields=line.split()
  if fields[3]=='0A' and int(fields[1].rsplit(':',1)[1],16)==8000:
   listeners.append({'table':tcp,'local_address':fields[1],'uid':int(fields[7]),'inode':int(fields[9])})
clients=set(row['kernel_kfd'])|{p['pid'] for p in row['kfd']}
foreign=sorted(clients-({pid} if service['ActiveState']=='active' else set()))
hot=[t for t in row['temperatures'] if t['guarded'] and t['value_c']>=t['limit_c']]
memory=m['memory_admission'];available=row['memory']['MemAvailable'];gtt=row['gpu']['mem_info_gtt_total'];used=row['gpu']['mem_info_gtt_used']
memory_valid=all(type(v) is int for v in (available,gtt,used)) and memory['expected_peak_gtt_bytes']<=gtt and available-max(memory['expected_peak_gtt_bytes']-used,0)>=memory['min_available_ram_bytes']
prepared=not (root/'result.json').exists() and not (root/'steering-build').exists() and not (root/'steering-build-review.json').exists()
r={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'READ_ONLY_NOT_ADMITTED',
 'boot_id':boot,'filesystem_uuid':mount['filesystems'][0]['uuid'],'source_hashes':hashes,'service':service,'router_start_ticks':main_ticks,
 'original_lease':{'path':str(path),'device':st.st_dev,'inode':st.st_ino,'free_briefly':free,'released':True},
 'observation':row,'foreign_compute_clients':foreign,'guarded_hot':hot,'http8000_listeners':listeners,'pinned_image':image,
 'free_disk_bytes':disk.f_bavail*disk.f_frsize,'bundle_manifest_sha256':bundle_sha,'exclusive_job_prepared':prepared,
 'projected_memory_admission_valid':memory_valid,'GPU_build_run_or_service_mutation':False,'standing_lease_waiter_reservation':False}
print(json.dumps(r))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':run.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':run.stdout,'stderr':run.stderr}
try:record['result']=json.loads(run.stdout)
except ValueError:pass
with Path('evidence/steering-build-tail16-fresh-r1.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
if 'result' in record:
 r=record['result'];print(json.dumps({k:r[k] for k in ('state','at_utc','boot_id','service','original_lease','foreign_compute_clients','guarded_hot','http8000_listeners','pinned_image','free_disk_bytes','exclusive_job_prepared','projected_memory_admission_valid')}))
else:print(json.dumps(record))
raise SystemExit(run.returncode)
