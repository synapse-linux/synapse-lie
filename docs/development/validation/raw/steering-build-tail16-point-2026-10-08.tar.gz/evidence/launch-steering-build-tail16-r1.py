# SPDX-License-Identifier: MIT
"""Admit the frozen native steering capture through its coordinated original lease."""
from pathlib import Path
import datetime,hashlib,json,subprocess

label='steering-build-multichunk-tail-point-20261008-r1';out=Path('evidence')/label
manifest=json.loads((out/'manifest.json').read_text())
fresh=json.loads(Path('evidence/steering-build-tail16-fresh-r1.json').read_text())
assert fresh['actual_exit_code']==0;r=fresh['result']
peers=json.loads(Path('evidence/steering-build-tail16-peer-coordination-r1.json').read_text())
assert peers['specific_plan_sha256']=='786510c89b53e873f37b84c7a8c07a7bfddca16d717dd0ce6bcf39fdc576043b'
assert peers['all_four_explicit_current_161_non_use'] is True and peers['boot_identity_declared_to_all_four'] is True
assert set(item['peer'] for item in peers['peer_declarations'])=={'Point','DGX','Q2','GLM'}
assert json.loads(Path('evidence/steering-build-tail16-stage-r1.json').read_text())['actual_exit_code']==0
age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(r['at_utc'])).total_seconds()
assert 0<=age<=180,'Fresh global preflight expired; no stale admission or restart'
assert r['original_lease']['free_briefly'] and r['original_lease']['released']
assert (r['original_lease']['device'],r['original_lease']['inode'])==(66308,105946405)
assert not r['foreign_compute_clients'] and not r['guarded_hot'] and not r['http8000_listeners']
assert r['exclusive_job_prepared'] and r['projected_memory_admission_valid'] and r['boot_id']==manifest['verified_boot_id']
assert r['pinned_image']['exit_code']==0 and r['pinned_image']['id']==manifest['image']
assert r['bundle_manifest_sha256']==manifest['bundle_manifest_sha256']
for name,expected in r['source_hashes'].items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==expected
assert r['source_hashes']['manifest.json']==peers['specific_plan_sha256']
assert r['source_hashes']['runner.py']==manifest['runner_sha256']
remote='/home/pop/workspace/synapse-lie/'+label
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3','-B',remote+'/runner.py',remote]
plan={'argv':argv,'remote_root':remote,'source_commit':manifest['source_commit'],'coordinator_commit':manifest['runner_commit'],
      'runner_sha256':manifest['runner_sha256'],'manifest_sha256':r['source_hashes']['manifest.json'],
      'fresh_preflight':'evidence/steering-build-tail16-fresh-r1.json','standing_future_window':False}
with (out/'plan.json').open('x') as f:json.dump(plan,f,indent=2);f.write('\n')
with (out/'controller-stdout.log').open('x') as stdout,(out/'controller-stderr.log').open('x') as stderr:
 run=subprocess.run(argv,stdout=stdout,stderr=stderr)
record={**plan,'exit_code':run.returncode}
with (out/'controller-result.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
try:
 result=json.loads((out/'controller-stdout.log').read_text())
 with (out/'result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({k:result.get(k) for k in ('state','error','exit_code','child_exit_code','pid','start_ticks','container','lease','lease_released_at','model_attempted','cleanup_failures','steering_build_partial')}))
except (OSError,ValueError):print(json.dumps({'actual_exit_code':run.returncode,'error':'Preserved controller logs; remote result unavailable'}))
raise SystemExit(run.returncode)
