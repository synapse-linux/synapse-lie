# SPDX-License-Identifier: MIT
"""Collect bounded complete/partial original capture evidence without model hashing."""
from pathlib import Path
import hashlib,json,subprocess
LABEL='steering-build-multichunk-tail-point-20261008-r1';local=Path('evidence')/LABEL
SSH=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161']
SCP=['scp','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8']
program='''
from pathlib import Path
import datetime,hashlib,json,os,stat
root=Path('/home/pop/workspace/synapse-lie/steering-build-multichunk-tail-point-20261008-r1')
assert root.resolve()==root and root.stat().st_uid==os.getuid()==1000
r=json.loads((root/'result.json').read_text());assert r.get('ended_at') and r.get('lease_released_at')
root_names=['manifest.json','runner.py','steering-build-gate.py','target-prompts.txt','contrast-prompts.txt',
 'result.json','telemetry.jsonl','stdout.log','stderr.log','distrobox-create.log','distrobox.stdout.log','distrobox.stderr.log','steering-build-review.json']
native_names={'build.jsonl','activations.f32le','target-prompts.txt','contrast-prompts.txt','direction.ffn.f32','direction.attention.f32',
 'direction.ffn.f32.partial','direction.attention.f32.partial'}
paths=[root/name for name in root_names if (root/name).exists()]
native=root/'steering-build'
if native.exists():
 assert native.resolve()==native and native.stat().st_uid==os.getuid()
 for p in sorted(native.iterdir()):
  assert p.name in native_names;paths.append(p)
files={};total=0
for p in paths:
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
 with os.fdopen(fd,'rb') as f:
  before=os.fstat(f.fileno());assert stat.S_ISREG(before.st_mode) and before.st_uid==os.getuid() and before.st_size<=67108864
  total+=before.st_size;assert total<=134217728
  digest=hashlib.file_digest(f,'sha256').hexdigest();after=os.fstat(f.fileno());current=p.stat(follow_symlinks=False)
  fields=('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')
  assert all(getattr(before,k)==getattr(after,k)==getattr(current,k) for k in fields)
 files[p.relative_to(root).as_posix()]={'bytes':before.st_size,'sha256':digest,'device':before.st_dev,'inode':before.st_ino}
required={'manifest.json','runner.py','result.json','telemetry.jsonl'}
assert required.issubset(files)
if r['state']=='PASSED':
 assert set(root_names).issubset(files)
 assert {'steering-build/'+n for n in native_names if not n.endswith('.partial')}.issubset(files)
print(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':r['state'],'actual_supervisor_exit_code':r['exit_code'],
 'actual_child_exit_code':r.get('child_exit_code'),'model_stat_unchanged':r.get('model_stat_unchanged'),'files':files,'total_bytes':total,
 'heavyweight_model_hash_or_GPU_operation':False}))
'''
run=subprocess.run(SSH+['python3 -B -'],input=program,text=True,capture_output=True,timeout=90)
status={'label':LABEL,'schema':'synapse-lie.steering-build-collection.v1','commands':[{'argv':SSH+['python3 -B -'],'exit_code':run.returncode,'stderr':run.stderr}],
        'inventory_program_sha256':hashlib.sha256(program.encode()).hexdigest(),'exit_code':1}
if run.returncode:
 status.update(error='Remote bounded artifact inventory failed',stdout=run.stdout)
else:
 inventory=json.loads(run.stdout);status['inventory']=inventory
 for name,identity in inventory['files'].items():
  dest=local/name;dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists():
   actual=hashlib.sha256(dest.read_bytes()).hexdigest()
   if dest.is_symlink() or dest.stat().st_size!=identity['bytes'] or actual!=identity['sha256']:
    status['error']='Existing local artifact differs: '+name;break
   continue
  argv=SCP+['pop@192.168.5.161:'+str(Path('/home/pop/workspace/synapse-lie')/LABEL/name),str(dest)]
  copied=subprocess.run(argv,capture_output=True,text=True,timeout=240)
  status['commands'].append({'argv':argv,'exit_code':copied.returncode,'stderr':copied.stderr})
  if copied.returncode or not dest.is_file() or dest.is_symlink() or dest.stat().st_size!=identity['bytes'] or hashlib.sha256(dest.read_bytes()).hexdigest()!=identity['sha256']:
   status['error']='Copy/hash mismatch: '+name;break
 if not status.get('error'):status['exit_code']=0
with (local/'collection.json').open('x') as f:json.dump(status,f,indent=2);f.write('\n')
print(json.dumps({'actual_exit_code':status['exit_code'],'state':status.get('inventory',{}).get('state'),'files':len(status.get('inventory',{}).get('files',{})),
 'total_bytes':status.get('inventory',{}).get('total_bytes'),'error':status.get('error')}))
raise SystemExit(status['exit_code'])
