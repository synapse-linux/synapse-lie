# SPDX-License-Identifier: MIT
"""Stage one private frozen capture job; never acquire a lease or run a model."""
import base64, hashlib, json, subprocess
from pathlib import Path

root = Path.cwd();label = 'steering-build-multichunk-tail-point-20261008-r1'
local = root/'evidence'/label
identity = json.loads((root/'evidence/steering-build-tail16-stage-input-r1.json').read_text())
packet = {}
for name, expected in identity['files'].items():
    data = (local/name).read_bytes()
    assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
    packet[name] = base64.b64encode(data).decode()
program = 'PACKET='+repr(packet)+'\nIDENTITY='+repr(identity)+'\n'+'''
from pathlib import Path
import base64,datetime,hashlib,json,os,stat,subprocess
base=Path('/home/pop/workspace/synapse-lie')
assert os.getuid()==1000 and base.resolve()==base and base.stat().st_uid==os.getuid()
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='7a966774-3424-46c3-8045-34f759ea58a1'
mount=json.loads(subprocess.check_output(['findmnt','--json','--target',str(base),'--output','UUID'],text=True,timeout=15))
assert mount.get('filesystems')==[{'uuid':'720d3f3a-db4b-4287-bf9c-77cc76bcb7cb'}]
assert base.stat().st_dev==66308
bundle=base/'rocm10-fedora-161/bundle-modern-r70/BUNDLE.json'
assert bundle.is_file() and not bundle.is_symlink()
assert hashlib.sha256(bundle.read_bytes()).hexdigest()==IDENTITY['bundle_sha256']
assert set(PACKET)=={'manifest.json','runner.py','steering-build-gate.py','target-prompts.txt','contrast-prompts.txt'}
target=base/'steering-build-multichunk-tail-point-20261008-r1'
target.mkdir(mode=0o700,exist_ok=False)
assert target.resolve()==target and target.stat().st_uid==os.getuid()
files={}
for name, encoded in PACKET.items():
 data=base64.b64decode(encoded,validate=True);expected=IDENTITY['files'][name]
 assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
 fd=os.open(target/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
 with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
 path=target/name;st=path.stat()
 assert stat.S_ISREG(st.st_mode) and st.st_uid==os.getuid() and path.read_bytes()==data
 files[name]={'bytes':st.st_size,'sha256':hashlib.sha256(data).hexdigest()}
print(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'remote_root':str(target),
 'state':'PRIVATE_JOB_STAGED_NOT_ADMITTED','exit_code':0,'files':files,
 'GPU_model_build_service_lease_or_foreign_operation':False}))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':run.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),
        'stdout':run.stdout,'stderr':run.stderr}
try:record['result']=json.loads(run.stdout)
except ValueError:pass
with (root/'evidence/steering-build-tail16-stage-r1.json').open('x') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps({'actual_exit_code':run.returncode,'result':record.get('result'),'stderr':run.stderr}))
raise SystemExit(run.returncode)
