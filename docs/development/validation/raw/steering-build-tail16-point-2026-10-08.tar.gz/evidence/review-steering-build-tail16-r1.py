# SPDX-License-Identifier: MIT
"""Repeat the independent raw-row oracle on collected actual original artifacts."""
from pathlib import Path
import datetime,hashlib,importlib.util,json
root=Path('evidence/steering-build-multichunk-tail-point-20261008-r1').resolve();m=json.loads((root/'manifest.json').read_text())
collection=json.loads((root/'collection.json').read_text());job=json.loads((root/'result.json').read_text())
controller=json.loads((root/'controller-result.json').read_text())
assert collection['exit_code']==controller['exit_code']==job['exit_code']==job['child_exit_code']==0 and job['state']=='PASSED'
for name,expected in collection['inventory']['files'].items():
 p=root/name;assert p.is_file() and not p.is_symlink() and p.stat().st_size==expected['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==expected['sha256']
helper=root/'steering-build-gate.py';assert hashlib.sha256(helper.read_bytes()).hexdigest()==m['steering_build_gate_sha256']
spec=importlib.util.spec_from_file_location('lie_steering_build_gate',helper);gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
settings=gate.validate_settings(m['steering_build']);sources,pairs=gate.input_pair(root,settings['max_pairs']);assert sources==m['steering_build_inputs']
review=gate.validate(root/'steering-build',settings,sources,pairs,job['child_exit_code'],m['runtime_build_id'],m['runtime_source_pin'],job['steering_build_command'][2])
remote=json.loads((root/'steering-build-review.json').read_text());assert review==remote==job['steering_build_result']
assert review['pairs']==8 and review['captured_rows']==1536 and review['layers']==48 and review['width']==2560 and review['ffn_branches']==4
assert review['classification']=='ORIGINAL_ACTIVATION_CAPTURE_LEARNED_QUALITY_UNQUALIFIED' and review['model_generation_or_quality_tested'] is False and review['performance_comparison'] is False

parent=Path(m['parent_original_capture_receipt']);assert hashlib.sha256(parent.read_bytes()).hexdigest()==m['parent_original_capture_receipt_sha256']
prior=json.loads(parent.read_text())['capture']
observed=[{k:p[k] for k in ('pair','side','physical_tokens','physical_ids_sha256')} for p in review['prompts']]
assert observed==m['expected_parent_physical_inputs']
assert observed==[{k:p[k] for k in ('pair','side','physical_tokens','physical_ids_sha256')} for p in prior['prompts']]
assert settings['prefill_chunk']==16 and sum(p['one_token_tail'] for p in review['prompts'])==m['expected_one_token_tails_from_parent']==4
assert all(p['physical_tokens']>settings['prefill_chunk'] for p in review['prompts'])
assert sum((p['physical_tokens']+15)//16 for p in review['prompts'])==m['expected_chunk_calls_from_source_loop_and_parent_counts']==37

r={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'COLLECTED_ORIGINAL_RAW_ROWS_AND_NORMALIZED_BANKS_REVERIFIED','actual_exit_code':0,
 'all_19_collected_artifacts_hash_match':True,'independent_local_review_exactly_matches_remote':True,'review':review,'GPU_repeat_or_model_hash':False}
with Path('evidence/steering-build-tail16-review-r1.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps({k:review[k] for k in ('state','classification','pairs','captured_rows','layers','width','ffn_branches','banks','model_generation_or_quality_tested','performance_comparison')}))
