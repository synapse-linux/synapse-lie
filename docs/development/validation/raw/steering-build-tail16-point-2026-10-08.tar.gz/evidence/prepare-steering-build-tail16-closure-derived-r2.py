# SPDX-License-Identifier: MIT
"""Derive an additive original-capture closure check from the qualified r70 recipe."""
from pathlib import Path
import ast,hashlib,json
label='steering-build-multichunk-tail-point-20261008-r1';local=Path('evidence')/label
job=json.loads((local/'result.json').read_text());collection=json.loads((local/'collection.json').read_text())
assert collection['exit_code']==0 and job['state']=='PASSED' and job['exit_code']==job['child_exit_code']==0
assert job['ended_at'] and job['lease_released_at'] and job['model_stat_unchanged'] and not job['cleanup_failures']
live=json.loads(Path('evidence/steering-build-tail16-live-1.json').read_text())
assert live['actual_exit_code']==0
init=live['result']['container_init_observed_identity']
assert init is None,'This additive recipe is only for the explicitly missed frontend live observation'
assert type(job['container_host_pid']) is int and job['container_host_pid']>0 and type(job['container_start_ticks']) is int and job['container_start_ticks']>0
inspects=[]
for command in job['commands']:
 if command['argv'][:2]==['docker','inspect'] and command['exit_code']==0:
  try:state=json.loads(command['stdout'])
  except ValueError:continue
  if isinstance(state,dict) and state.get('Running') is True and state.get('Pid')==job['container_host_pid']:inspects.append(state)
assert inspects,'Coordinator must have actually observed the live owned init'
groups={p['cgroup'] for row in map(json.loads,(local/'telemetry.jsonl').read_text().splitlines()) for p in row['dri'] if job['container'] in p['cgroup'] and '/dev/kfd' in p['devices']}
assert len(groups)==1
init={'pid':job['container_host_pid'],'start_ticks':job['container_start_ticks'],'cgroup':next(iter(groups)),
 'pid_start_evidence':'Campaign.observe_container_identity live /proc ticks and matching recorded Docker State',
 'cgroup_evidence':'Direct actual owned GPU process telemetry for the same whole container; frontend init cgroup not separately observed',
 'frontend_live_init_observed':False,'matching_recorded_live_docker_states':len(inspects)}
assert live['result']['container_id']==job['container'] and job['container'] in init['cgroup']
observed={}
for row in map(json.loads,(local/'telemetry.jsonl').read_text().splitlines()):
 for proc in row['dri']:
  if job['container'] in proc['cgroup'] and '/dev/kfd' in proc['devices']:observed[(proc['pid'],proc['start_ticks'])]=proc
assert observed,'Original GPU process identity must actually have been observed'
source=Path('evidence/context-r70-build-closure-r1.py').read_text()
tree=ast.parse(source);node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='program' for t in n.targets))
body=node.value.right.value;assert isinstance(body,str) and "runner=base/'context-r70-build-r1'/'runner.py'" in body
body=body.replace('context-r70-build-r1',label).replace('FRESH_SUCCESSFUL_BUILD_CLOSURE_NO_STANDING_RESERVATION','FRESH_ORIGINAL_CAPTURE_CLOSURE_NO_STANDING_RESERVATION').replace('UNVERIFIED_BUILD_CLOSURE','UNVERIFIED_ORIGINAL_CAPTURE_CLOSURE')
marker="valid=r['owned_supervisor_identity_absent']"
assert body.count(marker)==1
add='''
r['owned_launcher_identity_absent']=not owned_alive(JOB['child_pid'],JOB['child_start_ticks'])
r['observed_original_GPU_identities']=[dict(proc,identity_absent=not owned_alive(proc['pid'],proc['start_ticks'])) for proc in OWNED_GPU]
after=[]
for before in JOB['models_before']:
 st_model=Path(before['path']).stat()
 after.append({'path':before['path'],'bytes':st_model.st_size,'device':st_model.st_dev,'inode':st_model.st_ino,'mtime_ns':st_model.st_mtime_ns,'ctime_ns':st_model.st_ctime_ns})
r['models_reobserved_after_collection']=after;r['all_four_model_stats_unchanged']=after==JOB['models_before']==JOB['models_after']
checked=[]
for name,expected in FILES.items():
 p=base/'steering-build-multichunk-tail-point-20261008-r1'/name
 assert p.is_file() and not p.is_symlink() and p.stat().st_uid==os.getuid() and p.stat().st_size==expected['bytes']
 with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 assert digest==expected['sha256'];checked.append(name)
r['collected_artifacts_reverified']=checked
'''
body=body.replace(marker,add+'\n'+marker)
marker2="r['state']='FRESH_ORIGINAL_CAPTURE_CLOSURE_NO_STANDING_RESERVATION'"
assert body.count(marker2)==1
body=body.replace(marker2,"valid=valid and r['owned_launcher_identity_absent'] and r['all_four_model_stats_unchanged'] and all(p['identity_absent'] for p in r['observed_original_GPU_identities'])\n"+marker2)
program='INIT='+repr(init)+'\nJOB='+repr(job)+'\nEXPECTED_RUNNER='+repr(job['runner_sha256'])+'\nOWNED_GPU='+repr(list(observed.values()))+'\nFILES='+repr(collection['inventory']['files'])+'\n'+body
wrapper='''# SPDX-License-Identifier: MIT
"""Fresh strong closure of exact original capture identities and collected evidence."""
from pathlib import Path
import hashlib,json,subprocess
program=PROGRAM
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=60)
record={'argv':argv,'actual_exit_code':run.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':run.stdout,'stderr':run.stderr}
try:record['result']=json.loads(run.stdout)
except ValueError:pass
with Path('evidence/steering-build-tail16-closure-r1.json').open('x') as f:json.dump(record,f,indent=2);f.write('\\n')
if 'result' in record:
 r=record['result'];print(json.dumps({k:r[k] for k in ('state','at_utc','boot_id','service','original_lease','foreign_compute_clients','guarded_hot','http8000_listeners','owned_supervisor_identity_absent','owned_launcher_identity_absent','owned_container_init_identity_absent','observed_original_GPU_identities','all_four_model_stats_unchanged','collected_artifacts_reverified')}))
else:print(json.dumps(record))
raise SystemExit(run.returncode)
'''.replace('program=PROGRAM','program='+repr(program))
with Path('evidence/steering-build-tail16-closure-r1.py').open('x') as f:f.write(wrapper)
print(json.dumps({'recipe_prepared':True,'original_GPU_identities':len(observed),'required_artifacts':len(collection['inventory']['files']),'no_remote_operation':True,'qualified_template_sha256':hashlib.sha256(source.encode()).hexdigest(),'new_recipe_sha256':hashlib.sha256(wrapper.encode()).hexdigest()}))
