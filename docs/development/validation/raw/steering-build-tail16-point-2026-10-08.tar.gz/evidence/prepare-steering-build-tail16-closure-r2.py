# SPDX-License-Identifier: MIT
"""Preserve missing frontend live-init observation; use actual coordinator evidence."""
from pathlib import Path
import hashlib,json
path=Path('evidence/prepare-steering-build-tail16-closure-r1.py');before=path.read_text()
old="init=live['result']['container_init_observed_identity'];assert init['pid']==job['container_host_pid'] and init['start_ticks']==job['container_start_ticks']"
assert before.count(old)==1
new='''init=live['result']['container_init_observed_identity']
assert init is None,'This additive recipe is only for the explicitly missed frontend live observation'
assert type(job['container_host_pid']) is int and job['container_host_pid']>0 and type(job['container_start_ticks']) is int and job['container_start_ticks']>0
inspects=[]
for command in job['commands']:
 if command['argv'][:2]==['docker','inspect'] and command['exit_code']==0:
  try:state=json.loads(command['stdout'])
  except ValueError:continue
  if isinstance(state,dict) and state.get('Running') is True and state.get('Pid')==job['container_host_pid']:inspects.append(state)
assert inspects,'Coordinator must have actually observed the live owned init'
groups={p['cgroup'] for row in map(json.loads,(local/'telemetry.jsonl').read_text().splitlines()) for p in row['dri'] if job['container'] in p['cgroup'] and '/dev/kfd' in p['devices']}
assert len(groups)==1
init={'pid':job['container_host_pid'],'start_ticks':job['container_start_ticks'],'cgroup':next(iter(groups)),
 'pid_start_evidence':'Campaign.observe_container_identity live /proc ticks and matching recorded Docker State',
 'cgroup_evidence':'Direct actual owned GPU process telemetry for the same whole container; frontend init cgroup not separately observed',
 'frontend_live_init_observed':False,'matching_recorded_live_docker_states':len(inspects)}'''
after=before.replace(old,new)
derived=Path('evidence/prepare-steering-build-tail16-closure-derived-r2.py')
with derived.open('x') as f:f.write(after)
record={'source':str(path),'source_sha256':hashlib.sha256(before.encode()).hexdigest(),'derived_source':str(derived),'derived_sha256':hashlib.sha256(after.encode()).hexdigest(),
 'original_recipe_not_executed':True,'frontend_live_observation_missing_preserved':True,'all_other_closure_conditions_unchanged':True,'no_GPU_repeat':True}
with Path('evidence/steering-build-tail16-closure-preparation-r2.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
exec(compile(after,str(derived),'exec'),{'__name__':'__main__'})
