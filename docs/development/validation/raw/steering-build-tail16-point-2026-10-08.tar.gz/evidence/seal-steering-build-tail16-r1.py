# SPDX-License-Identifier: MIT
"""Seal multi-chunk proof, referring to byte-identical qualified parent payloads."""
from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os,stat,subprocess,tarfile
root=Path.cwd();label='steering-build-multichunk-tail-point-20261008-r1';job=root/'evidence'/label
read=lambda p:json.loads((root/p).read_text());m=read('evidence/'+label+'/manifest.json');r=read('evidence/'+label+'/result.json')
review=read('evidence/steering-build-tail16-review-r1.json');col=read('evidence/'+label+'/collection.json');close=read('evidence/steering-build-tail16-closure-r1.json');c=close['result']
assert r['state']=='PASSED' and r['exit_code']==r['child_exit_code']==review['actual_exit_code']==col['exit_code']==close['actual_exit_code']==0
assert read('evidence/'+label+'/controller-result.json')['exit_code']==0 and r['model_stat_unchanged'] and not r['cleanup_failures']
assert c['state']=='FRESH_ORIGINAL_CAPTURE_CLOSURE_NO_STANDING_RESERVATION' and c['owned_supervisor_identity_absent'] and c['owned_launcher_identity_absent'] and c['owned_container_init_identity_absent']
assert c['recorded_container_cgroup']['absent'] and all(not s['members'] and not s['unreadable'] for s in c['complete_cgroup_process_scans'])
assert c['all_four_model_stats_unchanged'] and all(p['identity_absent'] for p in c['observed_original_GPU_identities'])
assert c['original_lease']['free_briefly'] and c['original_lease']['released'] and c['service']['ActiveState']=='active' and not c['foreign_compute_clients'] and not c['guarded_hot'] and not c['http8000_listeners']
peer=read('evidence/steering-build-tail16-peer-coordination-r1.json');assert peer['all_four_explicit_current_161_non_use'] and peer['boot_identity_declared_to_all_four']
notes=read('evidence/steering-build-tail16-peer-release-r1.json');assert len(notes['notifications'])==4 and all(x['result'].get('isError') is False for x in notes['notifications'])
q=review['review'];assert q==r['steering_build_result']==read('evidence/'+label+'/steering-build-review.json')
assert q['pairs']==8 and q['captured_rows']==1536 and q['settings']['prefill_chunk']==16 and sum(p['one_token_tail'] for p in q['prompts'])==4
assert sum(p['physical_tokens'] for p in q['prompts'])==500 and all(p['physical_tokens']>16 for p in q['prompts'])
parent_path=root/m['parent_original_capture_receipt'];assert hashlib.sha256(parent_path.read_bytes()).hexdigest()==m['parent_original_capture_receipt_sha256']
parent=json.loads(parent_path.read_text());parent_archive=root/parent['raw']['path']
assert parent_archive.stat().st_size==parent['raw']['bytes'] and hashlib.sha256(parent_archive.read_bytes()).hexdigest()==parent['raw']['sha256']
prior=parent['capture'];assert q['raw']==prior['raw'] and all(q['banks'][n]['sha256']==prior['banks'][n]['sha256'] for n in q['banks'])
inputs=lambda ps:[{k:p[k] for k in ('pair','side','physical_tokens','physical_ids_sha256')} for p in ps]
assert inputs(q['prompts'])==inputs(prior['prompts'])==m['expected_parent_physical_inputs']
shared={};oldlabel=parent['job_label']
with tarfile.open(parent_archive,'r:gz') as tar:
 for filename in ('activations.f32le','direction.ffn.f32','direction.attention.f32'):
  name='evidence/'+label+'/steering-build/'+filename;prior_name='evidence/'+oldlabel+'/steering-build/'+filename
  data=tar.extractfile(prior_name).read();current=root/name;assert data==current.read_bytes()
  expected=parent['raw']['members'][prior_name];assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
  shared[name]={**expected,'archive':parent['raw']['path'],'archive_sha256':parent['raw']['sha256'],'member':prior_name,'deduplicated_byte_identical_payload':True}
members={'evidence/'+label+'/'+n for n in col['inventory']['files']}
members.update('evidence/'+label+'/'+n for n in ('plan.json','controller-result.json','controller-stdout.log','controller-stderr.log','collection.json'))
names=['steering-build-tail16-prepared-r1.json','steering-build-tail16-stage-input-r1.json','stage-steering-build-tail16-r1.py','steering-build-tail16-stage-r1.json',
 'steering-build-tail16-proposal-deliveries-r1.json','steering-build-tail16-peer-raw-r1.json','steering-build-tail16-peer-coordination-r1.json','steering-build-tail16-peer-release-r1.json',
 'prepare-steering-tail16-recipes-r1.py','steering-build-tail16-control-recipes-r1.json','steering-build-tail16-fresh-r1.py','steering-build-tail16-fresh-r1.json',
 'launch-steering-build-tail16-r1.py','read-steering-build-tail16-r1.py','steering-build-tail16-live-1.json','collect-steering-build-tail16-r1.py',
 'prepare-steering-build-tail16-closure-r1.py','prepare-steering-build-tail16-closure-r2.py','prepare-steering-build-tail16-closure-derived-r2.py','steering-build-tail16-closure-preparation-r2.json',
 'steering-build-tail16-closure-r1.py','steering-build-tail16-closure-r1.json','review-steering-build-tail16-r1.py','steering-build-tail16-review-r1.json','seal-steering-build-tail16-r1.py','context-r70-build-closure-r1.py']
members.update('evidence/'+n for n in names)
tracked=['tools/steering-build.c','src/steering_capture.c','src/steering_direction.c','include/lie/activation_observer.h','include/lie/steering_capture.h','include/lie/steering_direction.h','adapters/gufo_activation_observer.hpp','adapters/gufo-state/activation-observer-edits.json']
for name in tracked:
 assert (root/name).read_bytes()==subprocess.run(['git','show',m['source_commit']+':'+name],capture_output=True,check=True).stdout
members.update(tracked);members.update(('tools/strix-point-campaign.py','tools/strix-point-steering-build-gate.py',m['parent_original_capture_receipt']))
members-=set(shared);identities={};total=0
for name in sorted(members):
 p=root/name;st=p.stat(follow_symlinks=False);assert p.resolve()==p and stat.S_ISREG(st.st_mode) and st.st_uid==os.getuid() and st.st_size<=67108864
 data=p.read_bytes();identities[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};total+=len(data)
archive=root/'docs/development/validation/raw/steering-build-tail16-point-2026-10-08.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=6,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
 for name in sorted(members):
  p=root/name;info=tar.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with p.open('rb') as f:tar.addfile(info,f)
with tarfile.open(archive,'r:gz') as tar:
 entries=tar.getmembers();assert len(entries)==len(identities) and {p.name for p in entries}==set(identities)
 for entry in entries:
  assert entry.isfile();data=tar.extractfile(entry).read();expected=identities[entry.name]
  assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
  assert (root/entry.name).read_bytes()==data
rows=list(map(json.loads,(job/'telemetry.jsonl').read_text().splitlines()))
peaks={n:max(t['value_c'] for row in rows for t in row['temperatures'] if t['name']==n) for n in ('k10temp','amdgpu','nvme')}
assert peaks['k10temp']<98 and peaks['nvme']<85
capture_events=list(map(json.loads,(job/'steering-build/build.jsonl').read_text().splitlines()))
assert capture_events[-1]['event']=='complete' and capture_events[-1]['exit_code']==0
receipt={'schema':'synapse-lie.original-steering-capture-qualification.v1','at_utc':datetime.now(timezone.utc).isoformat(),
 'state':'ORIGINAL_MULTI_CHUNK_AND_ONE_TOKEN_TAIL_CAPTURES_VERIFIED_COLLECTED_STRONGLY_CLOSED_QUALITY_UNQUALIFIED',
 'target':'pop@192.168.5.161','platform':'strix-point','job_label':label,'manifest_sha256':hashlib.sha256((job/'manifest.json').read_bytes()).hexdigest(),
 'runtime_source_commit':m['source_commit'],'coordinator_commit':m['runner_commit'],'root_checkpoint':m['root_checkpoint'],'runtime_build_id':m['runtime_build_id'],
 'upstream_source_pin':m['runtime_source_pin'],'bundle_manifest_sha256':m['bundle_manifest_sha256'],'native_builder_sha256':m['artifacts']['runtime/bin/lie-steering-build'],
 'actual_exits':{'controller':0,'supervisor':0,'native_builder':0,'collector':col['exit_code'],'independent_local_review':review['actual_exit_code'],'strong_closure':close['actual_exit_code']},
 'capture':q,'physical_prompt_tokens':{'total':500,'minimum':28,'maximum':35,'completed_prompt_prefills':16,'one_token_tails_observed':4,'all_prompts_require_multiple_chunks':True,
 'chunk_calls_computed_from_successful_counts_and_frozen_native_loop':37,'individual_chunk_call_timing_or_trace_not_recorded':True},
 'parent_original_capture_receipt':m['parent_original_capture_receipt'],'parent_original_capture_receipt_sha256':m['parent_original_capture_receipt_sha256'],
 'cross_cohort':{'all_physical_prompt_IDs_equal':True,'complete_raw_activation_bytes_equal':True,'both_complete_bank_bytes_equal':True,'scope':'These16 short original prompts only, chunk256 versus16; no other source/model/long-context or general graph parity claim.'},
 'thermal':{'policy':m['thermal_policy'],'samples':len(rows),'peaks_c':peaks,'GPU_temperature_is_observation_only':True},
 'resources':{'max_observed_gtt_bytes':max(row['gpu']['mem_info_gtt_used'] for row in rows),'min_observed_available_ram_bytes':min(row['memory']['MemAvailable'] for row in rows),
 'requested_owned_host_peak_bytes':capture_events[-1]['owned_host_peak_bytes'],'requested_owned_host_scope_excludes_executor_allocator_crypto_stdio':True,'OS_threads_observed':27,'thread_role_census_or_speedup_proof':False},
 'ownership':{'all_four_specific_current_non_use':True,'fresh_global_at_utc':read('evidence/steering-build-tail16-fresh-r1.json')['result']['at_utc'],'boot_id':c['boot_id'],
 'filesystem_uuid':'720d3f3a-db4b-4287-bf9c-77cc76bcb7cb','original_lease':c['original_lease'],'actual_release_at_utc':r['lease_released_at'],'strong_closure_at_utc':c['at_utc'],
 'supervisor':{'pid':r['pid'],'start_ticks':r['start_ticks']},'launcher':{'pid':r['child_pid'],'start_ticks':r['child_start_ticks']},
 'container_init':{'pid':r['container_host_pid'],'start_ticks':r['container_start_ticks'],'actually_observed_by_coordinator':True,'matching_recorded_live_docker_states':57,'separate_frontend_live_observation':False},
 'whole_cgroup':c['recorded_container_cgroup'],'cgroup_source':'Direct original GPU telemetry; separate frontend init cgroup observation absent.',
 'original_GPU_identities':c['observed_original_GPU_identities'],'container':r['container'],'two_complete_cgroup_scans':c['complete_cgroup_process_scans'],'restored_router':c['service'],
 'four_model_stats_unchanged':True,'all_four_verified_release_notifications':True,'current_root_own_all_hosts':'NONE','standing_reservation_or_future_grant':False},
 'retained_observation_limit':'Frontend status first read after process retirement. No invented live init/cgroup witness; actual supervisor PID/start +57 saved Docker states and original GPU cgroup used for unchanged strong closure conditions.',
 'qualification_limits':['Only the sixteen28..35-token original prompts; capacity8192/chunk16/native.','Held-out learned response quality, generation parity, MTP correction/fault/vision and matched cost remain open.','No inference reactive speedup, long-context fit/quality, other models/platforms or performance comparison qualified.'],
 'roadmap':{'open_items':[2,3,4,5,6,7],'terminal_bench_last':True,'full_goal_complete':False},
 'raw':{'path':str(archive.relative_to(root)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'regular_members':len(identities),
 'uncompressed_bytes':total,'members':identities,'shared_artifacts':shared,'shared_artifacts_bytes':sum(x['bytes'] for x in shared.values()),'all_archived_shared_and_current_members_verified':True,
 'parent_archive_retained_not_rewritten':True,'no_duplicate_raw_or_bank_payloads':True},'GPU_repeat_heavyweight_model_hash_conversion_tuning_install_or_publication':False}
out=root/'docs/development/validation/steering-build-tail16-point-2026-10-08.json'
with out.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'receipt':str(out.relative_to(root)),'state':receipt['state'],'raw_bytes':receipt['raw']['bytes'],'raw_members':len(identities),'deduplicated_payload_bytes':receipt['raw']['shared_artifacts_bytes'],'all_archived_shared_current_members_verified':True}))
