# SPDX-License-Identifier: MIT
from pathlib import Path
import ast,datetime,hashlib,json
here=Path(__file__).resolve().parent
old=here.parent/'halo-r70-build-20261008-r1'
label=here.name
old_labels={'halo-r70-build-20261008-r1':label,'halo-r70-provider-r1':'halo-develop-q2-provider-r1','halo-r70-reference-r1':'halo-develop-q2-reference-r1','halo-r70-linked-r1':'halo-develop-q2-linked-r1'}
for name in ('runner.py','build.py','stage.py','fresh.py','launch.py','observe.py','collect-close.py'):
 text=(old/name).read_text()
 for a,b in old_labels.items():text=text.replace(a,b)
 if name=='build.py':
  needle="'-DLIE_LONG_CONTEXT_WMMA=ON', '-P', 'cmake/provider/Build.cmake'"
  assert text.count(needle)==1
  text=text.replace(needle,"'-DLIE_LONG_CONTEXT_WMMA=ON', '-DLIE_QWEN_Q2_FORMATS=ON', '-P', 'cmake/provider/Build.cmake'")
  needle="'-DLIE_LONG_CONTEXT_WMMA=ON', '-DLIE_BUILD_ID='+linked,"
  assert text.count(needle)==1
  text=text.replace(needle,"'-DLIE_LONG_CONTEXT_WMMA=ON', '-DLIE_QWEN_Q2_FORMATS=ON', '-DLIE_BUILD_ID='+linked,")
 if name=='runner.py':
  assert text.count("for row in previous['models']:")==1
  text=text.replace("for row in previous['models']:","for row in previous['models']+[previous['glm_model']]:")
  text=text.replace("return len(previous['models'])","return len(previous['models'])+1")
 if name=='fresh.py':
  assert text.count("for row in release['models']:")==1
  text=text.replace("for row in release['models']:","for row in release['models']+[release['glm_model']]:")
 if name=='collect-close.py':
  assert text.count("for row in previous['models']:")==1
  text=text.replace("for row in previous['models']:","for row in previous['models']+[previous['glm_model']]:")
  needle="assert receipt['c17_sampling']==(label=='halo-develop-q2-provider-r1')"
  assert text.count(needle)==1
  text=text.replace(needle,needle+"\n  assert receipt['qwen_q2_formats'] is True\n  assert receipt['qwen_q2_edits_sha256']==sha(source/'adapters/gufo-state/qwen-q2-format-edits.json')\n  assert receipt['qwen_q2_patch_sha256']==sha(source/'patches/gufo-q2.patch')")
 (here/name).open('x').write(text)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
discovery=json.loads((here/'discovery-r1.json').read_text())
plan=json.loads((old/'manifest.json').read_text())
assert discovery['boot_id']==plan['boot_id'] and discovery['filesystem_uuid']==plan['filesystem_uuid']
assert discovery['previous_release']['actual_exit_code']==0 and discovery['previous_release']['gpu_reserved'] is False
assert not discovery['kfd_clients']
plan.update(label=label,source_commit='9e95e4c49e1aa71e71f50003760ac14d96a3232e',production_runtime_base='f902ad45',
 previous_release_path=discovery['registry_last_event']['receipt'],previous_release_sha256=discovery['registry_last_event']['receipt_sha256'],
 previous_registry_event=discovery['registry_last_event'],leases=[{k:row[k] for k in ('path','device','inode')} for row in discovery['lease_path_identities_metadata_only']],
 Q2_numeric_provider_or_DS4_walk_ported=True,
 scope='one gfx1151 native compiler child, current original Q2/IQ2 formats ON in both C17-sampling ON provider and matched sampler OFF control, seven linked consumers; original five leases, frozen source collection/hash, independent whole-group closure, all reference+GLM model stats unchanged and four-peer releases; no future grant')
plan['inputs']={name:{'bytes':(here/name).stat().st_size,'sha256':sha(here/name)} for name in ('source.tar.gz','source-inventory.json','runner.py','build.py')}
(here/'manifest.json').open('x').write(json.dumps(plan,indent=2)+'\n')
digest=sha(here/'manifest.json')
for name in ('observe.py','collect-close.py'):
 p=here/name;s=p.read_text();old_hash='ab7184848f6a512ed72f290ab44429002f10bbbef28d0447deaba9c1becd4d25';assert s.count(old_hash)==1
 p.write_text(s.replace(old_hash,digest))
for name in ('runner.py','build.py','stage.py','fresh.py','launch.py','observe.py','collect-close.py'):
 ast.parse((here/name).read_text(),filename=name)
record={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':digest,'state':'LOCAL_EXACT_PROPOSAL_NOT_STAGED_OR_ADMITTED','AST_checks_actual_exit_code':0,'user_authorization':'adess puoi usare la .157 per i test','scripts':{name:sha(here/name) for name in ('runner.py','build.py','stage.py','fresh.py','launch.py','observe.py','collect-close.py')}}
(here/'manifest-preparation.json').open('x').write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
