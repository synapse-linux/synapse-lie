# SPDX-License-Identifier: MIT
"""Upload own frozen sources only. Does not acquire leases or launch compilers."""
from pathlib import Path
import datetime
import json
import subprocess

HERE=Path(__file__).resolve().parent
HOST='paperboy@192.168.5.157'
REMOTE='/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run/'+HERE.name
commands=[]


def record(row):
    commands.append(row)
    (HERE/'stage-result.json').write_text(json.dumps({
        'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'state':'SOURCE_STAGING_ONLY_NOT_BUILD_OR_ADMISSION','commands':commands,
        'GPU_or_model_or_lease_operation':False,'remote_root':REMOTE},indent=2)+'\n')


program='''
from pathlib import Path
import json,os
assert os.getuid()==1000
base=Path('/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run')
assert base.resolve()==base and base.stat().st_uid==1000
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='be3e89fd-955b-47a4-a385-11c3ad98bb78'
root=base/'halo-develop-q2-build-20261008-r1'
root.mkdir(mode=0o700)
print(json.dumps({'created_own_source_staging_directory':str(root),'lease_or_build_or_GPU_operation':False}))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',HOST,'python3 -B -']
r=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=30)
record({'argv':argv,'actual_exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
assert r.returncode==0
for name in ['source.tar.gz','source-inventory.json','runner.py','build.py','manifest.json']:
    argv=['scp','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',
          str(HERE/name),HOST+':'+REMOTE+'/'+name]
    r=subprocess.run(argv,text=True,capture_output=True,timeout=120)
    record({'argv':argv,'actual_exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    assert r.returncode==0
print(json.dumps({'state':'SOURCE_STAGED_NOT_ADMITTED','actual_exit_codes':[r['actual_exit_code'] for r in commands],
                  'GPU_or_model_or_lease_or_build_operation':False}))
