# SPDX-License-Identifier: MIT
"""Inner compiler child. No model load, numerical execution or installation."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'source'
assert os.environ.get('LIE_HALO_LEASED_BUILD') == 'admitted'
assert HERE.resolve() == HERE and SOURCE.resolve() == SOURCE
result = {'state': 'RUNNING_COMPILER_NOT_INFERENCE', 'commands': [],
          'gpu_kernel_or_model_execution_requested': False, 'installation': False,
          'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save():
    (HERE/'compiler-result.json').write_text(json.dumps(result, indent=2)+'\n')


def run(name, argv):
    row = {'name': name, 'argv': argv,
           'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    result['commands'].append(row)
    save()
    with (HERE/(name+'.log')).open('xb') as log:
        r = subprocess.run(argv, cwd=SOURCE, stdout=log, stderr=subprocess.STDOUT)
    row['actual_exit_code'] = r.returncode
    row['ended_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    if r.returncode:
        raise RuntimeError(name+' failed: '+str(r.returncode))


try:
    inventory = json.loads((HERE/'source-inventory.json').read_text())
    for name, row in inventory.items():
        assert sha(SOURCE/name) == row['sha256']
    libraries = 'halo-develop-q2-provider-r1'
    reference = 'halo-develop-q2-reference-r1'
    linked = 'halo-develop-q2-linked-r1'
    for label, sampling in [(libraries, 'ON'), (reference, 'OFF')]:
        run(label, ['cmake', '-DLABEL='+label, '-DLIE_HIP_ARCHITECTURE=gfx1151',
                    '-DLIE_GUFO_STATE_ACCESS=ON', '-DLIE_DS4_RUNTIME_CACHE=ON',
                    '-DLIE_C17_SAMPLING='+sampling, '-DLIE_VISION_WEIGHT_DECODE=ON',
                    '-DLIE_DIRECTIONAL_STEERING=ON', '-DLIE_ATTENTION_DISPATCH_STATS=ON',
                    '-DLIE_LONG_CONTEXT_WMMA=ON', '-DLIE_QWEN_Q2_FORMATS=ON', '-P', 'cmake/provider/Build.cmake'])
    run('configure-products', ['cmake', '-S', '.', '-B', 'build/'+linked, '-G', 'Ninja',
         '-DCMAKE_BUILD_TYPE=Release', '-DBUILD_TESTING=OFF', '-DLIE_GUFO_RUNTIME=ON',
         '-DLIE_Q2_QUALIFICATION_ONLY=OFF', '-DLIE_LEGACY_PYTHON_TESTS=OFF',
         '-DCMAKE_DISABLE_FIND_PACKAGE_Python3=ON', '-DLIE_GUFO_STATE_ACCESS=ON',
         '-DLIE_DS4_RUNTIME_CACHE=ON', '-DLIE_HIP_ARCHITECTURE=gfx1151',
         '-DLIE_C17_SAMPLING=ON', '-DLIE_ATTENTION_DISPATCH_STATS=ON',
         '-DLIE_LONG_CONTEXT_WMMA=ON', '-DLIE_QWEN_Q2_FORMATS=ON', '-DLIE_BUILD_ID='+linked,
         '-DGUFO_SOURCE='+str(SOURCE/'.deps'/('gufo-state-access-'+libraries)),
         '-DGUFO_BUILD='+str(SOURCE/'build'/libraries),
         '-DGUFO_REFERENCE_BUILD='+str(SOURCE/'build'/reference)])
    binaries = ['synapse-lie-server', 'synapse-lie-bench',
                'synapse-lie-bench-gufo-reference', 'lie-hip-probe',
                'lie-sampling-capture', 'lie-attention-qualify', 'lie-steering-build']
    run('link-products', ['cmake', '--build', 'build/'+linked, '--parallel', '1',
                         '--target', *binaries])
    result['binaries'] = {name: {'bytes': (SOURCE/'build'/linked/name).stat().st_size,
                                'sha256': sha(SOURCE/'build'/linked/name)} for name in binaries}
    for name, row in inventory.items():
        assert sha(SOURCE/name) == row['sha256']
    result['input_source_files_unchanged'] = len(inventory)
    result['state'] = 'BUILT_NOT_GPU_OR_NUMERICALLY_QUALIFIED'
    result['actual_exit_code'] = 0
except BaseException as error:
    result['state'] = 'COMPILER_FAILED'
    result['error'] = repr(error)
    result['actual_exit_code'] = 1
    raise
finally:
    result['ended_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
