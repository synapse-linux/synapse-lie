# SPDX-License-Identifier: MIT
"""Independently collect compiler evidence and verify full original-window closure."""
from pathlib import Path
import base64
import hashlib
import json
import subprocess

HERE=Path(__file__).resolve().parent
assert json.loads((HERE/'controller-result.json').read_text())['actual_exit_code']==0
program=r'''
from pathlib import Path
import base64,datetime,fcntl,hashlib,json,os,stat
root=Path('/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run/halo-develop-q2-build-20261008-r1')
assert os.getuid()==1000 and root.resolve()==root
def sha(p):
 assert p.resolve()==p and not p.is_symlink()
 before=p.stat();assert stat.S_ISREG(before.st_mode) and before.st_uid==1000
 with p.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 after=p.stat();assert all(getattr(before,k)==getattr(after,k) for k in ['st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns'])
 return digest
expected='2e08ae7116e33a4a20cec19ddf0e7d421756d338c2651837d048430c868147cb'
assert sha(root/'manifest.json')==expected
plan=json.loads((root/'manifest.json').read_text())
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==plan['boot_id']
release=json.loads((root/'release.json').read_text());compiler=json.loads((root/'compiler-result.json').read_text())
assert release['state']=='COMPILE_COMPLETE_NOT_GPU_QUALIFIED' and release['actual_exit_code']==0 and not release['gpu_reserved']
assert compiler['state']=='BUILT_NOT_GPU_OR_NUMERICALLY_QUALIFIED' and compiler['actual_exit_code']==0
assert len(compiler['commands'])==4 and all(r['actual_exit_code']==0 for r in compiler['commands'])
assert release['commands'][0]['exit_code']==0
registry=root.parent/'gpu-coordination/epochs'/plan['boot_id']/'runs.jsonl'
last=json.loads(registry.read_text().splitlines()[-1]);digest=sha(root/'release.json')
assert last['event']=='window_release' and last['label']==plan['label'] and last['receipt_sha256']==digest
identities=[release['supervisor'],*release['commands']]
groups={release['supervisor']['group'],*[r['pid'] for r in release['commands']]}
scans=[]
for pass_index in range(2):
 matches=[];group_matches=[];scanned=0
 for directory in Path('/proc').glob('[0-9]*'):
  try:fields=(directory/'stat').read_text().rsplit(') ',1)[1].split()
  except FileNotFoundError:continue
  scanned+=1;pid=int(directory.name);start=int(fields[19]);group=int(fields[2])
  if any(pid==r['pid'] and start==r['start_ticks'] for r in identities):matches.append({'pid':pid,'start_ticks':start})
  if group in groups:group_matches.append({'pid':pid,'group':group,'start_ticks':start})
 scans.append({'pass':pass_index,'processes_scanned':scanned,'exact_identity_matches':matches,'original_group_matches':group_matches})
 assert not matches and not group_matches
kfd=Path('/sys/class/kfd/kfd/proc');assert kfd.is_dir() and not list(kfd.iterdir())
fds=[];items={};checks={};binary_checks={};archive_checks={}
try:
 for row in plan['leases']:
  path=Path(row['path']);assert path.resolve()==path and not path.is_symlink()
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC);fds.append(fd);s=os.fstat(fd)
  assert stat.S_ISREG(s.st_mode) and s.st_uid==1000 and (s.st_dev,s.st_ino)==(row['device'],row['inode'])
  fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
 previous=json.loads(Path(plan['previous_release_path']).read_text())
 models=[]
 for row in previous['models']+[previous['glm_model']]:
  p=Path(row['path']);s=p.stat();assert p.resolve()==p and not p.is_symlink()
  assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==tuple(row[k] for k in ['device','inode','bytes','mtime_ns','ctime_ns'])
  models.append(row)
 source=root/'source';inventory=json.loads((root/'source-inventory.json').read_text())
 for name,row in inventory.items():
  p=source/name;assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
 linked=source/'build/halo-develop-q2-linked-r1'
 for name,row in compiler['binaries'].items():
  p=linked/name;digest=sha(p);assert digest==row['sha256'] and p.stat().st_size==row['bytes']
  binary_checks[name]={'path':str(p),'bytes':p.stat().st_size,'sha256':digest}
 names=['manifest.json','peer-declarations.json','fresh.json','admission.json','release.json','result.json','compiler-result.json',
        'telemetry.jsonl','compiler-supervisor.log','halo-develop-q2-provider-r1.log','halo-develop-q2-reference-r1.log','configure-products.log','link-products.log']
 for label in ['halo-develop-q2-provider-r1','halo-develop-q2-reference-r1']:
  build=source/'build'/label;receipt=json.loads((build/'BUILD-RECEIPT.json').read_text())
  assert receipt['hip_architecture']=='gfx1151' and not receipt['gpu_execution']
  assert receipt['source_pin']==plan['source_pin']
  assert receipt['c17_sampling']==(label=='halo-develop-q2-provider-r1')
  assert receipt['qwen_q2_formats'] is True
  assert receipt['qwen_q2_edits_sha256']==sha(source/'adapters/gufo-state/qwen-q2-format-edits.json')
  assert receipt['qwen_q2_patch_sha256']==sha(source/'patches/gufo-q2.patch')
  assert all(r['exit_code']==0 for r in receipt['commands'])
  for name,digest in receipt['libraries'].items():
   p=build/name;assert sha(p)==digest
   archive_checks[label+'/'+name]={'bytes':p.stat().st_size,'sha256':digest}
  names += ['source/build/'+label+'/BUILD-RECEIPT.json','source/build/'+label+'/CMakeCache.txt',
            'source/evidence/'+label+'/result.json','source/evidence/'+label+'/configure.log','source/evidence/'+label+'/build.log']
 names += ['source/build/halo-develop-q2-linked-r1/CMakeCache.txt']
 for name in names:
  p=root/name;assert p.stat().st_size<32*1024**2
  digest=sha(p);data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==digest
  items[name]=base64.b64encode(data).decode()
  checks[name]={'bytes':len(data),'sha256':digest}
 assert json.loads(registry.read_text().splitlines()[-1])==last and not list(kfd.iterdir())
finally:
 for fd in reversed(fds):os.close(fd)
strong={'state':'COMPILER_WHOLE_WINDOW_CLOSED_NOT_INFERENCE_QUALIFIED',
        'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':expected,
        'release_sha256':sha(root/'release.json'),'actual_compiler_child_exit_code':release['commands'][0]['exit_code'],
        'identities_checked':identities,'original_groups_checked':sorted(groups),'two_complete_process_scans':scans,
        'five_original_leases_acquired_nonblocking_verified_and_released':plan['leases'],
        'original_model_stat_checks':models,'kfd_empty':True,'source_input_files_verified_unchanged':len(inventory),
        'compiled_binary_checks':binary_checks,'provider_archive_checks':archive_checks,'collected_artifact_checks':checks,
        'future_grant':False,'GPU_model_numerical_or_performance_qualification':False}
with (root/'strong-closure.json').open('x') as stream:json.dump(strong,stream,indent=2);stream.write('\n')
print(json.dumps({'strong_closure':strong,'collected_files_base64':items}))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',
      'paperboy@192.168.5.157','python3 -B -']
r=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=180)
record={'argv':argv,'actual_exit_code':r.returncode,'stderr':r.stderr,
        'program_sha256':hashlib.sha256(program.encode()).hexdigest()}
if r.returncode==0:
    data=json.loads(r.stdout);strong=data['strong_closure'];out=HERE/'collected';out.mkdir()
    for name,encoded in data['collected_files_base64'].items():
        relative=Path(name);assert not relative.is_absolute() and '..' not in relative.parts
        content=base64.b64decode(encoded,validate=True);expected=strong['collected_artifact_checks'][name]
        assert len(content)==expected['bytes'] and hashlib.sha256(content).hexdigest()==expected['sha256']
        target=out/relative;target.parent.mkdir(parents=True,exist_ok=True);target.open('xb').write(content)
    (HERE/'strong-closure.json').open('x').write(json.dumps(strong,indent=2)+'\n')
    record['collection_files_verified']=len(strong['collected_artifact_checks'])
    record['state']=strong['state']
    record['strong_at_utc']=strong['at_utc']
else:
    record['stdout']=r.stdout
(HERE/'collect-close-result-r1.json').open('x').write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(r.returncode)
