# SPDX-License-Identifier: MIT
from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
here=Path(__file__).resolve().parent
root=here.parents[1]
assert root.name=='integrate-antirez-qwen'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='9e95e4c49e1aa71e71f50003760ac14d96a3232e'
argv=['git','archive',head,'--','CMakeLists.txt','Makefile','cmake','src','include','adapters','tools','tests','third_party','LICENSE','AGENTS.md','patches/gufo-q2.patch']
r=subprocess.run(argv,cwd=root,capture_output=True)
(here/'archive-command.json').write_text(json.dumps({'argv':argv,'actual_exit_code':r.returncode,'stderr':r.stderr.decode(),'publication':False},indent=2)+'\n')
assert r.returncode==0
files={}
with tarfile.open(fileobj=io.BytesIO(r.stdout),mode='r:') as archive:
 for entry in archive.getmembers():
  if entry.isdir():continue
  path=Path(entry.name)
  assert entry.isfile() and not path.is_absolute() and '..' not in path.parts and entry.size<16*1024**2
  files[entry.name]=(archive.extractfile(entry).read(),entry.mode)
manifest=json.loads((root/'third_party/gufo-source.json').read_text())
assert manifest['commit']=='f783fedb9bea2ec7de941f6da4e02f4a4596b29e'
for name,expected in manifest['files'].items():
 p=root/'.deps/gufo-f783fedb'/name
 assert p.resolve()==p and p.is_file() and not p.is_symlink()
 data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==expected and len(data)<16*1024**2
 files['.deps/gufo-f783fedb/'+name]=(data,p.stat().st_mode&0o777)
inventory={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,(data,mode) in sorted(files.items())}
(here/'source-inventory.json').open('x').write(json.dumps(inventory,indent=2,sort_keys=True)+'\n')
with tarfile.open(here/'source.tar.gz','w:gz') as archive:
 for name,(data,mode) in sorted(files.items()):
  entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=mode;entry.mtime=0
  archive.addfile(entry,io.BytesIO(data))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
record={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'LOCAL_SOURCE_PREPARED_NOT_STAGED_OR_ADMITTED','source_commit':head,'upstream_pin':manifest['commit'],'upstream_files_hash_verified':len(manifest['files']),'source_files':len(files),'source_bytes':sum(len(v[0]) for v in files.values()),'archive_bytes':(here/'source.tar.gz').stat().st_size,'archive_sha256':sha(here/'source.tar.gz'),'source_inventory_sha256':sha(here/'source-inventory.json'),'Q2_original_formats_and_native_DS4_walk':True,'GPU_operation':False,'remote_build_or_lease_or_waiter_or_reservation':False,'model_payload_or_heavyweight_hash_or_conversion':False}
(here/'source-preparation.json').open('x').write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
