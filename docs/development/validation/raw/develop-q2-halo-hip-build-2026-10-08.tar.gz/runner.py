# SPDX-License-Identifier: MIT
"""One admitted native gfx1151 compile window, original leases, private child."""
from pathlib import Path
import datetime
import fcntl
import hashlib
import json
import os
import stat
import subprocess
import sys
import tarfile
import time

HERE = Path(__file__).resolve().parent
BASE = Path('/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run')
PLAN = HERE/'manifest.json'
BOOT = 'be3e89fd-955b-47a4-a385-11c3ad98bb78'
REGISTRY = BASE/'gpu-coordination/epochs'/BOOT/'runs.jsonl'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value, exclusive=False):
    with path.open('x' if exclusive else 'w') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def read_last():
    assert REGISTRY.stat().st_size<2*1024**2 and not REGISTRY.is_symlink()
    return json.loads(REGISTRY.read_text().splitlines()[-1])


def model_stats(previous):
    for row in previous['models']+[previous['glm_model']]:
        path=Path(row['path']); s=path.stat()
        assert path.resolve()==path and not path.is_symlink()
        assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==tuple(
            row[k] for k in ['device','inode','bytes','mtime_ns','ctime_ns'])
    return len(previous['models'])+1


def sensors():
    rows=[]
    for folder in sorted(Path('/sys/class/hwmon').glob('hwmon*')):
        name=(folder/'name').read_text().strip()
        if name not in ['k10temp','coretemp','amdgpu','nvme']:
            continue
        for path in sorted(folder.glob('temp*_input')):
            limit=None if name=='amdgpu' else 85 if name=='nvme' else 98
            if limit is not None:
                for suffix in ['max','crit']:
                    bound=path.with_name(path.name[:-6]+'_'+suffix)
                    if bound.exists():
                        value=int(bound.read_text())/1000
                        if 30<=value<=150:
                            limit=min(limit,value)
            rows.append({'name':name,'path':str(path),'limit_c':limit})
    assert any(r['name']=='k10temp' and r['limit_c'] is not None for r in rows)
    return rows


def kfd_clients():
    directory=Path('/sys/class/kfd/kfd/proc')
    assert directory.is_dir()
    return [int(p.name) for p in directory.iterdir() if p.name.isdecimal()]


def append_event(kind, receipt):
    row={'event':kind,'owner':'synapse-lie-root','label':HERE.name,'at':now(),
         'boot_id':BOOT,'receipt':str(receipt),'receipt_sha256':sha(receipt)}
    with REGISTRY.open('a') as stream:
        stream.write(json.dumps(row)+'\n');stream.flush();os.fsync(stream.fileno())


def check(plan, previous):
    assert os.getuid()==1000 and HERE==BASE/plan['label'] and HERE.resolve()==HERE
    assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==BOOT
    fs=subprocess.run(['findmnt','--json','--target',str(BASE),'--output','UUID'],
                      capture_output=True,text=True,timeout=10)
    assert fs.returncode==0 and json.loads(fs.stdout)['filesystems'][0]['uuid']==plan['filesystem_uuid']
    assert 'ryzen ai max+ 395' in Path('/proc/cpuinfo').read_text().lower()
    assert sha(Path(plan['previous_release_path']))==plan['previous_release_sha256']
    assert read_last()==plan['previous_registry_event']
    assert not kfd_clients()
    prior_ids={r['pid']:r['start_ticks'] for r in previous['retired_identities']}
    prior_groups=set(previous['retired_groups'])
    for directory in Path('/proc').glob('[0-9]*'):
        try:
            fields=(directory/'stat').read_text().rsplit(') ',1)[1].split()
        except FileNotFoundError:
            continue
        pid=int(directory.name)
        assert pid not in prior_ids or int(fields[19])!=prior_ids[pid]
        assert int(fields[2]) not in prior_groups
    model_stats(previous)
    memory=dict((line.split(':',1)[0],line.split(':',1)[1].strip())
                for line in Path('/proc/meminfo').read_text().splitlines())
    assert int(memory['MemAvailable'].split()[0])*1024>=plan['compile_admission_available_bytes']
    assert os.statvfs(BASE).f_bavail*os.statvfs(BASE).f_frsize>=plan['compile_admission_disk_bytes']
    for name,expected in plan['inputs'].items():
        path=HERE/name;assert path.resolve()==path and not path.is_symlink()
        assert sha(path)==expected['sha256'] and path.stat().st_size==expected['bytes']
    fresh=json.loads((HERE/'fresh.json').read_text())
    assert fresh['state']=='FRESH_GLOBAL_BUILD_OBSERVED_NOT_ADMITTED'
    assert fresh['manifest_sha256']==sha(PLAN)
    age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(fresh['at_utc'])).total_seconds()
    assert 0<=age<=120
    declarations=json.loads((HERE/'peer-declarations.json').read_text())
    assert declarations['manifest_sha256']==sha(PLAN)
    assert set(declarations['specific_nonuse_peer_ids'])==set(plan['peer_ids'])
    return memory


plan=json.loads(PLAN.read_text())
assert sha(HERE/'runner.py')==plan['inputs']['runner.py']['sha256']
previous=json.loads(Path(plan['previous_release_path']).read_text())
held=[]; admitted=False; child_row={}; result={'state':'PREPARING_NOT_ADMITTED',
    'at_utc':now(),'manifest_sha256':sha(PLAN),'commands':[],
    'GPU_kernel_or_model_execution_requested':False,'installation_or_tuning':False}
try:
    check(plan,previous)
    for row in plan['leases']:
        path=Path(row['path']);assert path.resolve()==path and not path.is_symlink()
        fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW);held.append(fd)
        s=os.fstat(fd);assert stat.S_ISREG(s.st_mode) and s.st_uid==1000
        assert (s.st_dev,s.st_ino)==(row['device'],row['inode'])
        fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    memory=check(plan,previous)
    source=HERE/'source';source.mkdir()
    inventory=json.loads((HERE/'source-inventory.json').read_text())
    with tarfile.open(HERE/'source.tar.gz') as archive:
        entries=archive.getmembers()
        assert {e.name for e in entries}==set(inventory) and len(entries)==len(inventory)
        for entry in entries:
            relative=Path(entry.name)
            assert entry.isfile() and not relative.is_absolute() and '..' not in relative.parts
            assert entry.size==inventory[entry.name]['bytes'] and entry.size<16*1024**2
            data=archive.extractfile(entry).read()
            assert hashlib.sha256(data).hexdigest()==inventory[entry.name]['sha256']
            target=source/relative;target.parent.mkdir(parents=True,exist_ok=True)
            target.open('xb').write(data)
    sys.path.insert(0,str(source/'tools'))
    import q2_process
    supervisor=q2_process.identity(os.getpid())
    result.update(state='ADMITTED_COMPILE_ONLY',admitted_at=now(),supervisor=supervisor,
                  original_lease_fds=[{'fd':fd,**row} for fd,row in zip(held,plan['leases'])],
                  original_models_stat_verified=len(previous['models']),memory_before=memory)
    save(HERE/'admission.json',result,True);append_event('window_admit',HERE/'admission.json')
    admitted=True
    layout=sensors();peaks={}
    with (HERE/'telemetry.jsonl').open('x') as telemetry, (HERE/'compiler-supervisor.log').open('xb') as log:
        def observe(pid):
            sample={'at_utc':now(),'owned_child_pid':pid,'temperatures':[]}
            hot=[]
            for row in layout:
                value=int(Path(row['path']).read_text())/1000
                peaks[row['path']]=max(peaks.get(row['path'],value),value)
                sample['temperatures'].append({**row,'value_c':value})
                if row['limit_c'] is not None and value>=row['limit_c']:
                    hot.append(sample['temperatures'][-1])
            telemetry.write(json.dumps(sample)+'\n');telemetry.flush()
            result['peak_c']=dict(peaks)
            if hot:
                result['thermal_trip']=hot
                raise RuntimeError('CPU/NVMe thermal guard')
        observe(None)
        # The admitted lease runner owns remote compilation. Give only this
        # compiler child a clean local build environment; retain the actual
        # remote host, source, supervisor and five lease identities above.
        env=dict(os.environ,LIE_HALO_LEASED_BUILD='admitted',LC_ALL='C',
                 HIP_VISIBLE_DEVICES='-1',ROCR_VISIBLE_DEVICES='-1',CUDA_VISIBLE_DEVICES='-1',
                 OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
        env.pop('SSH_CONNECTION',None);env.pop('SSH_CLIENT',None)
        argv=[sys.executable,'-B',str(HERE/'build.py')]
        result['commands'].append(child_row)
        child_row['argv']=argv
        q2_process.supervise(argv,cwd=HERE,env=env,log=log,row=child_row,
            timeout=plan['timeout_seconds'],save=lambda:save(HERE/'result.json',result),
            clients=kfd_clients,observe=observe)
        observe(None)
    result['peak_c']=peaks
    compiler=json.loads((HERE/'compiler-result.json').read_text())
    assert compiler['actual_exit_code']==0 and compiler['state']=='BUILT_NOT_GPU_OR_NUMERICALLY_QUALIFIED'
    assert not q2_process.members(child_row['pid'],child_row['start_ticks'])
    assert not kfd_clients()
    model_stats(previous)
    result.update(state='COMPILE_COMPLETE_NOT_GPU_QUALIFIED',actual_exit_code=0,
                  original_models_after_match=True,owned_child_group_absent=True)
except BaseException as error:
    result.update(state='COMPILE_FAILED' if admitted else 'ADMISSION_REFUSED',
                  actual_exit_code=1,error=repr(error))
finally:
    for fd in reversed(held):
        os.close(fd)
    result['original_lease_descriptors_closed_at']=now()
    result['gpu_reserved']=False
    save(HERE/'result.json',result)
    if admitted:
        save(HERE/'release.json',result,True)
        append_event('window_release',HERE/'release.json')
print(json.dumps(result))
raise SystemExit(result['actual_exit_code'])
