# SPDX-License-Identifier: MIT
"""Fresh metadata/original-lease check for exactly one source-bound proposal."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

HERE=Path(__file__).resolve().parent
REMOTE='/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run/'+HERE.name
program=r'''
from pathlib import Path
import datetime,fcntl,hashlib,json,os,stat,subprocess
root=Path('/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run/halo-develop-q2-build-20261008-r1')
assert os.getuid()==1000 and root.resolve()==root
def sha(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
plan=json.loads((root/'manifest.json').read_text())
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==plan['boot_id']
fs=subprocess.run(['findmnt','--json','--target',str(root),'--output','UUID'],capture_output=True,text=True,timeout=10)
assert fs.returncode==0 and json.loads(fs.stdout)['filesystems'][0]['uuid']==plan['filesystem_uuid']
assert 'ryzen ai max+ 395' in Path('/proc/cpuinfo').read_text().lower()
registry=root.parent/'gpu-coordination/epochs'/plan['boot_id']/'runs.jsonl'
assert registry.stat().st_size<2*1024**2 and not registry.is_symlink()
assert json.loads(registry.read_text().splitlines()[-1])==plan['previous_registry_event']
previous=Path(plan['previous_release_path']);assert previous.resolve()==previous
assert sha(previous)==plan['previous_release_sha256']
release=json.loads(previous.read_text());assert not release['gpu_reserved']
declarations=json.loads((root/'peer-declarations.json').read_text())
assert declarations['manifest_sha256']==sha(root/'manifest.json')
assert set(declarations['specific_nonuse_peer_ids'])==set(plan['peer_ids'])
checks={}
for name,expected in plan['inputs'].items():
 p=root/name;assert p.resolve()==p and not p.is_symlink()
 digest=sha(p);assert digest==expected['sha256'] and p.stat().st_size==expected['bytes']
 checks[name]={'bytes':p.stat().st_size,'sha256':digest}
kfd=Path('/sys/class/kfd/kfd/proc');assert kfd.is_dir() and not list(kfd.iterdir())
models=[]
for row in release['models']+[release['glm_model']]:
 p=Path(row['path']);s=p.stat();assert p.resolve()==p and not p.is_symlink()
 assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==tuple(row[k] for k in ['device','inode','bytes','mtime_ns','ctime_ns'])
 models.append(row)
prior_ids={r['pid']:r['start_ticks'] for r in release['retired_identities']};groups=set(release['retired_groups']);scanned=0
for directory in Path('/proc').glob('[0-9]*'):
 try:fields=(directory/'stat').read_text().rsplit(') ',1)[1].split()
 except FileNotFoundError:continue
 scanned+=1;pid=int(directory.name)
 assert pid not in prior_ids or int(fields[19])!=prior_ids[pid]
 assert int(fields[2]) not in groups
pkg=subprocess.run(['pacman','-Q','hip-runtime-amd','rocm-hip-sdk','rocwmma','cmake','ninja','json-c','llhttp','libuv','icu'],capture_output=True,text=True,timeout=15)
assert pkg.returncode==0 and 'hip-runtime-amd 7.2.4-' in pkg.stdout and 'rocm-hip-sdk 7.2.4-' in pkg.stdout
meminfo=Path('/proc/meminfo').read_text();memory={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in meminfo.splitlines()}
assert int(memory['MemAvailable'].split()[0])*1024>=plan['compile_admission_available_bytes']
disk=os.statvfs(root);free=disk.f_bavail*disk.f_frsize;assert free>=plan['compile_admission_disk_bytes']
temperatures=[]
for folder in sorted(Path('/sys/class/hwmon').glob('hwmon*')):
 name=(folder/'name').read_text().strip()
 if name not in ['k10temp','coretemp','amdgpu','nvme']:continue
 for sensor in sorted(folder.glob('temp*_input')):
  limit=None if name=='amdgpu' else 85 if name=='nvme' else 98
  if limit is not None:
   for suffix in ['max','crit']:
    bound=sensor.with_name(sensor.name[:-6]+'_'+suffix)
    if bound.exists():
     value=int(bound.read_text())/1000
     if 30<=value<=150:limit=min(limit,value)
  value=int(sensor.read_text())/1000;assert limit is None or value<limit
  temperatures.append({'name':name,'path':str(sensor),'limit_c':limit,'value_c':value})
assert any(r['name']=='k10temp' for r in temperatures)
fds=[]
try:
 for row in plan['leases']:
  p=Path(row['path']);assert p.resolve()==p and not p.is_symlink()
  fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW);fds.append(fd);s=os.fstat(fd)
  assert stat.S_ISREG(s.st_mode) and s.st_uid==1000 and (s.st_dev,s.st_ino)==(row['device'],row['inode'])
  fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
finally:
 for fd in reversed(fds):os.close(fd)
record={'state':'FRESH_GLOBAL_BUILD_OBSERVED_NOT_ADMITTED','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'manifest_sha256':sha(root/'manifest.json'),'boot_id':plan['boot_id'],'filesystem_uuid':plan['filesystem_uuid'],
 'source_input_checks':checks,'previous_release_sha256':sha(previous),'five_original_leases_free_checked_and_released':plan['leases'],
 'kfd_empty':True,'previous_own_ids_groups_absent':True,'processes_scanned':scanned,
 'original_models_stat_checks':models,'packages':{'argv':pkg.args,'actual_exit_code':pkg.returncode,'stdout':pkg.stdout},
 'memory_before':memory,'disk_available_bytes':free,'temperatures':temperatures,
 'build_or_model_or_GPU_kernel_execution':False,'root_window_or_lease_or_waiter_or_reservation':False}
with (root/'fresh.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',
      'paperboy@192.168.5.157','python3 -B -']
r=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=60)
record={'argv':argv,'actual_exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,
        'observer_sha256':hashlib.sha256(program.encode()).hexdigest()}
try:
    record['result']=json.loads(r.stdout)
except ValueError:
    pass
(HERE/'fresh-result-r1.json').open('x').write(json.dumps(record,indent=2)+'\n')
v=record.get('result',{})
print(json.dumps({k:v.get(k) for k in ['state','at_utc','manifest_sha256','kfd_empty',
                                     'disk_available_bytes','temperatures']}))
print('SSH actual exit:',r.returncode)
raise SystemExit(r.returncode)
