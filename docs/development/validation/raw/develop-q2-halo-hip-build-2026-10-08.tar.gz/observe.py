# SPDX-License-Identifier: MIT
from pathlib import Path
import hashlib
import json
import subprocess
import sys

HERE=Path(__file__).resolve().parent
suffix=sys.argv[1]
assert suffix.isdecimal() and int(suffix)>0
program=r'''
from pathlib import Path
import datetime,hashlib,json,os
root=Path('/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run/halo-develop-q2-build-20261008-r1')
assert os.getuid()==1000 and root.resolve()==root
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='be3e89fd-955b-47a4-a385-11c3ad98bb78'
assert hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()=='2e08ae7116e33a4a20cec19ddf0e7d421756d338c2651837d048430c868147cb'
result=json.loads((root/'result.json').read_text())
def identity(pid):
 try:
  fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
  return {'pid':pid,'state':fields[0],'group':int(fields[2]),'session':int(fields[3]),'start_ticks':int(fields[19])}
 except FileNotFoundError:return None
supervisor=result.get('supervisor');observed=None;fds=[]
if supervisor:
 observed=identity(supervisor['pid'])
 if observed and observed['start_ticks']==supervisor['start_ticks']:
  for row in result['original_lease_fds']:
   path=Path('/proc',str(supervisor['pid']),'fd',str(row['fd']));s=path.stat()
   assert (s.st_dev,s.st_ino)==(row['device'],row['inode'])
   fds.append({'fd':row['fd'],'path':os.readlink(path),'device':s.st_dev,'inode':s.st_ino})
compiler=root/'compiler-result.json';phase=json.loads(compiler.read_text()) if compiler.exists() else None
telemetry=root/'telemetry.jsonl';last=None
if telemetry.exists():
 with telemetry.open('rb') as stream:
  stream.seek(max(0,telemetry.stat().st_size-16000));lines=stream.read().splitlines()
 if lines:last=json.loads(lines[-1])
print(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'READ_ONLY_COMPILER_OBSERVATION_NOT_INFERENCE','result':result,
 'observed_supervisor':observed,'original_lease_fds':fds,'compiler':phase,
 'latest_telemetry':last,'kfd_registered_pids':[p.name for p in Path('/sys/class/kfd/kfd/proc').iterdir()],
 'GPU_or_model_execution_requested':False}))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',
      'paperboy@192.168.5.157','python3 -B -']
r=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,
        'program_sha256':hashlib.sha256(program.encode()).hexdigest()}
try:
    record['result']=json.loads(r.stdout)
except ValueError:
    pass
(HERE/('live-'+suffix+'.json')).open('x').write(json.dumps(record,indent=2)+'\n')
v=record.get('result',{});compiler=v.get('compiler') or {};job=v.get('result') or {}
print(json.dumps({'SSH_actual_exit_code':r.returncode,'at_utc':v.get('at_utc'),
                  'job_state':job.get('state'),'supervisor':v.get('observed_supervisor'),
                  'original_lease_fds':v.get('original_lease_fds'),
                  'compiler_state':compiler.get('state'),'commands':compiler.get('commands'),
                  'kfd_registered_pids':v.get('kfd_registered_pids'),
                  'latest_telemetry':v.get('latest_telemetry'),'error':job.get('error')}))
raise SystemExit(r.returncode)
