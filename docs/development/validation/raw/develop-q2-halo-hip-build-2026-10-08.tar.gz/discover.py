# SPDX-License-Identifier: MIT
from pathlib import Path
import datetime, hashlib, json, subprocess
here=Path(__file__).resolve().parent
program=(here/'discovery-remote.py').read_text()
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','paperboy@192.168.5.157','python3 -B -']
r=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'actual_exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'observer_sha256':hashlib.sha256(program.encode()).hexdigest()}
(here/'discovery-result-r1.json').open('x').write(json.dumps(record,indent=2)+'\n')
if r.returncode==0:
 value=json.loads(r.stdout)
 (here/'discovery-r1.json').open('x').write(json.dumps(value,indent=2)+'\n')
 print(json.dumps({k:value[k] for k in ('state','boot_id','filesystem_uuid','registry_last_event','kfd_clients','disk_available_bytes','sensors')}))
else:print(r.stderr)
raise SystemExit(r.returncode)
