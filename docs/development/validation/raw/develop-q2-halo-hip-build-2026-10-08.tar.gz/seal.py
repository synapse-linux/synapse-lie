# SPDX-License-Identifier: MIT
from pathlib import Path
import datetime,hashlib,io,json,tarfile
here=Path(__file__).resolve().parent;root=here.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((here/name).read_text())
plan=read('manifest.json');strong=read('strong-closure.json');compiler=read('collected/compiler-result.json');release=read('collected/release.json');local=read('local-closure-review.json')
assert sha(here/'manifest.json')==strong['manifest_sha256']==release['manifest_sha256']
assert compiler['actual_exit_code']==release['actual_exit_code']==0
assert len(compiler['commands'])==4 and all(c['actual_exit_code']==0 for c in compiler['commands'])
assert strong['source_input_files_verified_unchanged']==3015
assert len(strong['compiled_binary_checks'])==7 and len(strong['provider_archive_checks'])==6
for name in ('controller-result.json','collect-close-result-r1.json'):
 assert read(name)['actual_exit_code']==0
for name in ('peer-proposals-r1.json','admission-notifications-r1.json','release-notifications-r1.json'):
 values=read(name);values=values.get('results',values)
 assert len(values)==4 and all(v['status']=='fulfilled' and v['value']['result']['isError'] is False for v in values)
for label,selected in [('halo-develop-q2-provider-r1',True),('halo-develop-q2-reference-r1',False)]:
 r=read('collected/source/build/'+label+'/BUILD-RECEIPT.json')
 assert r['c17_sampling'] is selected and r['qwen_q2_formats'] is True
 assert r['qwen_q2_edits_sha256']==sha(root/'adapters/gufo-state/qwen-q2-format-edits.json')
 assert r['qwen_q2_patch_sha256']==sha(root/'patches/gufo-q2.patch')
files={}
for p in sorted(here.rglob('*')):
 if not p.is_file() or p.is_symlink() or p.name=='source.tar.gz':continue
 rel=p.relative_to(here);assert '..' not in rel.parts and p.stat().st_size<32*1024**2
 files[str(rel)]={'bytes':p.stat().st_size,'sha256':sha(p)}
for name,row in strong['collected_artifact_checks'].items():
 assert files['collected/'+name]==row
raw=root/'docs/development/validation/raw/develop-q2-halo-hip-build-2026-10-08.tar.gz';raw.parent.mkdir(parents=True,exist_ok=True)
assert not raw.exists()
with tarfile.open(raw,'w:gz') as archive:
 for name,row in files.items():
  data=(here/name).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
with tarfile.open(raw,'r:gz') as archive:
 entries=archive.getmembers();assert len(entries)==len(files) and {p.name for p in entries}==set(files)
 for e in entries:
  data=archive.extractfile(e).read();assert len(data)==files[e.name]['bytes'] and hashlib.sha256(data).hexdigest()==files[e.name]['sha256']
receipt={
 'schema':'synapse-lie.develop-q2-halo-hip-build.v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'COHERENT_HIP_BUILD_COMPLETE_CLOSED_NOT_MODEL_QUALIFIED','source_commit':plan['source_commit'],'source_qualified_from':'f902ad45',
 'source_pin':plan['source_pin'],'host':plan['host'],'boot_id':plan['boot_id'],'filesystem_uuid':plan['filesystem_uuid'],'hip_architecture':plan['hip_architecture'],'sdk':plan['sdk'],
 'manifest_sha256':sha(here/'manifest.json'),'source_archive':plan['inputs']['source.tar.gz'],'source_inventory_sha256':sha(here/'source-inventory.json'),
 'input_files_verified_unchanged':3015,'upstream_files_independently_verified':1019,
 'selection':{'original_qwen_q2_formats':True,'c17_sampling_primary':True,'c17_sampling_control':False,'state_access':True,'ds4_runtime_cache':True,'vision_weight_decode':True,'directional_steering':True,'attention_dispatch_stats':True,'long_context_wmma':True,'legacy_python_tests':False,'python_discovery_disabled_for_products':True},
 'selected_format_inputs':{'adapters/gufo-state/qwen-q2-format-edits.json':sha(root/'adapters/gufo-state/qwen-q2-format-edits.json'),'patches/gufo-q2.patch':sha(root/'patches/gufo-q2.patch')},
 'actual_compiler_commands':compiler['commands'],'actual_controller_exit_code':0,'actual_collection_exit_code':0,
 'binaries':strong['compiled_binary_checks'],'provider_archives':strong['provider_archive_checks'],
 'thermal':{'cpu_guard_c':98,'nvme_guard_c':85,'lower_exposed_hardware_limits_retained':True,'gpu_observe_only':True,'peaks_by_sensor_name_c':local['temperature_peaks'],'guard_trip':False},
 'closure':{'original_lease_descriptors_closed_at':release['original_lease_descriptors_closed_at'],'release_sha256':sha(here/'collected/release.json'),'strong_at_utc':strong['at_utc'],'strong_sha256':sha(here/'strong-closure.json'),'two_complete_process_scans':strong['two_complete_process_scans'],'identities_checked':strong['identities_checked'],'original_groups_checked':strong['original_groups_checked'],'five_original_leases_verified_free_and_released':strong['five_original_leases_acquired_nonblocking_verified_and_released'],'all_eight_model_stats_unchanged':True,'kfd_empty':True,'four_final_notices_delivered':True,'future_grant':False},
 'scope':{'compilation_linking_only':True,'model_payload_read_hash_conversion':False,'gpu_kernel_or_original_weight_run':False,'numerical_quality_or_performance_qualification':False,'service_installation_tuning':False,'terminal_bench':False,'develop_merged':False},
 'raw':{'path':'raw/'+raw.name,'bytes':raw.stat().st_size,'sha256':sha(raw),'files':files,'members_verified':len(files)},
 'remaining':'Original-weight current-provider Q2/IQ2 and native walk, UD-Q4 regressions, then final develop integration. Broader benchmark/quality queue remains separate.'}
public=root/'docs/development/validation/develop-q2-halo-hip-build-2026-10-08.json';public.open('x').write(json.dumps(receipt,indent=2)+'\n')
(here/'seal-result.json').open('x').write(json.dumps({'actual_exit_code':0,'public_receipt':str(public),'public_receipt_sha256':sha(public),'raw_archive_bytes':raw.stat().st_size,'raw_archive_sha256':sha(raw),'members_verified':len(files)},indent=2)+'\n')
print(json.dumps({'actual_exit_code':0,'receipt':str(public.relative_to(root)),'raw_archive_bytes':raw.stat().st_size,'members_verified':len(files),'scope':'Compilation only; no GPU/model numerical qualification'}))
