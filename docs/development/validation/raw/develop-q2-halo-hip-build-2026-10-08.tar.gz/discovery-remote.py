# SPDX-License-Identifier: MIT
from pathlib import Path
import datetime, json, os, subprocess
base=Path('/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run')
assert os.getuid()==1000 and base.resolve()==base
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
fs=subprocess.run(['findmnt','--json','--target',str(base),'--output','UUID'],text=True,capture_output=True,timeout=10)
assert fs.returncode==0
registry=base/'gpu-coordination'/'epochs'/boot/'runs.jsonl'
assert registry.is_file() and not registry.is_symlink() and registry.stat().st_size<2*1024**2
rows=[json.loads(line) for line in registry.read_text().splitlines() if line]
last=rows[-1]
release={}
if last.get('event')=='window_release':
 p=Path(last['receipt']);assert p.resolve()==p and not p.is_symlink() and p.stat().st_size<2*1024**2
 release=json.loads(p.read_text())
packages=subprocess.run(['pacman','-Q','hip-runtime-amd','rocm-hip-sdk','rocwmma','cmake','ninja','json-c','llhttp','libuv','icu'],text=True,capture_output=True,timeout=15)
assert packages.returncode==0
leases=[]
paths=[base/'root-terminal-bench-r16/client.lock',Path('/home/paperboy/workspace/projects/cachyos/ai/ds4-gufo/qualification/.pipeline.lock'),Path('/home/paperboy/.local/state/ds4-kernel-work/20260927T161150Z-qwen-hip-prefill/download-gufo-native/download.lock'),Path('/home/paperboy/.local/state/ds4-kernel-work/20260927T161150Z-qwen-hip-prefill/.qualification.lock'),base/'gpu-coordination/epochs'/boot/'gpu.lock']
for p in paths:
 s=p.stat();assert p.resolve()==p and not p.is_symlink()
 leases.append({'path':str(p),'device':s.st_dev,'inode':s.st_ino,'uid':s.st_uid})
kfd=Path('/sys/class/kfd/kfd/proc');assert kfd.is_dir()
sensors=[]
for folder in sorted(Path('/sys/class/hwmon').glob('hwmon*')):
 name=(folder/'name').read_text().strip()
 if name in ('k10temp','coretemp','amdgpu','nvme'):
  for p in sorted(folder.glob('temp*_input')):sensors.append({'name':name,'path':str(p),'value_c':int(p.read_text())/1000})
record={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'READ_ONLY_DISCOVERY_NO_ADMISSION',
 'boot_id':boot,'filesystem_uuid':json.loads(fs.stdout)['filesystems'][0]['uuid'],
 'cpu_model':next(line for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),
 'memory':Path('/proc/meminfo').read_text(),'disk_available_bytes':os.statvfs(base).f_bavail*os.statvfs(base).f_frsize,
 'registry_last_event':last,'registry_last_five':rows[-5:],'previous_release':release,
 'lease_path_identities_metadata_only':leases,'kfd_clients':[p.name for p in kfd.iterdir()],
 'packages':{'argv':packages.args,'actual_exit_code':packages.returncode,'stdout':packages.stdout},'sensors':sensors,
 'source_staging_or_GPU_or_model_payload_or_build_or_lease':False}
print(json.dumps(record))
