# SPDX-License-Identifier: MIT
"""Launch the original admitted compile runner once; preserve actual exits."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

HERE=Path(__file__).resolve().parent
REMOTE='/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run/'+HERE.name
fresh=json.loads((HERE/'fresh-result-r1.json').read_text())
assert fresh['actual_exit_code']==0
assert fresh['result']['manifest_sha256']==hashlib.sha256((HERE/'manifest.json').read_bytes()).hexdigest()
age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(fresh['result']['at_utc'])).total_seconds()
assert 0<=age<=120
assert not (HERE/'controller-result.json').exists()
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',
      'paperboy@192.168.5.157','python3 -B '+REMOTE+'/runner.py']
with (HERE/'controller-stdout.log').open('xb') as out,(HERE/'controller-stderr.log').open('xb') as err:
    r=subprocess.run(argv,stdout=out,stderr=err)
record={'argv':argv,'actual_exit_code':r.returncode,
        'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'no_inherited_GPU_inference_or_future_grant':True}
(HERE/'controller-result.json').open('x').write(json.dumps(record,indent=2)+'\n')
try:
    record['result']=json.loads((HERE/'controller-stdout.log').read_text())
except ValueError:
    pass
print(json.dumps({**{k:v for k,v in record.items() if k!='result'},
                 'remote_state':record.get('result',{}).get('state'),
                 'remote_error':record.get('result',{}).get('error')}))
raise SystemExit(r.returncode)
