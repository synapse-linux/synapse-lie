#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Seal the completed prefill source for a future admitted Point build."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

root = Path.cwd()
label = 'context-source-modern-r45'
out = root / 'evidence' / label
archive = out.with_suffix('.tar.gz')
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
code = 'd6431db85d3119e112ffd01c557aaacd6d7c2714'
assert commit.startswith('2ec9798b')
assert not subprocess.check_output(['git', 'status', '--porcelain'])
assert not out.exists() and not archive.exists()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

receipt_path = root / 'docs/development/validation/prefill-runtime-local-2026-10-07.json'
receipt = json.loads(receipt_path.read_text())
assert receipt['source_commit'] == code
assert receipt['gpu_execution'] is False and receipt['model_access'] is False
assert [item['tests_passed'] for item in receipt['host']] == [26, 26]
delta = subprocess.check_output(['git', 'diff', '--name-only', code, commit], text=True).splitlines()
assert delta and all(name.startswith('docs/') for name in delta)
raw = receipt_path.parent / receipt['archive']['path']
assert sha(raw) == receipt['archive']['sha256']
assert raw.stat().st_size == receipt['archive']['bytes']
frozen = {}
with tarfile.open(raw) as retained:
    members = retained.getmembers()
    assert len(members) == receipt['archive']['members']
    for member in members:
        if not member.name.startswith('source/') or member.name.startswith('source/docs/'):
            continue
        assert member.isfile()
        name = member.name.removeprefix('source/')
        with retained.extractfile(member) as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        assert sha(root / name) == digest, name
        frozen[name] = digest
assert frozen
source = receipt['source']
assert source['pristine_files'] == 1019 and source['recipes'] == 41 and source['edits'] == 333
for name, digest in source['recipe_sha256'].items():
    assert Path(name).name == name and name.endswith('-edits.json')
    assert sha(root / 'adapters/gufo-state' / name) == digest, name

out.mkdir()
excluded, copied = [], []
process = subprocess.Popen(['git', 'archive', '--format=tar', commit], stdout=subprocess.PIPE)
try:
    with tarfile.open(fileobj=process.stdout, mode='r|') as tracked:
        for member in tracked:
            path = Path(member.name)
            assert not path.is_absolute() and '..' not in path.parts
            assert member.isfile() or member.isdir()
            if path.parts[0] == 'docs':
                if member.isfile():
                    excluded.append(member.name)
                continue
            tracked.extract(member, out, filter='data')
            if member.isfile():
                copied.append(member.name)
finally:
    process.stdout.close()
assert process.wait() == 0
for name in copied:
    assert sha(out / name) == sha(root / name), name

upstream = root / '.deps/gufo-f783fedb'
manifest = json.loads((out / 'third_party/gufo-source.json').read_text())
assert manifest['commit'] == 'f783fedb9bea2ec7de941f6da4e02f4a4596b29e'
assert len(manifest['files']) == 1019 and upstream.resolve() == upstream
for name, digest in manifest['files'].items():
    path = upstream / name
    assert not path.is_symlink() and path.resolve().is_relative_to(upstream)
    assert sha(path) == digest, name
    target = out / '.deps/gufo-f783fedb' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    assert sha(target) == digest

prior_path = root / 'evidence/context-r11-build-r2/result.json'
prior = json.loads(prior_path.read_text())['build_result']
zstd = {}
for name, key in {'zstd.h': 'zstd_header_sha256', 'zstd_errors.h': 'zstd_errors_sha256',
                  'LICENSE': 'zstd_license_sha256'}.items():
    path = root / 'evidence/context-source-modern-r11/third_party/point-zstd-dev' / name
    assert path.is_file() and not path.is_symlink() and sha(path) == prior[key]
    target = out / 'third_party/point-zstd-dev' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    zstd[name] = sha(target)
ryu = json.loads((out / 'third_party/ryu-source.json').read_text())
for name, item in ryu['files'].items():
    assert sha(out / 'third_party/ryu' / name) == item['sha256']

(out / 'SOURCE-COMMIT.txt').write_text(commit + '\n')
(out / 'CODE-CHECKPOINT.txt').write_text(code + '\n')
files = sorted(path for path in out.rglob('*') if path.is_file())
assert all(not path.is_symlink() for path in files)
(out / 'SOURCE-FILES.sha256').write_text(''.join(
    sha(path) + '  ./' + str(path.relative_to(out)) + '\n' for path in files))
with archive.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as package:
            package.add(out, arcname=label)
record = {
    'scope': 'LOCAL_SEALED_COMPILER_INPUTS_NOT_REMOTE_BUILD_OR_GPU',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit': commit, 'code_checkpoint': code,
    'prefill_local_receipt_sha256': sha(receipt_path),
    'prefill_local_archive_sha256': sha(raw),
    'prefill_HOST_frozen_inputs': frozen,
    'prefill_source': source,
    'documentation_only_delta_since_code': delta,
    'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
    'source_files_sha256': sha(out / 'SOURCE-FILES.sha256'), 'source_files': len(files),
    'compile_helper_sha256': sha(out / 'cmake/point/Build.cmake'),
    'runner_sha256': sha(out / 'tools/strix-point-campaign.py'),
    'gufo_pin': manifest['commit'], 'pristine_gufo_files_verified': 1019,
    'zstd_prior_receipt_sha256': sha(prior_path), 'zstd_development_sha256': zstd,
    'ryu_pin': ryu['commit'], 'unchanged_Ryu_files_verified': len(ryu['files']),
    'tracked_compiler_files_verified': len(copied),
    'excluded_compiler_unneeded_documentation': excluded,
    'six_required_consumer_targets': ['synapse-lie-server', 'synapse-lie-bench',
        'synapse-lie-bench-gufo-reference', 'lie-hip-probe', 'lie-sampling-capture',
        'lie-attention-qualify'],
    'remote_stage_build_or_GPU_run': False, 'all_six_tasks_remain_open': True,
}
with (root / 'evidence/context-r45-source-seal.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: record[key] for key in ('scope', 'source_commit', 'code_checkpoint',
    'archive_bytes', 'source_files', 'tracked_compiler_files_verified',
    'pristine_gufo_files_verified')}))
