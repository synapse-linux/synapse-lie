#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Retain completed coherent build and strict closure without another run."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import tarfile

base = Path('evidence/context-r45-build-r1')
out = Path('docs/development/validation/prefill-runtime-point-build-2026-10-07.json')
archive = out.parent / 'raw' / (out.stem + '.tar.gz')
assert not out.exists() and not archive.exists()
def read(path):
    return json.loads(Path(path).read_text())
def bound(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': digest}

job = read(base / 'result.json')
controller = read(base / 'controller-result.json')
verification = read(base / 'compile-verification-r1/result.json')
closure = read('evidence/context-r45-build-closure-r1.json')
seal = read('evidence/context-r45-source-seal.json')
bundle = read('evidence/context-r45-bundle-result.json')
host_path = Path('docs/development/validation/prefill-runtime-local-2026-10-07.json')
host = read(host_path)
assert job['state'] == 'PASSED'
assert job['exit_code'] == job['child_exit_code'] == controller['exit_code'] == 0
assert job['model_attempted'] is False and not job['cleanup_failures']
assert (job['lease']['device'], job['lease']['inode']) == (66307, 105946405)
assert verification['exit_code'] == 0
assert verification['state'] == 'BUILT_NOT_GPU_TESTED_COLLECTED_VERIFIED_CLOSED'
assert len(verification['recipes_verified']) == 41
assert verification['source_commit'] == seal['source_commit']
assert seal['code_checkpoint'] == host['source_commit'] == 'd6431db85d3119e112ffd01c557aaacd6d7c2714'
assert bound(host_path)['sha256'] == seal['prefill_local_receipt_sha256']
assert host['gpu_execution'] is False and [item['tests_passed'] for item in host['host']] == [26, 26]
assert closure['actual_exit_code'] == bundle['exit_code'] == 0
closed = closure['result']
assert closed['owned_supervisor_identity_absent'] and closed['owned_container_init_identity_absent']
assert closed['state'] == 'FRESH_SUCCESSFUL_BUILD_CLOSURE_NO_STANDING_RESERVATION'
assert closed['original_lease']['free_briefly'] and closed['original_lease']['released']
assert not closed['foreign_compute_clients'] and not closed['http8000_listeners']
assert not closed['guarded_hot'] and closed['service']['ActiveState'] == 'active'
assert not closed['standing_lease_waiter_reservation']
assert job['lease_released_at'] and job['service_after']['ActiveState'] == 'active'
rows = [json.loads(line) for line in (base / 'telemetry.jsonl').read_text().splitlines() if line]
assert rows
peaks = {}
for row in rows:
    for sensor in row['temperatures']:
        peaks[sensor['name']] = max(peaks.get(sensor['name'], 0), sensor['value_c'])
        if sensor.get('guarded', True):
            assert sensor['value_c'] < sensor['limit_c']
assert {pid for row in rows for pid in row['kernel_kfd']}.issubset({int(job['service_before']['MainPID'])})

members = {}
def capture(path):
    path = Path(path)
    name = str(path)
    if name not in members:
        members[name] = bound(path)
for path in sorted(base.rglob('*')):
    if path.is_file():
        capture(path)
for pattern in ('context-r45-*', 'prepare-context-r45-*', 'stage-context-r45-*',
                'collect-context-r45-*', 'seal-context-r45-*', 'verify-context-r45-*'):
    for path in sorted(Path('evidence').glob(pattern)):
        if path.is_file():
            capture(path)
capture('evidence/seal-prefill-runtime-point-r45.py')
capture(host_path)
capture('evidence/context-source-modern-r45/SOURCE-FILES.sha256')
for name in ('CMakeLists.txt', 'cmake/point/Build.cmake', 'cmake/provider/Build.cmake',
             'cmake/provider/Source.cmake', 'cmake/gufo-runtime/CMakeLists.txt',
             'third_party/gufo-source.json', 'include/lie/prefill.h', 'include/lie/core.h',
             'src/worker.c', 'src/core_input.c', 'src/server.c',
             'adapters/gufo.cpp', 'adapters/gufo-state/access.hpp',
             'tools/core-bench.c', 'tools/lie-bench.c'):
    assert bound(name) == bound(Path('evidence/context-source-modern-r45') / name)
    capture(name)
for name, digest in verification['recipes_verified'].items():
    assert bound(name)['sha256'] == digest
    capture(name)
inventory = (json.dumps(members, indent=2) + '\n').encode()
with archive.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as package:
            for name, item in sorted(members.items()):
                assert bound(name) == item
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = item['bytes']
                with Path(name).open('rb') as source:
                    package.addfile(info, source)
            info = tarfile.TarInfo('raw-inventory.json')
            info.mode = 0o644
            info.size = len(inventory)
            package.addfile(info, io.BytesIO(inventory))
with tarfile.open(archive) as package:
    actual = package.getmembers()
    assert len(actual) == len(members) + 1
    for item in actual:
        data = package.extractfile(item).read()
        if item.name == 'raw-inventory.json':
            assert data == inventory
        else:
            assert len(data) == members[item.name]['bytes']
            assert hashlib.sha256(data).hexdigest() == members[item.name]['sha256']
receipt = {
    'schema': 'synapse-lie.prefill-runtime-point-build.v1',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': verification['state'],
    'classification': 'CURRENT_SOURCE_COHERENT_ROCM10_BUILD_NOT_GPU_INFERENCE_QUALIFICATION',
    'source_commit': seal['source_commit'], 'code_checkpoint': seal['code_checkpoint'],
    'host_receipt': {'path': str(host_path), **bound(host_path)},
    'source_archive_sha256': seal['archive_sha256'],
    'source_inventory_sha256': seal['source_files_sha256'],
    'tracked_compiler_files': seal['tracked_compiler_files_verified'],
    'independently_pinned_gufo_files': 1019,
    'complete_recipes': 41, 'complete_recipe_replacements': 333,
    'private_C17_ON_OFF_coherent': True,
    'binary_consumers': sorted(job['build_result']['binaries']),
    'build_stages': {stage: int((base / 'compile-evidence' /
        ('evidence/rocm10-point-modern-r45-compile/' + stage + '.exit')).read_text().strip())
        for stage in ('provider', 'reference-provider', 'configure', 'link')},
    'controller_exit_code': controller['exit_code'],
    'supervisor_exit_code': job['exit_code'], 'child_exit_code': job['child_exit_code'],
    'supervisor_identity': {key: job[key] for key in ('pid', 'start_ticks')},
    'container_init_identity': {'pid': job['container_host_pid'], 'start_ticks': job['container_start_ticks']},
    'bundle': bundle['result'], 'lease': job['lease'],
    'lease_released_at_utc': job['lease_released_at'], 'fresh_closure': closed,
    'maximum_observed_temperature_c': peaks, 'telemetry_samples': len(rows),
    'thermal_policy': 'CPU98/NVMe85/lower limits guarded; GPU observed only; no tuning',
    'GPU_device_access_in_compiler': False, 'model_attempted': False,
    'installation_tuning_conversion_deployment_publication': False,
    'no_standing_root_job_lease_waiter_window_reservation_handle_after_closure': True,
    'next_gate': 'Fresh .161 admission for original-weight prefill parity, resource fit and remaining functional/quality/fault gates; matched benchmarks then TerminalBench last.',
    'open_task_numbers': [2, 3, 4, 5, 6, 7], 'goal_complete': False,
    'portable_raw_archive': {'path': 'raw/' + archive.name, **bound(archive), 'members': len(members) + 1},
    'raw_artifacts': members,
}
with out.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: receipt[key] for key in ('state', 'code_checkpoint',
    'build_stages', 'maximum_observed_temperature_c', 'portable_raw_archive')}))
