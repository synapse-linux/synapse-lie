#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Freeze owned HOST evidence and the retained, closed original-weight failure."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

root = Path.cwd()
receipt_path = root / 'docs/development/validation/output-schema-integer-host-2026-10-06.json'
archive_path = root / 'docs/development/validation/raw/output-schema-integer-host-2026-10-06.tar.gz'
assert not receipt_path.exists() and not archive_path.exists()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads((root / path).read_text())

def bind(path):
    data = (root / path).read_bytes()
    return {'bytes': len(data), 'sha256': sha(data)}

members = {}
def capture(path, name=None):
    name = name or path
    assert name not in members
    data = (root / path).read_bytes()
    members[name] = data
    return {'bytes': len(data), 'sha256': sha(data), 'raw_member': name}

previous = read_json('docs/development/validation/c17-schema-integer-host-2026-10-06.json')
old_provider = previous['private_provider_inventory']
assert len(old_provider) == 105
provider = {p: sha((root / p).read_bytes()) for p in old_provider}
changed = sorted(p for p in provider if provider[p] != old_provider[p])
assert changed == ['include/lie/schema_integer.h', 'src/schema_integer.c']
source = (root / 'src/schema_integer.c').read_bytes()
prior = subprocess.check_output(['git', 'show', '2059def4:src/schema_integer.c'])
a = source.index(b'typedef struct {\n  bool negative;\n')
z = source.index(b'static lie_schema_status finite(', a)
assert source[:a] + source[z:] == prior

tracked = subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0')
frozen = {}
for p in sorted(set(tracked + ['tests/test_output_schema.c'])):
    if not p:
        continue
    if p in provider or p in ('CMakeLists.txt', 'LICENSE') or (p.startswith('third_party/')
        and ('NOTICE' in Path(p).name or Path(p).name.startswith('LICENSE') or p.endswith('-source.json'))) or (p.startswith(('src/', 'include/', 'adapters/', 'tests/', 'cmake/'))
        and (p.endswith(('.c', '.h', '.cpp', '.hpp', '.cmake')) or p.endswith('CMakeLists.txt'))):
        frozen[p] = capture(p, 'sources/' + p)

commands = {}
cpu_peak = 0.0
for directory in sorted((root / 'evidence').glob('output-schema-numeric-*')):
    if not directory.is_dir() or not (directory / 'result.json').exists():
        continue
    rel = str(directory.relative_to(root))
    result = read_json(rel + '/result.json')
    plan = read_json(rel + '/plan.json')
    commands[rel] = {'result': capture(rel + '/result.json'),
                     'actual_exit_code': result['exit_code'],
                     'child_exit_code': result['child_exit_code'], 'argv': result['argv']}
    for sensor in plan['sensors']:
        if sensor['name'] in ('k10temp', 'coretemp'):
            cpu_peak = max(cpu_peak, result['peak_c'].get(sensor['path'], 0))
    for path in sorted(directory.iterdir()):
        name = str(path.relative_to(root))
        if path.is_file() and path.name != 'result.json':
            capture(name)

assert commands['evidence/output-schema-numeric-baseline-ctest-r1']['actual_exit_code'] == 8
assert commands['evidence/output-schema-numeric-expanded-build-r1']['actual_exit_code'] == 1
final_counts = {}
for stem, count in [('final-release', 4), ('final-asan', 7), ('provider', 3)]:
    rel = 'evidence/output-schema-numeric-' + stem + '-ctest-r1'
    assert commands[rel]['actual_exit_code'] == 0
    log = (root / rel / 'command.log').read_text()
    assert f'100% tests passed out of {count}' in log
    full = (root / rel / 'LastTest.log').read_text()
    assert len(re.findall(r'^\d+/\d+ Testing:', full, re.M)) == count
    if stem != 'provider':
        assert 'Exact output-schema: 9855 numeric checks; HOST NOT-INFERENCE' in full
        assert '16383 format, 4716 language oracles, 20 callback and 38 allocator refusals' in full
    assert not re.search(r'AddressSanitizer:|LeakSanitizer:|runtime error:', full)
    final_counts[stem] = count

raw_gpu = 'evidence/context-r33-integer-ar-r1'
collection = read_json(raw_gpu + '/collection.json')
assert collection['exit_code'] == 0 and len(collection['inventory']['files']) == 15
for name, expected in collection['inventory']['files'].items():
    assert bind(raw_gpu + '/' + name) == expected
gate = read_json(raw_gpu + '/http-schema-integer-result.json')
http = read_json(raw_gpu + '/http-result.json')
gpu = read_json(raw_gpu + '/result.json')
assert gate['state'] == 'FAILED' and len(gate['passed']) == 26
assert http['server_exit_code'] == 0 and gpu['exit_code'] == gpu['child_exit_code'] == 1
assert 'large-positive-exclusive' in gate['error']
for path in sorted((root / raw_gpu).iterdir()):
    if path.is_file(): capture(str(path.relative_to(root)))
closure_path = 'evidence/context-r33-ar-closure-r1.json'
closure = read_json(closure_path)
assert closure['actual_exit_code'] == 0
assert closure['result']['original_lease']['released']
assert not closure['result']['standing_lease_waiter_reservation']
assert all(x['supervisor_identity_absent'] and x['container_init_identity_absent'] and x['container_absent']
           for x in closure['result']['owned_window_closures'])
capture(closure_path)
for path in sorted((root / 'evidence').glob('context-r34-read-location-failure-*.json')):
    capture(str(path.relative_to(root)))

binaries = {}
for variant, names in [('release', ['test-output-schema', 'test-schema-integer', 'test-core-events', 'test-openai-core']),
                       ('asan', ['test-output-schema', 'test-schema-integer', 'test-core-events', 'test-openai-core',
                                 'test-tools', 'test-openai-http', 'test-synthetic-server'])]:
    prefix = 'build/output-schema-numeric-' + variant + '/'
    for name in names + ['liblie_core.a', 'liblie_sampling.a']:
        binaries[prefix + name] = bind(prefix + name)
    for name in ['CMakeCache.txt', 'build.ninja']:
        capture(prefix + name)
capture('evidence/seal-output-schema-integer-host-r1.py')
manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())}
members['raw-inventory.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive_path.parent.mkdir(parents=True, exist_ok=True)
with tarfile.open(archive_path, 'w:gz') as out:
    for name, data in sorted(members.items()):
        item = tarfile.TarInfo(name)
        item.size = len(data)
        item.mode = 0o644
        item.mtime = 0
        out.addfile(item, io.BytesIO(data))

receipt = {
 'schema': 'lie.output-schema-integer-host.v1', 'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state': 'HOST_PASSED_GPU_PENDING', 'source_parent_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
 'scope': 'Exact mathematical integer output classification and comparison with represented binary64 bounds; HOST fixtures only.',
 'previous_compiler_and_magnitude_source_unchanged_outside_added_comparator': True,
 'private_provider_inventory': provider, 'changed_provider_files': changed, 'unchanged_provider_files': 103,
 'immutable_upstream': previous['immutable_upstream'], 'frozen_sources': frozen,
 'actual_commands': commands, 'final_test_counts': final_counts,
 'independent_numeric_checks': 9855,
 'oracles': ['independent int64 intervals around +/-1e18', 'small signed half-integer boundaries',
             'hard-coded 309-digit DBL_MAX and one-unit neighbours', 'exact integrality after decimal/exponent normalization',
             'exponent saturation, long borrowed spans, malformed/nonfinite/aliasing refusal and preserved result',
             'existing format/language/allocator/callback oracles'],
 'sanitizer_execution': {'ASan': True, 'UBSan': True, 'LSan': True, 'outside_ptrace': True,
                         'options_unset': ['ASAN_OPTIONS', 'LSAN_OPTIONS', 'UBSAN_OPTIONS'], 'suppressions': False},
 'maximum_observed_local_CPU_C': cpu_peak,
 'guards': {'CPU_ceiling_C': 98, 'NVMe_ceiling_C': 85, 'lower_operating_limits': True, 'GPU': 'masked/observe-only'},
 'binaries': binaries,
 'retained_original_weight_failure': {'runtime_source': '9a4f45b11133df71a4f4b0e9a0dbcffd94ae04ef',
      'protocol_source': '7fb62c5a7f7cd8f1c8423d4fad73d8442206a61a', 'state': 'FAILED', 'passed': 26, 'expected': 66,
      'case': 'large-positive-exclusive', 'http_status': 502, 'server_exit_code': 0,
      'child_controller_supervisor_exit_code': 1, 'collection_exit_code': 0, 'collection_verified_files': 15,
      'MTP': 'not started', 'raw_directory': raw_gpu,
      'closure': {'path': closure_path, **bind(closure_path), 'at_utc': closure['result']['at_utc']},
      'closure_is_future_admission': False},
 'retained_HOST_failures': {'baseline_ctest_exit_code': 8, 'unregistered_core_only_target_build_exit_code': 1,
                           'read_discovery_metadata': sorted(p.name for p in (root / 'evidence').glob('context-r34-read-location-failure-*.json'))},
 'ABI_state_cache_event_metrics_layout_changes': False, 'reactive_or_worker_policy_changes': False,
 'new_dependency': False, 'native_product_default_tests_require_Python': False,
 'unqualified_precision_paths': ['general fractional-number bounds', 'numeric enum/const equality', 'multipleOf'],
 'pending': ['matching new-source HIP ON/OFF builds', 'complete original-weight AR66/MTP66 on .161 with fresh admission',
             'broader branch/fault/quality/resource and matched-cost gates'],
 'new_remote_job_client_build_lease_waiter_reservation': False, 'root_157_158_use': False,
 'all_six_owned_tasks_open': True, 'Terminal_Bench': 'STOPPED_COLLECTED_CLOSED_DEFERRED_LAST', 'publication': False,
 'portable_raw': {'path': str(archive_path.relative_to(root)), **bind(str(archive_path.relative_to(root))), 'members': len(members)}
}
draft = root / 'evidence/output-schema-integer-host-unsealed-r1'
if draft.exists():
    receipt['prior_unsealed_draft'] = {str(p.relative_to(root)): bind(str(p.relative_to(root)))
                                     for p in sorted(draft.iterdir()) if p.is_file()}
    receipt['prior_unsealed_draft_scope'] = 'Successful first generator output retained before adding standalone archive license/provenance notices; no test or GPU restart.'
assert cpu_peak == 75.5
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt': str(receipt_path.relative_to(root)), 'sha256': sha(receipt_path.read_bytes()),
                  'raw_members': len(members), 'raw_bytes': archive_path.stat().st_size,
                  'sources': len(frozen), 'provider': len(provider), 'changed_provider_files': changed,
                  'tests': final_counts, 'CPU_C': cpu_peak}))
