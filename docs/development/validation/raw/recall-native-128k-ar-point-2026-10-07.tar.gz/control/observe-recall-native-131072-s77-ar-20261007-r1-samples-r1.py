# SPDX-License-Identifier: MIT
"""Read already completed native rows from the same live job; no inference request."""
from pathlib import Path
import hashlib,json,subprocess

program = '''
from pathlib import Path
import datetime,json
root=Path('/home/pop/workspace/synapse-lie/recall-native-131072-s77-ar-20261007-r1')
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='7a966774-3424-46c3-8045-34f759ea58a1'
def ticks(pid):
 text=Path('/proc')/str(pid)/'stat';value=text.read_text();return int(value[value.rfind(')')+2:].split()[19])
job=json.loads((root/'result.json').read_text())
assert job['pid']==39081 and job['start_ticks']==2053279
assert ticks(job['pid'])==job['start_ticks']
assert ticks(40802)==2062391
assert (Path('/proc/40802/cgroup')).read_text().strip()=='0::/system.slice/docker-9938d0675ea81a05ebd51efba464a8aac25ec1716080ecd2786cd5a93fadae37.scope'
rows=[];partial=[]
with (root/'measurements.jsonl').open() as stream:
 for number,line in enumerate(stream,1):
  try:row=json.loads(line)
  except ValueError:partial.append(number);continue
  if row.get('event')=='sample':
   rows.append({key:row.get(key) for key in ('turn','prompt_tokens','output_tokens','cached_tokens','finish_reason','quality','assistant','server_timings','first_output_seconds','wall_seconds')})
assert ticks(job['pid'])==job['start_ticks']
print(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Interim already-completed rows; full job, saved wire, collection and closure not yet qualified.',
 'state':job['state'],'completed_samples':rows,'partial_JSON_lines':partial,'GPU_build_forward_or_mutation':False}))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':run.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':run.stdout,'stderr':run.stderr}
try:record['result']=json.loads(run.stdout)
except ValueError:pass
with Path('evidence/recall-native-131072-s77-ar-20261007-r1-interim-samples-r1.json').open('x') as stream:
 json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record.get('result',record)))
raise SystemExit(run.returncode)
