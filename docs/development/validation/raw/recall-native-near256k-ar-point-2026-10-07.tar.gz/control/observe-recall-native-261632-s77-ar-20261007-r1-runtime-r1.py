# SPDX-License-Identifier: MIT
"""Read the exact admitted server's threads and management snapshot during prefill."""
from pathlib import Path
import hashlib
import json
import subprocess

LABEL = 'recall-native-261632-s77-ar-20261007-r1'
manifest = json.loads((Path('evidence')/LABEL/'manifest.json').read_text())
live = json.loads(Path(f'evidence/{LABEL}-live-2.json').read_text())['result']
assert live['live_exact_supervisor'] and len(live['native_GPU_owners']) == 1
expected = live['native_GPU_owners'][0]
program = 'EXPECTED_RUNNER=' + repr(manifest['runner_sha256']) + '\nEXPECTED_GPU=' + repr(expected) + '\n' + '''
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,re,time,urllib.request
base=Path('/home/pop/workspace/synapse-lie')
root=base/'recall-native-261632-s77-ar-20261007-r1'
assert os.getuid()==1000 and root.resolve()==root
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='7a966774-3424-46c3-8045-34f759ea58a1'
assert hashlib.sha256((root/'runner.py').read_bytes()).hexdigest()==EXPECTED_RUNNER
spec=importlib.util.spec_from_file_location('point',root/'runner.py')
point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
job=json.loads((root/'result.json').read_text())
assert point.ticks(job['pid'])==job['start_ticks']
assert job['state']=='RUNNING_DISTROBOX' and job['container'] in EXPECTED_GPU['cgroup']
pid=EXPECTED_GPU['pid'];proc=Path('/proc')/str(pid)
assert point.ticks(pid)==EXPECTED_GPU['start_ticks']
assert (proc/'cgroup').read_text()==EXPECTED_GPU['cgroup']
status={}
for line in (proc/'status').read_text().splitlines():
 key,_,value=line.partition(':')
 if key in ('Name','State','Threads','VmPeak','VmSize','VmHWM','VmRSS','RssAnon','RssFile','RssShmem','voluntary_ctxt_switches','nonvoluntary_ctxt_switches'):
  status[key]=value.strip()
threads=[]
for path in sorted((proc/'task').iterdir(),key=lambda p:int(p.name)):
 try:
  fields=(path/'stat').read_text();fields=fields[fields.rfind(')')+2:].split()
  threads.append({'tid':int(path.name),'name':(path/'comm').read_text().strip(),'state':fields[0],
                  'user_ticks':int(fields[11]),'system_ticks':int(fields[12]),'start_ticks':int(fields[19])})
 except FileNotFoundError:
  threads.append({'tid':int(path.name),'vanished_during_read':True})
log=(root/'server.log').read_text()
match=re.search(r'management (http://127[.]0[.]0[.]1:[0-9]+)',log);assert match
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
responses=[]
for route in ('/actuator/llm','/actuator/llm/prefill'):
 start=time.monotonic()
 try:
  with opener.open(match.group(1)+route,timeout=5) as response:
   body=response.read(2*1024*1024+1);assert len(body)<=2*1024*1024
   responses.append({'route':route,'http_status':response.status,'wall_seconds':time.monotonic()-start,
                     'body':json.loads(body),'actual_exit_code':0})
 except Exception as error:
  responses.append({'route':route,'wall_seconds':time.monotonic()-start,'error':str(error),'actual_exit_code':1})
assert point.ticks(pid)==EXPECTED_GPU['start_ticks'] and (proc/'cgroup').read_text()==EXPECTED_GPU['cgroup']
print(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Read-only C1 server thread and management observations during the exact owned recall; not a latency or concurrency benchmark.',
 'job':root.name,'supervisor_identity':{'pid':job['pid'],'start_ticks':job['start_ticks']},
 'actual_GPU_identity':EXPECTED_GPU,'server_status':status,'actual_threads':threads,
 'management_listener':match.group(1),'management_responses':responses,
 'observation':point.observe(98,gpu_observation_only=True),
 'GPU_build_forward_lease_service_tuning_or_mutation':False}))
'''
argv = ['ssh', '-F', '/dev/null', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8',
        'pop@192.168.5.161', 'python3 -B -']
run = subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record = {'argv':argv,'actual_exit_code':run.returncode,
          'program_sha256':hashlib.sha256(program.encode()).hexdigest(),
          'stdout':run.stdout,'stderr':run.stderr}
try:
    record['result']=json.loads(run.stdout)
except ValueError:
    pass
with Path(f'evidence/{LABEL}-runtime-observation-r1.json').open('x') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
if 'result' in record:
    value=record['result']
    print(json.dumps({key:value[key] for key in ('at_utc','server_status','actual_threads','management_responses')}))
else:
    print(json.dumps(record))
raise SystemExit(run.returncode)
