# SPDX-License-Identifier: MIT
"""Seal own-child HOST supervision, visibly separate from model qualification."""
from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile

root=Path.cwd().resolve()
public=root/'docs/development/validation/steering-quality-supervision-host-2026-10-08.json'
raw=public.parent/'raw/steering-quality-supervision-host-2026-10-08.tar.gz'
assert not public.exists() and not raw.exists()
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(path.read_text())

sources=['tools/strix-point-steering-quality-run.py','tools/strix-point-steering-quality-gate.py',
         'tools/strix-point-steering-build-gate.py','tools/strix-point-http-recall-gate.py',
         'tests/test_strix_point_steering_quality_run.py','tests/test_strix_point_steering_quality.py',
         'tests/fixtures/steering-conciseness-v1.json','docs/development/protocols/STEERING-QUALITY-GPU-PROTOCOL.md',
         'LICENSE','CMakeLists.txt']
sources += [str(p.relative_to(root)) for p in sorted((root/'tools/native').iterdir()) if p.is_file()]
guards=['steering-quality-supervision-host-debug-r1','steering-quality-supervision-host-asan-r1',
        'steering-quality-supervision-ctest-debug-r1','steering-quality-supervision-ctest-asan-r1']
peaks={}
for name in guards:
    directory=root/'evidence'/name
    result=read(directory/'result.json')
    assert result['exit_code']==result['child_exit_code']==0 and result['reason'] is None
    for path,value in result['peak_c'].items():peaks[path]=max(peaks.get(path,-1),value)
    log=(directory/'command.log').read_text()
    if '-host-' in name:assert 'Ran 11 tests' in log and log.rstrip().endswith('OK')
    else:assert 'native-benchmark-contract' in log and 'Passed' in log and '100% tests passed' in log
    sources += [str(p.relative_to(root)) for p in sorted(directory.iterdir()) if p.is_file()]
assert max(peaks.values())<98
delta=subprocess.run(['git','diff','--quiet','4c703b3d604c6c877d6a2214d7aee0b15a013f61','--',
                      'src','include','adapters','cmake','CMakeLists.txt','tools/native','tools/steering-build.c'])
assert delta.returncode==0
sources += ['evidence/seal-steering-quality-supervision-host-r1.py']
assert len(sources)==len(set(sources))
inventory={name:{'bytes':(root/name).stat().st_size,'sha256':sha(root/name)} for name in sources}
with tarfile.open(raw,'x:gz') as tar:
    for name in sources:tar.add(root/name,arcname=name,recursive=False)
with tarfile.open(raw,'r:gz') as tar:
    assert len(tar.getmembers())==len(inventory)
    for member in tar.getmembers():
        assert member.isfile() and member.name in inventory
        data=tar.extractfile(member).read();wanted=inventory[member.name]
        assert len(data)==wanted['bytes'] and hashlib.sha256(data).hexdigest()==wanted['sha256']
receipt={'schema':'synapse-lie.steering-quality-supervision-host.v1',
 'state':'HOST_SERIAL_SUPERVISION_AND_NATIVE_CLIENTS_VERIFIED_MODEL_SERVERS_SIMULATED',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Own-child control/recording and strict synthetic HTTP wire review. No original weights, actual model server or numerical steering executed.',
 'tests':{'debug':11,'unsuppressed_native_asan_ubsan_lsan':11,'native_HTTP_samples_per_mode':70,
          'actual_native_client_children_per_mode':2,'simulated_model_server_lifetimes_per_mode':2,
          'focused_native_CTest_per_mode':1},
 'covered_failures':['Native timeout and partial-file retention.','Model load failure before client/second model.',
                     'Stored HTTP404 saved before refusal.','Failed first-server retirement prevents second model.',
                     'Byte-identical bank inode replacement.','Actual self-SIGTERM and handler restoration.',
                     'Replay refusal and bounded one-day deadline.','Arithmetic quality failure preserves all70 observations and actual native0.'],
 'actual_guard_exits':{name:read(root/'evidence'/name/'result.json')['exit_code'] for name in guards},
 'local_peak_C_by_sensor_path':peaks,'native_runtime_sources_byte_equal_to':'4c703b3d604c6c877d6a2214d7aee0b15a013f61',
 'native_fixture_binaries':{name:{'path':'build/'+name+'/synapse-lie-bench','sha256':sha(root/'build'/name/'synapse-lie-bench')}
                           for name in ('context-debug','tool-http-asan')},
 'product_Python_dependency_or_CMake_ABI_state_metrics_change':False,'new_build_directories':[],
 'original_model_loading_steering_quality_or_performance_qualified':False,
 'pending':['Outer campaign artifact/settings/corpus/qualified-bank provenance binding.','Successful original100-pair FFN learning and independent reconstruction.','Original-weight held-out response execution and exact whole-container closure.','Wider MTP/graph/correction/fault/vision/model/platform and matched cost.'],
 'separate_current_GPU_job':{'label':'recall-yarn4-261632-s77-ar-20261008-r1','manifest_sha256':'c63d2d144024ba784b49a6f050ea6f2c50de2568469ecd58bb1758c90db6e199',
                           'controller_handle':37799,'actual_observed_supervisor':103258,'actual_observed_GPU':105251,'qualification_pending':True},
 'GPU_run_build_model_hash_conversion_dependency_installation_or_publication_by_this_HOST_work':False,
 'roadmap':{'open_items':[2,3,4,5,6,7],'terminal_bench_last':True,'full_goal_complete':False},
 'raw':{'path':str(raw.relative_to(root)),'bytes':raw.stat().st_size,'sha256':sha(raw),
        'regular_members':len(inventory),'members':inventory},'actual_exit_code':0}
with public.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps({'state':receipt['state'],'members':len(inventory),'raw_bytes':raw.stat().st_size,'tests':receipt['tests'],'actual_exit_code':0}))
