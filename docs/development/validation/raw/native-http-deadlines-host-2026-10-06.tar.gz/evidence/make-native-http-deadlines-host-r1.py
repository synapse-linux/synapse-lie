# SPDX-License-Identifier: MIT
"""Seal native-client HOST evidence; never open models or contact a server."""
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
expected_parent = "96dc202d"
parent = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
assert parent.startswith(expected_parent)
assert subprocess.check_output(["git", "branch", "--show-current"], text=True).strip() == "feature/context-million-openai"
sources = [
    "tools/native/bench_native.h", "tools/native/http_transport.c",
    "tools/native/http_bench.c", "tools/native/http_curve.c",
    "tools/native/http_multi.c", "tests/test_native_bench.c",
    "tests/test_http_curve_native.c", "tests/test_http_multi_native.c",
]
binaries = ["synapse-lie-bench", "test-ssd-http-server",
            "test-synthetic-lie-bench", "test-steered-lie-bench",
            "test-native-bench", "test-http-multi-native", "test-http-curve-native"]
tests = ["native-benchmark-contract", "native-http-multi-contract",
         "native-http-curve-contract"]
members = {}
bindings = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def bind(path, portable=True):
    data = (root / path).read_bytes()
    row = {"path": path, "bytes": len(data), "sha256": digest(data)}
    bindings.append(row)
    if portable:
        assert path not in members
        members[path] = data
    return row


for path in sources:
    bind(path)
for path in ["CMakeLists.txt", "tests/fake_executor.c", "tests/bench_executor.c",
             "tests/ssd_read_gate.c", "tools/thermal-run.py",
             "evidence/http-timeout-preparation-failures-r1.json",
             "evidence/make-native-http-deadlines-host-r1.py"]:
    bind(path)

commands = []
cpu_maxima = []
for mode in ("release", "asan"):
    build = f"build/context-http-timeout-{mode}"
    cache = (root / build / "CMakeCache.txt").read_text()
    assert "LIE_GUFO_RUNTIME:BOOL=OFF" in cache
    assert "LIE_LEGACY_PYTHON_TESTS:BOOL=OFF" in cache
    assert f"LIE_SANITIZERS:BOOL={'ON' if mode == 'asan' else 'OFF'}" in cache
    assert "LIE_CORE_ONLY:BOOL=OFF" in cache
    for suffix in ("CMakeCache.txt", "build.ninja", "Testing/Temporary/LastTest.log",
                   "Testing/Temporary/CTestCostData.txt"):
        bind(f"{build}/{suffix}")
    for binary in binaries:
        bind(f"{build}/{binary}", portable=False)
    for stage in ("configure", "build", "ctest"):
        directory = f"evidence/http-timeout-{mode}-{stage}-r1"
        result = json.loads((root / directory / "result.json").read_text())
        plan = json.loads((root / directory / "plan.json").read_text())
        assert result["exit_code"] == result["child_exit_code"] == 0
        assert result["reason"] is None
        assert result["argv"][:7] == ["env", "-u", "ASAN_OPTIONS", "-u", "LSAN_OPTIONS", "-u", "UBSAN_OPTIONS"]
        cpus = [s for s in plan["sensors"] if s["name"] in ("k10temp", "coretemp")]
        assert cpus and all(s["limit_c"] <= 98 for s in cpus)
        assert all(s["limit_c"] <= 85 for s in plan["sensors"] if s["name"] == "nvme")
        assert all(s["limit_c"] is None and s["policy"] == "observe-only"
                   for s in plan["sensors"] if s["name"] == "amdgpu")
        cpu_maxima.extend(result["peak_c"][s["path"]] for s in cpus)
        for suffix in ("plan.json", "result.json", "temperatures.jsonl", "command.log"):
            bind(f"{directory}/{suffix}")
        if stage == "ctest":
            log = (root / directory / "command.log").read_text()
            assert "100% tests passed out of 3" in log
            for name in tests:
                assert re.search(r"Test\s+#\d+: " + re.escape(name) + r"\s+\.+\s+Passed", log)
        commands.append({"configuration": mode, "stage": stage, **result,
                         "sanitizer_test_outside_sandbox_ptrace": mode == "asan" and stage == "ctest"})

physical_path = "docs/development/validation/physical1m-fixed-point-gpu-2026-10-05.json"
physical_binding = bind(physical_path)
physical = json.loads((root / physical_path).read_text())
measurement = physical["measurement"]
assert measurement["prefill_tokens"] == 1048448 and measurement["output_tokens"] == 128
assert 7200 < measurement["total_ns"] / 1e9 < 14400
gpu_path = "docs/development/validation/c17-schema-compile-point-gpu-2026-10-06.json"
gpu_binding = bind(gpu_path)
members["source-and-documentation.patch"] = subprocess.check_output(["git", "diff", "--binary"])
manifest = [{"path": name, "bytes": len(data), "sha256": digest(data)}
            for name, data in sorted(members.items())]
members["MANIFEST.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
archive_path = "docs/development/validation/raw/native-http-deadlines-host-2026-10-06.tar.gz"
(root / archive_path).parent.mkdir(parents=True, exist_ok=True)
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode="wb", mtime=0, filename="") as compressed:
    with tarfile.open(fileobj=compressed, mode="w") as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
archive_bytes = buffer.getvalue()
with (root / archive_path).open("xb") as out:
    out.write(archive_bytes)
receipt = {
    "schema": "synapse-lie.native-http-deadlines-host.v1",
    "at_utc": datetime.now(timezone.utc).isoformat(),
    "state": "HOST_VALIDATED_NOT_GPU_QUALIFIED",
    "source_parent_commit": parent,
    "source_delta_sha256": digest(json.dumps([r for r in bindings if r["path"] in sources], sort_keys=True).encode()),
    "branch": "feature/context-million-openai",
    "scope": "Native C client timeout admission and report contracts only; synthetic child HTTP servers, no model forward, GPU performance or recall evidence.",
    "timeout_seconds": {"previous_maximum": 7200, "maximum": 86400,
                        "http_ordinary_default": 630, "http_long_context_default": 14400,
                        "http_curve_default": 3600, "http_multi_default": 630},
    "coverage": ["Every HTTP client completes its synthetic contract with timeout 86400",
                 "Ordinary HTTP default remains 630 in emitted identity",
                 "Long-context default 14400 is retained with three real synthetic HTTP calibration probes and the expected nonlinear-calibration refusal",
                 "HTTP CLI rejects 86400.001, zero, negative, NaN and infinity with exit 2",
                 "Shared transport rejects an excessive timeout before network work",
                 "Existing native HTTP/report/parser/PNG/SVG, prepared cohort and canonical curve contracts pass"],
    "tests": {"release": tests, "asan_ubsan_lsan": tests,
              "passes": 6, "unexpected_failures": 0,
              "private_ephemeral_loopback": True, "child_path_without_python": True,
              "sanitizer_options_unset": True, "suppressions": False,
              "asan_ubsan_lsan_executed_outside_sandbox_ptrace": True},
    "commands": commands,
    "maximum_local_cpu_c": max(cpu_maxima),
    "historical_1m_reference": {"binding": physical_binding,
                               "source_commit": physical["source_commit"],
                               "total_seconds": measurement["total_ns"] / 1e9,
                               "prefill_seconds": measurement["prefill_ns"] / 1e9,
                               "scope": physical["scope"]},
    "previous_gpu_receipt": gpu_binding,
    "new_gpu_run": False,
    "new_remote_job_lease_waiter_reservation": False,
    "server_runtime_or_model_state_change": False,
    "public_abi_or_ds4_cache_framing_change": False,
    "new_inference_worker_or_reactive_speedup_claim": False,
    "all_six_owned_tasks_open": True,
    "terminal_bench": "Stopped/collected/closed/deferred last",
    "publication": False,
    "bindings": bindings,
    "portable_raw_archive": {"path": archive_path, "bytes": len(archive_bytes),
                             "sha256": digest(archive_bytes), "members": len(members),
                             "scope": "Sources, commands, logs, thermal telemetry, build inputs, historical receipts and manifest; binary hashes remain in receipt, binaries are not redistributed."},
}
receipt_path = root / "docs/development/validation/native-http-deadlines-host-2026-10-06.json"
with receipt_path.open("x") as out:
    json.dump(receipt, out, indent=2)
    out.write("\n")
print(json.dumps({"receipt": str(receipt_path.relative_to(root)),
                  "bindings": len(bindings), "raw_members": len(members),
                  "archive_bytes": len(archive_bytes), "passes": 6,
                  "maximum_cpu_c": max(cpu_maxima)}))
