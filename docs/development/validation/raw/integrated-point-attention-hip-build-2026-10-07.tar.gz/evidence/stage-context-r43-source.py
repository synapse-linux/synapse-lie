# SPDX-License-Identifier: MIT
"""Copy a sealed owned capsule exclusively; no GPU/build/service operation."""
from pathlib import Path
import hashlib,json,subprocess
seal=json.loads(Path('evidence/context-r43-source-seal.json').read_text())
assert seal['source_commit']=='120e2fce40d830565c51d8818881a43b15de75f2'
assert seal['pristine_gufo_files_verified']==1019
assert len(seal['six_required_consumer_targets'])==6
assert seal['remote_stage_build_or_GPU_run'] is False
archive=Path('evidence/context-source-modern-r43.tar.gz').resolve()
with archive.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==seal['archive_sha256']
ssh=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161']
scp=['scp','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8']
output=Path('evidence/context-r43-source-stage.json')
assert not output.exists()
record={'source_seal':seal,'commands':[],'exit_code':None}
def run(argv, program=None):
    p=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=60)
    record['commands'].append({'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,
      'program_sha256':hashlib.sha256(program.encode()).hexdigest() if program else None})
    if p.returncode:record['exit_code']=p.returncode
    output.write_text(json.dumps(record,indent=2)+'\n')
    if p.returncode:raise SystemExit(p.returncode)
    return p
check='''from pathlib import Path
import json,os
base=Path('/home/pop/workspace/synapse-lie/rocm10-fedora-161')
assert base.resolve()==base and base.stat().st_uid==os.getuid()
for p in (base/'source-modern-r43',base/'source-modern-r43.tar.gz',base/'bundle-modern-r43'):
 assert not p.exists() and not p.is_symlink()
assert not (base.parent/'context-r43-build-r1').exists()
s=os.statvfs(base);free=s.f_bavail*s.f_frsize
print(json.dumps({'free_disk_bytes':free,'exclusive_destinations_absent':True}))
'''
run(ssh+['python3 -B -'],check)
run(scp+[str(archive),'pop@192.168.5.161:/home/pop/workspace/synapse-lie/rocm10-fedora-161/source-modern-r43.tar.gz'])
program='EXPECTED='+repr(seal)+'\n'+'''from pathlib import Path
import hashlib,json,os,tarfile
base=Path('/home/pop/workspace/synapse-lie/rocm10-fedora-161')
assert base.resolve()==base and base.stat().st_uid==os.getuid()
archive=base/'source-modern-r43.tar.gz';source=base/'source-modern-r43'
assert not source.exists() and not source.is_symlink() and not archive.is_symlink()
assert archive.stat().st_uid==os.getuid() and archive.stat().st_size==EXPECTED['archive_bytes']
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(archive)==EXPECTED['archive_sha256']
with tarfile.open(archive) as t:
 members=t.getmembers();assert members
 for m in members:
  p=Path(m.name)
  assert not p.is_absolute() and '..' not in p.parts and p.parts[0]=='context-source-modern-r43'
  assert m.isfile() or m.isdir()
 source.mkdir()
 for m in members:
  parts=Path(m.name).parts[1:]
  if not parts:continue
  m.name=str(Path(*parts));t.extract(m,source,filter='data')
assert sha(source/'SOURCE-FILES.sha256')==EXPECTED['source_files_sha256']
assert (source/'SOURCE-COMMIT.txt').read_text().strip()==EXPECTED['source_commit']
listed=set()
for line in (source/'SOURCE-FILES.sha256').read_text().splitlines():
 digest,sep,name=line.partition('  ');assert sep and name.startswith('./') and '..' not in Path(name).parts
 name=name[2:];assert name not in listed;listed.add(name)
 p=source/name;assert not p.is_symlink() and p.resolve().is_relative_to(source)
 assert sha(p)==digest,name
actual={str(p.relative_to(source)) for p in source.rglob('*') if p.is_file()}
assert actual==listed|{'SOURCE-FILES.sha256'}
assert sha(source/'cmake/point/Build.cmake')==EXPECTED['compile_helper_sha256']
print(json.dumps({'archive_sha256':sha(archive),'inventory_sha256':sha(source/'SOURCE-FILES.sha256'),
 'source_commit':EXPECTED['source_commit'],'source_files':len(listed),'GPU_build_or_run':False}))
'''
run(ssh+['python3 -B -'],program)
record['exit_code']=0;output.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'actual_exit_code':0,'source_commit':seal['source_commit'],'remote_source':'source-modern-r43'}))
