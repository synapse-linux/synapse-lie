# SPDX-License-Identifier: MIT
"""Read-only identity/lease/progress observation of the one owned native capture."""
from pathlib import Path
import hashlib,json,subprocess

program='''from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess
root=Path('/home/pop/workspace/synapse-lie/context-r39-sampling-text-r1')
r=json.loads((root/'result.json').read_text())
assert hashlib.sha256((root/'runner.py').read_bytes()).hexdigest()=='89f8f4edae2c9599d2636ae5dbf22345e039dcdc5afff602936fe48e19fd9a22'
spec=importlib.util.spec_from_file_location('point',root/'runner.py');point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
try:alive=point.ticks(r['pid'])==r['start_ticks']
except FileNotFoundError:alive=False
fds=[]
if alive:
 for p in Path('/proc').joinpath(str(r['pid']),'fd').iterdir():
  try:
   s=p.stat()
   if (s.st_dev,s.st_ino)==(66307,105946405):fds.append(int(p.name))
  except FileNotFoundError:pass
container_identity=None;state=None
if r.get('container'):
 q=subprocess.run(['docker','inspect','--format','{{json .State}}',r['container']],capture_output=True,text=True,timeout=15)
 if q.returncode==0:
  state=json.loads(q.stdout);init_pid=state.get('Pid',0)
  if init_pid>0:
   try:container_identity={'pid':init_pid,'start_ticks':point.ticks(init_pid),'container':r['container']}
   except FileNotFoundError:pass
events=[];path=root/'capture/capture.jsonl'
if path.exists():
 assert path.is_file() and not path.is_symlink() and path.stat().st_size<=8*2**20
 with path.open() as stream:
  for raw in stream:
   if not raw.endswith('\\n'):break
   events.append(json.loads(raw))
row=point.observe(98,gpu_observation_only=True)
result={'container_init_observed_identity':container_identity,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'supervisor_pid':r['pid'],'supervisor_start_ticks':r['start_ticks'],'live_exact_supervisor':alive,
 'original_lease_fds':fds,'state':r['state'],'model_attempted':r.get('model_attempted'),
 'capture_started':path.exists(),'profiles_begun':sum(v.get('event')=='profile_begin' for v in events),
 'profiles_complete':sum(v.get('event')=='profile_complete' for v in events),
 'raw_rows_complete':sum(v.get('event')=='row' for v in events),
 'capture_terminal':events[-1] if events and events[-1].get('event') in ('complete','failed') else None,
 'capture_result':r.get('capture_result'),'observation':row,'container_state':state,
 'new_GPU_job_build_or_restart':False}
result['active_owner_observed']=bool(alive and fds and r['state'] in ('ADMITTED','RUNNING_DISTROBOX'))
print(json.dumps(result))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
p=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
r={'argv':argv,'actual_exit_code':p.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':p.stdout,'stderr':p.stderr}
try:r['result']=json.loads(p.stdout)
except ValueError:pass
with Path('evidence/context-r39-text-live-r2.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in r.get('result',r).items() if k not in ('observation','stdout','capture_result')}))
raise SystemExit(p.returncode)
