# SPDX-License-Identifier: MIT
"""Offline original-row sampling qualification; no model forward or GPU access."""
from pathlib import Path
import hashlib,json,subprocess,sys

assert len(sys.argv)==2 and sys.argv[1] in ('release','asan')
kind=sys.argv[1];base=Path('build/sampling-original-r82-'+kind)
root=Path('evidence/context-r39-'+kind+'-replay');root.mkdir(exist_ok=False)
capture=Path('evidence/context-r39-sampling-text-r1/capture').resolve()
prior=json.loads(Path('docs/development/validation/sampling-tools-host-2026-10-07.json').read_text())
for name,item in prior['source_files'].items():
    data=Path(name).read_bytes();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
libraries={name:item for name,item in prior['read_only_qualified_libraries'].items()
           if '/final-integrated-r76-provider-'+kind+'/' in name}
assert len(libraries)==3
for name,item in libraries.items():
    data=Path(name).read_bytes();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
for stage in ('configure','build'):
    result=json.loads(Path('evidence/context-r39-replay-'+kind+'-'+stage+'/result.json').read_text())
    assert result['exit_code']==result['child_exit_code']==0
identity=json.loads((capture/'capture.jsonl').read_text().splitlines()[0])
assert identity['synthetic'] is False and identity['build_id']=='rocm10-point-modern-r38-runtime'
def bound(path):
    path=Path(path);assert path.is_file() and not path.is_symlink()
    with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':digest}
r={'scope':'ORIGINAL_WEIGHT_AR_RAW_ROW_OFFLINE_NUMERICAL_QUALIFICATION_ONLY',
   'kind':kind,'capture_manifest':bound(capture/'capture.jsonl'),'capture_identity':identity,
   'sources_unchanged':prior['source_files'],'read_only_qualified_libraries':libraries,
   'commands':[],'exit_code':1,'new_model_GPU_forward':False,
   'MTP_controller_tool_quality_fault_resources_performance_qualified':False}
target=root/'result.json';target.write_text(json.dumps(r,indent=2)+'\n')
for arm in ('reference','candidate','fallback'):
    binary=base/(arm+'-sampling-replay');proof=bound(binary)
    argv=[str(binary),'--capture',str(capture)]
    stdout=root/(arm.upper()+'.txt');stderr=root/(arm.upper()+'.stderr')
    with stdout.open('xb') as out,stderr.open('xb') as err:
        p=subprocess.run(argv,stdout=out,stderr=err,timeout=300)
    r['commands'].append({'arm':arm,'argv':argv,'actual_exit_code':p.returncode,
                          'bound_binary':proof,'stdout':bound(stdout),'stderr':bound(stderr)})
    target.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({'arm':arm,'actual_exit_code':p.returncode,'stdout_bytes':stdout.stat().st_size,
                      'stderr':stderr.read_text()[:1200]}),flush=True)
assert all(row['actual_exit_code']==0 for row in r['commands'])
assert len({row['stdout']['sha256'] for row in r['commands']})==1
for row in r['commands']:
    text=Path(row['stdout']['path']).read_text()
    assert 'ROWS=96 COMPLETE_OFFLINE_WITNESSES_NOT_FULL_ACCEPTANCE' in text
    assert 'CLASS=ORIGINAL-WEIGHT-ROW-REPLAY' in text
    assert text.count('profile=')>=96
r.update(exit_code=0,state='AR96_THREE_ARMS_FULL_WITNESS_AND_INDEPENDENT_MASS_RESIDUAL_ORACLES_PASS',
         complete_witness_sha256=r['commands'][0]['stdout']['sha256'],
         complete_witness_lines=sum(1 for _ in Path(r['commands'][0]['stdout']['path']).open()))
target.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ('state','kind','exit_code','complete_witness_sha256','complete_witness_lines')}))
