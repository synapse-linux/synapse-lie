# SPDX-License-Identifier: MIT
"""Seal HOST checking-code evidence without qualifying original inference."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import subprocess
import tarfile

root=Path.cwd().resolve()
public=root/'docs/development/validation/steering-quality-checker-host-2026-10-08.json'
raw=public.parent/'raw/steering-quality-checker-host-2026-10-08.tar.gz'
assert not public.exists() and not raw.exists()
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(path.read_text())

names=['tools/strix-point-steering-quality-gate.py','tools/strix-point-steering-build-gate.py',
       'tests/test_strix_point_steering_quality.py','tests/fixtures/steering-conciseness-v1.json',
       'docs/development/protocols/STEERING-QUALITY-GPU-PROTOCOL.md','LICENSE','CMakeLists.txt']
names += [str(p.relative_to(root)) for p in sorted((root/'tools/native').iterdir()) if p.is_file()]
guards=['steering-quality-host-debug-r1','steering-quality-host-debug-r2',
        'steering-quality-host-debug-r3','steering-quality-host-asan-r1',
        'steering-quality-host-asan-r2','steering-quality-native-ctest-debug-r1',
        'steering-quality-native-ctest-asan-r1', 'steering-quality-host-public-seal-guard-r1']
peaks={}
for name in guards:
    directory=root/'evidence'/name
    outcome=read(directory/'result.json')
    expected=1 if name in ('steering-quality-host-debug-r1','steering-quality-host-public-seal-guard-r1') else 0
    assert outcome['exit_code']==outcome['child_exit_code']==expected and outcome['reason'] is None
    for path,value in outcome['peak_c'].items():peaks[path]=max(peaks.get(path,-1),value)
    log=(directory/'command.log').read_text()
    if name in ('steering-quality-host-debug-r3','steering-quality-host-asan-r2'):
        assert 'Ran 13 tests' in log and log.rstrip().endswith('OK')
    if 'ctest-' in name:
        assert 'native-benchmark-contract' in log and 'Passed' in log and '100% tests passed' in log
    names += [str(p.relative_to(root)) for p in sorted(directory.iterdir()) if p.is_file()]
assert max(peaks.values())<98
unchanged=subprocess.run(['git','diff','--quiet','4c703b3d604c6c877d6a2214d7aee0b15a013f61','--',
                          'src','include','adapters','tools/native','tools/steering-build.c','CMakeLists.txt'])
assert unchanged.returncode==0
names += ['evidence/seal-steering-quality-host-r1.py', 'evidence/seal-steering-quality-host-r2.py', 'evidence/prepare-steering-quality-host-seal-r2.py']
assert len(names)==len(set(names))
inventory={name:{'bytes':(root/name).stat().st_size,'sha256':sha(root/name)} for name in names}
with tarfile.open(raw,'x:gz') as archive:
    for name in names:archive.add(root/name,arcname=name,recursive=False)
with tarfile.open(raw,'r:gz') as archive:
    assert len(archive.getmembers())==len(inventory)
    for member in archive.getmembers():
        assert member.isfile() and member.name in inventory
        data=archive.extractfile(member).read();wanted=inventory[member.name]
        assert len(data)==wanted['bytes'] and hashlib.sha256(data).hexdigest()==wanted['sha256']
spec=importlib.util.spec_from_file_location('held_out_steering',root/'tools/strix-point-steering-quality-gate.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
data=gate.corpus(read(root/'tests/fixtures/steering-conciseness-v1.json'))
binaries={name:{'path':'build/'+name+'/synapse-lie-bench','sha256':sha(root/'build'/name/'synapse-lie-bench')}
          for name in ('context-debug','tool-http-asan')}
receipt={'schema':'synapse-lie.steering-quality-checker-host.v1',
 'state':'HOST_HELD_OUT_CHECKER_AND_NATIVE_HTTP_CLIENT_VERIFIED_NOT_INFERENCE',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Strict review of synthetic saved-SSE responses and applied-plan snapshots; original weights and real GPU steering are not executed.',
 'native_runtime_sources_byte_equal_to':'4c703b3d604c6c877d6a2214d7aee0b15a013f61',
 'tests':{'debug':13,'unsuppressed_native_asan_ubsan_lsan':13,
          'native_HTTP_samples_per_mode':70,'own_native_children_per_mode':2,'focused_CTest_per_mode':1},
 'corpus':{'training_pairs':len(data['training_questions']),'held_out_questions':len(data['held_out']),
           'sha256':sha(root/'tests/fixtures/steering-conciseness-v1.json')},
 'predeclared_scales':[scale for _label,scale in gate.SCALES],
 'acceptance':'All70 arithmetic answers and natural stops;10 absent/zero text/count matches;median length ratios<=0.8 at-1 and>=1.2 at+2, with8/10 expected-sign cases each.',
 'actual_exit_codes':{name:read(root/'evidence'/name/'result.json')['exit_code'] for name in guards},
 'preserved_initial_failure':{'actual_exit_code':1,'source_and_dataset_preserved':True,
       'causes':['Duplicate minute-conversion training question was refused before review.','Sandbox refused private loopback socket creation.'],
       'correction':'Use100 unique questions; run own-loopback fixtures outside sandbox. No parser or quality criterion was weakened.',
       'original_model_quality_or_GPU_failure':False},
 'preserved_sealing_failure':{'actual_exit_code':1,'cause':'Broad suffix test mistook successful native CTest debug-r1 for the earlier failed Python checking group.','same_successful_native_and_checker_results_reused':True},
 'native_fixture_binaries':binaries,'local_peak_C_by_sensor_path':peaks,
 'product_default_or_CMake_Python_dependency_added':False,
 'original_weight_quality_or_matched_performance_qualified':False,
 'GPU_remote_model_or_service_mutation':False,'new_build_directories':[],
 'pending':['Supervised original-weight campaign integration.','Successful100-pair original FFN training and independent bank reconstruction.','Original held-out answer/parity/response-length observations.','General quality, othermodels, MTP, graph/correction/fault/vision and matched cost.'],
 'roadmap':{'open_items':[2,3,4,5,6,7],'terminal_bench_last':True,'full_goal_complete':False},
 'raw':{'path':str(raw.relative_to(root)),'bytes':raw.stat().st_size,'sha256':sha(raw),
        'regular_members':len(inventory),'members':inventory},'actual_exit_code':0}
with public.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps({'state':receipt['state'],'regular_members':len(inventory),'raw_bytes':raw.stat().st_size,
                  'tests':receipt['tests'],'preserved_failure_exit':1,'actual_exit_code':0}))
