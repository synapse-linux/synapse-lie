# SPDX-License-Identifier: MIT
"""Correct exact failure-record selection; retain the failed sealing attempt."""
from pathlib import Path
import json

old=Path('evidence/seal-steering-quality-host-r1.py')
text=old.read_text()
text=text.replace("'steering-quality-native-ctest-asan-r1']", "'steering-quality-native-ctest-asan-r1', 'steering-quality-host-public-seal-guard-r1']")
text=text.replace("expected=1 if name.endswith('debug-r1') else 0", "expected=1 if name in ('steering-quality-host-debug-r1','steering-quality-host-public-seal-guard-r1') else 0")
text=text.replace("names += ['evidence/seal-steering-quality-host-r1.py']", "names += ['evidence/seal-steering-quality-host-r1.py', 'evidence/seal-steering-quality-host-r2.py', 'evidence/prepare-steering-quality-host-seal-r2.py']")
text=text.replace(" 'native_fixture_binaries':binaries", " 'preserved_sealing_failure':{'actual_exit_code':1,'cause':'Broad suffix test mistook successful native CTest debug-r1 for the earlier failed Python checking group.','same_successful_native_and_checker_results_reused':True},\n 'native_fixture_binaries':binaries")
assert "name.endswith('debug-r1')" not in text
with Path('evidence/seal-steering-quality-host-r2.py').open('x') as output:output.write(text)
print(json.dumps({'state':'EXACT_HISTORY_SELECTION_CORRECTED_WITH_FAILURE_PRESERVED','actual_exit_code':0}))
