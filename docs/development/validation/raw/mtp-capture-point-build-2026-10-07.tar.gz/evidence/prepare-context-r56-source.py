# SPDX-License-Identifier: MIT
"""Prepare sealed current compiler inputs locally; no model/GPU/remote work."""
from pathlib import Path
import datetime,gzip,hashlib,json,re,shutil,subprocess,tarfile
root=Path.cwd(); label='context-source-modern-r56'; out=root/'evidence'/label; archive=out.with_suffix('.tar.gz')
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert commit=='c6625f094bd7815493a3364703757486027d48ec'
assert not subprocess.check_output(['git','status','--porcelain'])
assert not out.exists() and not archive.exists()
def sha(p):
    with p.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
receipt_path=root/'docs/development/validation/mtp-capture-host-2026-10-07.json'
r=json.loads(receipt_path.read_text()); raw=receipt_path.parent/r['portable_raw_archive']['path']
assert r['classification']=='HOST-NOT-INFERENCE' and r['MTP_capture_writer_replay_complete'] is True
assert r['observer_ABI']==1 and r['owned_sampling_file_inventory']==122
assert r['variant_files_verified']==1019 and r['optional_mocked_supervisor_collector_checks']==18
assert all(sum(q['passed'] for q in r['release_and_sanitizer_tests'] if q['configuration']==mode)==11 for mode in ('release','asan'))
assert r['new_GPU_model_remote_operation'] is False and r['independent_portable_review']['proof']['actual_exit_code']==0
assert sha(raw)==r['portable_raw_archive']['sha256']
for name,identity in r['implementation_sources'].items(): assert sha(root/name)==identity['sha256'],name
out.mkdir(); copied=[]; excluded=0
process=subprocess.Popen(['git','archive','--format=tar',commit],stdout=subprocess.PIPE)
try:
    with tarfile.open(fileobj=process.stdout,mode='r|') as tracked:
        for member in tracked:
            p=Path(member.name)
            assert not p.is_absolute() and '..' not in p.parts and (member.isfile() or member.isdir())
            if p.parts[0]=='docs':
                if member.isfile(): excluded+=1
                continue
            tracked.extract(member,out,filter='data')
            if member.isfile(): copied.append(member.name)
finally: process.stdout.close()
assert process.wait()==0
for name in copied: assert sha(out/name)==sha(root/name),name
upstream=root/'.deps/gufo-f783fedb'; manifest=json.loads((out/'third_party/gufo-source.json').read_text())
pin='f783fedb9bea2ec7de941f6da4e02f4a4596b29e'
assert upstream.resolve()==upstream and manifest['commit']==pin and len(manifest['files'])==1019
for name,digest in manifest['files'].items():
    p=upstream/name; assert not p.is_symlink() and p.resolve().is_relative_to(upstream) and sha(p)==digest
    target=out/'.deps/gufo-f783fedb'/name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,target)
    assert sha(target)==digest
# Independently compose all current source recipes before staging compiler inputs.
text=(out/'cmake/provider/Source.cmake').read_text()
recipes=re.search(r'set\(manifests ([^)]*)\)',text).group(1).split()+['kvc-edits.json']
assert len(recipes)==len(set(recipes))==42
files=dict(manifest['files']); changed={}; edits=0; recipe_hashes={}
for name in recipes:
    p=out/'adapters/gufo-state'/name; recipe=json.loads(p.read_text()); assert recipe['source_pin']==pin
    recipe_hashes[name]=sha(p)
    for edit in recipe['edits']:
        path=edit['path']; content=changed.get(path)
        if content is None: content=(upstream/path).read_text()
        assert edit['old'] and content.count(edit['old'])==1,(name,path)
        changed[path]=content.replace(edit['old'],edit['new'],1); edits+=1
        files[path]=hashlib.sha256(changed[path].encode()).hexdigest()
for mode in ('release','asan'):
    assert files==json.loads((root/('build/mtp-capture-sampling-r55-'+mode+'/variant-files.json')).read_text())
prior_path=root/'evidence/context-r11-build-r2/result.json'
prior=json.loads(prior_path.read_text())['build_result']; zstd={}
for name,key in {'zstd.h':'zstd_header_sha256','zstd_errors.h':'zstd_errors_sha256','LICENSE':'zstd_license_sha256'}.items():
    p=root/'evidence/context-source-modern-r11/third_party/point-zstd-dev'/name
    assert p.is_file() and not p.is_symlink() and sha(p)==prior[key]
    target=out/'third_party/point-zstd-dev'/name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,target)
    zstd[name]=sha(target)
ryu=json.loads((out/'third_party/ryu-source.json').read_text())
for name,identity in ryu['files'].items(): assert sha(out/'third_party/ryu'/name)==identity['sha256']
(out/'SOURCE-COMMIT.txt').write_text(commit+'\n'); (out/'CODE-CHECKPOINT.txt').write_text(commit+'\n')
paths=sorted(p for p in out.rglob('*') if p.is_file()); assert all(not p.is_symlink() for p in paths)
(out/'SOURCE-FILES.sha256').write_text(''.join(sha(p)+'  ./'+str(p.relative_to(out))+'\n' for p in paths))
with archive.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as package: package.add(out,arcname=label)
record={'scope':'LOCAL_SEALED_COMPILER_INPUTS_NOT_REMOTE_BUILD_OR_GPU',
        'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':commit,'code_checkpoint':commit,
        'engine_code_checkpoint':commit,'previous_goal_turn':'PROGRESS-c6625f09',
        'MTP_capture_host_receipt_sha256':sha(receipt_path),'MTP_capture_host_archive_sha256':sha(raw),
        'native_client_tests':{'Release':11,'ASan_UBSan_LSan':11,'mocked_supervisor_collector':18},
        'provider_source':{'pristine_files':1019,'recipes':len(recipes),'edits':edits,'recipe_sha256':recipe_hashes},
        'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
        'source_files_sha256':sha(out/'SOURCE-FILES.sha256'),'source_files':len(paths),
        'compile_helper_sha256':sha(out/'cmake/point/Build.cmake'),'runner_sha256':sha(out/'tools/strix-point-campaign.py'),
        'gufo_pin':pin,'pristine_gufo_files_verified':1019,'owned_sampling_file_inventory':122,
        'zstd_prior_receipt_sha256':sha(prior_path),'zstd_development_sha256':zstd,
        'ryu_pin':ryu['commit'],'unchanged_Ryu_files_verified':len(ryu['files']),
        'tracked_compiler_files_verified':len(copied),'excluded_documentation_files':excluded,
        'six_required_consumer_targets':['synapse-lie-server','synapse-lie-bench','synapse-lie-bench-gufo-reference',
                                         'lie-hip-probe','lie-sampling-capture','lie-attention-qualify'],
        'new_owner_only_observation_API':True,'numerical_algorithms_or_reactive_scheduler_changed':False,
        'remote_stage_build_or_GPU_run':False,'all_six_tasks_remain_open':True}
with (root/'evidence/context-r56-source-seal.json').open('x') as stream: json.dump(record,stream,indent=2); stream.write('\n')
print(json.dumps({k:record[k] for k in ('scope','source_commit','archive_bytes','source_files',
                                      'tracked_compiler_files_verified','provider_source')}),flush=True)
