# SPDX-License-Identifier: MIT
"""Review complete saved SSE independently; retain passes and quality misses alike."""
import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import tarfile

ROOT = Path.cwd()
LABEL = 'recall-yarn4-131072-s77-ar-20261008-r1'
JOB = ROOT/'evidence'/LABEL
PUBLIC = ROOT/'docs/development/validation/recall-yarn4-128k-ar-point-2026-10-08.json'
RAW = PUBLIC.parent/'raw/recall-yarn4-128k-ar-point-2026-10-08.tar.gz'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def strict(text):
    def pairs(items):
        result = {}
        for key,value in items:
            assert key not in result, 'Duplicate property'
            result[key] = value
        return result
    return json.loads(text,object_pairs_hook=pairs,
                      parse_constant=lambda _value: (_ for _ in ()).throw(ValueError('Nonfinite')))

def read(path):
    return strict(path.read_text())

assert not PUBLIC.exists() and not RAW.exists()
manifest = read(JOB/'manifest.json')
job = read(JOB/'result.json')
collection = read(JOB/'collection.json')
closure = read(ROOT/'evidence'/f'{LABEL}-closure-r2.json')
assert job['state'] in ('PASSED','FAILED')
assert type(job['exit_code']) is int and job['exit_code'] == job['child_exit_code']
assert job['model_stat_unchanged'] is True and not job['cleanup_failures']
assert read(JOB/'controller-result.json')['exit_code'] == job['exit_code']
assert collection['exit_code'] == closure['actual_exit_code'] == 0
assert closure['result']['state'] == 'WHOLE_CONTAINER_AND_EXACT_GPU_IDENTITIES_CLOSED_NO_STANDING_RESERVATION'
inventory = collection['inventory']['files']
assert len(inventory) == 18
for name,identity in inventory.items():
    path = JOB/name
    assert path.is_file() and not path.is_symlink()
    assert path.stat().st_size == identity['bytes'] and sha(path) == identity['sha256'], name
assert inventory['runner.py']['sha256'] == manifest['runner_sha256']
assert inventory['http-recall-gate.py']['sha256'] == manifest['http_recall_gate_sha256']
assert inventory['http-recall-settings.json']['sha256'] == manifest['http_recall_settings_sha256']
assert sha(JOB/'runner.py') == sha(ROOT/'tools/strix-point-campaign.py')
spec = importlib.util.spec_from_file_location('bound_recall_checker',JOB/'http-recall-gate.py')
gate = importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
settings = read(JOB/'http-recall-settings.json')
assert settings == manifest['http_recall']
assert settings['size'] == 131072 and settings['context'] == 1048576
assert settings['seed'] == 77 and settings['rope_scaling'] == 'yarn4' and settings['chunk'] == 256
rows = gate.json_lines(JOB/'measurements.jsonl',32*1024*1024)
cases = gate.json_lines(JOB/'requests.jsonl',8*1024*1024)
proof = gate.validate(rows,cases,settings,'ar')
assert proof['state'] in ('PASSED','QUALITY_FAILED')
expected_exit = 0 if proof['state'] == 'PASSED' else 1
assert job['exit_code'] == expected_exit
assert job['state'] == ('PASSED' if expected_exit == 0 else 'FAILED')
helper = read(JOB/'http-recall-result.json')
assert helper['state'] == proof['state'] and helper['client_exit_code'] == expected_exit
assert helper['server_exit_code'] == 0 and not helper['cleanup_errors']
assert helper['requests_sha256'] == sha(JOB/'requests.jsonl')
assert helper['measurements_sha256'] == sha(JOB/'measurements.jsonl')

# Reassemble the saved wire, rather than trusting the client's assembled answer.
observations = []
for row in rows[1:-1]:
    chunks = row['response_chunks']
    assert chunks and row['stream_complete'] is True
    request = row['request']
    assert request['model'] == gate.MODEL_ID and request['temperature'] == 0
    assert request['stream'] is True and request['stream_options'] == {'include_usage':True}
    assert not any(key in request for key in ('expected','corpus','followups'))
    identifier = chunks[0]['id']
    text = ''
    finishes,usages,timings = [],[],[]
    for chunk in chunks:
        assert chunk['id'] == identifier and chunk['object'] == 'chat.completion.chunk'
        assert chunk['model'] == gate.MODEL_ID and chunk['system_fingerprint'] == 'gufo-embedded-f783fedb'
        for choice in chunk['choices']:
            assert type(choice['index']) is int and choice['index'] == 0
            delta = choice['delta']
            assert not any(key in delta for key in ('tool_calls','function_call'))
            text += delta.get('content','')
            if choice.get('finish_reason') is not None:
                finishes.append(choice['finish_reason'])
        if chunk.get('usage') is not None: usages.append(chunk['usage'])
        if chunk.get('lie_timings') is not None: timings.append(chunk['lie_timings'])
    assert len(finishes) == len(usages) == len(timings) == 1
    assert finishes[0] == row['finish_reason'] and usages[0] == row['usage']
    assert text == row['assistant']['content'] and timings[0] == row['server_timings']
    assert 'tool_calls' not in row['assistant']
    phase = timings[0]
    assert phase['decode_mode'] == 'ar' and phase['mtp_drafted_tokens'] == phase['mtp_accepted_tokens'] == 0
    assert phase['cached_tokens'] == phase['ssd_cached_tokens'] == 0
    assert phase['prefill_tokens'] == usages[0]['prompt_tokens'] == row['prompt_tokens']
    assert phase['decode_tokens'] == usages[0]['completion_tokens'] == row['output_tokens']
    assert phase['output_token_limit'] == request['max_tokens']
    assert phase['prefill_calls'] == math.ceil(row['prompt_tokens']/settings['chunk'])
    assert phase['decode_calls'] == row['output_tokens'] + (finishes[0] == 'stop')
    if row['event'] == 'sample':
        turn = row['turn']
        assert finishes[0] in ('stop','length')
        try: answer = strict(text)
        except (ValueError,TypeError): answer = None
        expected = cases[0]['expected'][turn]['value']
        matched = type(answer) is dict and all(type(value) is str for value in answer.values()) and answer == expected
        assert row['quality']['pass'] is matched
        observations.append({'turn':turn,'prompt_tokens':row['prompt_tokens'],
            'output_tokens':row['output_tokens'],'cached_tokens':0,'exact_match':matched,
            'expected':expected,'actual_answer':text,'finish_reason':finishes[0],
            'prefill_ms':phase['prefill_ms'],'decode_ms':phase['decode_ms'],
            'prefill_tokens_per_second':phase['prefill_tokens_per_second'],
            'decode_tokens_per_second':phase['decode_tokens_per_second'],
            'ttft_seconds':row['first_output_seconds'],'wall_seconds':row['wall_seconds']})
assert len(observations) == 2
assert observations[0]['prompt_tokens'] == cases[0]['expected_prompt_tokens']
record_tokens = (rows[2]['usage']['prompt_tokens'] - rows[1]['usage']['prompt_tokens']) // 8
assert record_tokens > 0
assert settings['size'] - record_tokens < observations[0]['prompt_tokens'] <= settings['size']
assert observations[1]['prompt_tokens'] > observations[0]['prompt_tokens']
assert sum(o['exact_match'] for o in observations) == proof['quality_summary']['passes']
telemetry = [strict(line) for line in (JOB/'telemetry.jsonl').read_text().splitlines()]
peaks = {}
for row in telemetry:
    for sensor in row['temperatures']:
        peaks[sensor['name']] = max(peaks.get(sensor['name'],-math.inf),sensor['value_c'])
assert peaks['k10temp'] < 98 and peaks['nvme'] < 85
peers = read(ROOT/'evidence'/f'{LABEL}-peer-coordination-r2.json')
assert len(peers['peer_declarations']) == 4 and peers['explicit_current_161_non_use_from_all_three']
assert peers['separate_GLM_current_161_non_use'] and peers['last_observed_boot_identity_declared_to_all_four']
live = read(ROOT/'evidence'/f'{LABEL}-live-2.json')
assert live['actual_exit_code'] == 0 and live['result']['live_exact_supervisor'] is True
live_result = live['result']
assert live_result['actual_live_init_identity']['pid'] == job['container_host_pid']
assert live_result['actual_live_init_identity']['start_ticks'] == job['container_start_ticks']
assert len(live_result['native_GPU_owners']) == 1
gpu = live_result['native_GPU_owners'][0]
assert gpu['cgroup'].strip() == '0::/system.slice/docker-'+job['container']+'.scope'
assert any(p['pid']==gpu['pid'] and p['start_ticks']==gpu['start_ticks'] and p['exact_identity_absent']
           for p in closure['result']['identities'])
snapshot = {'scope':'Actual contemporaneous supervisor/init/GPU identities; no management-latency or thread-role census.',
            'actual_GPU_identity':gpu,'actual_live_init_identity':live_result['actual_live_init_identity']}
assert closure['result']['model_stats_reverified_unchanged'] is True
assert closure['result']['collected_artifacts_reverified'] == inventory
parts = [(p,'job/'+p.name) for p in sorted(JOB.iterdir()) if p.is_file() and not p.is_symlink()]
names = [f'{LABEL}-manifest.json',f'{LABEL}-settings.json',f'{LABEL}-readiness.json',
         f'{LABEL}-preparation-recipes.json',f'{LABEL}-jobs-prepared.json',
         f'{LABEL}-peer-coordination-r2.json',f'{LABEL}-closure-r2.json',
         f'before-{LABEL}-fresh-r1.json',
         f'launch-{LABEL}.py',f'observe-{LABEL}.py',f'close-{LABEL}-r1.py',f'close-{LABEL}-r2.py',f'prepare-{LABEL}-remote.py',
         f'before-{LABEL}-fresh-r1.py',
         'prepare-recall-yarn4-131072-s77-ar-20261008-r1-local.py',
         'prepare-seal-recall-yarn4-131072-r1.py', f'{LABEL}-release-notifications-r1.json']
names += [p.name for p in sorted((ROOT/'evidence').glob(f'{LABEL}-live-*.json'))]

parts += [(ROOT/'evidence'/name,'control/'+name) for name in names]
parts += [(Path(__file__),'recipe/'+Path(__file__).name),
          (ROOT/'tools/strix-point-bench-collect.py','source/strix-point-bench-collect.py'),
          (ROOT/'LICENSE','source/LICENSE')]
raw_inventory = [{'path':name,'bytes':p.stat().st_size,'sha256':sha(p)} for p,name in parts]
with tarfile.open(RAW,'x:gz') as archive:
    for path,name in parts: archive.add(path,arcname=name,recursive=False)
with tarfile.open(RAW,'r:gz') as archive:
    assert len(archive.getmembers()) == len(raw_inventory)
    for item in raw_inventory:
        data = archive.extractfile(item['path']).read()
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
receipt = {
 'schema':'synapse-lie.original-recall-point.v1',
 'state':'ORIGINAL_AR_YARN4_128K_'+proof['state']+'_COLLECTED_INDEPENDENT_WIRE_VERIFIED_CLOSED',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Original-weight synthetic associative recall and continued full-history Chat SSE; one seed/YaRN4 profile at the stated 128K physical target on the current r70 runtime.',
 'runtime_source_commit':manifest['source_commit'],'coordinator_checkpoint':manifest['root_checkpoint'],
 'bundle_manifest_sha256':manifest['bundle_manifest_sha256'],'runtime_artifacts':manifest['artifacts'],
 'settings':settings,'three_unscored_calibrations':3,'quality_summary':proof['quality_summary'],
 'observations':observations,'source_model':manifest['model_plan'],
 'model_stat_unchanged':True,'thermal_sample_count':len(telemetry),'peak_C_by_sensor':peaks,
 'current_owned_lifecycle_observation':snapshot,
 'actual_exit_codes':{'controller':job['exit_code'],'supervisor':job['exit_code'],'helper':expected_exit,
                      'native_client':helper['client_exit_code'],'server':helper['server_exit_code'],
                      'collector':collection['exit_code'],'strong_closure':closure['actual_exit_code'],
                      'independent_review_seal':0},
 'lease_release_at':job['lease_released_at'],'closure':closure['result'],
 'collection_artifacts':inventory,'four_current_peer_declarations':peers['peer_declarations'],
 'raw':{'path':'raw/'+RAW.name,'bytes':RAW.stat().st_size,'sha256':sha(RAW),'members':len(parts),'inventory':raw_inventory},
 'limitations':['Does not qualify other seeds, 256K/512K/786K/1M physical inputs, other profiles or MTP.',
                'Configured1048576 capacity is not a physical1M-input or long-recall result.',
                'Quality outputs are not matched fixed-output performance.',
                'Lifecycle witnesses do not establish concurrency, thread roles, latency distributions or reactive speedup.',
                'No claim of vendor or natural-language quality.',
                'All six root roadmap items remain open; Terminal Bench remains last.'],
 'current_root_remote_jobs_handles_leases_windows_waiters_reservations':[],
 'actual_exit_code':0}
with PUBLIC.open('x') as output: output.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(PUBLIC),'raw_members':len(parts),'raw_sha256':sha(RAW),
                  'original_quality_summary':proof['quality_summary'],'peak_C_by_sensor':peaks,'actual_exit_code':0}))
