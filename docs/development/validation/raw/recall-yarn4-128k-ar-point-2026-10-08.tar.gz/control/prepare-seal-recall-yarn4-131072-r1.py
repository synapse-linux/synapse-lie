# SPDX-License-Identifier: MIT
"""Derive the existing strict saved-wire qualification without changing it."""
from pathlib import Path
import hashlib
import json

old = Path('evidence/seal-recall-yarn4-8192-s77-ar-20261008-r1.py')
text = old.read_text()
text = text.replace('recall-yarn4-8192-s77-ar-20261008-r1', 'recall-yarn4-131072-s77-ar-20261008-r1')
text = text.replace('recall-yarn4-8k-ar-point-2026-10-08', 'recall-yarn4-128k-ar-point-2026-10-08')
text = text.replace("settings['size'] == 8192", "settings['size'] == 131072")
text = text.replace('ORIGINAL_AR_YARN4_8K_', 'ORIGINAL_AR_YARN4_128K_')
text = text.replace('at the stated short physical target', 'at the stated 128K physical target')
text = text.replace('other seeds, 128K/256K/512K/786K/1M physical inputs', 'other seeds, 256K/512K/786K/1M physical inputs')
text = text.replace("'prepare-recall-yarn4-closure-r2.py','recall-yarn4-closure-preparation-r2.json',\n         'prepare-recall-yarn4-131072-s77-ar-20261008-r1-local.py','recall-yarn4-peer-notifications-r1.json'", "f'before-{LABEL}-fresh-r1.py',\n         'prepare-recall-yarn4-131072-s77-ar-20261008-r1-local.py',\n         'prepare-seal-recall-yarn4-131072-r1.py', f'{LABEL}-release-notifications-r1.json'")
assert "settings['size'] == 131072" in text and 'settings[\'size\'] == 8192' not in text
assert 'recall-yarn4-closure-preparation-r2.json' not in text
new = Path('evidence/seal-recall-yarn4-131072-s77-ar-20261008-r1.py')
with new.open('x') as stream:
    stream.write(text)
print(json.dumps({'parent':str(old),'parent_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),
                  'derived':str(new),'derived_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),
                  'unchanged_saved_SSE_and_physical_phase_oracle':True,'actual_exit_code':0}))
