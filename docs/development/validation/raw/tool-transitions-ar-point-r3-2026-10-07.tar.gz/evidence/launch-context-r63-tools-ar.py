# SPDX-License-Identifier: MIT
"""Admit the prepared frozen original-weight HTTP tool qualification through the coordinated lease."""
from pathlib import Path
import datetime, hashlib, json, subprocess

root=Path.cwd();out=root/'evidence/context-r63-tools-ar-r1'
manifest=json.loads((out/'manifest.json').read_text())
fresh=json.loads((root/'evidence/context-r63-before-tools-ar-r1.json').read_text())
assert fresh['actual_exit_code']==0
r=fresh['result']
peers=json.loads((root/'evidence/context-r63-peer-coordination.json').read_text())
assert peers['explicit_current_161_non_use_from_all_three'] is True
assert peers['delivered_DGX_declaration'] and peers['delivered_Q2_declaration']
assert json.loads((root/'evidence/context-r63-tools-jobs-prepared.json').read_text())['actual_exit_code']==0
age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(r['at_utc'])).total_seconds()
assert 0<=age<=180,'Fresh preflight expired; no stale admission/restart'
assert r['original_lease']['free_briefly'] and r['original_lease']['released']
assert (r['original_lease']['device'],r['original_lease']['inode'])==(66308,105946405)
assert not r['foreign_compute_clients'] and not r['guarded_hot'] and not r['http8000_listeners']
assert r['exclusive_job_prepared'] and r['boot_id']==manifest['verified_boot_id']
assert r['pinned_image']['exit_code']==0 and r['pinned_image']['id']==manifest['image']
assert hashlib.sha256((out/'runner.py').read_bytes()).hexdigest()==manifest['runner_sha256']
remote='/home/pop/workspace/synapse-lie/context-r63-tools-ar-r1'
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',
      'pop@192.168.5.161','python3','-B',remote+'/runner.py',remote]
plan={'argv':argv,'remote_root':remote,'source_commit':manifest['source_commit'],
      'runner_sha256':manifest['runner_sha256'],
      'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),
      'fresh_preflight':'evidence/context-r63-before-tools-ar-r1.json','standing_future_window':False}
with (out/'plan.json').open('x') as stream:json.dump(plan,stream,indent=2);stream.write('\n')
with (out/'controller-stdout.log').open('x') as stdout,(out/'controller-stderr.log').open('x') as stderr:
    run=subprocess.run(argv,stdout=stdout,stderr=stderr)
record={**plan,'exit_code':run.returncode}
with (out/'controller-result.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
try:
    result=json.loads((out/'controller-stdout.log').read_text())
    with (out/'result.json').open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({k:result.get(k) for k in ['state','error','exit_code','child_exit_code','pid',
                      'start_ticks','container','lease','lease_released_at','model_attempted','cleanup_failures']}))
except (OSError,ValueError):
    print(json.dumps({'actual_exit_code':run.returncode,'error':'Preserved controller logs; remote result unavailable'}))
raise SystemExit(run.returncode)
