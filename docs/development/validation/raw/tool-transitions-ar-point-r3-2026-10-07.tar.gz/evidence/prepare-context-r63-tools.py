# SPDX-License-Identifier: MIT
"""Bind the corrected coherent runtime to the unchanged frozen HTTP client."""
from pathlib import Path
import datetime, hashlib, json, subprocess

root = Path.cwd()
def read(name):
    return json.loads((root / name).read_text())
def bound(name):
    path = root / name
    assert path.is_file() and not path.is_symlink()
    return {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
def write(name, value):
    with (root / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == 'db02da35239179bc12799ea41cd291ba62fd74e1'
assert subprocess.check_output(['git', 'status', '--porcelain'], text=True) == ''
host_path = 'docs/development/validation/tool-transitions-host-2026-10-07.json'
host = read(host_path)
assert host['actual_test_count'] == 121 and host['frozen_HTTP_check_count'] == 71
for name, identity in host['implementation_sources'].items():
    assert bound(name) == identity, name
for name, digest in host['current_unchanged_owned_provider_sources'].items():
    assert bound(name)['sha256'] == digest, name
build_path = 'docs/development/validation/tool-prompt-guidance-point-build-2026-10-07.json'
build = read(build_path)
assert build['state'] == 'BUILT_NOT_GPU_TESTED_COLLECTED_VERIFIED_CLOSED'
assert build['private_C17_ON_OFF_coherent'] is True
assert build['source_commit'] == 'acfb9d26f280c02344000e222bdf4792a3724cff'
assert build['tracked_compiler_files'] == 713
assert build['controller_exit_code'] == build['supervisor_exit_code'] == build['child_exit_code'] == 0
assert read('evidence/context-r62-postseal.json')['actual_exit_code'] == 0
capsule = root / 'evidence/context-source-modern-r62'
tracked = subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0')
compiler_files = [name for name in tracked if name and (capsule / name).is_file()]
assert len(compiler_files) == 713
for name in compiler_files:
    assert (capsule / name).read_bytes() == (root / name).read_bytes(), name
helpers = {'runner.py': 'tools/strix-point-campaign.py',
           'http-gate.py': 'tools/strix-point-http-gate.py',
           'http-tool-transitions.py': 'tools/strix-point-tool-transition-gate.py'}
manifests = {}
for mode in ('ar', 'mtp'):
    manifest = read(f'evidence/context-r60-tools-{mode}-manifest.json')
    manifest.update(
        root_checkpoint=head, runner_commit=head, fixture_commit=head,
        source_commit=build['source_commit'], functional_code_checkpoint=build['source_commit'],
        qualified_build_receipt=build_path, qualified_build_receipt_sha256=bound(build_path)['sha256'],
        bundle=build['bundle']['bundle'], bundle_manifest_sha256=build['bundle']['bundle_sha256'],
        artifacts=build['bundle']['metadata']['artifacts'],
        runtime_build_id='rocm10-point-modern-r62-runtime',
        distrobox_name=f'lie-context-r63-tools-{mode}-r1',
        verified_boot_id='7a966774-3424-46c3-8045-34f759ea58a1',
        canonical_HTTP_window_timeout_seconds=1200,
        prepared_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        purpose='Qualify the corrected model-layer constrained-tool prompt on original weights using the unchanged71 frozen HTTP transition checks and5 baseline controls. Source acfb9d26/current coherent r62 HIP bundle; client questions/schema/seed123/acceptance unchanged from r60. Sequential C1/private loopback/context16384/chunk2048/cache0/output512/natural completion. Canonical deadline1200seconds. No benchmark, Terminal Bench, rebuild, model conversion, heavyweight hash, tuning, installation or publication. Model quality misses remain failures; MTP requires separately fresh admission.')
    manifest['staging_filesystem_rebind'] = {
        'boot_id': manifest['verified_boot_id'],
        'filesystem_uuid': '720d3f3a-db4b-4287-bf9c-77cc76bcb7cb',
        'previous_device': 66307, 'current_device': 66308}
    assert manifest['runner_sha256'] == bound(helpers['runner.py'])['sha256']
    assert manifest['http_gate_sha256'] == bound(helpers['http-gate.py'])['sha256']
    assert manifest['http_tool_transitions_sha256'] == bound(helpers['http-tool-transitions.py'])['sha256']
    write(f'evidence/context-r63-tools-{mode}-manifest.json', manifest)
    manifests[mode] = manifest
write('evidence/context-r63-tools-readiness.json', {
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'previous_goal_turn': 'PROGRESS-db02da35-corrected-coherent-HIP-build-qualified-and-closed',
    'scope': 'CORRECTED_COHERENT_HIP_RUNTIME_AND_UNCHANGED_FROZEN_CLIENT_NOT_ADMISSION',
    'client_source_commit': head, 'runtime_source_commit': build['source_commit'],
    'HOST_receipt': {'path': host_path, **bound(host_path)},
    'HIP_receipt': {'path': build_path, **bound(build_path)},
    'helpers': {name: {'source': source, **bound(source)} for name, source in helpers.items()},
    'native_owned_files_verified': 130, 'current_compiler_files_equal_compiled_capsule': 713,
    'frozen_questions_schema_seed_or_acceptance_changed': False,
    'old_model_quality_failure_reclassified': False,
    'new_GPU_remote_operation': False, 'standing_window_reservation': False})
print(json.dumps({'local_prepared_modes': list(manifests), 'runtime_source': build['source_commit'],
                  'client_source': head, 'checks_per_run': 76, 'GPU_operation': False}))
