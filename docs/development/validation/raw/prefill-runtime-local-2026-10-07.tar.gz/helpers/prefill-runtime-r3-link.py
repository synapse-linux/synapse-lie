#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Coherent local HIP links only. Never executes the resulting clients."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root=Path.cwd();label='prefill-runtime-r3-linked';out=root/'evidence'/label;out.mkdir()
build=root/'build'/label
env=dict(os.environ,LC_ALL='C',HIP_VISIBLE_DEVICES='-1',ROCR_VISIBLE_DEVICES='-1',CUDA_VISIBLE_DEVICES='-1')
result=dict(classification='LOCAL-HIP-COMPILE-NOT-INFERENCE',gpu_execution=False,commands=[],state='RUNNING',
            source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
assert result['source_commit'].startswith('d6431db8')
def save(): (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
def run(name,argv):
    with (out/(name+'.log')).open('xb') as log:
        p=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    result['commands'].append(dict(name=name,argv=argv,exit_code=p.returncode))
    result['state']='FAILED' if p.returncode else 'RUNNING';save()
    if p.returncode:raise SystemExit(p.returncode)
save()
run('configure',['cmake','-S',str(root),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
    '-DBUILD_TESTING=OFF','-DLIE_GUFO_RUNTIME=ON','-DLIE_GUFO_STATE_ACCESS=ON','-DLIE_DS4_RUNTIME_CACHE=ON',
    '-DLIE_LONG_CONTEXT_WMMA=ON','-DLIE_HIP_ARCHITECTURE=gfx1150','-DLIE_BUILD_ID='+label,
    '-DGUFO_SOURCE='+str(root/'.deps/gufo-state-access-prefill-runtime-r3-provider-on'),
    '-DGUFO_BUILD='+str(root/'build/prefill-runtime-r3-provider-on'),
    '-DGUFO_REFERENCE_BUILD='+str(root/'build/prefill-runtime-r3-provider-off')])
targets=['synapse-lie-server','synapse-lie-bench','synapse-lie-bench-gufo-reference',
         'lie-hip-probe','lie-sampling-capture','lie-attention-qualify']
run('build',['cmake','--build',str(build),'--parallel','2','--target']+targets)
result['artifacts']={}
for target in targets:
    p=build/target
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    result['artifacts'][target]=dict(bytes=p.stat().st_size,sha256=h,executed=False)
result.update(state='PASS',ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
