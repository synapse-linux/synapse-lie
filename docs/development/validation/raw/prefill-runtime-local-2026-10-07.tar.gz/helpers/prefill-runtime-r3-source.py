#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Independent exact recipe and public-header controls. No model or device access."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

root=Path.cwd();out=root/'evidence/prefill-runtime-r3-source';out.mkdir()
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
manifest=json.loads((root/'third_party/gufo-source.json').read_text())
assert manifest['commit']=='f783fedb9bea2ec7de941f6da4e02f4a4596b29e'
contents={}
for name,wanted in manifest['files'].items():
    path=root/'.deps/gufo-f783fedb'/name
    assert path.is_file() and not path.is_symlink() and sha(path)==wanted,name
    contents[name]=path.read_bytes()
cmake=(root/'cmake/provider/Source.cmake').read_text()
recipes=re.search(r'set\(manifests ([^)]+)\)',cmake).group(1).split()+['kvc-edits.json']
assert len(recipes)==41
edits=0
for name in recipes:
    recipe=json.loads((root/'adapters/gufo-state'/name).read_text())
    assert recipe['source_pin']==manifest['commit']
    for edit in recipe['edits']:
        key=edit['path'];old=edit['old'].encode();new=edit['new'].encode()
        assert contents[key].count(old)==1,(name,key)
        contents[key]=contents[key].replace(old,new);edits+=1
engine=contents['src/models/qwen38_flash_next/engine.cpp'].decode()
assert 'kPrefillChunkTokens' not in engine
assert 'return std::min(rows, options_.max_context);' in engine
assert 'std::max({options_.lie_prefill_capacity,' in engine
prior=subprocess.check_output(['git','show','HEAD:include/lie/core.h'],text=True)
current=(root/'include/lie/core.h').read_text()
types=r'typedef\s+(?:struct|enum)\s*\{.*?\}\s*\w+\s*;'
assert re.findall(types,prior,re.S)==re.findall(types,current,re.S),'public core layout changed'
commands=[]
for language,compiler,standard in [('c','cc','c17'),('c++','c++','c++17')]:
    for header in ['lie/core.h','lie/prefill.h']:
        code='#include "'+header+'"\n'
        if header=='lie/prefill.h':
            keyword='static_assert' if language=='c++' else '_Static_assert'
            code+=keyword+'(sizeof(lie_prefill_options)==12,"prefill options layout");\n'
            code+=keyword+'(sizeof(lie_prefill_info)==24,"prefill info layout");\n'
        argv=[compiler,'-std='+standard,'-Wall','-Wextra','-Werror','-pedantic-errors','-Iinclude','-x',language,'-fsyntax-only','-']
        p=subprocess.run(argv,input=code,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        name=header.replace('/','-')+'-'+language.replace('+','p')+'.log'
        (out/name).write_text(p.stdout)
        commands.append(dict(header=header,argv=argv,exit_code=p.returncode))
        assert p.returncode==0,p.stdout
result=dict(classification='HOST-NOT-INFERENCE',pristine_files=len(contents),recipes=len(recipes),edits=edits,
            commands=commands,existing_core_layouts_unchanged=True,
            recipe_sha256={n:sha(root/'adapters/gufo-state'/n) for n in recipes},
            variant_sha256={n:hashlib.sha256(b).hexdigest() for n,b in contents.items()},
            prefill_header_sha256=sha(root/'include/lie/prefill.h'))
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(pristine_files=len(contents),recipes=len(recipes),edits=edits,header_checks=len(commands))))
