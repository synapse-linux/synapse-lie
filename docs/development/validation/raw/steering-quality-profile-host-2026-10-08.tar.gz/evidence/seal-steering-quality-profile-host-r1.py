# SPDX-License-Identifier: MIT
"""Seal HOST profile/provenance coverage without claiming original inference."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import tarfile

root = Path.cwd().resolve()
public = root/'docs/development/validation/steering-quality-profile-host-2026-10-08.json'
raw = public.parent/'raw/steering-quality-profile-host-2026-10-08.tar.gz'
assert not public.exists() and not raw.exists()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(path.read_text())

sources = [
    'tools/strix-point-steering-quality-profile.py',
    'tools/strix-point-steering-quality-run.py',
    'tools/strix-point-steering-quality-gate.py',
    'tools/strix-point-steering-build-gate.py',
    'tools/strix-point-http-recall-gate.py',
    'tests/test_strix_point_steering_quality_profile.py',
    'tests/test_strix_point_steering_quality_run.py',
    'tests/test_strix_point_steering_quality.py',
    'tests/fixtures/steering-conciseness-v1.json',
    'docs/development/protocols/STEERING-QUALITY-GPU-PROTOCOL.md',
    'LICENSE', 'CMakeLists.txt']
sources += [str(p.relative_to(root)) for p in sorted((root/'tools/native').iterdir()) if p.is_file()]
guards = {
    'steering-quality-profile-host-debug-r1': 17,
    'steering-quality-profile-host-asan-r1': 17,
    'steering-quality-profile-host-debug-r2': 17,
    'steering-quality-profile-host-asan-r2': 17,
    'steering-quality-supervision-budget-debug-r1': 12,
    'steering-quality-supervision-budget-asan-r1': 12,
    'steering-quality-profile-ctest-debug-r1': 2,
    'steering-quality-profile-ctest-asan-r1': 2}
peaks = {}
for name, count in guards.items():
    directory = root/'evidence'/name
    result, plan = read(directory/'result.json'), read(directory/'plan.json')
    assert result['exit_code'] == result['child_exit_code'] == 0 and result['reason'] is None
    log = (directory/'command.log').read_text()
    if '-ctest-' in name:
        assert '100% tests passed out of 2' in log
        assert all(check in log for check in ('steering-bank-format-identity-lifetimes', 'native-benchmark-contract'))
    else:
        assert f'Ran {count} tests' in log and log.rstrip().endswith('OK')
        assert any(arg.startswith('LIE_STEERING_NATIVE_CLIENT=') for arg in plan['argv'])
    if '-asan-' in name:
        assert 'ASAN_OPTIONS=detect_leaks=1:abort_on_error=1' in plan['argv']
        assert 'UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1' in plan['argv']
    for path, value in result['peak_c'].items():
        peaks[path] = max(peaks.get(path, -1), value)
    for sensor in plan['sensors']:
        if sensor['limit_c'] is not None:
            assert result['peak_c'][sensor['path']] < sensor['limit_c']
    sources += [str(p.relative_to(root)) for p in sorted(directory.iterdir()) if p.is_file()]

preserved = root/'evidence/steering-quality-profile-before-deadline-r1'
inventory_before = read(preserved/'inventory.json')
for expected in inventory_before.values():
    path = root/expected['preserved_copy']
    assert path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256']
sources += [str(p.relative_to(root)) for p in sorted(preserved.iterdir()) if p.is_file()]
sources += ['evidence/seal-steering-quality-profile-host-r1.py',
            'evidence/steering-quality-profile-document-patch-failures-r1.json']

source_commit = '4c703b3d604c6c877d6a2214d7aee0b15a013f61'
comparison = subprocess.run(['git', 'diff', '--quiet', source_commit, '--',
    'src', 'include', 'adapters', 'cmake', 'CMakeLists.txt', 'tools/native', 'tools/steering-build.c'])
assert comparison.returncode == 0
label = 'recall-yarn4-523776-s77-ar-20261008-r1'
manifest = read(root/'evidence'/label/'manifest.json')
assert sha(root/'tools/strix-point-campaign.py') == manifest['runner_sha256']
observed = read(root/f'evidence/{label}-live-5.json')
assert observed['actual_exit_code'] == 0
live = observed['result']
assert live['live_exact_supervisor'] is True and live['lease_fds']
assert len(live['native_GPU_owners']) == 1 and live['model_attempted'] is True
assert len(sources) == len(set(sources))
inventory = {}
for name in sources:
    path = root/name
    assert path.resolve() == path and path.is_file() and not path.is_symlink()
    inventory[name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
with tarfile.open(raw, 'x:gz') as tar:
    for name in sources:
        tar.add(root/name, arcname=name, recursive=False)
with tarfile.open(raw, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(inventory)
    for member in tar.getmembers():
        assert member.isfile() and member.name in inventory
        payload = tar.extractfile(member).read()
        expected = inventory[member.name]
        assert len(payload) == expected['bytes'] and hashlib.sha256(payload).hexdigest() == expected['sha256']

receipt = {
    'schema': 'synapse-lie.steering-quality-profile-host.v1',
    'state': 'HOST_BANK_PROVENANCE_AND_PROFILE_BODY_VERIFIED_DISPATCH_PENDING_NOT_INFERENCE',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Model-neutral admission/profile body, supervised lifetimes and saved synthetic wire. Training receipts/model servers/snapshots are simulated; the campaign dispatcher, lease, GPU and original weights are not executed by these fixtures.',
    'tests': {'profile_per_mode': 17, 'supervision_per_mode': 12, 'focused_native_CTest_per_mode': 2,
              'actual_native_client_children_per_mode': 4, 'synthetic_HTTP_samples_per_mode': 140,
              'initial_profile_tests_per_mode_before_deadline_correction': 17},
    'covered': ['Exact five-helper hashes checked before staged imports.',
        'Corpus/settings/training receipt/model/runtime/native bank content identities.',
        'Original 100-pair prompt/capture geometry and complete closure/release prerequisites.',
        'Model-neutral two-by-two geometry; no fixed Qwen dimensions.',
        'Finite/unit-layer bank admission and eight-pair/synthetic/missing-exit refusal.',
        'Independent complete saved-wire review, quality-failure scores and actual native/container exit distinction.',
        'Same-byte inode replacement, launch failure and partial symlink refusal with model postflight.'],
    'supervision_deadline': {'formula': '2 * load_timeout_seconds + 70 * request_timeout_seconds + 600',
        'snapshot_timeout_seconds': 3, 'overhead_seconds': 600, 'previous_overhead_seconds': 180,
        'one_day_refusal_seconds': 86400, 'fixture_deadline_seconds': 4500,
        'load900_request600_deadline_seconds': 44400,
        'original_before_correction_sources_preserved': True},
    'actual_guard_exits': {name: read(root/'evidence'/name/'result.json')['exit_code'] for name in guards},
    'local_peak_C_by_sensor_path': peaks,
    'native_runtime_sources_byte_equal_to': source_commit,
    'actual_native_source_comparison_exit_code': comparison.returncode,
    'native_fixture_binaries': {name: {'path': 'build/'+name+'/synapse-lie-bench',
        'sha256': sha(root/'build'/name/'synapse-lie-bench')} for name in ('context-debug', 'tool-http-asan')},
    'frozen_campaign_sha256': manifest['runner_sha256'],
    'product_Python_dependency_or_CMake_ABI_state_metrics_change': False,
    'new_build_directories': [],
    'original_model_loading_steering_quality_or_performance_qualified': False,
    'pending': ['Campaign dispatcher hook after the admitted recall window is sealed.',
        'Original 100-pair FFN learning, independent reconstruction and complete qualified receipt.',
        'Original 70 held-out responses with separate fresh admission and complete container closure.',
        'Wider MTP/graph/correction/fault/vision/model/platform and matched cost.'],
    'separate_current_GPU_job': {'label': label, 'manifest_sha256': sha(root/'evidence'/label/'manifest.json'),
        'controller_handle': 95198, 'observed_at_utc': live['at_utc'],
        'actual_observed_supervisor': live['supervisor_identity'],
        'actual_observed_GPU': live['native_GPU_owners'][0], 'qualification_pending': True},
    'GPU_run_build_model_hash_conversion_dependency_installation_or_publication_by_this_HOST_work': False,
    'roadmap': {'open_items': [2, 3, 4, 5, 6, 7], 'terminal_bench_last': True, 'full_goal_complete': False},
    'raw': {'path': str(raw.relative_to(root)), 'bytes': raw.stat().st_size, 'sha256': sha(raw),
            'regular_members': len(inventory), 'members': inventory},
    'actual_exit_code': 0}
with public.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({'state': receipt['state'], 'members': len(inventory), 'raw_bytes': raw.stat().st_size,
                  'tests': receipt['tests'], 'actual_exit_code': 0}))
