#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Inspect sealed completed evidence without rebuilding or rerunning inference."""
from pathlib import Path
import datetime, hashlib, json, re, subprocess, tarfile

def sha(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

p = Path('docs/development/validation/c17-json-slot-point-gpu-2026-10-06.json')
r = json.loads(p.read_text())
assert r['state'] == 'PASSED_WITH_STATED_SCOPE'
assert r['source_commit'] == 'dbdac28df9169b7d292b24e950551ca957329ca1'
assert len(r['compiled_provider_files']) == 105 and r['all_six_owned_tasks_open']
assert not r['goal_complete'] and not r['publication'] and r['new_inference_threads'] == 0
for run in r['runs']:
    assert run['actual_window_retired']
    assert run['actual_exit_code'] == run['child_exit_code'] == run['controller_exit_code'] == 0
    for item in run['artifacts']:
        f = Path(item['path'])
        assert f.stat().st_size == item['bytes'] and sha(f) == item['sha256']
    if run['mode'] == 'build':
        continue
    assert run['checks'] == 37 and run['integer_checks'] == 66
    assert run['integer_exact_values'] == 60 and run['expected_HTTP400_refusals'] == 6
    assert len(run['integer_witnesses']) == 66 and run['server_exit_code'] == 0
    assert run['observed_process_threads_max'] == 44
    for name, witness in run['integer_witnesses'].items():
        if '_refusal_' in name:
            assert witness['status'] == 400
        else:
            value = int(witness['lexeme'])
            assert value == witness['value']
            assert witness['low'] <= value <= witness['high']
            assert json.loads(witness['text'])['value'] == value

archive = r['portable_archive']
assert sha(archive['path']) == archive['sha256']
assert Path(archive['path']).stat().st_size == archive['bytes']
expected = {x['path']: x for x in r['portable_archive_inventory']}
with tarfile.open(archive['path'], 'r:gz') as t:
    members = t.getmembers()
    assert len(members) == len(expected) > 100
    assert {m.name for m in members} == set(expected)
    for m in members:
        assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
        assert m.size == expected[m.name]['bytes']
        assert hashlib.sha256(t.extractfile(m).read()).hexdigest() == expected[m.name]['sha256']
    assert 'LICENSE' in expected and 'third_party/README.md' in expected

changed = subprocess.run(['git', 'diff', '--name-only'], capture_output=True, text=True, check=True).stdout.splitlines()
checked = 0
broken = []
for name in changed:
    if not name.endswith('.md'):
        continue
    f = Path(name)
    for target in re.findall(r'\]\(([^)\s]+)\)', f.read_text()):
        if target.startswith(('https://', 'http://', 'mailto:', '#')):
            continue
        if not (f.parent/target.split('#')[0]).resolve().exists():
            broken.append({'file': name, 'target': target})
        checked += 1
assert not broken, broken
for f in [Path('README.md'), Path('docs/guides/BUILD.md')]:
    s = f.read_text()
    assert '-DLIE_C17_SAMPLING=OFF' in s and '-DGUFO_REFERENCE_BUILD=' in s
    assert '-DLIE_HIP_ARCHITECTURE="$lie_target_arch"' in s
assert 'MATCHES "^gfx115[01]$"' in Path('cmake/provider/Build.cmake').read_text()
assert not any(name.endswith(('.c', '.h', '.hpp', '.cpp', '.cmake')) for name in changed)
check = subprocess.run(['git', 'diff', '--check'], capture_output=True, text=True)
assert check.returncode == 0, check.stdout+check.stderr
proof = dict(state='PASSED', at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Independent local inspection of collected qualification; no build/test/GPU rerun',
    receipt_sha256=sha(p), portable_members=len(expected), general_checks_per_mode=37,
    integer_checks_per_mode=66, exact_values_per_mode=60, HTTP400_refusals_per_mode=6,
    local_documentation_links_checked=checked, broken_local_links=broken,
    diff_check_actual_exit_code=check.returncode, all_six_tasks_remain_open=True,
    terminal_bench='STOPPED_COLLECTED_CLOSED_DEFERRED_LAST',
    previous_inspector_failure=None)
with Path('evidence/json-slot-point-proof-r35-r1.json').open('x') as f:
    json.dump(proof, f, indent=2); f.write('\n')
print(json.dumps(proof))
