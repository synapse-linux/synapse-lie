# SPDX-License-Identifier: MIT
"""Verify all completed portable parts, member identities and recorded gates."""
from pathlib import Path
import datetime,hashlib,json,tarfile

root=Path.cwd();receipt=root/'docs/development/validation/sampling-mtp-tools-point-2026-10-07.json'
r=json.loads(receipt.read_text());seen=set();count=0
assert r['state']=='ORIGINAL_REQUIRED_TOOL_MTP_MASK_NUMERICAL_WITNESSES_COLLECTED_REPLAYED_CLOSED'
assert r['goal_complete'] is False and r['open_task_numbers']==[2,3,4,5,6,7]
assert r['numerical_verification']['complete_three_arm_witnesses_in_release_and_unsuppressed_sanitizers'] is True
assert r['numerical_verification']['full_witness_lines']==2916
assert r['capture']['full_target_masks']==169 and r['capture']['full_mask_bits_per_program']==169*248320
assert r['capture']['semantic_matches']==6 and r['capture']['natural_EOS'] is True
assert r['strict_machine_closure']['state']=='WHOLE_CONTAINER_AND_EXACT_GPU_IDENTITIES_CLOSED_NO_STANDING_RESERVATION'
assert r['strict_machine_closure']['observed_container_init_PID_available'] is False
for part in r['portable_raw_archive_parts']:
    path=root/part['path']
    assert path.stat().st_size==part['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==part['sha256']
    with tarfile.open(path) as archive:
        members=archive.getmembers();assert len(members)==part['members']==len(part['inventory'])+1
        assert len({m.name for m in members})==len(members)
        for member in members:
            assert member.isreg();data=archive.extractfile(member).read();count+=1
            if member.name=='raw-inventory.json':
                assert json.loads(data)==part['inventory'];continue
            assert member.name not in seen;seen.add(member.name)
            expected=part['inventory'][member.name]
            assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
            live=root/member.name;assert live.is_file() and not live.is_symlink()
            assert live.stat().st_size==expected['bytes'] and hashlib.sha256(live.read_bytes()).hexdigest()==expected['sha256']
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit_code':0,
        'parts_verified':len(r['portable_raw_archive_parts']),'all_regular_members':count,
        'all_archived_and_current_member_bindings_match':True,'new_remote_GPU_model_or_build_work':False}
with (root/'evidence/context-r58-postseal.json').open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps(result))
