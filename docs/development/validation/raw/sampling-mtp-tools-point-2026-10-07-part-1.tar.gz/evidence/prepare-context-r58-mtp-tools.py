# SPDX-License-Identifier: MIT
"""Prepare current MTP capture and qualified offline replay bindings locally."""
from pathlib import Path
import datetime, hashlib, json, subprocess

root = Path.cwd()
def read(name): return json.loads((root / name).read_text())
def bound(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream: sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': sha}
def write(name, value):
    with (root / name).open('x') as stream:
        json.dump(value, stream, indent=2); stream.write('\n')

host_rel = 'docs/development/validation/mtp-capture-host-2026-10-07.json'
build_rel = 'docs/development/validation/mtp-capture-point-build-2026-10-07.json'
host, build = read(host_rel), read(build_rel)
assert build['state'] == 'BUILT_NOT_GPU_TESTED_COLLECTED_VERIFIED_CLOSED'
assert host['MTP_capture_writer_replay_complete'] is True
assert build['host_receipt']['sha256'] == bound(root / host_rel)['sha256']
assert build['source_commit'] == 'c6625f094bd7815493a3364703757486027d48ec'
for name, expected in host['implementation_sources'].items():
    assert bound(root / name) == expected, name
provider = read('evidence/context-r56-build-r1/compile-evidence/build/rocm10-point-modern-r56-provider/BUILD-RECEIPT.json')
owned = provider['owned_sampling_files']
assert len(owned) == 122
for name, sha in owned.items(): assert bound(root / name)['sha256'] == sha, name
commands = []
for kind in ['release', 'asan']:
    for arm, binary in [('original','reference-sampling-replay'),
                        ('C17','candidate-sampling-replay'), ('OFF','fallback-sampling-replay')]:
        name = f'build/mtp-capture-sampling-r55-{kind}/{binary}'
        expected = host['qualified_host_binary_inventory'][name]
        assert bound(root / name) == expected, name
        commands.append({'kind':kind, 'arm':arm,
                         'bound_binary':{'path':str(root / name), **expected}})
runner = bound(root / 'tools/strix-point-campaign.py')
assert runner['sha256'] == read('evidence/context-r56-source-seal.json')['runner_sha256']
root_checkpoint = subprocess.run(['git','rev-parse','HEAD'],check=True,capture_output=True,text=True).stdout.strip()
assert root_checkpoint.startswith('b9459086')
readiness = {
    'scope':'HOST_QUALIFIED_REPLAY_PLUS_COHERENT_CURRENT_HIP_BINDING_NOT_ADMISSION',
    'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'root_checkpoint':root_checkpoint, 'runtime_source_commit':build['source_commit'],
    'previous_goal_turn':'PROGRESS-b9459086-original-MTP-text-accepted-and-closed',
    'host_receipt':{'path':host_rel, **bound(root / host_rel)},
    'build_receipt':{'path':build_rel, **bound(root / build_rel)},
    'implementation_sources':host['implementation_sources'], 'owned_sampler_files':owned,
    'native_replay_commands':commands, 'current_runner':runner,
    'remote_GPU_model_build_or_admission':False, 'standing_window_reservation':False,
}
write('evidence/context-r58-mtp-tools-readiness.json',readiness)
manifest = read('evidence/context-r46-sampling-tools-manifest.json')
manifest.update({
    'source_commit':build['source_commit'], 'root_checkpoint':root_checkpoint,
    'functional_code_checkpoint':build['code_checkpoint'],
    'qualified_build_receipt':build_rel,
    'qualified_build_receipt_sha256':bound(root / build_rel)['sha256'],
    'runner_commit':build['source_commit'], 'fixture_commit':build['source_commit'],
    'runner_sha256':runner['sha256'], 'bundle':build['bundle']['bundle'],
    'bundle_manifest_sha256':build['bundle']['bundle_sha256'],
    'artifacts':build['bundle']['metadata']['artifacts'],
    'runtime_build_id':'rocm10-point-modern-r56-runtime',
    'decode_mode':'mtp', 'capture_mode':'tools', 'capture_row_budget':128,
    'mtp_draft_tokens':7,
    'predictor_plan':read('evidence/context-r47-integer-mtp-manifest.json')['predictor_plan'],
    'distrobox_name':'lie-context-r58-sampling-mtp-tools-r1',
    'purpose':'Final current-runtime original Q4/Q8 MTP required-function qualification: six frozen seeded profiles, maximum128 confirmed tokens, natural EOS, complete strict describe_stack call; every actual target/proposal/verification row and full grammar mask. Independent original/C17/OFF probability, mask, RNG and complete-call controller replay afterward. Greedy covers the host head only. No benchmark or Terminal Bench. Prose/parallel/results, steering, long recall, faults/resources and matched cost remain separate gates.',
    'memory_admission':{'expected_peak_gtt_bytes':100*2**30,'min_available_ram_bytes':2**30},
    'memory_estimate_scope':'100GiB preflight estimate for known original Q4/Q8 short C1 context8192/chunk2048; not a measured peak or capacity guarantee. The native diagnostic saves bounded raw rows to disk.',
    'prepared_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'prepared_manifest_not_admission':True,
})
write('evidence/context-r58-mtp-tools-manifest.json',manifest)
print(json.dumps({'scope':readiness['scope'],'source_commit':build['source_commit'],
                  'bound_replay_binaries':6,'owned_sampler_files':122,
                  'prepared_manifest_not_admission':True,'remote_operation':False}))
