# SPDX-License-Identifier: MIT
"""Seal saved original MTP numerical witnesses in bounded portable parts."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,tarfile

root=Path.cwd();dest=root/'docs/development/validation'
name='sampling-mtp-tools-point-2026-10-07';out=dest/(name+'.json')
assert not out.exists()
def read(rel):return json.loads((root/rel).read_text())
def bound(path):
    assert path.is_file() and not path.is_symlink(),path
    with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':sha}
base=root/'evidence/context-r58-sampling-mtp-tools-r1'
job=read('evidence/context-r58-sampling-mtp-tools-r1/result.json')
controller=read('evidence/context-r58-sampling-mtp-tools-r1/controller-result.json')
collection=read('evidence/context-r58-sampling-mtp-tools-r1/collection.json')
review=read('evidence/context-r58-final-verification.json')
readiness=read('evidence/context-r58-mtp-tools-readiness.json')
closure=read('evidence/context-r58-mtp-tools-closure-r2.json')
peers=read('evidence/context-r58-peer-coordination.json')
assert review['actual_exit_code']==closure['actual_exit_code']==collection['exit_code']==0
assert job['exit_code']==job['child_exit_code']==controller['exit_code']==0
assert job['model_stat_unchanged'] is True and job['model_attempted'] is True
assert peers['explicit_current_161_non_use_from_all_three'] is True
replays={kind:read('evidence/context-r58-'+kind+'-replay/result.json') for kind in ('release','asan')}
guards={kind:read('evidence/context-r58-'+kind+'-replay-guard/result.json') for kind in ('release','asan')}
for kind in replays:
    assert replays[kind]['exit_code']==guards[kind]['exit_code']==guards[kind]['child_exit_code']==0
    assert all(c['actual_exit_code']==0 and c['stderr']['bytes']==0 for c in replays[kind]['commands'])
assert replays['release']['complete_witness_sha256']==replays['asan']['complete_witness_sha256']==review['complete_witness_sha256']
members={}
def capture(path):members[str(path.relative_to(root))]=bound(path)
for path in (root/'evidence').glob('context-r58-*'):
    if path.name in ('context-r58-proof-sealing-guard','context-r58-proof-postseal-guard'):continue
    if path.is_file():capture(path)
    elif path.is_dir():
        for child in path.rglob('*'):
            if child.is_file():capture(child)
for rel in ['evidence/prepare-context-r58-mtp-tools.py','evidence/launch-context-r58-mtp-tools.py',
            'evidence/prefetch-context-r58-capture.py',
            'evidence/seal-mtp-tools-point-r58.py','evidence/verify-mtp-tools-point-r58.py',
            'README.md','docs/PROGRESS.md','docs/BACKEND.md','docs/reference/ABI.md',
            'docs/COORDINATION.md','docs/development/protocols/DS4-SAMPLING-GPU-PROTOCOL.md',
            'third_party/README.md','third_party/gufo-source.json','tools/thermal-run.py',
            'tests/sampling/replay.cpp','cmake/provider/Source.cmake',
            'evidence/context-r56-build-r1/compile-evidence/build/rocm10-point-modern-r56-provider/BUILD-RECEIPT.json',
            'evidence/context-r56-build-r1/compile-evidence/build/rocm10-point-modern-r56-reference-provider/BUILD-RECEIPT.json']:
    capture(root/rel)
for field in ('host_receipt','build_receipt'):
    proof=readiness[field];assert bound(root/proof['path'])=={k:proof[k] for k in ('bytes','sha256')}
    capture(root/proof['path'])
for rel,expected in readiness['implementation_sources'].items():
    assert bound(root/rel)==expected;capture(root/rel)
for rel,sha in readiness['owned_sampler_files'].items():
    assert bound(root/rel)['sha256']==sha;capture(root/rel)
build=read(readiness['build_receipt']['path'])
for rel in read('evidence/context-r56-build-r1/compile-verification-r1/result.json')['recipes_verified']:
    capture(root/rel)
parts=[];group={};used=0
def package(items):
    path=dest/'raw'/(name+'-part-'+str(len(parts)+1)+'.tar.gz')
    assert not path.exists()
    inventory=(json.dumps(items,indent=2)+'\n').encode()
    with path.open('xb') as stream:
        with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,compresslevel=3) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as archive:
                for rel,identity in items.items():
                    assert bound(root/rel)==identity
                    info=tarfile.TarInfo(rel);info.mode=0o644;info.size=identity['bytes']
                    with (root/rel).open('rb') as data:archive.addfile(info,data)
                info=tarfile.TarInfo('raw-inventory.json');info.mode=0o644;info.size=len(inventory)
                archive.addfile(info,io.BytesIO(inventory))
    assert path.stat().st_size<64*2**20
    parts.append({'path':str(path.relative_to(root)),**bound(path),
                  'members':len(items)+1,'inventory':items})
data={rel:item for rel,item in members.items() if '/capture/' in rel and rel.endswith(('.f32le','.u8'))}
metadata={rel:item for rel,item in members.items() if rel not in data}
package(dict(sorted(metadata.items())))
for rel,identity in sorted(data.items()):
    if group and used+identity['bytes']>48*2**20:
        package(group);group={};used=0
    group[rel]=identity;used+=identity['bytes']
if group:package(group)
result={
    'schema':'synapse-lie.sampling-mtp-tools-point.v1',
    'sealed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state':'ORIGINAL_REQUIRED_TOOL_MTP_MASK_NUMERICAL_WITNESSES_COLLECTED_REPLAYED_CLOSED',
    'scope':'Selected six original-weight required-function MTP profiles; full saved masks/probabilities/RNG/controller/calls only, not performance or general tool/quality acceptance',
    'compiled_source_commit':build['source_commit'],'root_checkpoint_at_preparation':readiness['root_checkpoint'],
    'runtime_build_id':'rocm10-point-modern-r56-runtime','machine':'pop@192.168.5.161 / Strix Point gfx1150',
    'matching_HIP_receipt':readiness['build_receipt'],'source_binding':readiness,
    'model_plan':json.loads((base/'manifest.json').read_text())['model_plan'],
    'predictor_plan':json.loads((base/'manifest.json').read_text())['predictor_plan'],
    'model_stat_before':job['models_before'],'model_stat_after':job['models_after'],'model_stat_unchanged':True,
    'capture':{'profiles':6,'context':8192,'prefill_chunk':2048,'confirmed_token_budget_per_profile':128,'natural_EOS':True,'semantic_matches':6,
               'requested_drafts':7,'raw_traces':226,'proposals':57,'accepted_verifications':14,
               'rejected_verifications':21,'deferred_target_draws':21,
               'rows_per_profile':[25,35,61,35,35,35],'trace_payload_bytes':209844992,
               'full_target_masks':169,'full_mask_bits_per_program':41966080,
               'proposal_mask_policy':'Original WithoutConstraint sampler; null allowed field; full masks on target draw/verification',
               'observed_native_GPU_process_thread_counts':[27,43],
               'greedy_scope':'Host head only; greedy GPU verification is not covered'},
    'numerical_verification':{'complete_three_arm_witnesses_in_release_and_unsuppressed_sanitizers':True,
                              'full_witness_SHA256':review['complete_witness_sha256'],'full_witness_lines':review['complete_witness_lines'],
                              'oracles':['Independent full vocabulary byte-walk mask and complete-call validation',
                                         'Independent long-double target mass/support',
                                         'Exact compact integer proposal mass/draw',
                                         'Independent acceptance/residual draw and RNG',
                                         'Captured actual history/penalties and deferred RNG',
                                         'Complete committed token/cycle/frontier reconstruction'],
                              'probability_tolerance':'absolute 5e-14 + relative 5e-12; exact support'},
    'native_replay_commands':[c for replay in replays.values() for c in replay['commands']],
    'controller_supervisor_native_exit_codes':[0,0,0],
    'release_wrapper_and_three_native_exit_codes':[0,0,0,0],
    'asan_wrapper_and_three_native_exit_codes':[0,0,0,0],
    'offline_thermal_guards':guards,'offline_sanitizer_options':'ASAN_OPTIONS/UBSAN_OPTIONS/LSAN_OPTIONS absent; no suppressions; outside ptrace; GPU masked; no model forward',
    'remote_CPU_GPU_NVMe_peak_C':[58.875,62,62.85],
    'strict_machine_closure':closure['result'],'init_identity_provenance':review['init_identity_provenance'],
    'lease_released_at_utc':job['lease_released_at'],'fresh_peer_coordination':peers,
    'collected_files':407,'capture_files':397,
    'preserved_failures':[read('evidence/context-r58-collection-failure-r1.json'),
                          {'scope':'Initial exact-init closure refusal','actual_exit_code':1,
                           'path':'evidence/context-r58-mtp-tools-closure-r1.json',
                           'reason':'Legacy Distrobox omits init PID; observer ran after retirement',
                           'correction':'Exact GPU/launcher/supervisor identities plus whole recorded container cgroup absence and two complete process scans. No missing-PID success or GPU rerun.'}],
    'preparation_label_limit':read('evidence/context-r58-preparation-label-note.json'),
    'corrected_saved_data_review':review,'native_capture_or_replay_repeated':False,
    'broader_open_gates':['Wider prose/parallel/result tool transitions','Greedy GPU verifier',
                         'Wider tools/vision/steering and long-context quality',
                         'Fault/resource/memory fit acceptance','Matched Gufo/Halogen/reactive cost and performance','Terminal Bench last'],
    'open_task_numbers':[2,3,4,5,6,7],'goal_complete':False,
    'no_standing_root_job_lease_window_waiter_reservation_handle':True,
    'packaging_runs_build_test_GPU_model_hash':False,'publication':False,'initial_transfer_check_repeated_after_completed_prefetch':True,
    'portable_raw_archive_parts':parts,
    'reproduction':'Extract all parts into one root. Use the supplied native --capture replay source and pinned upstream inputs/build receipt; do not run model forward locally. Saved rows retain original-weight supervisor provenance.',
}
with out.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({'receipt':str(out.relative_to(root)),'parts':[{'path':p['path'],'bytes':p['bytes'],'sha256':p['sha256'],'members':p['members']} for p in parts],
                  'all_regular_members':sum(p['members'] for p in parts),'state':result['state']}))
