# SPDX-License-Identifier: MIT
"""Batch-copy bounded finished native capture files before standard collection."""
from pathlib import Path
import hashlib,importlib.util,inspect,json,subprocess

root=Path.cwd();label='context-r58-sampling-mtp-tools-r1'
local=root/'evidence'/label
assert (local/'controller-result.json').is_file()
spec=importlib.util.spec_from_file_location('point_collect',root/'tools/strix-point-bench-collect.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
program='from pathlib import Path\nimport os,stat,re,hashlib,json\n'
program+=inspect.getsource(module.sampling_capture_inventory)
program+='\nroot=Path('+repr(module.BASE+'/'+label)+')\n'
program+='''assert os.getuid()==1000 and root.resolve()==root and root.stat().st_uid==os.getuid()
result=json.loads((root/'result.json').read_text())
assert result.get('ended_at') and result.get('lease_released_at')
files=sampling_capture_inventory(root)
print(json.dumps(files))
'''
record={'scope':'READ_ONLY_BATCH_PREFETCH_FOR_STANDARD_COLLECTOR_NOT_ACCEPTANCE',
        'commands':[],'exit_code':1,'GPU_model_build_or_lease_operation':False}
target=root/'evidence/context-r58-capture-prefetch.json'
assert not target.exists()
def save():target.write_text(json.dumps(record,indent=2)+'\n')
save()
inventory=subprocess.run(module.SSH+['python3 -B -'],input=program,text=True,capture_output=True,timeout=90)
record['commands'].append({'argv':module.SSH+['python3 -B -'],'actual_exit_code':inventory.returncode,
                           'program_sha256':hashlib.sha256(program.encode()).hexdigest(),
                           'stderr':inventory.stderr});save()
if inventory.returncode:raise SystemExit(inventory.returncode)
files=json.loads(inventory.stdout);record['inventory']=files;save()
directory=local/'capture';directory.mkdir(exist_ok=True)
assert directory.resolve()==directory and not directory.is_symlink()
for name in files:
    assert name.startswith('capture/') and len(Path(name).parts)==2
    assert not (local/name).exists(), 'Prefetch only fills new paths; never overwrite evidence'
names=sorted(files);batches=0
for start in range(0,len(names),256):
    group=names[start:start+256]
    argv=module.SCP+[f'pop@192.168.5.161:{module.BASE}/{label}/{name}' for name in group]+[str(directory)]
    copied=subprocess.run(argv,text=True,capture_output=True,timeout=240)
    record['commands'].append({'argv':argv,'actual_exit_code':copied.returncode,'stderr':copied.stderr})
    batches+=1;save()
    if copied.returncode:raise SystemExit(copied.returncode)
    for name in group:
        path=local/name;expected=files[name]
        assert path.is_file() and not path.is_symlink() and path.stat().st_size==expected['bytes']
        with path.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected['sha256']
record.update(exit_code=0,files_verified=len(files),batches=batches);save()
print(json.dumps({'exit_code':0,'files_verified':len(files),'copy_batches':batches,
                  'standard_collection_still_required':True}))
