# SPDX-License-Identifier: MIT
"""Review saved capture, complete replay witnesses and exact retired ownership."""
from pathlib import Path
import datetime,hashlib,json

root=Path.cwd();base=root/'evidence/context-r58-sampling-mtp-tools-r1'
def read(path):return json.loads((root/path).read_text())
def bound(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':sha}
job=read('evidence/context-r58-sampling-mtp-tools-r1/result.json')
controller=read('evidence/context-r58-sampling-mtp-tools-r1/controller-result.json')
collection=read('evidence/context-r58-sampling-mtp-tools-r1/collection.json')
assert job['state']=='PASSED' and job['exit_code']==job['child_exit_code']==controller['exit_code']==0
assert job['model_attempted'] is True and job['model_stat_unchanged'] is True and not job['cleanup_failures']
assert len(job['models_before'])==len(job['models_after'])==5
assert job['models_before']==job['models_after']
assert collection['exit_code']==0 and all(c['exit_code']==0 for c in collection['commands'])
assert len(collection['inventory']['files'])==407
for name,expected in collection['inventory']['files'].items():assert bound(base/name)==expected,name
native=job['capture_result']
assert native['profiles']==6 and native['mode']=='tools' and native['decode_mode']=='mtp'
assert native['proposals']>0 and native['accepted_verifications']>0
events=[json.loads(line) for line in (base/'capture/capture.jsonl').read_text().splitlines()]
traces=[v for v in events if v['event']=='sampling_trace']
assert len(traces)==native['rows']
assert all((v['allowed'] is None) if v['kind']=='proposal' else isinstance(v['allowed'],dict) for v in traces)
assert sum(isinstance(v['allowed'],dict) for v in traces)==169
assert sum(v['kind']=='proposal' for v in traces)==native['proposals']
assert sum(v['kind']=='verification' and v['accepted']==1 for v in traces)==native['accepted_verifications']
assert sum(v['kind']=='verification' and v['accepted']==0 for v in traces)==native['rejected_verifications']
assert sum(v['kind']=='target-draw' and v['deferred']==1 for v in traces)==native['deferred_draws']
completed=[v for v in events if v['event']=='profile_complete']
assert len(completed)==6 and all(0<len(v['output_ids'])<=128 for v in completed)
assert all(v['tool_call']['name']=='describe_stack' for v in completed)
assert native['semantic_matches']==6 and all(v['tool_call']['arguments']=={'order':'LIFO','size':3} for v in completed)
assert events[-1]=={'event':'complete','exit_code':0,'profiles':6,'rows':native['rows']}
closure=read('evidence/context-r58-mtp-tools-closure-r2.json')
assert closure['actual_exit_code']==0
closed=closure['result'];assert closed['state']=='WHOLE_CONTAINER_AND_EXACT_GPU_IDENTITIES_CLOSED_NO_STANDING_RESERVATION'
assert closed['original_lease']['free_briefly'] and closed['original_lease']['released']
assert not closed['foreign_compute_clients'] and not closed['http8000_listeners'] and not closed['guarded_hot']
assert closed['service']['ActiveState']=='active'
assert closed['observed_container_init_PID_available'] is False and closed['original_init_PID_absence_claimed'] is False
assert len(closed['identities'])==3 and all(v['exact_identity_absent'] for v in closed['identities'])
assert closed['container_cgroup']['exists'] is False and closed['container_cgroup']['empty']
assert len(closed['whole_container_process_scans'])==2
assert all(v['processes_checked']>0 and not v['owned_cgroup_matches'] and not v['unreadable'] for v in closed['whole_container_process_scans'])
assert closed['container_inspect']['exit_code']==1
assert closed['label_listing']['exit_code']==0 and not closed['label_listing']['stdout'].strip()
replays={kind:read('evidence/context-r58-'+kind+'-replay/result.json') for kind in ('release','asan')}
assert replays['release']['complete_witness_sha256']==replays['asan']['complete_witness_sha256']
for kind, replay in replays.items():
    assert replay['exit_code']==0 and replay['rows']==native['rows'] and replay['complete_witness_lines']>0
    assert len(replay['commands'])==3
    for c in replay['commands']:
        assert c['actual_exit_code']==0 and not c['timed_out'] and c['stderr']['bytes']==0
        for key in ('stdout','stderr','bound_binary'):
            saved=c[key];assert bound(Path(saved['path']))=={k:saved[k] for k in ('bytes','sha256')}
    guard=read('evidence/context-r58-'+kind+'-replay-guard/result.json')
    assert guard['exit_code']==guard['child_exit_code']==0 and guard['reason'] is None
telemetry=[json.loads(line) for line in (base/'telemetry.jsonl').read_text().splitlines()]
peaks={}
for row in telemetry:
    for sensor in row['temperatures']:
        peaks[sensor['name']]=max(peaks.get(sensor['name'],-40),sensor['value_c'])
        if sensor.get('guarded',True):assert sensor['value_c']<sensor['limit_c']
assert set(peaks)=={'nvme','amdgpu','k10temp'}
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit_code':0,
        'state':'ORIGINAL_REQUIRED_TOOL_MTP_MASK_NUMERICAL_WITNESSES_COLLECTED_REPLAYED_CLOSED',
        'files_verified':len(collection['inventory']['files']),'capture_files_verified':len(native['artifacts']),
        'profiles':6,'confirmed_token_budget_per_profile':128,'semantic_matches':native['semantic_matches'],'full_target_masks':169,'mask_bits_per_program':169*248320,
        'raw_traces':native['rows'],'proposals':native['proposals'],'accepted':native['accepted_verifications'],
        'rejected':native['rejected_verifications'],'deferred':native['deferred_draws'],
        'three_arms_in_release_and_unsuppressed_sanitizers':True,
        'complete_witness_sha256':replays['release']['complete_witness_sha256'],
        'complete_witness_lines':replays['release']['complete_witness_lines'],'peak_C':peaks,
        'init_identity_provenance':'Init PID is explicitly unknown. Exact recorded GPU/supervisor/launcher PID-start identities are absent; the entire CID cgroup is absent and two complete /proc scans find no members. Missing-PID collector flags are not evidence.',
        'GPU_or_model_forward_in_review':False,'broader_quality_fault_resource_cost_acceptance':False}
with (root/'evidence/context-r58-final-verification.json').open('x') as stream:
    json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps(result))
