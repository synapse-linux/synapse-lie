# SPDX-License-Identifier: MIT
"""Replay saved original MTP rows with qualified binaries; no model forward."""
from pathlib import Path
import hashlib, json, os, subprocess, sys

assert len(sys.argv)==2 and sys.argv[1] in ('release','asan')
kind=sys.argv[1]
if kind=='asan':
    assert not any(k in os.environ for k in ('ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS'))
root=Path.cwd()
capture=(root/'evidence/context-r58-sampling-mtp-tools-r1/capture').resolve()
output=root/('evidence/context-r58-'+kind+'-replay');output.mkdir(exist_ok=False)
def bound(path):
    path=Path(path);assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha}
prior=json.loads((root/'evidence/context-r58-mtp-tools-readiness.json').read_text())
assert prior['scope']=='HOST_QUALIFIED_REPLAY_PLUS_COHERENT_CURRENT_HIP_BINDING_NOT_ADMISSION'
for name,expected in prior['implementation_sources'].items():
    current=bound(root/name);assert all(current[k]==expected[k] for k in ('bytes','sha256'))
for name,sha in prior['owned_sampler_files'].items():assert bound(root/name)['sha256']==sha
collection=json.loads((capture.parent/'collection.json').read_text())
assert collection['exit_code']==0
for name,expected in collection['inventory']['files'].items():
    current=bound(capture.parent/name);assert all(current[k]==expected[k] for k in ('bytes','sha256')),name
job=json.loads((capture.parent/'result.json').read_text())
assert job['state']=='PASSED' and job['exit_code']==job['child_exit_code']==0
assert job['model_attempted'] is True and job['model_stat_unchanged'] is True
assert not job['cleanup_failures'] and job['lease_released_at'] and job['ended_at']
native=job['capture_result']
lines=[json.loads(line) for line in (capture/'capture.jsonl').read_text().splitlines()]
identity,terminal=lines[0],lines[-1]
assert identity['schema']=='synapse-lie.sampling-capture.v3' and identity['synthetic'] is False
assert identity['build_id']=='rocm10-point-modern-r56-runtime' and identity['decode_mode']=='mtp'
assert terminal['event']=='complete' and terminal['exit_code']==0 and terminal['profiles']==6
rows=terminal['rows'];assert rows==native['rows'] and 6<=rows<=6*128*9
assert native['proposals'] and native['accepted_verifications']
assert identity['tools'] is True
assert native['mode']=='tools'
assert native['semantic_matches'] is not None
commands=[c for c in prior['native_replay_commands'] if c['kind']==kind];assert len(commands)==3
result={'scope':'ORIGINAL_WEIGHT_REQUIRED_FUNCTION_MTP_MASK_TARGET_PROPOSAL_RNG_CONTROLLER_ONLY',
        'kind':kind,'capture_identity':identity,'capture_manifest':bound(capture/'capture.jsonl'),
        'source_binding_receipt':'evidence/context-r58-mtp-tools-readiness.json',
        'commands':[],'exit_code':1,'new_GPU_or_model_CPU_forward':False,
        'tool_steering_long_context_fault_quality_resource_cost_qualified':False}
target=output/'result.json'
def save():target.write_text(json.dumps(result,indent=2)+'\n')
save()
for command in commands:
    arm=command['arm'];binary=Path(command['bound_binary']['path']);proof=bound(binary)
    assert proof==command['bound_binary']
    argv=[str(binary),'--capture',str(capture)]
    stdout=output/(arm+'.txt');stderr=output/(arm+'.stderr');timed_out=False
    with stdout.open('xb') as out,stderr.open('xb') as err:
        child=subprocess.Popen(argv,stdout=out,stderr=err)
        try:child.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timed_out=True;child.terminate()
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:child.kill();child.wait()
    record={'arm':arm,'argv':argv,'actual_exit_code':child.returncode,'timed_out':timed_out,
            'bound_binary':proof,'stdout':bound(stdout),'stderr':bound(stderr)}
    result['commands'].append(record);save()
    print(json.dumps({'arm':arm,'actual_exit_code':child.returncode,'timed_out':timed_out,
                      'stdout_bytes':stdout.stat().st_size,'stderr':stderr.read_text()[:1000]}),flush=True)
    if child.returncode or timed_out:raise SystemExit(1)
assert len({c['stdout']['sha256'] for c in result['commands']})==1
last_expected=(f"MTP_ROWS={rows} PROPOSALS={native['proposals']} ACCEPTED={native['accepted_verifications']} "
               f"REJECTED={native['rejected_verifications']} DEFERRED={native['deferred_draws']} "
               'COMPLETE_OFFLINE_WITNESSES_NOT_FULL_ACCEPTANCE\n')
for command in result['commands']:
    with Path(command['stdout']['path']).open() as stream:
        first=stream.readline()
        assert first==('classification=CAPTURE-DECLARED-ORIGINAL-WEIGHTS-REQUIRE-SUPERVISOR-PROVENANCE '
                       'scope=MTP-target-proposal-verification-controller;greedy-host-head;not-performance\n')
        count=1;last=first
        for last in stream:count+=1
        assert last==last_expected
    assert command['stderr']['bytes']==0
result.update(exit_code=0,state='ORIGINAL_REQUIRED_TOOL_MTP_THREE_ARMS_FULL_MASK_MASS_RNG_CALL_WITNESSES_PASS',
              rows=rows,proposals=native['proposals'],accepted=native['accepted_verifications'],
              rejected=native['rejected_verifications'],deferred=native['deferred_draws'],semantic_matches=native['semantic_matches'],
              complete_witness_sha256=result['commands'][0]['stdout']['sha256'],complete_witness_lines=count)
save()
print(json.dumps({k:result[k] for k in ['state','kind','exit_code','rows','proposals','accepted','rejected',
                                       'deferred','complete_witness_sha256','complete_witness_lines']}))
