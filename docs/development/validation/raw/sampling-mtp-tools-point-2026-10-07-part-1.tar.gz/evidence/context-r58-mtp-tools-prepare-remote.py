# SPDX-License-Identifier: MIT
"""Stage one owned qualification job; no process/model/GPU/service operation."""
from pathlib import Path
import hashlib, json, subprocess

manifest = json.loads(Path('evidence/context-r58-mtp-tools-manifest.json').read_text())
program = 'MANIFEST=' + repr(manifest) + '\n' + '''
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
base=Path('/home/pop/workspace/synapse-lie')
assert os.getuid()==1000 and base.resolve()==base and base.stat().st_uid==os.getuid()
lease=base/'campaign.lock';st=lease.stat()
assert not lease.is_symlink() and (st.st_dev,st.st_ino)==(66307,105946405)
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
assert boot==MANIFEST['verified_boot_id']==MANIFEST['staging_filesystem_rebind']['boot_id']
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
source=base/'rocm10-fedora-161/source-modern-r56'
runner=source/'tools/strix-point-campaign.py'
assert not runner.is_symlink() and sha(runner)==MANIFEST['runner_sha256']
bundle=Path(MANIFEST['bundle']);assert bundle.resolve()==bundle
assert sha(bundle/'BUNDLE.json')==MANIFEST['bundle_manifest_sha256']
metadata=json.loads((bundle/'BUNDLE.json').read_text())
assert metadata['source_commit']==MANIFEST['source_commit'] and metadata['artifacts']==MANIFEST['artifacts']
for name,digest in MANIFEST['artifacts'].items():
 path=bundle/name;assert not path.is_symlink() and path.stat().st_uid==os.getuid()
 assert sha(path)==digest,name
models=[]
for plan,expected_source_sha in [(MANIFEST['model_plan'],'1da4904abb2278498b08329038558e8fe20cf95611c64ffa62af00aee457745b'),
 (MANIFEST['predictor_plan'],'c4708d9b0289a11d2facb64346a36eb9879480908ec780589d961bf9a56262be')]:
 directory=Path(plan['destination']);assert directory.resolve()==directory and directory.stat().st_uid==os.getuid()
 receipt=directory/'SOURCE.json';assert not receipt.is_symlink() and receipt.stat().st_size<65536
 proof=json.loads(receipt.read_text());assert proof['result']['state']=='VERIFIED' and proof['plan']==plan
 assert sha(receipt)==expected_source_sha
 rows=[]
 for row in plan['files']:
  path=directory/row['name'];s=path.stat()
  assert path.is_file() and not path.is_symlink() and s.st_size==row['bytes'] and s.st_uid==os.getuid()
  rows.append({'name':row['name'],'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns})
 models.append({'directory':str(directory),'SOURCE_sha256':expected_source_sha,'stat_only':rows})
inspected=subprocess.run(['docker','inspect',MANIFEST['distrobox_name']],capture_output=True,text=True,timeout=15)
assert inspected.returncode==1
job=base/'context-r58-sampling-mtp-tools-r1';assert not job.exists() and not job.is_symlink()
job.mkdir(mode=0o700);shutil.copy2(runner,job/'runner.py')
with (job/'manifest.json').open('x') as stream:json.dump(MANIFEST,stream,indent=2);stream.write(chr(10))
record={'scope':'PREPARED_CURRENT_RUNTIME_NATIVE_MTP_TEXT_CAPTURE_NOT_STARTED_OR_ADMITTED',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runner_sha256':sha(job/'runner.py'),
 'manifest_sha256':sha(job/'manifest.json'),'bundle_sha256':MANIFEST['bundle_manifest_sha256'],
 'boot_id':boot,'original_lease_device':st.st_dev,'original_lease_inode':st.st_ino,
 'models_stat_only':models,'GPU_run_model_hash_conversion_or_service_mutation':False,
 'standby_waiter_window_reservation':False}
with (job/'prepared.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write(chr(10))
print(json.dumps(record))
'''
argv = ['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
run = subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record = {'argv':argv,'actual_exit_code':run.returncode,
          'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':run.stdout,'stderr':run.stderr}
try: record['result'] = json.loads(run.stdout)
except ValueError: pass
with Path('evidence/context-r58-mtp-tools-job-prepared.json').open('x') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
if run.returncode == 0:
    out=Path('evidence/context-r58-sampling-mtp-tools-r1');out.mkdir()
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (out/'runner.py').write_bytes(Path('tools/strix-point-campaign.py').read_bytes())
print(json.dumps(record.get('result',record)))
raise SystemExit(run.returncode)
