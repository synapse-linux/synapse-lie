#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Archive finished local tooling checks; no new test/build/remote operation."""
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import stat
import tarfile

OUT = Path('docs/development/validation/sampling-capture-host-2026-10-07.json')
RAW = Path('docs/development/validation/raw/sampling-capture-host-2026-10-07.tar.gz')
assert not OUT.exists() and not RAW.exists()

def read(path):
    return json.loads(Path(path).read_text())

def bound(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}

host_path = Path('docs/development/validation/integrated-final-host-2026-10-06.json')
host = read(host_path)
changed = [name for name, item in host['frozen_sources'].items()
           if bound(name)['sha256'] != item['sha256']]
assert changed == ['CMakeLists.txt', 'tests/sampling/CMakeLists.txt']
commands, peaks = {}, {}
for directory in sorted(Path('evidence').glob('sampling-capture-r78-*')):
    if not directory.is_dir():
        continue
    result = read(directory / 'result.json')
    commands[str(directory)] = result
    for path, value in result['peak_c'].items():
        peaks[path] = max(value, peaks.get(path, 0))
assert commands['evidence/sampling-capture-r78-release-configure']['exit_code'] == 1
assert commands['evidence/sampling-capture-r78-release-build']['exit_code'] == 1
for key, value in commands.items():
    if key not in ['evidence/sampling-capture-r78-release-configure',
                   'evidence/sampling-capture-r78-release-build']:
        assert value['exit_code'] == value['child_exit_code'] == 0
for key in ['release-ctest-r2', 'asan-ctest-r2', 'root-ctest-r2']:
    assert commands['evidence/sampling-capture-r78-' + key]['exit_code'] == 0

witnesses = {}
refusals = ['synthetic', 'token', 'SHA', 'truncated', 'terminal', 'generation', 'path', 'row-fifo', 'metadata-fifo']
for kind in ['release', 'asan']:
    paths = [p for p in Path('build/sampling-capture-r78-' + kind).glob('replay-*')
             if (p / 'row-fifo.exit').exists()]
    assert len(paths) == 1
    root = paths[0]
    hashes = {arm: bound(root / (arm + '.txt'))['sha256'] for arm in ['REFERENCE', 'CANDIDATE', 'FALLBACK']}
    assert len(set(hashes.values())) == 1
    assert 'ROWS=48 COMPLETE_OFFLINE_WITNESSES_NOT_FULL_ACCEPTANCE' in (root / 'REFERENCE.txt').read_text()
    for case in refusals:
        assert (root / (case + '.exit')).read_text().strip() == '1'
    witnesses[kind] = {'directory': str(root), 'full_witness_sha256': hashes['REFERENCE'],
                       'rows': 48, 'lines': len((root / 'REFERENCE.txt').read_text().splitlines()),
                       'arms': hashes, 'refusals': {case: 1 for case in refusals}}
assert witnesses['release']['full_witness_sha256'] == witnesses['asan']['full_witness_sha256']

libraries = {}
for kind in ['release', 'asan']:
    for arm in ['reference', 'candidate', 'fallback']:
        path = Path('build/final-integrated-r76-provider-' + kind) / ('lib' + arm + '.a')
        libraries[str(path)] = bound(path)

members, special = {}, {}
def capture(path):
    path = Path(path)
    if path.is_symlink():
        raise ValueError('Unexpected symlink in raw evidence: ' + str(path))
    if path.is_file():
        item = bound(path)
        assert item['path'] not in members
        members[item['path']] = item
    elif stat.S_ISFIFO(path.stat().st_mode):
        special[str(path)] = {'kind': 'owned-FIFO-refusal-fixture', 'payload_bytes': 0,
                              'recreated_by': 'tests/test_sampling_capture.c --fifo'}

for directory in sorted(Path('evidence').glob('sampling-capture-r78-*')):
    if directory.is_dir():
        for path in sorted(directory.rglob('*')):
            if not path.is_dir():
                capture(path)
for name in ['CMakeLists.txt', 'tests/sampling/CMakeLists.txt', 'tools/sampling-capture.c',
             'tests/sampling/replay.cpp', 'tests/sampling/replay_contract.cmake',
             'tests/sampling_capture/CMakeLists.txt', 'tests/sampling_capture_executor.c',
             'tests/test_sampling_capture.c', 'evidence/seal-sampling-capture-r78.py', str(host_path)]:
    capture(name)
for kind in ['release', 'asan', 'root-release']:
    base = Path('build/sampling-capture-r78-' + kind)
    for pattern in ['format-*', 'replay-*', 'sampling-capture-*']:
        for directory in sorted(base.glob(pattern)):
            if directory.is_dir():
                for path in sorted(directory.rglob('*')):
                    if not path.is_dir():
                        capture(path)
    for name in ['CTestTestfile.cmake', 'CMakeCache.txt', 'build.ninja', 'Testing/Temporary/LastTest.log']:
        capture(base / name)

inventory = (json.dumps(members, indent=2) + '\n').encode()
with RAW.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', compresslevel=3, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, item in sorted(members.items()):
                assert bound(name) == item
                entry = tarfile.TarInfo(name); entry.mode = 0o644; entry.size = item['bytes']
                with Path(name).open('rb') as source:
                    tar.addfile(entry, source)
            entry = tarfile.TarInfo('raw-inventory.json'); entry.mode = 0o644; entry.size = len(inventory)
            tar.addfile(entry, io.BytesIO(inventory))

receipt = {
    'schema': 'synapse-lie.sampling-capture-host.v1',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'NATIVE_CAPTURE_AND_OFFLINE_REPLAY_FIXTURES_PASSED_NOT_INFERENCE',
    'scope': 'Development tooling only; synthetic raw rows, complete original/C17/OFF numerical witnesses and independent math. No GPU/model/performance/quality or MTP-controller acceptance.',
    'base_commit': '4372f139ea402af5b20d3e04782ead72e2d57c6f',
    'prior_runtime_code_commit': host['source_commit'], 'prior_host_receipt': bound(host_path),
    'existing_source_files_verified_unchanged': len(host['frozen_sources']) - len(changed),
    'existing_source_files_changed_only_for_tool_builds': changed,
    'core_executor_ABI_HTTP_reactive_runtime_numerics_changed': False,
    'read_only_existing_coherent_host_libraries': libraries,
    'local_commands_and_actual_exits': commands, 'final_focused_CTest_counts': {'release': 2, 'asan': 2, 'main-project-native': 1},
    'complete_witnesses': witnesses, 'Release_ASan_complete_witnesses_identical': True,
    'independent_math': 'Full ranking, generated-token count oracle and long-double filter/softmax mass; absolute5e-14 plus relative5e-12; exact support and separately implemented draw/RNG/residual checks.',
    'retained_failures': {'configure_actual_exit': 1, 'build_actual_exit': 1,
        'correction': 'Verify changed-file overlay plus complete pinned mapping; explicit fclose deleter type. No warning suppression.'},
    'special_fixture_nodes_not_read_as_files': special,
    'sensor_peaks_C': peaks, 'maximum_observed_local_CPU_C': peaks['/sys/class/hwmon/hwmon8/temp1_input'],
    'thermal_policy': 'CPU98/NVMe85/lower; GPU masked/observe only; no tuning',
    'sanitizers': 'ASan/UBSan/LSan, detect_leaks=1:abort_on_error=1, halt_on_error=1:print_stacktrace=1; outside ptrace; no suppressions',
    'new_test_build_for_collection': False, 'new_GPU_run_remote_build_model_hash_conversion_or_installation': False,
    'new_product_or_default_test_Python_dependency': False, 'root_job_client_lease_window_waiter_reservation': False,
    'new_remote_campaign_queued': False, 'r37_MTP': 'PREPARED_ONLY_NOT_ADMITTED_NOT_LAUNCHED_DEFERRED',
    'pending': ['admitted original-weight full-row capture and independent replay', 'tool transitions',
                'actual MTP acceptance/correction', 'fault/resource/quality gates', 'matched cost and long-context comparisons'],
    'open_task_numbers': [2, 3, 4, 5, 6, 7], 'Terminal_Bench': 'DEFERRED_LAST',
    'publication': False, 'goal_complete': False,
    'portable_raw_archive': {**bound(RAW), 'members': len(members) + 1}, 'raw_artifacts': members}
with OUT.open('x') as stream:
    json.dump(receipt, stream, indent=2); stream.write('\n')
print(json.dumps({'receipt': bound(OUT), 'archive': bound(RAW), 'members': len(members) + 1,
                  'CPU_peak_C': receipt['maximum_observed_local_CPU_C'], 'new_test_or_model_run': False}))
