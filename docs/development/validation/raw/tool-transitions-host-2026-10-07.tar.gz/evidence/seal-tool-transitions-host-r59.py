# SPDX-License-Identifier: MIT
"""Seal HOST-only checking code and exact exits; no hardware acceptance."""
import datetime,hashlib,json,re,subprocess,tarfile
from pathlib import Path
root=Path.cwd()
def read(name):return json.loads((root/name).read_text())
def bound(name):
 p=root/name;assert p.is_file() and not p.is_symlink(),name
 with p.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 return {'bytes':p.stat().st_size,'sha256':digest}
source='c6625f094bd7815493a3364703757486027d48ec'
changed=subprocess.run(['git','diff','--name-only',source],check=True,capture_output=True,text=True).stdout.splitlines()
allowed={'tools/strix-point-campaign.py','tools/strix-point-http-gate.py','tools/strix-point-bench-collect.py','tests/test_strix_point_campaign.py','third_party/README.md'}
assert all(name.startswith('docs/') or name in allowed for name in changed),changed
build=read('docs/development/validation/mtp-capture-point-build-2026-10-07.json')
provider=read('evidence/context-r56-build-r1/compile-evidence/build/rocm10-point-modern-r56-provider/BUILD-RECEIPT.json')
assert build['source_commit']==source and build['private_C17_ON_OFF_coherent'] is True
owned={}
for group in ['owned_sampling_files','owned_dispatch_files','owned_steering_files','owned_weight_decode_files']:
 for name,digest in provider[group].items():
  assert bound(name)['sha256']==digest,name
  owned[name]=digest
final=[('transitions',8,'context-r59-final-transitions-r2'),('supervisor',87,'context-r59-final-campaign'),
       ('capture_regression',18,'context-r59-final-capture-regression'),('OpenAI_regression',8,'context-r59-final-host-r1')]
commands=[]
for kind,count,label in final:
 data=read('evidence/'+label+'/result.json')
 assert data['exit_code']==data['child_exit_code']==0 and data['reason'] is None,label
 log=(root/'evidence'/label/'command.log').read_text()
 assert f'Ran {count} tests' in log and log.rstrip().endswith('OK'),label
 commands.append({'group':kind,'test_count':count,'guard_directory':'evidence/'+label,'result':data,
                  'result_binding':bound('evidence/'+label+'/result.json'),'log_binding':bound('evidence/'+label+'/command.log')})
implementation=['tools/strix-point-tool-transition-gate.py','tools/strix-point-http-gate.py',
 'tools/strix-point-campaign.py','tools/strix-point-bench-collect.py','tools/thermal-run.py',
 'tests/test_strix_point_tool_transitions.py','tests/test_strix_point_campaign.py',
 'tests/test_strix_point_openai_controls.py','tests/test_sampling_capture_campaign.py']
docs=['docs/BACKEND.md','docs/COORDINATION.md','docs/PROGRESS.md',
 'docs/development/protocols/TOOL-TRANSITIONS-GPU-PROTOCOL.md']
files=set(implementation+docs+['evidence/context-r59-preserved-errors.json',
 'evidence/seal-tool-transitions-host-r59.py'])
for p in sorted((root/'evidence').glob('context-r59-*')):
 if p.is_dir():
  for member in p.iterdir():
   if member.is_file():files.add(str(member.relative_to(root)))
raw={name:bound(name) for name in sorted(files)}
archive='docs/development/validation/raw/tool-transitions-host-2026-10-07.tar.gz'
assert not (root/archive).exists()
with tarfile.open(root/archive,'x:gz') as stream:
 for name in raw:stream.add(root/name,arcname=name,recursive=False)
with tarfile.open(root/archive) as stream:
 members=stream.getmembers();assert len(members)==len(raw)
 for member in members:
  assert member.isfile() and member.name in raw
  payload=stream.extractfile(member).read()
  assert len(payload)==raw[member.name]['bytes'] and hashlib.sha256(payload).hexdigest()==raw[member.name]['sha256']
receipt={'schema':'synapse-lie.tool-transitions-host.v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'HOST_CHECKING_CODE_PASSED_NOT_ORIGINAL_WEIGHT_ACCEPTANCE','classification':'CPU_CANNED_WIRE_AND_MOCKED_OWNERSHIP_NOT_INFERENCE',
 'previous_goal_turn':'PROGRESS-6fae35f8-original-MTP-required-functions-qualified-and-closed',
 'base_checkpoint':subprocess.run(['git','rev-parse','HEAD'],check=True,capture_output=True,text=True).stdout.strip(),
 'frozen_HTTP_check_count':71,'frozen_profiles':['greedy','ds4','filtered'],'actual_test_count':sum(x[1] for x in final),
 'commands':commands,'implementation_sources':{name:bound(name) for name in implementation},
 'native_runtime_source_commit':source,'native_source_and_ABI_unchanged':True,'native_diff_since_runtime_compile':changed,
 'current_unchanged_owned_provider_sources':owned,
 'qualified_HIP_receipt':{'path':'docs/development/validation/mtp-capture-point-build-2026-10-07.json',
                         **bound('docs/development/validation/mtp-capture-point-build-2026-10-07.json')},
 'bound_native_artifacts':build['consumer_binary_SHA256'],'new_HIP_build_required_for_development_client':False,
 'native_sanitizer_reexecution_required':False,'reason':'Only optional Python development clients/supervisor/fixtures and documentation change; no native C/C++ parser, lifetime, ABI, metrics or numerical source changes.',
 'refusal_controls':['orphan','missing','duplicate','unknown'],'before_forward_counter_oracle':True,
 'independent_full_wire_assembly_and_done_ID_validation':True,'model_quality_misses_fail_with_partial_receipt':True,
 'Distrobox_actual_live_init_identity_binding_and_replacement_refusal':True,
 'CPU_peak_C':max(x['result']['peak_c']['/sys/class/hwmon/hwmon8/temp1_input'] for x in commands),
 'preserved_failures':read('evidence/context-r59-preserved-errors.json')['failures'],
 'GPU_model_or_remote_operation':False,'heavyweight_model_hash_or_conversion':False,
 'product_Python_dependency':False,'standing_remote_job_lease_window_reservation':False,
 'original_weight_acceptance':False,'performance_comparison':False,'Terminal_Bench_run':False,
 'goal_complete':False,'open_task_numbers':[2,3,4,5,6,7],
 'portable_raw_archive':{'path':archive,**bound(archive),'members':len(raw)},'raw_artifacts':raw}
public=root/'docs/development/validation/tool-transitions-host-2026-10-07.json'
with public.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps({'state':receipt['state'],'tests':receipt['actual_test_count'],'checks':71,
 'unchanged_owned_provider_files':len(owned),'raw_members':len(raw),'archive_bytes':bound(archive)['bytes'],'GPU_operation':False}))
