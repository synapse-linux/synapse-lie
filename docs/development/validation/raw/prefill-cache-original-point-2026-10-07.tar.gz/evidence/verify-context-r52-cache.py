# SPDX-License-Identifier: MIT
"""Independent complete saved-data cache namespace review; no GPU/model work."""
from pathlib import Path
import datetime,hashlib,json,struct

root=Path.cwd();ready=json.loads((root/'evidence/context-r52-readiness.json').read_text())
def read(path):return json.loads(path.read_text())
def ident(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':digest}
def integer(row,key,wanted=None,minimum=0):
    value=row[key];assert type(value) is int and value>=minimum,(key,value)
    assert wanted is None or value==wanted,(key,value,wanted)
    return value
outputs=[];arms=[];models=None
for mode in ('ram','ssd'):
    folder=root/('evidence/context-r52-prefill-'+mode+'-ar-r1')
    m=read(folder/'manifest.json');r=read(folder/'result.json')
    c=read(folder/'controller-result.json');collection=read(folder/'collection.json')
    assert collection['exit_code']==0 and all(q['exit_code']==0 for q in collection['commands'])
    for path,wanted in collection['inventory']['files'].items():assert ident(folder/path)==wanted,path
    assert c['exit_code']==r['exit_code']==r['child_exit_code']==0 and r['state']=='PASSED'
    assert r==json.loads((folder/'controller-stdout.log').read_text())
    assert r['model_attempted'] is True and r['model_stat_unchanged'] is True
    assert len(r['models_before'])==4 and r['models_before']==r['models_after']
    assert not r['cleanup_failures'] and r['ended_at'] and r['lease_released_at']
    assert r['lease']['device']==66307 and r['lease']['inode']==105946405
    assert r['final_container_state']['OOMKilled'] is False
    if models is None:models=r['models_before']
    assert r['models_before']==models
    assert ident(folder/'runner.py')['sha256']==m['runner_sha256']==r['runner_sha256']==ready['runner_sha256']
    assert ident(folder/'tokens.json')['sha256']==m['tokens_sha256']==ready['tokens_sha256']
    assert ident(root/m['qualified_build_receipt'])['sha256']==m['qualified_build_receipt_sha256']
    build=read(root/m['qualified_build_receipt'])
    assert build['source_commit']==m['source_commit']==ready['compiled_source']
    assert build['bundle']['bundle_sha256']==m['bundle_manifest_sha256']
    assert build['bundle']['metadata']['artifacts']==m['artifacts']
    tokens=read(folder/'tokens.json');assert len(tokens)==8192
    assert all(type(token) is int and 0<=token<248320 for token in tokens)
    rows=[json.loads(line) for line in (folder/'measurements.jsonl').read_text().splitlines()]
    def events(name,count=1):
        selected=[row for row in rows if row.get('event')==name]
        assert len(selected)==count,(mode,name,len(selected));return selected
    identity=events('identity')[0]
    assert identity['schema']=='synapse-lie.core-bench.v1' and identity['execution']=='shared-reactive-core'
    assert identity['synthetic'] is False and identity['mode']=='ar' and identity['prefill_probe']==mode
    assert identity['build_id']==m['runtime_build_id']=='rocm10-point-modern-r50-runtime'
    assert identity['input_kind']=='physical-tokens' and identity['cache_policy']==mode
    assert identity['generation']==m['generation'] and identity['generation']['temperature']==0
    assert identity['eos_policy']=='ignore' and not identity['mtp_model'] and not identity['vision_model']
    assert identity['checkpoint_policy']=='ds4' and identity['state_format']=='ds4-kvc-payload'
    assert identity['checkpoint_compression'] is True and identity['checkpoint_codec']=='byte-plane4-zstd1-v1'
    assert identity['cache_retention_policy']=='ds4-time-token-byte-utility-v1'
    assert identity['cache_capture_finish'] is False
    for key,value in {'users':1,'context_capacity':16384,'prefill_chunk':2048,'prefill_capacity':8192,
                      'warmups':0,'repetitions':1,'output_limit':32,'cache_min_tokens':1,
                      'cache_cold_max_tokens':0,'cache_continued_tokens':0,'cache_trim_tokens':0,
                      'cache_align_tokens':0,'prefix_cache_bytes':4096*1024**2 if mode=='ram' else 0,
                      'ssd_quota_bytes':4096*1024**2 if mode=='ssd' else 0,
                      'ssd_staging_bytes':512*1024**2 if mode=='ssd' else 0}.items():integer(identity,key,value)
    source=events('input')[0];assert source['physical_ids']==tokens
    integer(source,'prompt_tokens',8192)
    physical_sha=hashlib.sha256(b''.join(struct.pack('<i',token) for token in tokens)).hexdigest()
    assert source['physical_ids_sha256']==physical_sha
    jobs=events('job',5);samples=events('sample',5);steps=events('prefill_cache_step',5)
    output=jobs[0]['output_ids'];assert len(output)==32
    assert all(type(token) is int and 0<=token<248320 for token in output)
    stages=('initial-cold','initial-hot','changed-cold','changed-hot','initial-restored-hot')
    for step,(job,sample,record) in enumerate(zip(jobs,samples,steps,strict=True)):
        hot=step in (1,3,4);changed=step in (2,3)
        chunk=8192 if changed else 2048;revision=3 if step==4 else 2 if changed else 1
        calls=0 if hot else 1 if changed else 4
        assert job['output_ids']==output and job['finish']=='length'
        for key,value in {'rep':step,'warmup':0,'user':0,'prompt_tokens':8192,'output_tokens':32,
                          'prefill_tokens':0 if hot else 8192,'prefill_calls':calls,'prefill_chunk':chunk,
                          'prefill_capacity':8192,'prefill_revision':revision,'cached_tokens':8192 if hot else 0,
                          'ssd_cached_tokens':8192 if hot and mode=='ssd' else 0,
                          'mtp_drafted_tokens':0,'mtp_accepted_tokens':0}.items():integer(job,key,value)
        for key,value in {'rep':step,'warmup':0,'users':1,'output_tokens':32,'ssd_errors':0}.items():integer(sample,key,value)
        if hot:integer(sample,'ssd_hits' if mode=='ssd' else 'cache_hits',minimum=1)
        integer(sample,'cache_compressed_captures',0)
        if mode=='ram':assert sample['cache_expanded_bytes']==sample['cache_retained_bytes']
        assert record['stage']==stages[step] and record['storage']==mode and record['verified'] is True
        for key,value in {'step':step,'cached_tokens':job['cached_tokens'],'ssd_cached_tokens':job['ssd_cached_tokens'],
                          'prefill_calls':calls,'ssd_errors':0,'ssd_pending':0}.items():integer(record,key,value)
        for key,value in {'chunk_tokens':chunk,'capacity_tokens':8192,'revision':revision}.items():integer(record['selection'],key,value)
        integer(record,'ssd_writes',minimum=1 if mode=='ssd' else 0)
    if mode=='ssd':
        drained=events('ssd_drained')[0]
        integer(drained,'writes',minimum=2);integer(drained,'errors',0);integer(drained,'pending',0)
        integer(drained,'disk_bytes',minimum=1);integer(drained,'entries',minimum=2)
    else:assert not any(row.get('event')=='ssd_drained' for row in rows)
    complete=events('prefill_probe_complete')[0]
    assert complete['mode']==mode and complete['synthetic'] is False and complete['baseline_output_ids']==output
    integer(complete,'prompt_tokens',8192);integer(complete,'output_tokens',32)
    assert events('complete')[0]==rows[-1]=={'event':'complete','exit_code':0}
    assert type(rows[-1]['exit_code']) is int
    closure=read(root/('evidence/context-r52-'+mode+'-closure-r1.json'))
    assert closure['actual_exit_code']==0
    closed=closure['result'];assert closed['state']=='FRESH_CACHE_PREFILL_CLOSURE_NO_STANDING_RESERVATION'
    for key in ('owned_supervisor_identity_absent','owned_client_identity_absent','owned_container_init_identity_recorded','owned_container_init_identity_absent'):assert closed[key] is True
    assert closed['original_lease']['free_briefly'] is True and closed['original_lease']['released'] is True
    assert not closed['foreign_compute_clients'] and not closed['guarded_hot'] and not closed['http8000_listeners']
    assert closed['service']['ActiveState']=='active'
    peaks={};peak_gtt=0;available=None;count=0
    for line in (folder/'telemetry.jsonl').read_text().splitlines():
        row=json.loads(line);count+=1;peak_gtt=max(peak_gtt,row['gpu']['mem_info_gtt_used'])
        ram=row['memory']['MemAvailable'];available=ram if available is None else min(available,ram)
        for sensor in row['temperatures']:
            peaks[sensor['name']]=max(peaks.get(sensor['name'],-100),sensor['value_c'])
            if sensor['guarded']:assert sensor['value_c']<sensor['limit_c']
    assert count and available>=m['memory_admission']['min_available_ram_bytes']
    outputs.append(output)
    arms.append({'mode':mode,'stages':stages,'full_prompt_cached_tokens':[job['cached_tokens'] for job in jobs],
                 'prefill_calls':[job['prefill_calls'] for job in jobs],'confirmed_output_ids':output,
                 'physical_input_ids_sha256':physical_sha,'all_five_complete_outputs_equal':True,
                 'SSD_full_reads_with_RAM_disabled':mode=='ssd','DS4_format_utility_retained':True,
                 'checkpoint_compression_build_capability':True,'actual_RAM_compressed_captures':0,
                 'high_ratio_compression_qualified':False,'packing_scope':'Exact DS4/KVC payload remains raw; generic aligned-state packing is not applied.',
                 'sampled_temperature_peaks_C':peaks,'sampled_peak_gtt_bytes':peak_gtt,
                 'sampled_minimum_available_ram_bytes':available,'telemetry_samples':count})
assert outputs[0]==outputs[1]
proof={'schema':'synapse-lie.prefill-cache-original-saved-review.v1',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit_code':0,
 'state':'SELECTED_ORIGINAL_AR_RAM_SSD_PREFILL_NAMESPACE_PASSED',
 'scope':'Original Q4 PP8192/TG32/C1, context16384/capacity8192, separate RAM/SSD five-stage namespace probes; functional only.',
 'arms':arms,'all_ten_complete_outputs_equal':True,'unchanged_models_across_both_windows':True,
 'MTP_broader_quality_fault_performance_qualified':False,'new_GPU_or_model_run':False,
 'open_task_numbers':[2,3,4,5,6,7],'goal_complete':False}
with (root/'evidence/context-r52-cache-proof.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\n')
print(json.dumps(proof))
