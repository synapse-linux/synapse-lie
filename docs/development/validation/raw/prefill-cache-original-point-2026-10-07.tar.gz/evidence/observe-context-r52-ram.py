# SPDX-License-Identifier: MIT
"""Observe only the owned r52 ram GPU gate; do not alter processes or devices."""
from pathlib import Path
import hashlib, json, subprocess, sys

program = '''
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess
base=Path('/home/pop/workspace/synapse-lie');root=base/'context-r52-prefill-ram-ar-r1'
assert hashlib.sha256((root/'runner.py').read_bytes()).hexdigest()=='7f2b3d42adb93c401f3dffe29d2a18d0fd3e5bb5f5d76c8f7a543b39337ede99'
spec=importlib.util.spec_from_file_location('point',root/'runner.py');point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
r=json.loads((root/'result.json').read_text())
try:live=point.ticks(r['pid'])==r['start_ticks']
except FileNotFoundError:live=False
fds=[]
if live:
 for p in Path('/proc').joinpath(str(r['pid']),'fd').iterdir():
  try:
   s=p.stat()
   if (s.st_dev,s.st_ino)==(66307,105946405):fds.append(int(p.name))
  except OSError:pass
state={};init_identity=None
if r.get('container'):
 q=subprocess.run(['docker','inspect','--format','{{json .State}}',r['container']],capture_output=True,text=True,timeout=15)
 state={'exit_code':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
 if q.returncode==0:
  value=json.loads(q.stdout);init_pid=value.get('Pid',0)
  if init_pid>0:
   try:init_identity={'pid':init_pid,'start_ticks':point.ticks(init_pid),'container':r['container']}
   except FileNotFoundError:pass
partial=[];path=root/'measurements.jsonl'
if path.is_file():
 for line in path.read_text().splitlines():
  try:partial.append(json.loads(line))
  except ValueError:pass
tails={}
for name in ('distrobox.stdout.log','distrobox.stderr.log'):
 p=root/name
 if p.is_file():
  with p.open('rb') as f:
   f.seek(max(0,p.stat().st_size-1800));tails[name]=f.read().decode(errors='replace')
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'live_exact_supervisor':live,'pid':r['pid'],'start_ticks':r['start_ticks'],
 'state':r['state'],'original_lease_fds':fds,'model_attempted':r.get('model_attempted'),
 'container':state,'container_init_observed_identity':init_identity,
 'measurements':partial,'tails':tails,'observation':point.observe(98,gpu_observation_only=True),
 'terminal_summary':{k:r.get(k) for k in ('error','exit_code','child_exit_code','lease_released_at','cleanup_failures','bench_result')} if r.get('ended_at') else None}
if live and r['state']=='ADMITTED':assert fds
print(json.dumps(result))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':run.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':run.stdout,'stderr':run.stderr}
try:record['result']=json.loads(run.stdout)
except ValueError:pass
with Path(sys.argv[1]).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
if 'result' in record:
 r=record['result'];short={k:r[k] for k in ('at_utc','live_exact_supervisor','pid','start_ticks','state','original_lease_fds','model_attempted','container_init_observed_identity','terminal_summary')}
 short['events']=[{k:row[k] for k in ('event','stage','output_tokens','prefill_calls','success') if k in row} for row in r['measurements']]
 short['temperature_maxima_C']={}
 for sensor in r['observation']['temperatures']:
  short['temperature_maxima_C'][sensor['name']]=max(short['temperature_maxima_C'].get(sensor['name'],-100),sensor['value_c'])
 short['gpu']=r['observation']['gpu'];short['memory']=r['observation']['memory']
 if r['state']=='FAILED':short['tails']=r['tails']
 print(json.dumps(short))
else:print(json.dumps(record))
raise SystemExit(run.returncode)
