# SPDX-License-Identifier: MIT
"""Run the prepared original-weight native ssd cache gate under its original lease."""
from pathlib import Path
import hashlib, json, subprocess

root = Path.cwd()
out = root / 'evidence/context-r52-prefill-ssd-ar-r1'
manifest = json.loads((out / 'manifest.json').read_text())
fresh = json.loads((root / 'evidence/context-r52-before-ssd-r1.json').read_text())
assert fresh['actual_exit_code'] == 0
r = fresh['result']
assert r['original_lease']['free_briefly'] is True and r['original_lease']['released'] is True
assert (r['original_lease']['device'], r['original_lease']['inode']) == (66307, 105946405)
assert not r['foreign_compute_clients'] and not r['guarded_hot'] and not r['http8000_listeners']
assert r['exclusive_job_prepared']
assert r['boot_id'] == manifest['verified_boot_id']
assert r['pinned_image']['exit_code'] == 0 and r['pinned_image']['id'] == manifest['image']
assert hashlib.sha256((out / 'runner.py').read_bytes()).hexdigest() == manifest['runner_sha256']
assert hashlib.sha256((out / 'tokens.json').read_bytes()).hexdigest() == manifest['tokens_sha256']
assert hashlib.sha256((root / manifest['qualified_build_receipt']).read_bytes()).hexdigest() == manifest['qualified_build_receipt_sha256']
assert (root / 'evidence/context-r52-peer-coordination.json').is_file()
memory = r['observation']['memory']; gpu = r['observation']['gpu']
assert manifest['memory_admission']['expected_peak_gtt_bytes'] <= gpu['mem_info_gtt_total']
assert memory['MemAvailable'] - max(manifest['memory_admission']['expected_peak_gtt_bytes'] - gpu['mem_info_gtt_used'], 0) >= manifest['memory_admission']['min_available_ram_bytes']
remote = '/home/pop/workspace/synapse-lie/context-r52-prefill-ssd-ar-r1'
argv = ['ssh', '-F', '/dev/null', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8',
        'pop@192.168.5.161', 'python3', '-B', remote + '/runner.py', remote]
plan = {'argv': argv, 'remote_root': remote, 'source_commit': manifest['source_commit'],
        'native_client_code_checkpoint': manifest['native_client_code_checkpoint'],
        'runner_commit': manifest['runner_commit'], 'runner_sha256': manifest['runner_sha256'],
        'manifest_sha256': hashlib.sha256((out / 'manifest.json').read_bytes()).hexdigest(),
        'fresh_preflight': 'evidence/context-r52-before-ssd-r1.json',
        'peer_coordination': 'evidence/context-r52-peer-coordination.json',
        'standing_future_window': False}
with (out / 'plan.json').open('x') as f:
    json.dump(plan, f, indent=2); f.write('\n')
with (out / 'controller-stdout.log').open('x') as stdout, (out / 'controller-stderr.log').open('x') as stderr:
    p = subprocess.run(argv, stdout=stdout, stderr=stderr)
record = {**plan, 'exit_code': p.returncode}
with (out / 'controller-result.json').open('x') as f:
    json.dump(record, f, indent=2); f.write('\n')
try:
    result = json.loads((out / 'controller-stdout.log').read_text())
    with (out / 'result.json').open('x') as f:
        json.dump(result, f, indent=2); f.write('\n')
    print(json.dumps({k: result.get(k) for k in ('state', 'error', 'exit_code', 'child_exit_code',
        'pid', 'start_ticks', 'container', 'lease', 'lease_released_at', 'model_attempted', 'cleanup_failures')}))
except (OSError, ValueError):
    print(json.dumps({'actual_exit_code': p.returncode, 'error': 'Remote result unavailable; preserved controller logs'}))
raise SystemExit(p.returncode)
