# SPDX-License-Identifier: MIT
"""Verify the new completed archive and member bindings locally, once."""
from pathlib import Path
import datetime, hashlib, json, tarfile

root = Path.cwd()
receipt = root / 'docs/development/validation/responses-generation-controls-point-build-2026-10-07.json'
record = json.loads(receipt.read_text())
archive = record['portable_raw_archive']
path = receipt.parent / archive['path']
assert path.stat().st_size == archive['bytes']
assert hashlib.sha256(path.read_bytes()).hexdigest() == archive['sha256']
assert record['state'] == 'BUILT_NOT_GPU_TESTED_COLLECTED_VERIFIED_CLOSED'
assert record['shared_chat_history_compiled_as_C17'] is True
assert record['shared_chat_history_linked_consumers'] == ['synapse-lie-server', 'synapse-lie-bench', 'lie-sampling-capture']
assert record['current_source_original_weight_qualification_completed'] is False
assert record['previous_source_Chat_reversed_result_original_weight_pass_retained'] is True
assert record['Responses_Chat_server_controls_compiled_as_C17'] is True
assert record['fixed_question_schema_or_acceptance_changed'] is False
assert record['GPU_or_model_executed'] is False and record['original_weight_acceptance'] == 'OPEN'
with tarfile.open(path) as package:
    members = package.getmembers()
    assert len(members) == archive['members'] == len(record['raw_artifacts']) + 1
    assert len({m.name for m in members}) == len(members)
    for member in members:
        assert member.isreg()
        data = package.extractfile(member).read()
        if member.name == 'raw-inventory.json':
            assert json.loads(data) == record['raw_artifacts']
            continue
        expected = record['raw_artifacts'][member.name]
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
        live = root / member.name
        assert live.is_file() and not live.is_symlink()
        assert live.stat().st_size == expected['bytes']
        assert hashlib.sha256(live.read_bytes()).hexdigest() == expected['sha256']
result = {
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'actual_exit_code': 0,
    'all_archived_and_current_members_match': True, 'members': archive['members'],
    'archive_sha256': archive['sha256'], 'scope': 'Local completed evidence verification only',
    'remote_build_GPU_or_model_run': False,
}
with (root / 'evidence/context-r68-postseal.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
