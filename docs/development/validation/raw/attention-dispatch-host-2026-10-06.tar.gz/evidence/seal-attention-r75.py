# SPDX-License-Identifier: MIT
"""Seal the focused host/source increment; never run a model or rebuild."""
from pathlib import Path
import hashlib, json, os, subprocess, tarfile, gzip, io, re
root=Path.cwd()
sha=lambda b: hashlib.sha256(b).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert base=='5a957bf2eb2b06cab6c78e06be2d453fd68a0322'
labels=['dispatch-r75-release-configure','dispatch-r75-asan-configure',
 'dispatch-r75-release-build','dispatch-r75-asan-build',
 'dispatch-r75-release-ctest','dispatch-r75-asan-ctest',
 'dispatch-r75-release-build-r2','dispatch-r75-asan-build-r2',
 'dispatch-r75-release-ctest-r2','dispatch-r75-asan-ctest-r2',
 'dispatch-r75-source-proof','dispatch-r75-source-proof-r2',
 'dispatch-r75-header-c','dispatch-r75-header-cxx']
records={}
for label in labels:
 r=json.loads((root/'evidence'/label/'result.json').read_text())
 expected=8 if label in ['dispatch-r75-release-ctest','dispatch-r75-asan-ctest'] else 1 if label=='dispatch-r75-source-proof' else 0
 assert r['exit_code']==r['child_exit_code']==expected,(label,r)
 records[label]=r
for kind in ['release','asan']:
 log=(root/f'evidence/dispatch-r75-{kind}-ctest-r2/command.log').read_text()
 assert '100% tests passed out of 3' in log and 'AddressSanitizer' not in log
 cc=json.loads((root/f'build/dispatch-r75-{kind}/compile_commands.json').read_text())
 entries={Path(x['file']).name:x['command'] for x in cc}
 for name in ['test_attention_dispatch.c','test_core_dispatch.c','dispatch_executor.c']:
  assert '-std=c17' in entries[name] and '-Werror' in entries[name] and '-UNDEBUG' in entries[name]
  if kind=='asan': assert '-fsanitize=address,undefined' in entries[name]
 assert '-std=c17' in entries['dispatch.c']
assert 'detect_leaks=0' not in os.environ.get('ASAN_OPTIONS','')
assert not os.environ.get('LSAN_OPTIONS','')
source_names=subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).splitlines()
source_names += subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
source_names=sorted(set(source_names))
assert len(source_names)==32,(len(source_names),source_names)
source_map={p:sha((root/p).read_bytes()) for p in source_names}
recipes=sorted(p.relative_to(root).as_posix() for p in (root/'adapters/gufo-state').glob('*-edits.json'))
recipe_map={p:sha((root/p).read_bytes()) for p in recipes}
pristine=json.loads((root/'third_party/gufo-source.json').read_text())
assert pristine['commit']=='f783fedb9bea2ec7de941f6da4e02f4a4596b29e'
assert len(pristine['files'])==1019
for name,digest in pristine['files'].items():
 assert sha((root/'.deps/gufo-f783fedb'/name).read_bytes())==digest,name
variants=json.loads((root/'evidence/dispatch-r75-source-proof-r2/variants.json').read_text())
assert set(variants)=={'kvc_OFF','kvc_ON'}
assert all(len(files)==1019 for files in variants.values())
peak=max(v for r in records.values() for path,v in r['peak_c'].items() if 'hwmon8/' in path)
assert peak==83.125,peak
artifacts=list(source_names)+recipes+['third_party/gufo-source.json',
 'evidence/check-attention-r75.cmake','evidence/check-attention-r75-r2.cmake',
 'evidence/dispatch-r75-public.c','evidence/seal-attention-r75.py']
for label in labels:
 artifacts += [p.relative_to(root).as_posix() for p in (root/'evidence'/label).rglob('*') if p.is_file()]
for kind in ['release','asan']:
 for name in ['CMakeCache.txt','compile_commands.json','Testing/Temporary/LastTest.log']:
  artifacts.append(f'build/dispatch-r75-{kind}/{name}')
artifacts=sorted(set(artifacts))
manifest={name:sha((root/name).read_bytes()) for name in artifacts}
archive_name='docs/development/validation/raw/attention-dispatch-host-2026-10-06.tar.gz'
archive=root/archive_name
assert not archive.exists()
archive.parent.mkdir(parents=True,exist_ok=True)
with archive.open('xb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name in artifacts:
    data=(root/name).read_bytes(); info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; tar.addfile(info,io.BytesIO(data))
   data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();info=tarfile.TarInfo('ARTIFACT-SHA256.json');info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(manifest)+1
 for name,digest in manifest.items():assert sha(tar.extractfile(name).read())==digest,name
receipt={
 'schema':'lie.focused-host-validation.v1','state':'SOURCE_AND_FOCUSED_HOST_PASSED_PRIVATE_HIP_AND_GPU_PENDING',
 'date_utc':'2026-10-06','base_commit':base,'branch':'feature/context-million-openai',
 'scope':'Shared C17 prefill attention observer, owner publication and native core bench projection; NOT-INFERENCE',
 'source_files':source_map,'source_file_count':len(source_map),'recipe_files':recipe_map,
 'upstream':{'commit':pristine['commit'],'pristine_files_verified':1019,'new_non_kvc_recipes':40,
   'exact_variant_map_kvc_off_entries':1019,'exact_variant_map_kvc_on_entries':1019,
   'numerical_kernel_prefix_new_recipe_unchanged':True,'private_full_coherent_rebuild_required':True},
 'focused_checks':{'release':{'checks':3,'passed':3,'actual_exit_code':0,'run':'dispatch-r75-release-ctest-r2'},
   'asan_ubsan_lsan':{'checks':3,'passed':3,'actual_exit_code':0,'unsuppressed':True,'run':'dispatch-r75-asan-ctest-r2'},
   'public_headers':['C17','C++17'],'source_proof':'dispatch-r75-source-proof-r2'},
 'preserved_failures':[
  {'run':'dispatch-r75-release-ctest','actual_exit_code':8,'reason':'Dedicated fixture wrapped scalar admission; core uses batch admission, so initial observer remained unavailable'},
  {'run':'dispatch-r75-asan-ctest','actual_exit_code':8,'reason':'Same dedicated fixture admission hook plus restricted sandbox LSan ptrace refusal'},
  {'run':'dispatch-r75-source-proof','actual_exit_code':1,'reason':'Source checker compared new variant prefix with pristine, omitting preceding valid sampler recipes'}],
 'semantics':{'abi':1,'default_on_compile_option':'LIE_ATTENTION_DISPATCH_STATS',
   'storage':'Inline owner-serialized counter; no heap, lock, thread or device work in counter',
   'publication':'Core copies last returned owner view; clients perform no provider/device wait',
   'scope':'Trunk prefill host selections only; no decode, capture/replay or predictor attention',
   'completion':'Staged calls confirm only after numerical Sync completion; early fault/refusal/cancel retains unconfirmed counts',
   'rows':'Summed attention-layer rows, not physical prompt tokens',
   'unavailable':'Explicit unsupported/non-exact flags and null native JSON totals, never inferred zero GPU work',
   'delta':'Same nonzero process-local epoch, available endpoints, monotonic counters, no pending/overflow',
   'maxima':'Lifetime host-observed rows/mask words, including unconfirmed work',
   'overflow':'Saturates without wrap; exact deltas refused'},
 'runtime_qualifications':{'gpu':False,'original_weights':False,'performance':False,'new_private_hip_compilation':False,
   'threads_changed':False,'cache_framing_changed':False,'reactive_scheduling_changed':False},
 'host_resources':{'cpu_peak_c':peak,'cpu_guard_c':98,'nvme_guard_c':85,
   'lower_sensor_limits_honored':True,'gpu_masked':True,'gpu_temperatures_observe_only':True,
   'build_parallelism_per_group':2,'fan_clock_power_tuning':False,'shutdown_or_deterioration_observed':False},
 'sequencing':'Finish functional source; integrated .161 qualification; matched benchmarks; Terminal Bench last',
 'open_root_items':[2,3,4,5,6,7],
 'archive':{'path':archive_name,'sha256':sha(archive.read_bytes()),'members':len(manifest)+1,'file_hashes':manifest},
 'commands':records}
path=root/'docs/development/validation/attention-dispatch-host-2026-10-06.json'
assert not path.exists();path.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'receipt_sha256':sha(path.read_bytes()),'archive_sha256':receipt['archive']['sha256'],
 'source_file_count':len(source_map),'archive_members':len(manifest)+1,'cpu_peak_c':peak,'actual_exit_code':0}))
