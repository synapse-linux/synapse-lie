/* SPDX-License-Identifier: MIT */
#include "lie/dispatch.h"
#include "lie/core.h"
#include "lie/executor.h"
int main(void) { return LIE_ATTENTION_DISPATCH_ABI != 1; }
