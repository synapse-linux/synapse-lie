/* SPDX-License-Identifier: MIT */
/* Direct client of the production C core. Reports client and executor scopes. */
#include "lie/core.h"
#include "lie/events.h"
#include "bench_native.h"
#include "lie/text.h"
#include "../src/output_json.h"
#include <errno.h>
#include <fcntl.h>
#include <json-c/json.h>
#include <limits.h>
#include <math.h>
#include <openssl/evp.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
int lie_bench_graphs(const char *,const char *,const char *);
static volatile sig_atomic_t interrupted;
static void stop_signal(int signo) { (void)signo;interrupted=1; }
static uint64_t now(void) {
    struct timespec t;if(clock_gettime(CLOCK_MONOTONIC,&t)||t.tv_sec<0)return 0;
    return (uint64_t)t.tv_sec*1000000000u+(uint64_t)t.tv_nsec;
}
static void number(json_object *o,const char *key,uint64_t n) { json_object_object_add(o,key,json_object_new_uint64(n)); }
static void text(json_object *o,const char *key,const char *s) { json_object_object_add(o,key,json_object_new_string(s)); }
static json_object *event(const char *name) { json_object *o=json_object_new_object();text(o,"event",name);return o; }
static json_object *dispatch_totals(const lie_attention_dispatch_totals *t) {
    json_object *o=json_object_new_object();
    number(o,"matrix_dense",t->matrix_dense);number(o,"matrix_sparse",t->matrix_sparse);
    number(o,"scalar_dense",t->scalar_dense);number(o,"scalar_sparse",t->scalar_sparse);
    number(o,"geometry_refusals",t->geometry_refusals);number(o,"mask_pitch_refusals",t->mask_pitch_refusals);
    number(o,"attention_rows",t->attention_rows);return o;
}
static json_object *dispatch_view(const lie_attention_dispatch_info *v,bool exact,const char *scope) {
    json_object *o=json_object_new_object();text(o,"scope",scope);
    json_object_object_add(o,"supported",json_object_new_boolean(v->supported));
    json_object_object_add(o,"exact",json_object_new_boolean(exact));
    json_object_object_add(o,"pending",json_object_new_boolean(v->pending));
    json_object_object_add(o,"overflowed",json_object_new_boolean(v->overflowed));
    json_object_object_add(o,"model_domain",v->supported?json_object_new_uint64(v->domain):NULL);
    json_object_object_add(o,"confirmed_batches",exact?json_object_new_uint64(v->confirmed_batches):NULL);
    json_object_object_add(o,"unconfirmed_batches",exact?json_object_new_uint64(v->unconfirmed_batches):NULL);
    json_object_object_add(o,"confirmed",exact?dispatch_totals(&v->confirmed):NULL);
    json_object_object_add(o,"unconfirmed",exact?dispatch_totals(&v->unconfirmed):NULL);
    json_object_object_add(o,"lifetime_max_rows",v->supported?json_object_new_uint64(v->max_observed_rows):NULL);
    json_object_object_add(o,"lifetime_max_mask_words",v->supported?json_object_new_uint64(v->max_observed_mask_words):NULL);
    if(!exact)text(o,"reason",v->supported?"non-exact-observation-window":"provider-unsupported");
    return o;
}
static bool emit(FILE *f,json_object *o) {
    bool ok=fputs(json_object_to_json_string_ext(o,JSON_C_TO_STRING_PLAIN),f)>=0 && fputc('\n',f)!=EOF && !fflush(f);
    json_object_put(o);return ok;
}
static bool integer(const char *s,unsigned lo,unsigned hi,unsigned *out) {
    char *end;errno=0;unsigned long value=strtoul(s,&end,10);
    if(errno||!*s||*s=='-'||*end||value<lo||value>hi)return false;
    *out=(unsigned)value;return true;
}
static bool real(const char *s,double lo,double hi,double *out) {
    if(!*s||strspn(s,"-+0123456789.eE")!=strlen(s))return false;
    char *end;errno=0;double value=strtod(s,&end);
    if(errno||*end||!isfinite(value)||value<lo||value>hi)return false;
    *out=value;return true;
}
static bool seed_value(const char *s,int64_t *out) {
    if(!*s||strspn(s,"+0123456789")!=strlen(s))return false;
    char *end;errno=0;long long value=strtoll(s,&end,10);
    if(errno||*end||value<0||value>INT64_MAX)return false;
    *out=(int64_t)value;return true;
}
static json_object *ids_json(const int32_t *p,size_t n) {
    json_object *a=json_object_new_array();for(size_t i=0;i<n;++i)json_object_array_add(a,json_object_new_int(p[i]));return a;
}
static bool ids_hash(const int32_t *p,size_t n,char hex[65]) {
    EVP_MD_CTX *ctx=EVP_MD_CTX_new();if(!ctx)return false;
    bool ok=EVP_DigestInit_ex(ctx,EVP_sha256(),NULL)==1;
    for(size_t i=0;ok&&i<n;++i){uint32_t v=(uint32_t)p[i];unsigned char b[]={v,v>>8,v>>16,v>>24};ok=EVP_DigestUpdate(ctx,b,4)==1;}
    unsigned char bytes[32];unsigned count=0;
    ok=ok&&EVP_DigestFinal_ex(ctx,bytes,&count)==1&&count==32;EVP_MD_CTX_free(ctx);
    if(ok)for(unsigned i=0;i<32;++i)snprintf(hex+2*i,3,"%02x",bytes[i]);
    return ok;
}
static char *read_input(const char *path,size_t *bytes) {
    FILE *f=fopen(path,"rb");if(!f)return NULL;
    char *p=malloc(LIE_CHAT_BODY_BYTES+1u);if(!p){fclose(f);return NULL;}
    *bytes=fread(p,1,LIE_CHAT_BODY_BYTES+1u,f);
    bool valid=*bytes && *bytes<=LIE_CHAT_BODY_BYTES && !ferror(f);fclose(f);
    if(!valid){free(p);return NULL;}p[*bytes]=0;return p;
}
static bool read_schedule(const char *path,lie_steering_step steps[LIE_STEERING_SCHEDULE_MAX],lie_steering_schedule *plan){
    size_t bytes=0;char *data=read_input(path,&bytes);if(!data)return false;
    oj_node *unique=oj_parse(data,bytes);nb_error error={0};json_object *array=unique?nb_parse(data,bytes,&error):NULL;oj_free(unique);free(data);
    bool valid=json_object_is_type(array,json_type_array);
    size_t count=valid?json_object_array_length(array):0;
    valid=valid&&count&&count<=LIE_STEERING_SCHEDULE_MAX;
    for(size_t i=0;valid&&i<count;++i){
        json_object *row=json_object_array_get_idx(array,i);int64_t position=0;
        valid=json_object_is_type(row,json_type_object)&&json_object_object_length(row)==3&&
              nb_count(row,"position",0,LIE_CORE_MAX_CONTEXT-1,&position)&&(!i||(uint64_t)position>steps[i-1].position);
        const char *keys[]={"ffn","attention"};float *values[]={&steps[i].settings.ffn,&steps[i].settings.attention};
        lie_steering_settings_init(&steps[i].settings,true);steps[i].position=(uint64_t)position;
        for(unsigned k=0;valid&&k<2;++k){json_object *v=nb_get(row,keys[k]);double x=json_object_get_double(v);
            valid=(json_object_is_type(v,json_type_int)||json_object_is_type(v,json_type_double))&&isfinite(x)&&fabs(x)<=100;
            if(valid)*values[k]=(float)(x==0?0:x);
        }
    }
    json_object_put(array);
    if(valid)*plan=(lie_steering_schedule){LIE_STEERING_SCHEDULE_ABI,sizeof(*plan),count,steps};
    return valid;
}
static json_object *schedule_json(const lie_steering_schedule *plan){
    json_object *array=json_object_new_array();
    for(size_t i=0;plan&&i<plan->count;++i){json_object *step=json_object_new_object();
        number(step,"position",plan->steps[i].position);nb_real(step,"ffn",plan->steps[i].settings.ffn);
        nb_real(step,"attention",plan->steps[i].settings.attention);json_object_array_add(array,step);
    }
    return array;
}
static json_object *schedule_result(lie_job *job,bool *complete){
    lie_steering_schedule_info plan={.abi_version=LIE_STEERING_SCHEDULE_ABI,.struct_bytes=sizeof(plan)};
    lie_job_steering_info policy={.abi_version=LIE_JOB_STEERING_ABI,.struct_bytes=sizeof(policy)};
    if(lie_job_steering_schedule_snapshot(job,&plan,NULL)!=LIE_OK||lie_job_steering_snapshot(job,&policy,NULL)!=LIE_OK)return NULL;
    *complete=plan.terminal&&plan.completed==plan.count&&plan.applied==plan.count;
    json_object *out=json_object_new_object(),*results=json_object_new_array();
    number(out,"completed",plan.completed);number(out,"applied",plan.applied);
    json_object_object_add(out,"terminal",json_object_new_boolean(plan.terminal));
    json_object_object_add(out,"steps",results);
    for(size_t i=0;i<plan.count;++i){json_object *step=json_object_new_object();
        number(step,"position",plan.steps[i].position);number(step,"actual_position",plan.results[i].actual_position);
        nb_real(step,"ffn",plan.steps[i].settings.ffn);nb_real(step,"attention",plan.steps[i].settings.attention);
        json_object_object_add(step,"attempted",json_object_new_boolean(plan.results[i].attempted));
        json_object_object_add(step,"applied",json_object_new_boolean(plan.results[i].applied));
        nb_num(step,"status",plan.results[i].status);json_object_array_add(results,step);
        *complete=*complete&&plan.results[i].applied&&plan.results[i].actual_position==plan.steps[i].position;
    }
    nb_real(out,"final_ffn",policy.policy.settings.ffn);nb_real(out,"final_attention",policy.policy.settings.attention);
    number(out,"history_epochs",policy.policy.history_epochs);number(out,"completed_positions",policy.policy.completed_positions);
    char scope[65];for(unsigned k=0;k<32;++k)snprintf(scope+2*k,3,"%02x",policy.combined_scope[k]);text(out,"combined_scope_sha256",scope);
    return out;
}
static bool wait_core(lie_core *c,lie_core_state wanted,uint64_t deadline) {
    for(;;){lie_core_info info;lie_core_snapshot(c,&info);if(info.state==wanted)return true;
        if(wanted!=LIE_STOPPED && (interrupted||info.state==LIE_FAILED||!now()||now()>=deadline))return false;
        struct pollfd fd={lie_core_fd(c),POLLIN,0};
        int rc=poll(&fd,1,100);if(rc<0&&errno!=EINTR)return false;
        if(rc>0)lie_core_drain(c);
    }
}
typedef struct {
    lie_job *job;uint64_t start,first,end,tokens,bytes;bool terminal,scheduled;
} consumer;
typedef struct { int32_t *prompt;size_t count;bool initialized;int32_t output[LIE_CORE_MAX_OUTPUT];size_t output_count; } witness;
/* Metadata snapshots only. Sampling does not consume output loans or invoke
 * the numerical provider. Core and job snapshots have separate lock scopes. */
static bool progress(lie_core *core,const consumer *rows,unsigned users,
                     unsigned rep,bool warmup,uint64_t begin,bool final) {
    uint64_t observed=now();if(!observed||observed<begin)return false;
    lie_core_info info;lie_core_snapshot(core,&info);
    lie_attention_dispatch_info dispatch;lie_attention_dispatch_info_init(&dispatch);
    bool seen=lie_core_attention_dispatch_snapshot(core,&dispatch,NULL)==LIE_OK;
    json_object *line=event("core_progress"),*jobs=json_object_new_array();
    json_object_object_add(line,"prefill_attention_dispatch",dispatch_view(&dispatch,
        seen&&dispatch.supported&&!dispatch.pending&&!dispatch.overflowed,"model-cumulative"));
    text(line,"schema","synapse-lie.core-progress.v1");
    number(line,"rep",rep);number(line,"warmup",warmup);
    number(line,"snapshot_monotonic_ns",observed);number(line,"elapsed_ns",observed-begin);
    json_object_object_add(line,"final_snapshot",json_object_new_boolean(final));
    json_object_object_add(line,"synthetic",json_object_new_boolean(lie_backend_is_synthetic()));
    const char *phases[]={"idle","prefill","decode","capture","restore"};
    text(line,"executor_phase",(unsigned)info.executor_phase<sizeof(phases)/sizeof(*phases)?phases[info.executor_phase]:"unknown");
    number(line,"queued",info.queued);number(line,"active",info.active);number(line,"output_blocked",info.output_blocked);
    number(line,"prefill_started",info.prefill_started);number(line,"prefill_returned",info.prefill_returned);
    json_object_object_add(line,"jobs",jobs);
    for(unsigned i=0;i<users;++i)if(rows[i].job){
        lie_job_info job;lie_job_snapshot(rows[i].job,&job);
        json_object *row=json_object_new_object();number(row,"user",i);
        json_object_object_add(row,"prepared",json_object_new_boolean(job.prepared));
        json_object_object_add(row,"retired",json_object_new_boolean(job.retired));
        json_object_object_add(row,"terminal_observed",json_object_new_boolean(rows[i].terminal));
        number(row,"prompt_tokens",job.prompt_tokens);number(row,"cached_tokens",job.cached_tokens);
        number(row,"prefill_tokens",job.prefill_tokens);number(row,"prefill_calls",job.prefill_calls);
        number(row,"output_tokens",job.output_tokens);number(row,"consumer_tokens",rows[i].tokens);
        number(row,"decode_calls",job.decode_calls);number(row,"prefill_ns",job.prefill_ns);number(row,"decode_ns",job.decode_ns);
        if(job.error[0])text(row,"error",job.error);
        if(rows[i].scheduled){bool complete=false;json_object_object_add(row,"steering_schedule",schedule_result(rows[i].job,&complete));}
        json_object_array_add(jobs,row);
    }
    return emit(stderr,line);
}
static bool sample(lie_core *c,const lie_core_request *r,unsigned users,unsigned rep,bool warmup,
                   unsigned timeout,unsigned progress_ms,const lie_steering_schedule *plan,witness *w,FILE *f,char error[256]) {
    consumer rows[LIE_CORE_JOBS]={0};bool ok=false;unsigned finished=0;
    uint64_t begin=now(),last=0,deadline=begin+(uint64_t)timeout*1000000u,next_progress=begin;
    if(!begin){snprintf(error,256,"clock failure");return false;}
    lie_core_info before;lie_core_snapshot(c,&before);
    lie_attention_dispatch_info dispatch_before;lie_attention_dispatch_info_init(&dispatch_before);
    bool dispatch_start=lie_core_attention_dispatch_snapshot(c,&dispatch_before,NULL)==LIE_OK;
    for(unsigned i=0;i<users;++i){rows[i].start=now();rows[i].scheduled=plan!=NULL;
        if(!rows[i].start||lie_core_submit_steering(c,r,plan,&rows[i].job)){snprintf(error,256,"core admission refused");goto done;}}
    while(finished<users){
        if(interrupted||!now()||now()>=deadline){snprintf(error,256,"interrupted or core deadline exceeded");goto done;}
        uint64_t observed=progress_ms?now():0;
        if(progress_ms&&observed>=next_progress){
            if(!progress(c,rows,users,rep,warmup,begin,false)){snprintf(error,256,"core progress output failed");goto done;}
            next_progress=observed+(uint64_t)progress_ms*1000000u;
        }
        struct pollfd fds[LIE_CORE_JOBS];nfds_t count=0;
        for(unsigned i=0;i<users;++i)if(!rows[i].terminal){
            if(lie_job_event_drain(rows[i].job)!=LIE_FLOW_OK)goto done;
            for(;;){lie_event e;lie_flow_status rc=lie_job_event_next(rows[i].job,&e);
                if(rc==LIE_FLOW_WOULD_BLOCK)break;
                if(rc!=LIE_FLOW_OK){snprintf(error,256,"core output contract failure");goto done;}
                uint64_t seen=now();
                if(!seen||seen<rows[i].start){
                    if(e.kind!=LIE_EVENT_TURN_END)(void)lie_job_event_release(rows[i].job,e.ticket);
                    snprintf(error,256,"clock failure");goto done;
                }
                if(e.kind==LIE_EVENT_TURN_END){
                    rows[i].terminal=true;rows[i].end=seen;last=seen;++finished;
                    if(e.end!=LIE_FLOW_COMPLETE){lie_job_info info;lie_job_snapshot(rows[i].job,&info);
                        snprintf(error,256,"core job failed: %.220s",info.error);goto done;}
                    break;
                }
                if(!rows[i].first && e.tokens)rows[i].first=seen;
                bool ordered=e.token_offset==rows[i].tokens;
                rows[i].tokens+=e.tokens;rows[i].bytes+=e.bytes;
                if(lie_job_event_release(rows[i].job,e.ticket)!=LIE_FLOW_OK||!ordered){snprintf(error,256,"core token order failure");goto done;}
                if(e.tokens)(void)lie_job_event_request(rows[i].job,e.tokens);
            }
            if(!rows[i].terminal)fds[count++]=(struct pollfd){lie_job_event_fd(rows[i].job),POLLIN,0};
        }
        if(count && poll(fds,count,100)<0 && errno!=EINTR){snprintf(error,256,"core event wait failed");goto done;}
    }
    if(last<=begin){snprintf(error,256,"invalid core elapsed time");goto done;}
    /* Model retirement can follow the observable terminal by a few instructions. */
    for(unsigned i=0;i<users;++i)for(;;){lie_job_info info;lie_job_snapshot(rows[i].job,&info);if(info.retired)break;
        if(interrupted||now()>=deadline){snprintf(error,256,"core retirement deadline");goto done;}
        struct pollfd fd={lie_core_fd(c),POLLIN,0};if(poll(&fd,1,100)>0)lie_core_drain(c);
    }
    for(unsigned i=0;i<users;++i){
        lie_job_info info;lie_job_snapshot(rows[i].job,&info);size_t n=0;
        if(plan){bool complete=false;json_object *result=schedule_result(rows[i].job,&complete);
            if(!result||!complete){json_object *failure=event("steering_failure");number(failure,"rep",rep);number(failure,"user",i);
                json_object_object_add(failure,"steering_schedule",result);(void)emit(f,failure);
                snprintf(error,256,"steering schedule was not completely applied at its declared boundaries");goto done;}
            json_object_put(result);
        }
        if(r->eos_policy==LIE_EOS_IGNORE &&
           (info.finish!=LIE_FINISH_LENGTH || info.output_tokens!=r->max_tokens)){
            snprintf(error,256,"incomplete fixed-budget core decode");goto done;}
        int32_t *input=malloc((size_t)info.prompt_tokens*sizeof(*input));
        int32_t output[LIE_CORE_MAX_OUTPUT];
        if(!input||!info.timing_valid||info.output_tokens!=rows[i].tokens||
           lie_job_prompt_tokens(rows[i].job,input,info.prompt_tokens,&n)!=LIE_OK||n!=info.prompt_tokens){
            free(input);snprintf(error,256,"core prompt/timing witness failed");goto done;}
        if(!w->initialized){
            w->prompt=input;w->count=n;input=NULL;
            char digest[65];if(!ids_hash(w->prompt,w->count,digest)){snprintf(error,256,"input digest failure");goto done;}
            json_object *in=event("input");number(in,"prompt_tokens",n);text(in,"physical_ids_sha256",digest);
            json_object_object_add(in,"physical_ids",ids_json(w->prompt,n));if(!emit(f,in))goto done;
        }else if(n!=w->count||memcmp(input,w->prompt,n*sizeof(*input))){free(input);snprintf(error,256,"physical prompt drift");goto done;}
        free(input);
        if(lie_job_output_tokens(rows[i].job,output,LIE_CORE_MAX_OUTPUT,&n)!=LIE_OK||n!=info.output_tokens){snprintf(error,256,"output witness failure");goto done;}
        if(w->initialized && (n!=w->output_count||memcmp(output,w->output,n*sizeof(*output)))){snprintf(error,256,"reproducible output drift");goto done;}
        if(!w->initialized){w->output_count=n;memcpy(w->output,output,n*sizeof(*output));w->initialized=true;}
        json_object *job=event("job");number(job,"rep",rep);number(job,"warmup",warmup);number(job,"user",i);
        number(job,"prompt_tokens",info.prompt_tokens);number(job,"output_tokens",info.output_tokens);number(job,"output_bytes",rows[i].bytes);
        number(job,"prefill_tokens",info.prefill_tokens);number(job,"prefill_ns",info.prefill_ns);number(job,"decode_ns",info.decode_ns);
        number(job,"cached_tokens",info.cached_tokens);number(job,"cache_capture_ns",info.cache_capture_ns);number(job,"cache_restore_ns",info.cache_restore_ns);
        number(job,"ssd_cached_tokens",info.ssd_cached_tokens);number(job,"ssd_read_ns",info.ssd_read_ns);
        number(job,"max_decode_output_tokens",info.max_decode_output_tokens);
        number(job,"mtp_drafted_tokens",info.mtp_drafted);number(job,"mtp_accepted_tokens",info.mtp_accepted);
        number(job,"prefill_calls",info.prefill_calls);number(job,"decode_calls",info.decode_calls);
        number(job,"total_ns",rows[i].end-rows[i].start);
        json_object_object_add(job,"first_token_ns",rows[i].first?json_object_new_uint64(rows[i].first-rows[i].start):NULL);
        text(job,"finish",info.finish==LIE_FINISH_STOP?"stop":"length");json_object_object_add(job,"output_ids",ids_json(output,n));
        if(plan){bool complete=false;json_object_object_add(job,"steering_schedule",schedule_result(rows[i].job,&complete));}
        if(!emit(f,job))goto done;
    }
    lie_core_info after;lie_core_snapshot(c,&after);
    lie_attention_dispatch_info dispatch_after,dispatch_delta;
    lie_attention_dispatch_info_init(&dispatch_after);lie_attention_dispatch_info_init(&dispatch_delta);
    bool dispatch_end=lie_core_attention_dispatch_snapshot(c,&dispatch_after,NULL)==LIE_OK;
    bool dispatch_exact=dispatch_start&&dispatch_end&&
        lie_attention_dispatch_delta(&dispatch_before,&dispatch_after,&dispatch_delta)==LIE_DISPATCH_OK;
    json_object *point=event("sample");
    json_object_object_add(point,"prefill_attention_dispatch",dispatch_view(
        dispatch_exact?&dispatch_delta:&dispatch_after,dispatch_exact,"model-cohort-delta"));
    number(point,"rep",rep);number(point,"warmup",warmup);number(point,"users",users);
    uint64_t tokens=0;for(unsigned i=0;i<users;++i)tokens+=rows[i].tokens;
    number(point,"output_tokens",tokens);number(point,"wall_ns",last-begin);
    json_object_object_add(point,"output_per_total_wall_tps",json_object_new_double(tokens*1e9/(last-begin)));
    number(point,"decode_batches",after.decode_batches-before.decode_batches);number(point,"decode_batch_rows",after.decode_batch_rows-before.decode_batch_rows);
    number(point,"decode_single_calls",after.decode_single_calls-before.decode_single_calls);
    number(point,"cache_hits",after.cache.hits-before.cache.hits);number(point,"cache_misses",after.cache.misses-before.cache.misses);
    number(point,"cache_captures",after.cache.captures-before.cache.captures);number(point,"cache_evictions",after.cache.evictions-before.cache.evictions);
    number(point,"cache_skipped",after.cache.skipped-before.cache.skipped);
    number(point,"cache_retained_bytes",after.cache.retained_bytes);number(point,"cache_budget_bytes",after.cache.budget_bytes);
    number(point,"cache_expanded_bytes",after.cache.expanded_bytes);
    number(point,"cache_compressed_captures",after.cache.compressed_captures-before.cache.compressed_captures);
    number(point,"ssd_hits",after.ssd.hits-before.ssd.hits);number(point,"ssd_misses",after.ssd.misses-before.ssd.misses);
    number(point,"ssd_writes",after.ssd.writes-before.ssd.writes);number(point,"ssd_read_ns",after.ssd.read_ns-before.ssd.read_ns);
    number(point,"ssd_evictions",after.ssd.evictions-before.ssd.evictions);number(point,"ssd_skipped",after.ssd.skipped-before.ssd.skipped);
    number(point,"ssd_errors",after.ssd.errors-before.ssd.errors);
    number(point,"ssd_write_ns",after.ssd.write_ns-before.ssd.write_ns);number(point,"ssd_disk_bytes",after.ssd.disk_bytes);
    ok=emit(f,point);
done:
    if(progress_ms&&!progress(c,rows,users,rep,warmup,begin,true)){
        snprintf(error,256,"core progress output failed");ok=false;
    }
    for(unsigned i=0;i<users;++i)if(rows[i].job)lie_job_release(rows[i].job);
    return ok;
}
/* A direct C-core consumer holds one borrowed output while a peer finishes.
 * This is a functional credit/cancellation gate, not a throughput benchmark. */
static bool reactive_probe(lie_core *core,const lie_core_request *request,unsigned limit,
                           unsigned timeout,bool mtp,FILE *f,char error[256]) {
    lie_job *held=NULL,*peer=NULL;lie_event loan={0};bool borrowed=false,passed=false;
    uint64_t deadline=now()+(uint64_t)timeout*1000000u;
    uint64_t held_tokens=0,peer_tokens=0;unsigned char *held_copy=NULL;
    lie_core_info before,blocked,after;lie_core_snapshot(core,&before);
    if(lie_core_submit(core,request,&held)||lie_core_submit(core,request,&peer)){
        snprintf(error,256,"reactive admission failed");goto done;
    }
    for(;;){
        if(interrupted||now()>=deadline){snprintf(error,256,"reactive held-output deadline");goto done;}
        lie_flow_status status=lie_job_event_next(held,&loan);
        if(status==LIE_FLOW_WOULD_BLOCK){
            struct pollfd fd={lie_job_event_fd(held),POLLIN,0};
            if(poll(&fd,1,100)<0&&errno!=EINTR){snprintf(error,256,"reactive held-output poll failed");goto done;}
            if(lie_job_event_drain(held)!=LIE_FLOW_OK){snprintf(error,256,"reactive held-output drain failed");goto done;}
            continue;
        }
        if(status!=LIE_FLOW_OK||loan.kind==LIE_EVENT_TURN_END){snprintf(error,256,"reactive held-output missing");goto done;}
        borrowed=true;held_tokens+=loan.tokens;
        if(loan.kind==LIE_EVENT_TEXT&&loan.bytes&&loan.text){
            held_copy=malloc(loan.bytes);
            if(!held_copy){snprintf(error,256,"reactive loan snapshot allocation failed");goto done;}
            memcpy(held_copy,loan.text,loan.bytes);break;
        }
        if(lie_job_event_release(held,loan.ticket)!=LIE_FLOW_OK){snprintf(error,256,"reactive early loan release failed");goto done;}
        borrowed=false;if(loan.tokens){
            lie_flow_status credit=lie_job_event_request(held,loan.tokens);
            if(credit!=LIE_FLOW_OK&&credit!=LIE_FLOW_CLOSED){snprintf(error,256,"reactive early credit failed");goto done;}
        }
    }
    for(;;){
        if(interrupted||now()>=deadline){snprintf(error,256,"reactive peer deadline");goto done;}
        lie_event current;lie_flow_status status=lie_job_event_next(peer,&current);
        if(status==LIE_FLOW_WOULD_BLOCK){
            struct pollfd fd={lie_job_event_fd(peer),POLLIN,0};
            if(poll(&fd,1,100)<0&&errno!=EINTR){snprintf(error,256,"reactive peer poll failed");goto done;}
            if(lie_job_event_drain(peer)!=LIE_FLOW_OK){snprintf(error,256,"reactive peer drain failed");goto done;}
            continue;
        }
        if(status!=LIE_FLOW_OK){snprintf(error,256,"reactive peer event failed");goto done;}
        if(current.kind==LIE_EVENT_TURN_END){
            if(current.end!=LIE_FLOW_COMPLETE||!current.info.retired||peer_tokens!=limit){
                snprintf(error,256,"reactive peer did not complete full budget");goto done;
            }
            break;
        }
        if(current.token_offset!=peer_tokens){snprintf(error,256,"reactive peer token order failed");goto done;}
        peer_tokens+=current.tokens;
        if(lie_job_event_release(peer,current.ticket)!=LIE_FLOW_OK){snprintf(error,256,"reactive peer release failed");goto done;}
        if(current.tokens){
            lie_flow_status credit=lie_job_event_request(peer,current.tokens);
            if(credit!=LIE_FLOW_OK&&credit!=LIE_FLOW_CLOSED){snprintf(error,256,"reactive peer credit failed");goto done;}
        }
    }
    /* The peer terminal can precede the core-wide completion counter. Keep
     * the other loan held while waiting for the owner notice to settle. */
    lie_job_info held_info;
    uint64_t peer_deadline=now()+2000000000u;
    for(;;){
        lie_core_snapshot(core,&blocked);
        lie_job_snapshot(held,&held_info);
        if(blocked.completed_requests>=before.completed_requests+1&&
           blocked.active==1&&blocked.output_blocked==1)break;
        if(interrupted||now()>=deadline||now()>=peer_deadline)break;
        struct pollfd fd={lie_core_fd(core),POLLIN,0};
        int rc=poll(&fd,1,100);
        if(rc<0&&errno!=EINTR){snprintf(error,256,"reactive peer counter poll failed");goto done;}
        if(rc>0)lie_core_drain(core);
    }
    if(blocked.active!=1||blocked.output_blocked!=1||held_info.output_tokens>=limit||
       held_info.retired||peer_tokens!=limit||blocked.completed_requests!=before.completed_requests+1){
        snprintf(error,256,"peer did not progress during held credit stall: active=%llu blocked=%llu completed=%llu held=%llu",
                 (unsigned long long)blocked.active,(unsigned long long)blocked.output_blocked,
                 (unsigned long long)(blocked.completed_requests-before.completed_requests),
                 (unsigned long long)held_info.output_tokens);goto done;
    }
    lie_job_cancel(held);
    if(memcmp(loan.text,held_copy,loan.bytes)||lie_job_event_release(held,loan.ticket)!=LIE_FLOW_OK){
        snprintf(error,256,"borrowed output changed during cancellation");goto done;
    }
    borrowed=false;
    for(;;){
        if(interrupted||now()>=deadline){snprintf(error,256,"reactive cancellation deadline");goto done;}
        lie_event current;lie_flow_status status=lie_job_event_next(held,&current);
        if(status==LIE_FLOW_WOULD_BLOCK){
            struct pollfd fd={lie_job_event_fd(held),POLLIN,0};
            if(poll(&fd,1,100)<0&&errno!=EINTR){snprintf(error,256,"reactive cancellation poll failed");goto done;}
            if(lie_job_event_drain(held)!=LIE_FLOW_OK){snprintf(error,256,"reactive cancellation drain failed");goto done;}
            continue;
        }
        if(status!=LIE_FLOW_OK){snprintf(error,256,"reactive cancellation event failed");goto done;}
        if(current.kind==LIE_EVENT_TURN_END){
            if(current.reason!=LIE_TURN_CANCELLED||!current.info.retired){
                snprintf(error,256,"reactive cancellation terminal invalid");goto done;
            }
            break;
        }
        if(lie_job_event_release(held,current.ticket)!=LIE_FLOW_OK){
            snprintf(error,256,"reactive cancellation loan release failed");goto done;
        }
    }
    /* The terminal can become visible just before worker-wide counters are
     * published. Wait for the core notice, with a short independent bound. */
    uint64_t counter_deadline=now()+2000000000u;
    for(;;){
        lie_core_snapshot(core,&after);
        if(after.completed_requests>=before.completed_requests+1&&
           after.cancelled_requests>=before.cancelled_requests+1)break;
        if(interrupted||now()>=deadline||now()>=counter_deadline)break;
        struct pollfd fd={lie_core_fd(core),POLLIN,0};
        int rc=poll(&fd,1,100);
        if(rc<0&&errno!=EINTR){snprintf(error,256,"reactive counter poll failed");goto done;}
        if(rc>0)lie_core_drain(core);
    }
    if(after.active||after.output_blocked||
       after.cancelled_requests!=before.cancelled_requests+1||
       after.completed_requests!=before.completed_requests+1||
       (mtp&&after.mtp_accepted<=before.mtp_accepted)){
        snprintf(error,256,"reactive retirement counters invalid: active=%llu blocked=%llu completed=%llu cancelled=%llu mtp_accepted=%llu",
                 (unsigned long long)after.active,(unsigned long long)after.output_blocked,
                 (unsigned long long)(after.completed_requests-before.completed_requests),
                 (unsigned long long)(after.cancelled_requests-before.cancelled_requests),
                 (unsigned long long)(after.mtp_accepted-before.mtp_accepted));goto done;
    }
    json_object *row=event("reactive");text(row,"scope","direct-c-core-held-loan-peer-cancel");
    json_object_object_add(row,"synthetic",json_object_new_boolean(lie_backend_is_synthetic()));
    number(row,"peer_output_tokens",peer_tokens);number(row,"held_output_tokens",held_info.output_tokens);
    number(row,"held_borrowed_tokens",held_tokens);number(row,"held_output_blocked",blocked.output_blocked);
    number(row,"completed_delta",after.completed_requests-before.completed_requests);
    number(row,"cancelled_delta",after.cancelled_requests-before.cancelled_requests);
    number(row,"decode_batches_delta",after.decode_batches-before.decode_batches);
    number(row,"mtp_drafted_delta",after.mtp_drafted-before.mtp_drafted);
    number(row,"mtp_accepted_delta",after.mtp_accepted-before.mtp_accepted);
    passed=emit(f,row);
done:
    if(borrowed)(void)lie_job_event_release(held,loan.ticket);
    free(held_copy);
    if(held){if(!passed)lie_job_cancel(held);lie_job_release(held);}
    if(peer){if(!passed)lie_job_cancel(peer);lie_job_release(peer);}
    return passed;
}
int lie_core_bench_main(int argc,char **argv) {
    lie_core_request request;lie_core_request_init(&request);
    const char *mtp=NULL;unsigned mtp_drafts=0;
    const char *model=NULL,*output=NULL,*prompt_path=NULL,*tokens_path=NULL,*graphs=NULL;
    const char *encoder=NULL,*image_path=NULL,*plan_path=NULL;
    lie_steering_step steps[LIE_STEERING_SCHEDULE_MAX]={0};lie_steering_schedule plan={0};
    lie_store_options ssd={0};lie_cache_policy policy;lie_cache_policy_init(&policy);policy.enabled=LIE_DS4_CACHE_POLICY!=0;
    unsigned context=4096,chunk=2048,users=1,tg=128,repetitions=3,warmups=0,timeout=600000,progress_ms=0;
    unsigned cache_mib=(unsigned)(LIE_PREFIX_CACHE_DEFAULT_BYTES/(1024u*1024u));
    bool build_info=false,probe=false;uint64_t seen=0;
    lie_steering_model_options steering;lie_steering_model_options_init(&steering);
    bool steering_supplied=false;
    lie_rope_profile rope_profile=LIE_ROPE_NATIVE;
    for(int i=1;i<argc;++i){
        if(!strcmp(argv[i],"--help")){puts("Usage: synapse-lie-bench --suite core --model FIRST-SHARD --output NEW-JSONL\n  (--prompt-file UTF8 | --tokens-file JSON-INT-ARRAY) [--context 128..1048576] [--rope-scaling native|yarn2|yarn4]\n  [--model-mtp PREDICTOR.gguf --mtp-draft-tokens N] [--model-vision PROJECTOR.gguf --image-file PNG-OR-JPEG] [--chunk 2048] [--users 1..8] [--tg 128] [--warmups 0] [--repetitions 3]\n  [--temperature 0..2 --seed 0..9223372036854775807] [--top-p 0<p<=1] [--top-k 0..2147483647] [--min-p 0..1]\n  [--frequency-penalty -2..2] [--presence-penalty -2..2] [--ignore-eos]\n  [--dir-steering-file LAYER-MAJOR.f32 --dir-steering-ffn -100..100 --dir-steering-attn -100..100] [--dir-steering-plan JSON-FILE]\n  [--timeout-ms 600000] [--progress-ms 0|100..60000] [--graphs DIRECTORY] [--kv-cache-ram-mb 4096] [--kv-cache-policy ds4|legacy]\n  [--kv-cache-min-tokens 512] [--kv-cache-cold-max-tokens 30000] [--kv-cache-continued-interval-tokens 10000]\n  [--kv-cache-boundary-trim-tokens 32] [--kv-cache-boundary-align-tokens 2048] [--kv-cache-text-prefix on|off] [--kv-cache-capture-finish on|off]\n  [--kv-disk-dir ABSOLUTE-DIRECTORY --kv-disk-space-mb N --kv-disk-staging-mb N]\n  [--reactive-probe] requires physical tokens, C2, one repetition, no warmup/cache/vision, TG>=16; holds a borrowed output loan while a peer completes, then cancels the held job. Functional gate, not a throughput benchmark.\nDirect shared reactive core; raw text has no chat template. EOS ends generation by default; --ignore-eos continues to the fixed token budget and records the EOS token without masking it. Only raw-text/token samples allow this flag; vision and reactive probes retain natural EOS. Greedy AR by default; nonzero temperature requires an explicit reproducible seed. RAM prefix cache on by default (zero disables); KV disk persistence is opt-in; MTP requires an explicit predictor; KV reuse requires complete admitted predictor state; vision accepts a prompt file and an image; MTP and vision can be combined.\nReports core-client total/first-token latency and separate per-job executor calls. Progress is optional JSONL on stderr; 0 disables it. Snapshots report completed prefill tokens, cache reuse and confirmed output, with a final observation before job release. Progress applies to regular samples, not --reactive-probe.\nSteering uses fixed initial model-wide scales (defaults FFN 1, attention 0), a bounded 16 MiB vector bank and shared RAM/SSD semantic identity. --dir-steering-plan reads 1..64 changes [{\"position\":0,\"ffn\":1,\"attention\":0}, ...] at strictly increasing retained physical frontiers, splitting prefill/MTP work and recording applied results. Unreached changes fail the sample. Plans require a bank and are excluded from --reactive-probe. Numerical GPU qualification remains pending.\nShared GPU requires coordinated admission. Synthetic builds are NOT-INFERENCE.");return 0;}
        if(!strcmp(argv[i],"--build-info")){build_info=true;continue;}
        if(!strcmp(argv[i],"--ignore-eos")){if(request.eos_policy==LIE_EOS_IGNORE)goto usage;request.eos_policy=LIE_EOS_IGNORE;continue;}
        if(!strcmp(argv[i],"--reactive-probe")){if(probe)goto usage;probe=true;continue;}
        if(i+1==argc)goto usage;
        const char *key=lie_cache_option_name(argv[i]),*value=argv[++i];uint64_t bit=0;
        if(!strcmp(key,"--suite")){bit=1u;if(strcmp(value,"core"))goto usage;}
        else if(!strcmp(key,"--model-mtp")){bit=131072u;mtp=value;}
        else if(!strcmp(key,"--mtp-draft-tokens")){bit=262144u;if(!integer(value,0,LIE_MTP_MAX_DRAFT,&mtp_drafts))goto usage;}
        else if(!strcmp(key,"--model")){bit=2u;model=value;}
        else if(!strcmp(key,"--model-vision")){bit=524288u;encoder=value;}
        else if(!strcmp(key,"--image-file")){bit=1048576u;image_path=value;}
        else if(!strcmp(key,"--dir-steering-plan")){bit=UINT64_C(1)<<33;plan_path=value;}
        else if(!strncmp(key,"--dir-steering-",15)){
            bit=!strcmp(key,"--dir-steering-file")?UINT64_C(1)<<30:
                !strcmp(key,"--dir-steering-ffn")?UINT64_C(1)<<31:UINT64_C(1)<<32;
            if(lie_steering_model_option(&steering,key,value)!=1)goto usage;
            steering_supplied=true;
        }
        else if(!strcmp(key,"--output")){bit=4u;output=value;}
        else if(!strcmp(key,"--prompt-file")){bit=8u;prompt_path=value;}
        else if(!strcmp(key,"--tokens-file")){bit=16u;tokens_path=value;}
        else if(!strcmp(key,"--context")){bit=32u;if(!integer(value,128,LIE_CORE_MAX_CONTEXT,&context))goto usage;}
        else if(!strcmp(key,"--rope-scaling")){bit=67108864u;if(!lie_rope_profile_parse(value,&rope_profile))goto usage;}
        else if(!strcmp(key,"--chunk")){bit=64u;if(!integer(value,1,2048,&chunk))goto usage;}
        else if(!strcmp(key,"--users")){bit=128u;if(!integer(value,1,LIE_CORE_JOBS,&users))goto usage;}
        else if(!strcmp(key,"--tg")){bit=256u;if(!integer(value,1,LIE_CORE_MAX_OUTPUT,&tg))goto usage;}
        else if(!strcmp(key,"--repetitions")){bit=512u;if(!integer(value,1,100,&repetitions))goto usage;}
        else if(!strcmp(key,"--warmups")){bit=1024u;if(!integer(value,0,10,&warmups))goto usage;}
        else if(!strcmp(key,"--temperature")){bit=2097152u;if(!real(value,0,2,&request.generation.temperature))goto usage;}
        else if(!strcmp(key,"--top-p")){bit=4194304u;if(!real(value,0,1,&request.generation.top_p)||request.generation.top_p==0)goto usage;}
        else if(!strcmp(key,"--top-k")){unsigned k;bit=268435456u;if(!integer(value,0,INT32_MAX,&k))goto usage;request.generation.top_k=(int32_t)k;}
        else if(!strcmp(key,"--min-p")){bit=536870912u;if(!real(value,0,1,&request.generation.min_p))goto usage;}
        else if(!strcmp(key,"--frequency-penalty")){bit=8388608u;if(!real(value,-2,2,&request.generation.frequency_penalty))goto usage;}
        else if(!strcmp(key,"--presence-penalty")){bit=16777216u;if(!real(value,-2,2,&request.generation.presence_penalty))goto usage;}
        else if(!strcmp(key,"--seed")){bit=33554432u;if(!seed_value(value,&request.generation.seed))goto usage;}
        else if(!strcmp(key,"--timeout-ms")){bit=2048u;if(!integer(value,1,86400000,&timeout))goto usage;}
        else if(!strcmp(key,"--progress-ms")){bit=134217728u;if(!integer(value,0,60000,&progress_ms)||(progress_ms&&progress_ms<100))goto usage;}
        else if(!strcmp(key,"--graphs")){bit=4096u;graphs=value;}
        else if(!strcmp(key,"--kv-cache-ram-mb")){bit=8192u;if(!integer(value,0,1048576,&cache_mib))goto usage;}
        else if(!strcmp(key,"--kv-disk-dir")){bit=16384u;ssd.directory=value;}
        else if(!strcmp(key,"--kv-disk-space-mb")){unsigned mib;bit=32768u;if(!integer(value,1,1048576,&mib))goto usage;ssd.quota_bytes=(uint64_t)mib*1024u*1024u;}
        else if(!strcmp(key,"--kv-disk-staging-mb")){unsigned mib;bit=65536u;if(!integer(value,1,1048576,&mib))goto usage;ssd.staging_bytes=(uint64_t)mib*1024u*1024u;}
        else if(lie_cache_policy_option(&policy,key,value)!=1)goto usage;
        if(seen&bit)goto usage;
        seen|=bit;
    }
    if(mtp_drafts&&!mtp)goto usage;
    if(steering_supplied&&!steering.file)goto usage;
    if(plan_path&&(!steering.file||probe||!read_schedule(plan_path,steps,&plan)))goto usage;
    if(request.generation.temperature>0&&request.generation.seed<0)goto usage;
    if(request.eos_policy==LIE_EOS_IGNORE&&(encoder||image_path||probe))goto usage;
    if(probe&&(users!=2||warmups||repetitions!=1||cache_mib||ssd.directory||encoder||image_path||!tokens_path||tg<16||progress_ms))goto usage;
    if(mtp&&(!LIE_MTP||!*mtp))goto usage;
    if((ssd.directory&&(*ssd.directory!='/'||!ssd.quota_bytes||!ssd.staging_bytes))||
       (!ssd.directory&&(ssd.quota_bytes||ssd.staging_bytes)))goto usage;
    if((encoder||image_path)&&(!LIE_VISION||!encoder||!*encoder||!image_path||!*image_path||!prompt_path))goto usage;
    json_object *identity=event("identity");text(identity,"schema","synapse-lie.core-bench.v1");text(identity,"suite","core");
    text(identity,"execution","shared-reactive-core");text(identity,"mode",mtp?(encoder?"mtp+vision":"mtp"):(encoder?"vision":"ar"));text(identity,"vision_model",encoder?encoder:"");text(identity,"mtp_model",mtp?mtp:"");number(identity,"mtp_draft_tokens_requested",mtp_drafts);text(identity,"provider",lie_backend_name());text(identity,"build_id",LIE_BUILD_ID);
    text(identity,"ownership",lie_backend_ownership());text(identity,"source_pin",lie_backend_source_pin());
    text(identity,"dense_sampling",lie_backend_dense_sampling());
    text(identity,"eos_policy",request.eos_policy==LIE_EOS_IGNORE?"ignore":"stop");
    json_object *generation=json_object_new_object();
    nb_real(generation,"temperature",request.generation.temperature);nb_real(generation,"top_p",request.generation.top_p);
    nb_num(generation,"top_k",request.generation.top_k);nb_real(generation,"min_p",request.generation.min_p);
    nb_real(generation,"frequency_penalty",request.generation.frequency_penalty);nb_real(generation,"presence_penalty",request.generation.presence_penalty);
    nb_num(generation,"seed",request.generation.seed);json_object_object_add(identity,"generation",generation);
    json_object *directions=json_object_new_object();
    json_object_object_add(directions,"requested",json_object_new_boolean(steering.file!=NULL));
    nb_real(directions,"ffn",steering.file?steering.defaults.ffn:0);
    nb_real(directions,"attention",steering.file?steering.defaults.attention:0);
    number(directions,"vector_budget_bytes",steering.vector_budget_bytes);
    json_object_object_add(directions,"schedule",schedule_json(plan_path?&plan:NULL));
    json_object_object_add(identity,"steering",directions);
    json_object_object_add(identity,"synthetic",json_object_new_boolean(lie_backend_is_synthetic()));
    text(identity,"scope","core client submit through confirmed output; per-job executor durations overlap in batches; cache transfer timing is separate; no HTTP");
    text(identity,"cache_policy",ssd.directory?(cache_mib?"ram+ssd":"ssd"):(cache_mib?"ram":"off"));number(identity,"prefix_cache_bytes",(uint64_t)cache_mib*1024u*1024u);
    text(identity,"cache_retention_policy",LIE_CACHE_UTILITY?"ds4-time-token-byte-utility-v1":"lru");
    json_object_object_add(identity,"checkpoint_compression",json_object_new_boolean(lie_state_compression_enabled()));
    text(identity,"checkpoint_codec",lie_state_compression_codec());
    text(identity,"state_format",lie_backend_state_format());
    text(identity,"checkpoint_policy",policy.enabled?"ds4":"legacy");
    number(identity,"cache_min_tokens",policy.min_tokens);number(identity,"cache_cold_max_tokens",policy.cold_max_tokens);
    number(identity,"cache_continued_tokens",policy.continued_interval_tokens);number(identity,"cache_trim_tokens",policy.boundary_trim_tokens);
    number(identity,"cache_align_tokens",policy.boundary_align_tokens);
    json_object_object_add(identity,"cache_text_prefix",json_object_new_boolean(policy.text_prefix));
    json_object_object_add(identity,"cache_capture_finish",json_object_new_boolean(policy.capture_finish));
    number(identity,"ssd_quota_bytes",ssd.quota_bytes);number(identity,"ssd_staging_bytes",ssd.staging_bytes);
    number(identity,"context_capacity",context);number(identity,"prefill_chunk",chunk);number(identity,"users",users);
    text(identity,"rope_scaling",lie_rope_profile_name(rope_profile));
    number(identity,"output_limit",tg);number(identity,"warmups",warmups);number(identity,"repetitions",repetitions);
    number(identity,"progress_interval_ms",progress_ms);
    if(build_info)return emit(stdout,identity)?0:1;
    if(!model||!*model||!output||!*output||!!prompt_path==!!tokens_path||tg>=context){json_object_put(identity);goto usage;}
    request.max_tokens=tg;
    size_t bytes=0;char *data=read_input(prompt_path?prompt_path:tokens_path,&bytes);int32_t *ids=NULL;
    if(!data){json_object_put(identity);goto usage;}
    if(prompt_path){request.kind=LIE_INPUT_TEXT;request.text=data;request.text_bytes=bytes;
        if(!lie_utf8_valid(data,bytes,false)){free(data);json_object_put(identity);goto usage;}}
    else {
        json_tokener *t=json_tokener_new_ex(4);if(!t){free(data);json_object_put(identity);return 1;}
        json_tokener_set_flags(t,JSON_TOKENER_STRICT);json_object *array=json_tokener_parse_ex(t,data,(int)bytes+1);
        size_t end=json_tokener_get_parse_end(t);while(end<bytes&&(data[end]==' '||data[end]=='\n'||data[end]=='\r'||data[end]=='\t'))++end;
        bool valid=json_tokener_get_error(t)==json_tokener_success&&(end==bytes||end==bytes+1)&&json_object_is_type(array,json_type_array);
        size_t n=valid?json_object_array_length(array):0;valid=valid&&n>0&&n<=context-tg;
        if(valid){ids=malloc(n*sizeof(*ids));valid=ids!=NULL;}
        for(size_t i=0;valid&&i<n;++i){json_object *v=json_object_array_get_idx(array,i);int64_t value=json_object_get_int64(v);
            valid=json_object_is_type(v,json_type_int)&&value>=0&&value<=INT32_MAX;if(valid)ids[i]=(int32_t)value;}
        json_object_put(array);json_tokener_free(t);
        if(!valid){free(ids);free(data);json_object_put(identity);goto usage;}
        request.kind=LIE_INPUT_TOKENS;request.tokens=ids;request.token_count=n;
    }
    text(identity,"input_kind",image_path?"messages-with-image":prompt_path?"raw-text":"physical-tokens");
    json_object_object_add(identity,"reactive_probe",json_object_new_boolean(probe));
    struct sigaction sa={0};sa.sa_handler=stop_signal;sigemptyset(&sa.sa_mask);
    if(sigaction(SIGINT,&sa,NULL)||sigaction(SIGTERM,&sa,NULL)){free(ids);free(data);json_object_put(identity);return 1;}
    if(progress_ms){struct sigaction pipe_action={0};pipe_action.sa_handler=SIG_IGN;sigemptyset(&pipe_action.sa_mask);
        if(sigaction(SIGPIPE,&pipe_action,NULL)){free(ids);free(data);json_object_put(identity);return 1;}}
    int fd=open(output,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
    if(fd<0){perror("exclusive core benchmark output");free(ids);free(data);json_object_put(identity);return 1;}
    FILE *f=fdopen(fd,"w");if(!f){close(fd);free(ids);free(data);json_object_put(identity);return 1;}
    int code=1;lie_core *core=NULL;char error[256]="core benchmark failed";witness w={0};
    char *encoded=NULL;lie_image_input image={0};lie_chat_message message={0};
    if(image_path){
        size_t image_bytes=0;encoded=read_input(image_path,&image_bytes);
        image=(lie_image_input){.data=(const unsigned char *)encoded,.bytes=image_bytes,.format=LIE_IMAGE_PNG};
        lie_image_dimensions dimensions;
        if(lie_image_inspect(&image,&dimensions,NULL)!=LIE_OK){image.format=LIE_IMAGE_JPEG;
            if(lie_image_inspect(&image,&dimensions,NULL)!=LIE_OK){snprintf(error,256,"invalid PNG/JPEG image header or budget");emit(f,identity);goto done;}}
        char image_hash[65];if(!nb_hash(encoded,image_bytes,image_hash)){emit(f,identity);goto done;}
        text(identity,"image_sha256",image_hash);number(identity,"image_bytes",image_bytes);
        message=(lie_chat_message){LIE_CHAT_USER,data,bytes};image.text_offset=bytes;
        request.kind=LIE_INPUT_MESSAGES;request.text=NULL;request.text_bytes=0;
        request.chat.messages=&message;request.chat.count=1;request.images=&image;request.image_count=1;
    }
    if(!emit(f,identity))goto done;
    uint64_t started=now();lie_core_options options;lie_core_options_init(&options);options.model_path=model;options.context=context;options.vision_model_path=encoder;options.mtp_model_path=mtp;options.mtp_draft_tokens=mtp_drafts;
    options.chunk=chunk;options.max_active=users;options.rope_profile=rope_profile;options.prefix_cache_bytes=(uint64_t)cache_mib*1024u*1024u;options.ssd=ssd;options.cache_policy=policy;
    core=steering.file?lie_core_create_steered(&options,&steering):lie_core_create(&options);
    if(!started||!core||!wait_core(core,LIE_READY,started+(uint64_t)timeout*1000000u)){
        snprintf(error,256,"core readiness failed");
        if(core){lie_core_info info;lie_core_snapshot(core,&info);
            if(info.error[0])snprintf(error,256,"core readiness failed: %.220s",info.error);}
        goto done;
    }
    json_object *ready=event("core_ready");number(ready,"load_to_ready_ns",now()-started);
    lie_steering_model_info admitted={.abi_version=LIE_STEERING_MODEL_ABI,.struct_bytes=sizeof(admitted)};
    if(lie_core_steering_snapshot(core,&admitted,NULL)!=LIE_OK){json_object_put(ready);snprintf(error,256,"steering admission snapshot failed");goto done;}
    json_object *bank=json_object_new_object();char file_hash[65]={0},scope_hash[65]={0};
    if(admitted.admitted)for(unsigned k=0;k<32;++k){snprintf(file_hash+2*k,3,"%02x",admitted.bank.file_sha256[k]);snprintf(scope_hash+2*k,3,"%02x",admitted.bank.scope_sha256[k]);}
    json_object_object_add(bank,"admitted",json_object_new_boolean(admitted.admitted));
    nb_real(bank,"ffn",admitted.defaults.ffn);nb_real(bank,"attention",admitted.defaults.attention);
    number(bank,"host_vector_bytes",admitted.bank.bytes);number(bank,"device_vector_bytes",admitted.device_vector_bytes);
    text(bank,"bank_file_sha256",file_hash);text(bank,"bank_scope_sha256",scope_hash);
    text(bank,"scope","model_admission_vector_data_excludes_allocator_overhead_and_workspaces");
    json_object_object_add(ready,"steering",bank);if(!emit(f,ready))goto done;
    if(probe){if(!reactive_probe(core,&request,tg,timeout,mtp!=NULL,f,error))goto done;}
    else for(unsigned rep=0;rep<warmups+repetitions;++rep)if(!sample(core,&request,users,rep,rep<warmups,timeout,progress_ms,plan_path?&plan:NULL,&w,f,error))goto done;
    code=0;
done:
    if(core){lie_core_stop(core);if(!wait_core(core,LIE_STOPPED,0))code=1;else {
        if(ssd.directory){lie_core_info info;lie_core_snapshot(core,&info);json_object *store=event("ssd_drained");
            number(store,"writes",info.ssd.writes);number(store,"errors",info.ssd.errors);number(store,"disk_bytes",info.ssd.disk_bytes);
            number(store,"evictions",info.ssd.evictions);number(store,"skipped",info.ssd.skipped);
            number(store,"allocated_bytes",info.ssd.allocated_bytes);number(store,"entries",info.ssd.entries);
            number(store,"write_ns",info.ssd.write_ns);number(store,"pending",info.ssd.pending);if(!emit(f,store))code=1;}
        lie_core_destroy(core);
    }}
    json_object *end=event(code?"failed":"complete");number(end,"exit_code",code);if(code)text(end,"error",error);
    bool written=emit(f,end);if(fclose(f)||!written)code=1;
    free(encoded);free(w.prompt);free(ids);free(data);
    if(!code&&graphs)code=lie_bench_graphs(output,graphs,NULL);
    return code;
usage:
    fputs("Invalid core benchmark arguments; use --suite core --help\n",stderr);return 2;
}
