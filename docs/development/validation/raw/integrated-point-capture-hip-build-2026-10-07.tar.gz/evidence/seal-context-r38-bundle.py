# SPDX-License-Identifier: MIT
"""Seal new compiled LIE artifacts; no GPU, model or service operation."""
from pathlib import Path
import hashlib
import json
import subprocess

build=json.loads(Path('evidence/context-r38-build-r1/result.json').read_text())
assert build['state']=='PASSED' and build['exit_code']==build['child_exit_code']==0
compiled=build['build_result']
program='expected='+repr(compiled)+'\n'
program+='''
from pathlib import Path
import hashlib,json,os,shutil
base=Path('/home/pop/workspace/synapse-lie/rocm10-fedora-161')
assert base.resolve()==base and base.stat().st_uid==os.getuid()
source=base/'source-modern-r38'
receipt=source/'evidence/rocm10-point-modern-r38-compile/result.json'
assert json.loads(receipt.read_text())==expected
assert expected['state']=='BUILT_NOT_GPU_TESTED' and expected['exit_code']==0
bundle=base/'bundle-modern-r38'
assert not bundle.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in expected['binaries'].items():
    path=source/'build/rocm10-point-modern-r38-runtime'/name
    assert not path.is_symlink() and sha(path)==digest,name
(bundle/'runtime/bin').mkdir(parents=True)
(bundle/'runtime/lib').mkdir()
artifacts={}
for name,digest in expected['binaries'].items():
    destination=bundle/'runtime/bin'/name
    shutil.copy2(source/'build/rocm10-point-modern-r38-runtime'/name,destination)
    assert sha(destination)==digest
    artifacts['runtime/bin/'+name]=digest
r={'schema':'synapse-lie.point-bundle.v1','source_commit':expected['source_commit'],
   'image':'sha256:89c6f9da64694da226948bca7b50d5e4e38caab9e138cb5cbe8678b7778cbe7e',
   'compile_receipt_sha256':sha(receipt),'artifacts':artifacts,
   'runtime_libraries':'pinned ROCm10 image','scope':'BUILT_NOT_GPU_TESTED'}
with (bundle/'BUNDLE.json').open('x') as f:json.dump(r,f,indent=2);f.write(chr(10))
print(json.dumps({'bundle':str(bundle),'bundle_sha256':sha(bundle/'BUNDLE.json'),'metadata':r}))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',
      'pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
r={'argv':argv,'exit_code':run.returncode,'stderr':run.stderr,
   'program_sha256':hashlib.sha256(program.encode()).hexdigest()}
try:r['result']=json.loads(run.stdout)
except ValueError:r['stdout']=run.stdout
with Path('evidence/context-r38-bundle-result.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps(r.get('result',r)))
raise SystemExit(run.returncode)
