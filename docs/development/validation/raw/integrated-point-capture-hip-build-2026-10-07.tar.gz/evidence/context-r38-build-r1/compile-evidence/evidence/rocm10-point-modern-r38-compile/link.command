/usr/bin/cmake --build /source/build/rocm10-point-modern-r38-runtime --parallel 1 --target synapse-lie-server synapse-lie-bench synapse-lie-bench-gufo-reference lie-hip-probe lie-sampling-capture
