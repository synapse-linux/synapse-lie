#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Seal qualified LIE code and official pins locally; no remote operation."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

root = Path.cwd()
out = root / 'evidence/context-source-modern-r38'
archive = out.with_suffix('.tar.gz')
commit = 'df0780dd7601421f7097315702275c2349e7ed20'
code_commit = '88d4c4e5fabb34035bed6a307bf61e9fc18844df'
assert not out.exists() and not archive.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == commit
assert not subprocess.check_output(['git', 'status', '--porcelain'])

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

receipt = root / 'docs/development/validation/integrated-final-host-2026-10-06.json'
proof_path = root / 'evidence/integrated-r76-archive-verification.json'
proof = json.loads(proof_path.read_text())
host = json.loads(receipt.read_text())
assert proof['state'] == 'VERIFIED_HOST_NOT_INFERENCE' and proof['witness_files'] == 534
assert sha(receipt) == proof['receipt_sha256'] == '26cb7c71082efad3666621f95ee77e2effdd87628ec93e502b28d27d3a844de0'
assert host['state'] == 'HOST_PASSED_GPU_PENDING' and host['source_commit'] == code_commit
assert host['final_test_counts'] == {'release': 101, 'asan': 101, 'provider-release': 67,
                                   'provider-asan': 67, 'core-icu-off': 69}
assert len(host['private_provider_inventory']) == 120
assert len(host['private_observer_inventory']) == 2
changed = [name for name, binding in host['frozen_sources'].items()
           if sha(root / name) != binding['sha256']]
expected_changed = ['CMakeLists.txt', 'adapters/gufo.cpp', 'cmake/point/Build.cmake',
                    'include/lie/executor.h', 'tests/sampling/CMakeLists.txt',
                    'tests/test_strix_point_campaign.py', 'tools/strix-point-campaign.py',
                    'tools/strix-point-rocm10-compile.py']
assert sorted(changed) == expected_changed, changed
capture_path = root / 'docs/development/validation/sampling-tools-host-2026-10-07.json'
capture = json.loads(capture_path.read_text())
assert sha(capture_path) == 'bb8786462de0d6a63e6f659d3e4d525f2266d00d1b2ef4069e297f6df90bec92'
assert capture['focused_checks'] == {'Release':'3/3', 'ASan_UBSan_LSan_unsuppressed':'3/3', 'main_project':'1/1'}
for name, binding in capture['source_files'].items():
    assert sha(root / name) == binding['sha256'], name
integration = json.loads((root / 'evidence/context-r38-capture-build-integration.json').read_text())
assert sha(root / 'cmake/point/Build.cmake') == integration['cmake_sha256']
assert sha(root / 'tools/strix-point-rocm10-compile.py') == integration['legacy_helper_sha256']
receiver = json.loads((root / 'evidence/context-r38-build-receiver-fixture/result.json').read_text())
assert receiver['exit_code'] == receiver['child_exit_code'] == 0

# Archive evidence is already retained in the repository. It is not needed by
# the compiler; excluding only this directory avoids duplicating old campaigns.
excluded_prefix = 'docs/development/validation/raw/'
excluded = []
out.mkdir()
proc = subprocess.Popen(['git', 'archive', '--format=tar', commit], stdout=subprocess.PIPE)
try:
    with tarfile.open(fileobj=proc.stdout, mode='r|') as tar:
        for member in tar:
            p = Path(member.name)
            assert not p.is_absolute() and '..' not in p.parts
            assert member.isfile() or member.isdir(), member.name
            if member.name.startswith(excluded_prefix):
                if member.isfile():
                    excluded.append(member.name)
                continue
            tar.extract(member, out, filter='data')
finally:
    proc.stdout.close()
assert proc.wait() == 0
for name, binding in host['frozen_sources'].items():
    assert sha(out / name) == sha(root / name)

manifest = json.loads((out / 'third_party/gufo-source.json').read_text())
assert manifest['commit'] == 'f783fedb9bea2ec7de941f6da4e02f4a4596b29e'
assert len(manifest['files']) == 1019
upstream = root / '.deps/gufo-f783fedb'
assert not upstream.is_symlink()
for name, expected in manifest['files'].items():
    p = upstream / name
    assert p.resolve().is_relative_to(upstream.resolve()) and not p.is_symlink()
    assert sha(p) == expected
    target = out / '.deps/gufo-f783fedb' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, target)
    assert sha(target) == expected
ryu = json.loads((out / 'third_party/ryu-source.json').read_text())
for name, binding in ryu['files'].items():
    assert sha(out / 'third_party/ryu' / name) == binding['sha256']

prior_path = root / 'evidence/context-r11-build-r2/result.json'
prior = json.loads(prior_path.read_text())['build_result']
names = {'zstd.h': 'zstd_header_sha256', 'zstd_errors.h': 'zstd_errors_sha256', 'LICENSE': 'zstd_license_sha256'}
for name, key in names.items():
    p = root / 'evidence/context-source-modern-r11/third_party/point-zstd-dev' / name
    assert p.is_file() and not p.is_symlink() and sha(p) == prior[key]
    target = out / 'third_party/point-zstd-dev' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, target)
(out / 'SOURCE-COMMIT.txt').write_text(commit + '\n')
(out / 'CODE-CHECKPOINT.txt').write_text(code_commit + '\n')
files = sorted(p for p in out.rglob('*') if p.is_file())
assert all(not p.is_symlink() for p in files)
inventory = ''.join(sha(p) + '  ./' + str(p.relative_to(out)) + '\n' for p in files)
(out / 'SOURCE-FILES.sha256').write_text(inventory)
with archive.open('xb') as f:
    with gzip.GzipFile(fileobj=f, mode='wb', mtime=0, compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            tar.add(out, arcname='context-source-modern-r38')
record = {'scope': 'LOCAL_SEALED_SOURCE_NOT_REMOTE_BUILD_OR_GPU',
          'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_commit': commit,
          'code_checkpoint': code_commit, 'archive_sha256': sha(archive),
          'archive_bytes': archive.stat().st_size, 'source_files_sha256': sha(out / 'SOURCE-FILES.sha256'),
          'source_files': len(files), 'compile_helper_sha256': sha(out / 'cmake/point/Build.cmake'),
          'runner_sha256': sha(out / 'tools/strix-point-campaign.py'),
          'gufo_pin': manifest['commit'], 'pristine_gufo_files_verified': 1019,
          'final_host_receipt_sha256': sha(receipt), 'host_inventory_proof_sha256': sha(proof_path),
          'zstd_prior_receipt_sha256': sha(prior_path),
          'zstd_development_sha256': {name: prior[key] for name, key in names.items()},
          'ryu_pin': ryu['commit'], 'unchanged_Ryu_files_verified': len(ryu['files']),
          'owned_source_files_verified': len(host['frozen_sources']),
          'preceding_HOST_files_unchanged': len(host['frozen_sources']) - len(changed),
          'changed_since_preceding_HOST': changed,
          'new_capture_source_receipt_sha256': sha(capture_path),
          'new_capture_frozen_sources_verified': len(capture['source_files']),
          'five_target_build_integration': integration,
          'focused_build_receiver_fixture': receiver,
          'executor_ABI_layout_HTTP_reactive_numerical_algorithms_changed': False,
          'provider_inventory_files_verified': 120, 'observer_inventory_files_verified': 2,
          'excluded_only_compiler_unneeded_historical_raw_archives': excluded,
          'remote_stage_build_or_GPU_run': False, 'all_six_tasks_remain_open': True}
with (root / 'evidence/context-r38-source-seal.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps({k: v for k, v in record.items() if k != 'excluded_only_compiler_unneeded_historical_raw_archives'}))
