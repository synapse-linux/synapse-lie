# SPDX-License-Identifier: MIT
"""Prepare a reviewable coordinator patch; never modify the active runner."""
from pathlib import Path
import difflib
import hashlib
import json

root = Path.cwd().resolve()
source = root/'tools/strix-point-campaign.py'
manifest = json.loads((root/'evidence/recall-yarn4-523776-s77-ar-20261008-r1/manifest.json').read_text())
payload = source.read_bytes()
assert hashlib.sha256(payload).hexdigest() == manifest['runner_sha256']
old = payload.decode()
anchor = "        if profile == 'modern-steering-build':\n"
assert old.count(anchor) == 1
new = old.replace(anchor, "        if profile == 'modern-steering-quality':\n            return self.modern_steering_quality()\n"+anchor, 1)
anchor = '    def modern_steering_build(self):\n'
assert new.count(anchor) == 1
method = '''    def modern_steering_quality(self):
        name = 'strix-point-steering-quality-profile.py'
        helpers = self.m.get('steering_quality_helpers')
        if (type(helpers) is not dict or type(helpers.get(name)) is not str or
                not re.fullmatch(r'[0-9a-f]{64}', helpers[name])):
            raise ValueError('Missing explicitly admitted steering profile hash')
        helper = checked_path(self.root/name)
        fd = os.open(helper, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
        try:
            before = os.fstat(fd)
            if not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid() or not 1 <= before.st_size <= 2**20:
                raise ValueError('Invalid bounded steering profile source')
            with os.fdopen(fd, 'rb', closefd=False) as stream:
                payload = stream.read(2**20+1)
            after, named = os.fstat(fd), helper.stat(follow_symlinks=False)
            fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
            if (len(payload) != before.st_size or not stat.S_ISREG(named.st_mode) or
                    any(getattr(before, key) != getattr(after, key) or
                        getattr(after, key) != getattr(named, key) for key in fields) or
                    hashlib.sha256(payload).hexdigest() != helpers[name]):
                raise ValueError('Steering profile source changed or differs from admission')
        finally:
            os.close(fd)
        # Execute exactly the checked immutable bytes, avoiding an import reread.
        spec = importlib.util.spec_from_file_location('lie_steering_quality_profile', helper)
        profile = importlib.util.module_from_spec(spec)
        exec(compile(payload, str(helper), 'exec'), profile.__dict__)
        return profile.run(self)

'''
new = new.replace(anchor, method+anchor, 1)
candidate = root/'evidence/strix-point-campaign-steering-quality-candidate-r2.py'
patch = root/'evidence/steering-quality-dispatch-after-recall-r2.patch'
for path in (candidate, patch): assert not path.exists()
candidate.write_text(new)
patch.write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
    fromfile='a/tools/strix-point-campaign.py', tofile='b/tools/strix-point-campaign.py')))
record = {'state': 'LOCAL_DISPATCH_CANDIDATE_PREPARED_ACTIVE_COORDINATOR_UNCHANGED',
    'base_sha256': manifest['runner_sha256'], 'candidate_sha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
    'patch_sha256': hashlib.sha256(patch.read_bytes()).hexdigest(),
    'application_pending_until_admitted_recall_collection_strong_closure_release_and_seal': True,
    'GPU_lease_or_remote_action': False, 'actual_exit_code': 0}
with (root/'evidence/steering-quality-dispatch-candidate-prepared-r2.json').open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps(record))
