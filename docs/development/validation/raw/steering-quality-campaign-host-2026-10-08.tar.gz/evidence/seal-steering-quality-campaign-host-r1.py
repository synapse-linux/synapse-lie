# SPDX-License-Identifier: MIT
"""Seal applied HOST campaign dispatch, keeping original generation pending."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import tarfile

root = Path.cwd().resolve()
public = root/'docs/development/validation/steering-quality-campaign-host-2026-10-08.json'
raw = public.parent/'raw/steering-quality-campaign-host-2026-10-08.tar.gz'
assert not public.exists() and not raw.exists()
def read(path): return json.loads(path.read_text())
def sha(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
sources = ['tools/strix-point-campaign.py', 'tools/strix-point-steering-quality-profile.py',
    'tools/strix-point-steering-quality-run.py', 'tools/strix-point-steering-quality-gate.py',
    'tools/strix-point-steering-build-gate.py', 'tools/strix-point-http-recall-gate.py',
    'tests/test_strix_point_steering_quality_campaign.py', 'tests/test_strix_point_steering_quality_profile.py',
    'tests/test_strix_point_steering_quality_run.py', 'tests/test_strix_point_steering_quality.py',
    'tests/test_strix_point_campaign.py', 'tests/fixtures/steering-conciseness-v1.json',
    'tests/fixtures/prefill-probe-receipts.json', 'docs/development/protocols/STEERING-QUALITY-GPU-PROTOCOL.md',
    'LICENSE', 'CMakeLists.txt']
guards = {'steering-quality-dispatch-candidate-host-debug-r1': 8,
    'steering-quality-dispatch-candidate-host-asan-r1': 8,
    'steering-quality-campaign-host-debug-r1': 8,
    'steering-quality-campaign-host-asan-r1': 8,
    'steering-quality-campaign-supervisor-host-r1': 89}
peaks = {}
for name, count in guards.items():
    directory = root/'evidence'/name
    result, plan = read(directory/'result.json'), read(directory/'plan.json')
    assert result['exit_code'] == result['child_exit_code'] == 0 and result['reason'] is None
    log = (directory/'command.log').read_text()
    assert f'Ran {count} tests' in log and log.rstrip().endswith('OK')
    if count == 8:
        assert any(arg.startswith('LIE_STEERING_NATIVE_CLIENT=') for arg in plan['argv'])
    if '-asan-' in name:
        assert 'ASAN_OPTIONS=detect_leaks=1:abort_on_error=1' in plan['argv']
        assert 'UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1' in plan['argv']
    for path, value in result['peak_c'].items(): peaks[path] = max(peaks.get(path, -1), value)
    for sensor in plan['sensors']:
        if sensor['limit_c'] is not None: assert result['peak_c'][sensor['path']] < sensor['limit_c']
    sources += [str(p.relative_to(root)) for p in sorted(directory.iterdir()) if p.is_file()]
sources += ['evidence/prepare-steering-quality-dispatch-candidate-r1.py',
    'evidence/prepare-steering-quality-dispatch-candidate-r2.py',
    'evidence/strix-point-campaign-steering-quality-candidate-r1.py',
    'evidence/strix-point-campaign-steering-quality-candidate-r2.py',
    'evidence/steering-quality-dispatch-after-recall-r1.patch',
    'evidence/steering-quality-dispatch-after-recall-r2.patch',
    'evidence/steering-quality-dispatch-candidate-prepared-r1.json',
    'evidence/steering-quality-dispatch-candidate-prepared-r2.json',
    'evidence/test-steering-quality-dispatch-candidate-r1.py',
    'evidence/steering-quality-dispatch-candidate-host-qualified-r1.json',
    'evidence/seal-steering-quality-campaign-host-r1.py']
prepared = read(root/'evidence/steering-quality-dispatch-candidate-prepared-r2.json')
assert sha(root/'tools/strix-point-campaign.py') == prepared['candidate_sha256']
assert (root/'tools/strix-point-campaign.py').read_bytes() == (root/'evidence/strix-point-campaign-steering-quality-candidate-r2.py').read_bytes()
recall_path = root/'docs/development/validation/recall-yarn4-near512k-ar-point-2026-10-08.json'
recall = read(recall_path)
assert recall['state'] == 'ORIGINAL_AR_YARN4_NEAR512K_PASSED_COLLECTED_INDEPENDENT_WIRE_VERIFIED_CLOSED'
assert all(code == 0 for code in recall['actual_exit_codes'].values())
post = read(root/'evidence/yarn4-near512-postseal-r2.json')
assert post['actual_exit_code'] == 0 and post['members'] == 53
source_commit = '4c703b3d604c6c877d6a2214d7aee0b15a013f61'
source = subprocess.run(['git', 'diff', '--quiet', source_commit, '--', 'src', 'include',
    'adapters', 'cmake', 'CMakeLists.txt', 'tools/native', 'tools/steering-build.c'])
assert source.returncode == 0
assert len(sources) == len(set(sources))
inventory = {}
for name in sources:
    path = root/name
    assert path.resolve() == path and path.is_file() and not path.is_symlink()
    inventory[name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
with tarfile.open(raw, 'x:gz') as tar:
    for name in sources: tar.add(root/name, arcname=name, recursive=False)
with tarfile.open(raw, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(inventory)
    for member in tar.getmembers():
        assert member.isfile() and member.name in inventory
        payload = tar.extractfile(member).read(); expected = inventory[member.name]
        assert len(payload) == expected['bytes'] and hashlib.sha256(payload).hexdigest() == expected['sha256']
receipt = {'schema': 'synapse-lie.steering-quality-campaign-host.v1',
    'state': 'HOST_CAMPAIGN_DISPATCH_AND_NATIVE_HTTP_CLIENTS_VERIFIED_ORIGINAL_LEARNING_AND_QUALITY_PENDING',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Applied coordinator route, immutable admitted helper execution and complete synthetic profile/wire checks. Model servers/training receipts/metadata are simulated; no lease, original model or GPU is executed.',
    'tests': {'dispatch_checks_per_debug_native_sanitizer_mode': 8,
        'existing_supervisor_checks': 89, 'actual_native_C_clients_per_mode': 2,
        'synthetic_HTTP_replies_per_mode': 70, 'earlier_candidate_checks_per_mode': 8},
    'actual_guard_exits': {name: read(root/'evidence'/name/'result.json')['exit_code'] for name in guards},
    'covered': ['Explicit dispatch avoids generic benchmark fallback.',
        'Typed admitted helper hash, bounded owned canonical regular descriptor and exact immutable bytes executed.',
        'Hash/source/type/symlink/FIFO/directory and post-hash source replacement refuse before model.',
        'Real qualification profile requires complete original training provenance and independently reviews all70saved replies.',
        'Complete quality failure preserves scores, actual native exits and model postflight.'],
    'applied_coordinator_sha256': prepared['candidate_sha256'],
    'previous_frozen_coordinator_sha256': prepared['base_sha256'],
    'native_runtime_sources_byte_equal_to': source_commit,
    'actual_native_source_comparison_exit_code': source.returncode,
    'local_peak_C_by_sensor_path': peaks,
    'prerequisite_completed_recall': {'receipt': str(recall_path.relative_to(root)),
        'sha256': sha(recall_path), 'portable_members': 53,
        'standalone_postseal_actual_exit_code': 0, 'four_verified_release_deliveries': True},
    'new_build_directories': [], 'product_Python_dependency_or_CMake_ABI_state_metrics_change': False,
    'original_learning_response_quality_or_GPU_inference_qualified_by_this_HOST_work': False,
    'current_root_remote_jobs_handles_leases_windows_waiters_reservations': [],
    'pending': ['Fresh original100-pair training admission and complete independently reconstructed FFN bank receipt.',
        'Original70held-out responses with fresh model/runtime/corpus/bank/helper-bound campaign admission.',
        'Wider MTP/graph/correction/fault/vision/model/platform and matched cost.'],
    'roadmap': {'open_items': [2, 3, 4, 5, 6, 7], 'terminal_bench_last': True, 'full_goal_complete': False},
    'raw': {'path': str(raw.relative_to(root)), 'bytes': raw.stat().st_size, 'sha256': sha(raw),
        'regular_members': len(inventory), 'members': inventory}, 'actual_exit_code': 0}
with public.open('x') as stream: json.dump(receipt, stream, indent=2); stream.write('\n')
print(json.dumps({'state': receipt['state'], 'raw_bytes': raw.stat().st_size,
    'members': len(inventory), 'tests': receipt['tests'], 'actual_exit_code': 0}))
