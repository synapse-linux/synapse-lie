# SPDX-License-Identifier: MIT
"""Launch the prepared coherent device-hidden Point build under original lease."""
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=root/'evidence/context-r50-build-r1'
seal=json.loads((root/'evidence/context-r50-source-seal.json').read_text())
fresh=json.loads((root/'evidence/context-r50-fresh-161-r2.json').read_text())
assert fresh['actual_exit_code']==0;r=fresh['result']
assert r['original_lease']['free_briefly'] is True and r['original_lease']['released'] is True
assert (r['original_lease']['device'],r['original_lease']['inode'])==(66307,105946405)
assert not r['foreign_compute_clients'] and not r['guarded_hot'] and not r['http8000_listeners']
assert r['exclusive_job_prepared'] and r['sealed_source_present']
assert r['boot_id']=='c82c90ed-7f94-4212-bc52-681c63eac395'
assert hashlib.sha256((out/'runner.py').read_bytes()).hexdigest()==seal['runner_sha256']
remote='/home/pop/workspace/synapse-lie/context-r50-build-r1'
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161',
      'python3','-B',remote+'/runner.py',remote]
plan={'argv':argv,'remote_root':remote,'source_commit':seal['source_commit'],
      'runner_sha256':seal['runner_sha256'],'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),
      'fresh_preflight':'evidence/context-r50-fresh-161-r2.json','standing_future_window':False}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with (out/'controller-stdout.log').open('x') as stdout,(out/'controller-stderr.log').open('x') as stderr:
    p=subprocess.run(argv,stdout=stdout,stderr=stderr)
record={**plan,'exit_code':p.returncode};(out/'controller-result.json').write_text(json.dumps(record,indent=2)+'\n')
try:
    result=json.loads((out/'controller-stdout.log').read_text())
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result.get(k) for k in ('state','error','exit_code','child_exit_code','pid','start_ticks','container','lease','lease_released_at','model_attempted','cleanup_failures')}))
except (OSError,ValueError):print(json.dumps({'actual_exit_code':p.returncode,'error':'Remote result unavailable; preserved controller logs'}))
raise SystemExit(p.returncode)
