# SPDX-License-Identifier: MIT
"""Verify completed archive/current members without remote/build/test/model work."""
from pathlib import Path
import datetime,hashlib,json,tarfile
root=Path.cwd();receipt=root/'docs/development/validation/prefill-probe-point-build-2026-10-07.json'
r=json.loads(receipt.read_text());a=r['portable_raw_archive'];path=receipt.parent/a['path']
assert path.stat().st_size==a['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==a['sha256']
with tarfile.open(path) as package:
    members=package.getmembers();assert len(members)==a['members']==len(r['raw_artifacts'])+1
    for member in members:
        data=package.extractfile(member).read()
        if member.name=='raw-inventory.json':
            assert json.loads(data)==r['raw_artifacts'];continue
        assert not member.name.startswith('evidence/context-r50-proof-sealing-guard/')
        assert not member.name.startswith('evidence/context-r50-proof-postseal-guard/')
        info=r['raw_artifacts'][member.name]
        assert len(data)==info['bytes'] and hashlib.sha256(data).hexdigest()==info['sha256']
        live=root/member.name;assert live.stat().st_size==info['bytes'] and hashlib.sha256(live.read_bytes()).hexdigest()==info['sha256']
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit_code':0,
        'all_archived_and_current_members_match':True,'members':a['members'],'archive_sha256':a['sha256'],
        'scope':'Local completed evidence verification only','remote_build_GPU_or_model_run':False}
(root/'evidence/context-r50-postseal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
