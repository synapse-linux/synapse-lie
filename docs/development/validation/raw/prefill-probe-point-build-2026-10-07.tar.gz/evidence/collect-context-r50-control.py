#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Collect only four terminal artifacts from the finished owned build."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('evidence/context-r50-build-r1/terminal-control')
root.mkdir(exist_ok=False)
remote = '/home/pop/workspace/synapse-lie/context-r50-build-r1'
ssh = ['ssh', '-F', '/dev/null', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'pop@192.168.5.161']
scp = ['scp', '-F', '/dev/null', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8']
program = '''from pathlib import Path
import hashlib,json,os
root=Path('/home/pop/workspace/synapse-lie/context-r50-build-r1')
assert root.resolve()==root and root.stat().st_uid==os.getuid()
job=json.loads((root/'result.json').read_text())
assert job['state']=='PASSED' and job['exit_code']==job['child_exit_code']==0
assert job['ended_at'] and job['lease_released_at'] and not job['model_attempted']
assert not job['cleanup_failures']
files={}
for name in ('result.json','stdout.log','stderr.log','telemetry.jsonl'):
 path=root/name;assert path.is_file() and not path.is_symlink() and path.stat().st_uid==os.getuid()
 with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 files[name]={'bytes':path.stat().st_size,'sha256':digest}
print(json.dumps(files))
'''
receipt = root / 'control-collection.json'
assert not receipt.exists()
record = {'scope': 'OWN_FINISHED_CONTROL_ARTIFACTS_NOT_BUILD_OR_GPU', 'exit_code': 1, 'commands': []}
def save():
    receipt.write_text(json.dumps(record, indent=2) + '\n')
inventory = subprocess.run(ssh + ['python3 -B -'], input=program, text=True, capture_output=True, timeout=45)
record.update(inventory_exit_code=inventory.returncode, inventory_stdout=inventory.stdout,
              inventory_stderr=inventory.stderr, program_sha256=hashlib.sha256(program.encode()).hexdigest())
save()
assert inventory.returncode == 0
record['files'] = json.loads(inventory.stdout)
for name, identity in record['files'].items():
    target = root / name
    assert not target.exists()
    argv = scp + ['pop@192.168.5.161:' + remote + '/' + name, str(target)]
    run = subprocess.run(argv, text=True, capture_output=True, timeout=45)
    record['commands'].append({'argv': argv, 'actual_exit_code': run.returncode,
                              'stdout': run.stdout, 'stderr': run.stderr})
    save()
    assert run.returncode == 0 and target.stat().st_size == identity['bytes']
    assert hashlib.sha256(target.read_bytes()).hexdigest() == identity['sha256']
assert json.loads((root / 'result.json').read_text()) == json.loads(
    Path('evidence/context-r50-build-r1/controller-stdout.log').read_text())
record['exit_code'] = 0
save()
print(json.dumps({'actual_exit_code': 0, 'verified_finished_artifacts': 4}))
