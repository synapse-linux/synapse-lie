# SPDX-License-Identifier: MIT
"""Seal completed coherent Point build and separately checked host-only runner."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,tarfile
root=Path.cwd();base=root/'evidence/context-r50-build-r1'
dest=root/'docs/development/validation';name='prefill-probe-point-build-2026-10-07'
out=dest/(name+'.json');archive=dest/'raw'/(name+'.tar.gz')
assert not out.exists() and not archive.exists()
def read(rel):return json.loads((root/rel).read_text())
def bound(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':sha}
job=read('evidence/context-r50-build-r1/result.json');controller=read('evidence/context-r50-build-r1/controller-result.json')
verification=read('evidence/context-r50-build-r1/compile-verification-r1/result.json')
seal=read('evidence/context-r50-source-seal.json');bundle=read('evidence/context-r50-bundle-result.json')
closure=read('evidence/context-r50-build-closure-r2.json');initial=read('evidence/context-r50-build-closure-r1.json')
assert job['state']=='PASSED' and job['exit_code']==job['child_exit_code']==controller['exit_code']==0
assert job['model_attempted'] is False and not job['cleanup_failures']
assert verification['exit_code']==closure['actual_exit_code']==bundle['exit_code']==0
assert initial['actual_exit_code']==1 and initial['result']['r45_bundle_present'] is False
assert verification['source_commit']==seal['source_commit']==bundle['result']['metadata']['source_commit']
assert len(verification['recipes_verified'])==41 and verification['complete_variant_files_per_variant']==1019
assert seal['pristine_gufo_files_verified']==1019 and seal['tracked_compiler_files_verified']==701
closed=closure['result'];assert closed['state']=='FRESH_SUCCESSFUL_BUILD_CLOSURE_NO_STANDING_RESERVATION'
assert closed['owned_supervisor_identity_absent'] and closed['owned_container_init_identity_absent']
assert closed['original_lease']['free_briefly'] and closed['original_lease']['released']
assert not closed['foreign_compute_clients'] and not closed['http8000_listeners'] and not closed['guarded_hot']
assert closed['service']['ActiveState']=='active' and not closed['standing_lease_waiter_reservation']
rows=[json.loads(line) for line in (base/'terminal-control/telemetry.jsonl').read_text().splitlines()]
peaks={}
for row in rows:
    for sensor in row['temperatures']:
        peaks[sensor['name']]=max(peaks.get(sensor['name'],-40),sensor['value_c'])
        if sensor.get('guarded',True):assert sensor['value_c']<sensor['limit_c']
assert peaks=={'nvme':47.85,'amdgpu':44.0,'k10temp':74.0}
assert {p for row in rows for p in row['kernel_kfd']}.issubset({int(job['service_before']['MainPID'])})
for part,n in (('terminal-control/control-collection.json',4),('compile-evidence/collection.json',25),('coherence-evidence/collection.json',3)):
    coll=json.loads((base/part).read_text());assert coll['exit_code']==0 and len(coll['files'])==n
mock_guard=read('evidence/context-r50-cache-policy-supervisor-guard/result.json')
assert mock_guard['exit_code']==mock_guard['child_exit_code']==0 and mock_guard['reason'] is None
assert 'Ran 83 tests' in (root/'evidence/context-r50-cache-policy-supervisor-guard/command.log').read_text()
host_rel='docs/development/validation/prefill-probe-host-r2-2026-10-07.json'
assert bound(root/host_rel)['sha256']==seal['prefill_probe_host_receipt_sha256']
assert bound(root/'evidence/context-source-modern-r50.tar.gz')['sha256']==seal['archive_sha256']
members={}
def capture(path):
    rel=str(path.relative_to(root));members[rel]=bound(path)
for path in base.rglob('*'):
    if path.is_file():capture(path)
for path in (root/'evidence').glob('context-r50-*'):
    if path.name in ('context-r50-proof-sealing-guard','context-r50-proof-postseal-guard'):continue
    if path.is_file():capture(path)
    elif path.is_dir():
        for child in path.rglob('*'):
            if child.is_file():capture(child)
for pattern in ('prepare-context-r50-*','stage-context-r50-*','collect-context-r50-*','seal-context-r50-*','verify-context-r50-*','launch-context-r50-*'):
    for path in (root/'evidence').glob(pattern):
        if path.is_file():capture(path)
for rel in (host_rel,'evidence/seal-prefill-probe-point-r50.py','evidence/verify-prefill-probe-point-r50.py',
            'evidence/context-source-modern-r50.tar.gz','README.md','docs/BACKEND.md','docs/PROGRESS.md',
            'docs/COORDINATION.md','docs/guides/BENCHMARKS.md','tools/thermal-run.py',
            'tools/strix-point-campaign.py','tests/test_strix_point_campaign.py','tools/strix-point-launch.py',
            'tools/core-bench.c','tools/native/report.c','CMakeLists.txt','cmake/point/Build.cmake',
            'cmake/provider/Build.cmake','cmake/provider/Source.cmake','third_party/gufo-source.json'):
    capture(root/rel)
for rel,sha in verification['recipes_verified'].items():
    assert bound(root/rel)['sha256']==sha;capture(root/rel)
inventory=(json.dumps(members,indent=2)+'\n').encode()
with archive.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as package:
            for rel,item in sorted(members.items()):
                assert bound(root/rel)==item;info=tarfile.TarInfo(rel);info.mode=0o644;info.size=item['bytes']
                with (root/rel).open('rb') as data:package.addfile(info,data)
            info=tarfile.TarInfo('raw-inventory.json');info.mode=0o644;info.size=len(inventory);package.addfile(info,io.BytesIO(inventory))
result={'schema':'synapse-lie.prefill-probe-point-build.v1',
        'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'state':'BUILT_NOT_GPU_TESTED_COLLECTED_VERIFIED_CLOSED',
        'classification':'COHERENT_ROCM10_COMPILATION_AND_SEPARATE_MOCKED_HOST_RUNNER_NOT_INFERENCE',
        'source_commit':seal['source_commit'],'code_checkpoint':seal['code_checkpoint'],
        'engine_code_checkpoint':seal['engine_code_checkpoint'],'native_source_changed_after_compile':False,
        'host_receipt':{'path':host_rel,**bound(root/host_rel)},
        'source_archive_sha256':seal['archive_sha256'],'source_inventory_sha256':seal['source_files_sha256'],
        'tracked_compiler_files':701,'independently_pinned_gufo_files':1019,'complete_recipes':41,
        'complete_recipe_replacements':333,'private_C17_ON_OFF_coherent':True,
        'consumer_binary_SHA256':job['build_result']['binaries'],
        'build_stages':{n:0 for n in ('provider','reference-provider','configure','link')},
        'collected_artifacts':{'compile':25,'terminal_control':4,'coherence':3},
        'controller_exit_code':controller['exit_code'],'supervisor_exit_code':job['exit_code'],'child_exit_code':job['child_exit_code'],
        'supervisor_identity':{'pid':job['pid'],'start_ticks':job['start_ticks']},
        'container_init_identity':{'pid':job['container_host_pid'],'start_ticks':job['container_start_ticks']},
        'bundle':bundle['result'],'lease':job['lease'],'lease_released_at_utc':job['lease_released_at'],
        'fresh_closure':closed,'CPU_GPU_NVMe_peak_C':[74,44,47.85],
        'fresh_peer_evidence_limit':'Point/DGX explicit own non-use; Q2 inferred from fresh local/sole .157 declared scope, pending explicit .161 reply. No peer grant/standing window.',
        'later_host_only_cache_probe_runner':{
            'scope':'Existing DS4 controls isolate one complete input checkpoint; engine defaults unchanged',
            'mocked_tests':83,'actual_exit_code':0,'CPU_peak_C':65,
            'source_SHA256':{p:bound(root/p)['sha256'] for p in ('tools/strix-point-campaign.py','tests/test_strix_point_campaign.py')},
            'fixture_transforms':'Stored native fixture receipts stay synthetic=true. Mocked original-shaped copies additionally set controlled cache policy fields, context/build ID and top-level synthetic flags; never GPU evidence.',
            'compiled_native_code_or_ABI_scheduler_provider_changed':False,'GPU_remote_or_model_run':False},
        'preserved_failures':[{'kind':'Initial strict closure before the bundle was sealed','actual_exit_code':1,
                              'path':'evidence/context-r50-build-closure-r1.json',
                              'correction':'Seal only completed owned binaries; repeat the read-only closure, without repeating compilation.'}],
        'live_packaging_guards_excluded':True,'GPU_or_model_executed':False,'model_hash_or_conversion':False,
        'installation_tuning_deployment_or_publication':False,'original_weight_acceptance':'OPEN',
        'performance_comparison':False,'goal_complete':False,'open_task_numbers':[2,3,4,5,6,7],
        'portable_raw_archive':{'path':'raw/'+archive.name,**bound(archive),'members':len(members)+1},
        'raw_artifacts':members}
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'receipt':str(out.relative_to(root)),'archive':result['portable_raw_archive'],
                  'build_exit_codes':[0,0,0],'separate_mocked_controls':83,'original_weight_acceptance':'OPEN'}))
