# SPDX-License-Identifier: MIT
"""Seal current native qualification clients and unchanged pinned providers."""
from pathlib import Path
import datetime,gzip,hashlib,json,shutil,subprocess,tarfile
root=Path.cwd();label='context-source-modern-r50';out=root/'evidence'/label;archive=out.with_suffix('.tar.gz')
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
code=subprocess.check_output(['git','rev-parse','4b0cb675'],text=True).strip()
assert commit.startswith('cb75a48f') and not subprocess.check_output(['git','status','--porcelain'])
assert not out.exists() and not archive.exists()

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
receipt_path=root/'docs/development/validation/prefill-probe-host-r2-2026-10-07.json'
receipt=json.loads(receipt_path.read_text());raw=receipt_path.parent/receipt['portable_raw_archive']['path']
assert receipt['classification']=='HOST_SYNTHETIC_AND_MOCKED_CLIENT_CONTRACTS_NOT_INFERENCE'
assert [g['tests_passed'] for g in receipt['native_checks']]==[5,5]
assert receipt['optional_mocked_supervisor']['tests_passed']==82
assert receipt['GPU_execution'] is False and receipt['model_access'] is False
assert sha(raw)==receipt['portable_raw_archive']['sha256']
assert json.loads((root/'evidence/prefill-probe-host-r2-postseal.json').read_text())['actual_exit_code']==0
for name,item in receipt['source_files'].items():assert sha(root/name)==item['sha256'],name
old_commit='2ec9798bf00f774fdaf3d9150ba79712dd88feaf'
delta=subprocess.check_output(['git','diff','--name-only',old_commit,commit],text=True).splitlines()
allowed={'CMakeLists.txt','README.md','tests/fixtures/prefill-probe-receipts.json',
         'tests/test_prefill_bench.c','tests/test_strix_point_campaign.py','tools/bench-report.py',
         'tools/core-bench.c','tools/native/report.c','tools/strix-point-campaign.py'}
assert {n for n in delta if not n.startswith('docs/')}==allowed
local_path=root/'docs/development/validation/prefill-runtime-local-2026-10-07.json'
local=json.loads(local_path.read_text());provider_source=local['source']
assert provider_source['pristine_files']==1019 and provider_source['recipes']==41 and provider_source['edits']==333
for name,digest in provider_source['recipe_sha256'].items():
    assert Path(name).name==name and sha(root/'adapters/gufo-state'/name)==digest
out.mkdir();copied=[];excluded_count=0
process=subprocess.Popen(['git','archive','--format=tar',commit],stdout=subprocess.PIPE)
try:
    with tarfile.open(fileobj=process.stdout,mode='r|') as tracked:
        for member in tracked:
            path=Path(member.name)
            assert not path.is_absolute() and '..' not in path.parts and (member.isfile() or member.isdir())
            if path.parts[0]=='docs':
                if member.isfile():excluded_count+=1
                continue
            tracked.extract(member,out,filter='data')
            if member.isfile():copied.append(member.name)
finally:process.stdout.close()
assert process.wait()==0
for name in copied:assert sha(out/name)==sha(root/name),name
upstream=root/'.deps/gufo-f783fedb';manifest=json.loads((out/'third_party/gufo-source.json').read_text())
assert manifest['commit']=='f783fedb9bea2ec7de941f6da4e02f4a4596b29e' and len(manifest['files'])==1019
assert upstream.resolve()==upstream
for name,digest in manifest['files'].items():
    path=upstream/name;assert not path.is_symlink() and path.resolve().is_relative_to(upstream) and sha(path)==digest
    target=out/'.deps/gufo-f783fedb'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
    assert sha(target)==digest
prior_path=root/'evidence/context-r11-build-r2/result.json';prior=json.loads(prior_path.read_text())['build_result'];zstd={}
for name,key in {'zstd.h':'zstd_header_sha256','zstd_errors.h':'zstd_errors_sha256','LICENSE':'zstd_license_sha256'}.items():
    path=root/'evidence/context-source-modern-r11/third_party/point-zstd-dev'/name
    assert path.is_file() and not path.is_symlink() and sha(path)==prior[key]
    target=out/'third_party/point-zstd-dev'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
    zstd[name]=sha(target)
ryu=json.loads((out/'third_party/ryu-source.json').read_text())
for name,item in ryu['files'].items():assert sha(out/'third_party/ryu'/name)==item['sha256']
(out/'SOURCE-COMMIT.txt').write_text(commit+'\n');(out/'CODE-CHECKPOINT.txt').write_text(code+'\n')
files=sorted(path for path in out.rglob('*') if path.is_file());assert all(not p.is_symlink() for p in files)
(out/'SOURCE-FILES.sha256').write_text(''.join(sha(p)+'  ./'+str(p.relative_to(out))+'\n' for p in files))
with archive.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as package:package.add(out,arcname=label)
record={'scope':'LOCAL_SEALED_COMPILER_INPUTS_NOT_REMOTE_BUILD_OR_GPU',
        'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':commit,'code_checkpoint':code,
        'engine_code_checkpoint':'d6431db85d3119e112ffd01c557aaacd6d7c2714',
        'qualified_provider_build_source':old_commit,'non_documentation_delta':sorted(allowed),
        'engine_provider_numerical_ABI_or_scheduler_changed':False,
        'prefill_probe_host_receipt_sha256':sha(receipt_path),'prefill_probe_host_archive_sha256':sha(raw),
        'native_client_tests':{'Release':5,'ASan_UBSan_LSan':5,'mocked_supervisor':82},
        'provider_source':provider_source,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
        'source_files_sha256':sha(out/'SOURCE-FILES.sha256'),'source_files':len(files),
        'compile_helper_sha256':sha(out/'cmake/point/Build.cmake'),'runner_sha256':sha(out/'tools/strix-point-campaign.py'),
        'gufo_pin':manifest['commit'],'pristine_gufo_files_verified':1019,
        'zstd_prior_receipt_sha256':sha(prior_path),'zstd_development_sha256':zstd,
        'ryu_pin':ryu['commit'],'unchanged_Ryu_files_verified':len(ryu['files']),
        'tracked_compiler_files_verified':len(copied),'excluded_documentation_files':excluded_count,
        'six_required_consumer_targets':['synapse-lie-server','synapse-lie-bench',
          'synapse-lie-bench-gufo-reference','lie-hip-probe','lie-sampling-capture','lie-attention-qualify'],
        'remote_stage_build_or_GPU_run':False,'all_six_tasks_remain_open':True}
with (root/'evidence/context-r50-source-seal.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps({k:record[k] for k in ('scope','source_commit','code_checkpoint','archive_bytes','source_files',
                    'tracked_compiler_files_verified','pristine_gufo_files_verified')}))
