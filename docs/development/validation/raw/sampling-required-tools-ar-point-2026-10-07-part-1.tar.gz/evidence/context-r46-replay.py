# SPDX-License-Identifier: MIT
"""Replay saved original tool rows with the already bound binaries; no model."""
from pathlib import Path
import hashlib,json,subprocess,sys

assert len(sys.argv)==2 and sys.argv[1] in ('release','asan')
kind=sys.argv[1]
capture=Path('evidence/context-r46-sampling-tools-r1/capture').resolve()
output=Path('evidence/context-r46-'+kind+'-replay')
output.mkdir(exist_ok=False)
def bound(path):
    path=Path(path)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':digest}
prior=json.loads(Path('evidence/context-r46-sampling-readiness.json').read_text())
assert prior['scope']=='CURRENT_GPU_RUNTIME_PLUS_UNCHANGED_QUALIFIED_OFFLINE_SAMPLER_BINDING_NOT_ADMISSION'
for name,expected in prior['native_capture_and_replay_unchanged_files'].items():
    assert bound(name)==expected
for name,digest in prior['owned_sampler_files'].items():
    assert bound(name)['sha256']==digest
for name,expected in prior['host_reference_libraries'].items():
    if '/final-integrated-r76-provider-'+kind+'/' in name:
        actual=bound(name)
        assert actual['bytes']==expected['bytes'] and actual['sha256']==expected['sha256']
lines=[json.loads(line) for line in (capture/'capture.jsonl').read_text().splitlines()]
identity=lines[0];terminal=lines[-1]
assert identity['schema']=='synapse-lie.sampling-capture.v2' and identity['synthetic'] is False
assert identity['build_id']=='rocm10-point-modern-r45-runtime'
assert terminal['event']=='complete' and terminal['exit_code']==0 and terminal['profiles']==6
rows=terminal['rows']
assert 6<=rows<=768
commands=[c for c in prior['native_replay_commands'] if c['kind']==kind]
assert len(commands)==3
result={'scope':'ORIGINAL_WEIGHT_REQUIRED_FUNCTION_AR_MASK_FILTER_DRAW_COMPLETE_CALL_ONLY',
        'kind':kind,'capture_identity':identity,'capture_manifest':bound(capture/'capture.jsonl'),
        'source_binding_receipt':'evidence/context-r46-sampling-readiness.json',
        'commands':[],'exit_code':1,'new_GPU_or_model_CPU_forward':False,
        'MTP_prose_parallel_results_fault_quality_resource_cost_qualified':False}
target=output/'result.json'
target.write_text(json.dumps(result,indent=2)+'\n')
for command in commands:
    arm=command['arm'];binary=Path(command['bound_binary']['path'])
    proof=bound(binary)
    assert proof==command['bound_binary']
    argv=[str(binary),'--capture',str(capture)]
    stdout=output/(arm.upper()+'.txt');stderr=output/(arm.upper()+'.stderr')
    timed_out=False
    with stdout.open('xb') as out,stderr.open('xb') as err:
        child=subprocess.Popen(argv,stdout=out,stderr=err)
        try:child.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timed_out=True;child.terminate()
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:child.kill();child.wait()
    record={'arm':arm,'argv':argv,'actual_exit_code':child.returncode,'timed_out':timed_out,
            'bound_binary':proof,'stdout':bound(stdout),'stderr':bound(stderr)}
    result['commands'].append(record)
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'arm':arm,'actual_exit_code':child.returncode,'timed_out':timed_out,'stdout_bytes':stdout.stat().st_size,'stderr':stderr.read_text()[:1000]}),flush=True)
    if child.returncode or timed_out:raise SystemExit(1)
assert len({c['stdout']['sha256'] for c in result['commands']})==1
for cmd in result['commands']:
    with Path(cmd['stdout']['path']).open() as f:
        first=f.readline()
        assert first=='classification=CAPTURE-DECLARED-ORIGINAL-WEIGHTS-REQUIRE-SUPERVISOR-PROVENANCE scope=required-function-AR-mask/filter/draw/complete-call;not-MTP-controller/performance\n'
        count=1;last=first;mask_rows=0
        for last in f:
            count+=1
            if last.startswith('allowed='):mask_rows+=1
        assert mask_rows==rows
        assert last==f'ROWS={rows} COMPLETE_OFFLINE_WITNESSES_NOT_FULL_ACCEPTANCE\n'
    assert cmd['stderr']['bytes']==0
result.update(exit_code=0,state='ORIGINAL_REQUIRED_TOOL_AR_THREE_ARMS_FULL_MASK_MASS_HISTORY_RNG_CALL_WITNESSES_PASS',rows=rows,complete_witness_sha256=result['commands'][0]['stdout']['sha256'],complete_witness_lines=count)
target.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['state','kind','exit_code','rows','complete_witness_sha256','complete_witness_lines']}))
