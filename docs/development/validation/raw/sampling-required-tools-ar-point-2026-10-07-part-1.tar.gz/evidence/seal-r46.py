# SPDX-License-Identifier: MIT
"""Seal completed own capture and offline reviews; never launch tests or GPU."""
from pathlib import Path
import datetime, hashlib, json, subprocess, tarfile

root = Path.cwd()
name = 'sampling-required-tools-ar-point-2026-10-07'
dest = root/'docs/development/validation'
receipt = dest/(name+'.json')
assert not receipt.exists()
def read(rel): return json.loads((root/rel).read_text())
def ident(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as f: sha = hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':sha}

collection = read('evidence/context-r46-sampling-tools-r1/collection.json')
assert collection['exit_code'] == 0 and collection['inventory']['result_state'] == 'PASSED'
job = root/'evidence/context-r46-sampling-tools-r1'
for rel,expected in collection['inventory']['files'].items():
    assert ident(job/rel) == expected
assert len(collection['inventory']['files']) == 164
capture = read('evidence/context-r46-capture-collection-verification.json')
assert capture['actual_exit_code'] == 0 and capture['raw_rows'] == 152
math = read('evidence/context-r46-math-verification-r1.json')
assert math['actual_exit_code'] == 0 and math['raw_rows'] == 152
ready = read('evidence/context-r46-sampling-readiness.json')
manifest = read('evidence/context-r46-sampling-tools-manifest.json')
HIP = read(manifest['qualified_build_receipt'])
assert ident(root/manifest['qualified_build_receipt'])['sha256'] == manifest['qualified_build_receipt_sha256']
assert HIP['source_commit'] == manifest['source_commit'] == ready['compiled_source_commit']
assert HIP['code_checkpoint'] == manifest['functional_code_checkpoint'] == ready['code_checkpoint']
for rel,sha in ready['owned_sampler_files'].items():
    assert ident(root/rel)['sha256'] == sha
for rel,expected in ready['native_capture_and_replay_unchanged_files'].items():
    assert ident(root/rel) == {k:expected[k] for k in ('bytes','sha256')}
for rel,expected in ready['host_reference_libraries'].items():
    assert ident(root/rel) == {k:expected[k] for k in ('bytes','sha256')}
closure = read('evidence/context-r46-tools-closure-r1.json')
assert closure['actual_exit_code'] == 0
assert closure['result']['state'] == 'FRESH_NATIVE_CAPTURE_WINDOW_CLOSED_NO_STANDING_RESERVATION'
assert closure['result']['original_lease']['free_briefly']
supervisor = read('evidence/context-r46-sampling-tools-r1/result.json')
assert supervisor['exit_code'] == supervisor['child_exit_code'] == 0
assert supervisor['models_before'] == supervisor['models_after']
assert supervisor == read('evidence/context-r46-sampling-tools-r1/controller-terminal-result.json')
witnesses = []; guards = {}
for kind in ('release','asan'):
    r = read(f'evidence/context-r46-{kind}-replay/result.json')
    guards[kind] = read(f'evidence/context-r46-{kind}-replay-guard/result.json')
    assert r['exit_code'] == guards[kind]['exit_code'] == guards[kind]['child_exit_code'] == 0
    for cmd in r['commands']:
        assert cmd['actual_exit_code'] == 0
        for field in ('bound_binary','stdout','stderr'):
            d = cmd[field]
            assert ident(root/d['path']) == {k:d[k] for k in ('bytes','sha256')}
        assert cmd['stdout']['sha256'] == math['full_witness_sha256'] and cmd['stderr']['bytes'] == 0
        witnesses.append({'kind':kind,**cmd})
assert len(witnesses) == 6

files = {}
for path in root.glob('evidence/context-r46-*'):
    if path.name == 'context-r46-seal-guard':
        # A running wrapper's telemetry/log is not terminal evidence. Its
        # completed exit0 record is retained in the packaging revision note.
        continue
    if path.is_dir():
        for f in path.rglob('*'):
            if f.is_file(): files[str(f.relative_to(root))] = f
    elif path.is_file(): files[str(path.relative_to(root))] = path
files['evidence/seal-r46.py'] = root/'evidence/seal-r46.py'
for rel in ready['owned_sampler_files']:
    files[rel] = root/rel
for rel in ready['native_capture_and_replay_unchanged_files']:
    files[rel] = root/rel
for proof in ready['host_sampler_variant_binding'].values():
    rel = proof['variant_map']['path']; assert ident(root/rel) == {k:proof['variant_map'][k] for k in ('bytes','sha256')}
    files[rel] = root/rel
for cmd in witnesses:
    rel = cmd['bound_binary']['path']; files[rel] = root/rel
for rel in (manifest['qualified_build_receipt'],
            'docs/development/validation/sampling-tools-host-2026-10-07.json',
            'docs/development/validation/sampling-original-ar-point-2026-10-07.json',
            'docs/development/validation/integrated-final-host-2026-10-06.json',
            'tools/strix-point-bench-collect.py','tools/thermal-run.py'):
    files[rel] = root/rel
parts = [{},{},{}]
for rel,path in sorted(files.items()):
    if path.suffix == '.f32le':
        index = 1 if int(path.name.split('-')[1]) < 3 else 2
    else: index = 0
    parts[index][rel] = path
archives = []
for index,part in enumerate(parts):
    path = dest/'raw'/f'{name}-part-{index+1}.tar.gz'
    inventory = {rel:ident(p) for rel,p in part.items()}
    if path.exists():
        assert index in (1,2)
        first = read('evidence/seal-r46-original-r1/receipt.json')['portable_raw_archive_parts'][index]
        assert ident(path) == {k:first[k] for k in ('bytes','sha256')}
        assert inventory == first['inventory']
    else:
        assert index == 0
        with tarfile.open(path,'w:gz',compresslevel=3) as arc:
            for rel,p in part.items(): arc.add(p,arcname=rel,recursive=False)
    with tarfile.open(path,'r:gz') as arc:
        assert len(arc.getmembers()) == len(inventory) and set(arc.getnames()) == set(inventory)
        for member in arc.getmembers():
            assert member.isfile()
            with arc.extractfile(member) as stream:
                payload = stream.read()
            assert len(payload) == inventory[member.name]['bytes']
            assert hashlib.sha256(payload).hexdigest() == inventory[member.name]['sha256']
    assert path.stat().st_size < 100*1024*1024
    archives.append({'path':str(path.relative_to(root)),**ident(path),'members':len(part),
                     'all_members_independently_verified':True,'inventory':inventory})

head = subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
data = {
 'schema':'synapse-lie.required-tool-ar-numerical-qualification.v1',
 'sealed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':math['state'],
 'scope':'SELECTED_REQUIRED_FUNCTION_AR_FULL_MASK_FILTER_HISTORY_RNG_COMPLETE_CALL_ONLY',
 'compiled_source_commit':manifest['source_commit'],'functional_code_checkpoint':manifest['functional_code_checkpoint'],
 'runtime_build_id':manifest['runtime_build_id'],'bundle_manifest_sha256':manifest['bundle_manifest_sha256'],
 'runner_commit':manifest['runner_commit'],'fixture_commit':manifest['fixture_commit'],'checkpoint_at_sealing':head,
 'matching_HIP_receipt':manifest['qualified_build_receipt'],'source_binding':ready,
 'reuse_scope':'Only unchanged offline sampler/grammar inputs reuse six qualified executables and read-only static libraries. Three changed model-engine/HIP sources are not linked by host replay. Original-weight GPU capture uses the new coherent r45 runtime, not r38/r39.',
 'model':'Qwen3.8 Flash Next Unsloth UD-Q4_K_XL, official four-shard revision 38bb39ee97821de2c9009abb7e93950eec396e66',
 'machine':'192.168.5.161 AMD Strix Point gfx1150 ROCm10',
 'capture':capture,'numerical_verification':math,'native_replay_commands':witnesses,
 'controller_supervisor_native_exit_codes':[0,0,0],
 'release_wrapper_and_three_native_exit_codes':[0,0,0,0],
 'asan_wrapper_and_three_native_exit_codes':[0,0,0,0],
 'offline_thermal_guards':guards,'offline_sanitizer_options':read('evidence/context-r46-host-replay-options.json'),
 'strict_machine_closure':closure['result'],'lease_released_at_utc':supervisor['lease_released_at'],
 'fresh_peer_coordination':read('evidence/context-r46-peer-coordination.json'),
 'coordination_inference_limit':'Q2 supplied fresh own no-GPU and sole .157 plan; its .161 non-use is an explicitly recorded scope inference, not an explicit per-target reply or global grant. Point/DGX answered per target. Fresh global preflight and original lease were separately checked.',
 'packaging_observer_snapshot_correction':read('evidence/context-r46-packaging-revision.json'),
 'raw_row_archive_parts_reused_without_recapture':True,
 'preserved_failures':[read('evidence/context-r46-inspection-failure-r1.json'),read('evidence/context-r46-additional-review-failure-r1.json'),read('evidence/context-r46-additional-review-failure-r2.json')],
 'corrected_additional_review_guard':read('evidence/context-r46-math-review-guard-r3/result.json'),
 'prefill_selected_and_reserved_tokens':2048,
 'EOS_scope':'The live ABI exposes stop/emitted flags and no EOS token ID. Replay checks a stop-token draw at the same completed frontier; exact live EOS ID equality is not claimed.',
 'broader_open_gates':['MTP target-distribution/controller transitions','prose, parallel tools and tool results',
                     'HTTP and long-context recall','larger live prefill chunks: parity, memory, cache, cancellation, fairness',
                     'steering quality/correction/fault/vision coverage','allocation-exact resources and faults',
                     'matched comparative performance through 1M and C1/2/4/6/8','Terminal Bench last'],
 'six_root_items_open':[2,3,4,5,6,7],'goal_complete':False,
 'no_standing_root_job_lease_window_waiter_reservation_handle':True,
 'packaging_runs_build_test_GPU_model_hash':False,'portable_raw_archive_parts':archives,
 'reproduction':'Extract all three archive parts at one root. Run each archived sampling-original-r82-{release,asan} binary with --capture evidence/context-r46-sampling-tools-r1/capture. Rebind paths in saved helpers for a different extraction root. No model forward or GPU is required for replay. Original collection/controller records remain immutable.'
}
receipt.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'receipt':str(receipt.relative_to(root)),'raw_rows':152,
                  'verified_members':sum(a['members'] for a in archives),
                  'archive_bytes':sum(a['bytes'] for a in archives),'archive_parts':len(archives),
                  'full_witness_sha256':math['full_witness_sha256'],'scope':data['scope']}))
