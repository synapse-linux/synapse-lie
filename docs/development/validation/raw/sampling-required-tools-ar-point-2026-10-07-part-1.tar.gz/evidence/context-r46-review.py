# SPDX-License-Identifier: MIT
"""Independent review of saved masks/mass/history/RNG/calls; no model or GPU."""
from pathlib import Path
import array, collections, datetime, hashlib, json, math, re, struct, sys

root = Path.cwd()
capture = root/'evidence/context-r46-sampling-tools-r1/capture'
lines = [json.loads(s) for s in (capture/'capture.jsonl').read_text().splitlines()]
profiles = [s for s in lines if s['event'] == 'profile_begin']
rows = [s for s in lines if s['event'] == 'row']
calls = [s for s in lines if s['event'] == 'profile_complete']
assert len(profiles) == len(calls) == 6 and len(rows) == 152
assert lines[0]['build_id'] == 'rocm10-point-modern-r45-runtime'
assert lines[0]['synthetic'] is False and lines[0]['decode_mode'] == 'ar'
vocab = profiles[0]['vocab']
assert vocab == 248320 and all(p['vocab'] == vocab for p in profiles)

def bound(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as f:
        sha = hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':path.stat().st_size, 'sha256':sha}

artifacts = []
for kind in ('release','asan'):
    r = json.loads((root/f'evidence/context-r46-{kind}-replay/result.json').read_text())
    assert r['exit_code'] == 0 and r['rows'] == 152
    guard = json.loads((root/f'evidence/context-r46-{kind}-replay-guard/result.json').read_text())
    assert guard['exit_code'] == guard['child_exit_code'] == 0 and guard['reason'] is None
    for c in r['commands']:
        assert c['actual_exit_code'] == 0 and c['stderr']['bytes'] == 0
        for key in ('bound_binary','stdout','stderr'):
            assert bound(root/c[key]['path']) == {k:c[key][k] for k in ('bytes','sha256')}
        artifacts.append(c['stdout'])
assert len(artifacts) == 6 and len({a['sha256'] for a in artifacts}) == 1

# The six native replays independently feed each vocabulary piece byte by byte
# through the grammar and compare the resulting complete mask to production.
# This additional reviewer consumes that saved mask, independently ranks raw
# F32 logits, applies generated-only penalties/filtering, and checks all mass.
sections = []
with (root/artifacts[0]['path']).open() as witness:
    section = None
    for text in witness:
        text = text.rstrip('\n')
        if text.startswith('profile='):
            found = re.fullmatch(r'profile=(\d+) step=(\d+) sha256=([0-9a-f]{64})',text)
            assert found
            section = {'profile':int(found[1]), 'step':int(found[2]), 'sha256':found[3], 'p':[], 'residual':[]}
            sections.append(section)
        elif text.startswith('allowed='):
            section['allowed'] = text[8:]
        elif text.startswith('p='):
            token, value = text[2:].split(':')
            section['p'].append((int(token),float.fromhex(value)))
        elif text.startswith('draw='):
            found = re.fullmatch(r'draw=(\d+) rng=(\d+)',text)
            assert found
            section['draw'] = (int(found[1]),int(found[2]))
        elif text.startswith('residual='):
            if text == 'residual=singleton-target':
                section['residual'].append('singleton')
            else:
                found = re.fullmatch(r'residual=(\d+) rng=(\d+)',text)
                assert found
                section['residual'].append((int(found[1]),int(found[2])))
assert len(sections) == len(rows)

data = (capture/'vocabulary.bin').read_bytes()
assert data[:8] == b'LIEVOC01' and struct.unpack_from('<I',data,8)[0] == vocab
pieces = []; at = 12
for _ in range(vocab):
    size = struct.unpack_from('<I',data,at)[0]; at += 4
    stop = struct.unpack_from('<I',data,at)[0]; at += 4
    assert stop in (0,1) and size <= 32768
    pieces.append((data[at:at+size],bool(stop))); at += size
assert at == len(data)

MASK64 = (1 << 64)-1
def draw(mass,state):
    if len(mass) == 1:
        return mass[0][0],state
    x = state or 0x9e3779b97f4a7c15
    x ^= x >> 12
    x ^= (x << 25) & MASK64
    x ^= x >> 27
    u = (((x*0x2545f4914f6cdd1d) & MASK64) >> 11) * 2**-53
    for token,value in mass:
        u -= value
        if u < 0:
            return token,x
    return mass[-1][0],x

max_mass_error = 0.0; residual_draws = 0; generated = None; previous = None
output = b''; accepted = []; rng = 123; profile_results = []
for row,section in zip(rows,sections):
    profile = row['profile']
    # JSON records the requested decimal controls; the existing executor
    # sampling contract admits these real fields as F32 (replay.cpp::config).
    config = {k:(v if k in ('top_k','seed') else struct.unpack('<f',struct.pack('<f',v))[0])
              for k,v in profiles[profile]['generation'].items()}
    if profile != previous:
        generated = collections.Counter(); output = b''; accepted = []; rng = 123; previous = profile
    assert (section['profile'],section['step'],section['sha256']) == (profile,row['step'],row['sha256'])
    raw = (capture/row['file']).read_bytes()
    assert len(raw) == row['bytes'] == 4*vocab and hashlib.sha256(raw).hexdigest() == row['sha256']
    logits = array.array('f'); logits.frombytes(raw)
    if sys.byteorder != 'little': logits.byteswap()
    assert all(math.isfinite(v) for v in logits)
    mask = section['allowed']
    assert len(mask) == vocab and set(mask) <= {'0','1'}
    ranked = [(i,float(logits[i])-config['frequency_penalty']*generated[i]
               -(config['presence_penalty'] if generated[i] else 0.0))
              for i,bit in enumerate(mask) if bit == '1']
    ranked.sort(key=lambda pair:(-pair[1],pair[0])); assert ranked
    temperature = config['temperature']
    if temperature == 0:
        expected = [(ranked[0][0],1.0)]
    else:
        if config['top_k']:
            ranked = ranked[:config['top_k']]
        maximum = ranked[0][1]
        if config['top_p'] < 1:
            unnormalized = [math.exp((v-maximum)/temperature) for _,v in ranked]
            threshold = config['top_p']*math.fsum(unnormalized)
            cumulative = 0.0; used = 0
            for v in unnormalized:
                used += 1; cumulative += v
                if cumulative >= threshold: break
            ranked = ranked[:used]
        if config['min_p']:
            threshold = maximum+temperature*math.log(config['min_p'])
            ranked = [(i,v) for i,v in ranked if v >= threshold]
        unnormalized = [(i,math.exp((v-maximum)/temperature)) for i,v in ranked]
        total = math.fsum(v for _,v in unnormalized)
        expected = [(i,v/total) for i,v in unnormalized if v/total > 0]
    actual = section['p']
    # Entry order is part of the captured draw witness, not a requirement that
    # the probability vector be ranked by mass. Compare every token's mass;
    # replay RNG draws in the actual order shared by all six native outputs.
    wanted_by_token = dict(expected)
    assert len(dict(actual)) == len(actual)
    assert wanted_by_token.keys() == dict(actual).keys()
    assert abs(math.fsum(v for _,v in actual)-1) <= 5e-12
    for token,value in actual:
        wanted = wanted_by_token[token]
        error = abs(value-wanted); max_mass_error = max(max_mass_error,error)
        assert error <= 5e-14+5e-12*wanted
    token,new_rng = draw(actual,rng)
    assert section['draw'] == (token,new_rng); rng = new_rng
    if len(actual) == 1:
        assert section['residual'] == ['singleton']
    else:
        total = sum(v for _,v in actual[1:])
        residual = [(i,v/total) for i,v in actual[1:]]
        assert section['residual'] == [draw(residual,seed) for seed in range(8)]
        residual_draws += 8
    assert row['position'] == len(profiles[profile]['prompt_ids'])+len(accepted)+row['emitted']
    if row['stop']:
        assert row['token'] is None and not row['emitted'] and pieces[token][1]
        assert output.startswith(b'<tool_call>') and output.endswith(b'</tool_call>')
        call = json.loads(output[11:-12])
        assert call == calls[profile]['tool_call'] == {'name':'describe_stack','arguments':{'order':'LIFO','size':3}}
        assert accepted == calls[profile]['output_ids']
        profile_results.append({'name':profiles[profile]['name'],'rows':calls[profile]['rows'],
                                'emitted_tokens':len(accepted),'natural_EOS':True,'tool_call':call,
                                'masked_probability_entries':sum(len(s['p']) for s in sections if s['profile']==profile)})
    else:
        assert row['token'] == token and row['emitted'] == 1 and not pieces[token][1]
        output += pieces[token][0]; generated[token] += 1; accepted.append(token)
assert len(profile_results) == 6
result = {'schema':'synapse-lie.required-tool-ar-offline-review.v1',
          'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit_code':0,
          'state':'REQUIRED_TOOL_AR152_SIX_ARMS_FULL_MASK_MASS_HISTORY_RNG_COMPLETE_CALL_PASS',
          'raw_rows':152,'vocabulary_tokens':vocab,'mask_bits_per_arm':152*vocab,
          'full_witness_sha256':artifacts[0]['sha256'],'full_witness_bytes_per_arm':artifacts[0]['bytes'],
          'all_six_outputs_size_SHA_identical':True,'native_independent_full_mask_byte_feed':True,
          'native_independent_long_double_mass_oracle':True,
          'additional_mass_oracle':'Python stdlib double-precision rank/exp/fsum against saved full masks',
          'additional_mass_max_absolute_error':max_mass_error,'residual_draws_independently_checked':residual_draws,
          'profiles':profile_results,'ASan_UBSan_LSan_unsuppressed_outside_ptrace':True,
          'new_GPU_or_model_CPU_forward':False,'MTP_controller_fault_broad_quality_resource_cost_qualified':False}
with (root/'evidence/context-r46-math-verification-r1.json').open('x') as f:
    json.dump(result,f,indent=2); f.write('\n')
print(json.dumps(result))
