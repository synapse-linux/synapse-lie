# SPDX-License-Identifier: MIT
"""Fresh read-only global observation for the frozen original capture window."""
from pathlib import Path
import hashlib, json, subprocess

LABEL = 'steering-conciseness-quality-point-20261008-r1'
local = Path('evidence')/LABEL
manifest = json.loads((local/'manifest.json').read_text())
expected = {'strix-point-steering-quality-profile.py': '98d16c07475205505ff1d5346a740b6f4425e0951ef16e9bad0e2fb7c793540e', 'strix-point-steering-quality-run.py': 'c936a6f5570fde93c83ebca2aadfd8a18d08f4897bf969c9625905c501fa7417', 'strix-point-steering-quality-gate.py': 'd548a4cac15cb79e4f936f0d29808b80cf837d38efa773ad4be53f77b3027321', 'strix-point-steering-build-gate.py': '218a71af2eca71709a9cf00ff55ad3eb1190d1909a3857ebed358d964d8d6f3f', 'strix-point-http-recall-gate.py': '5bce29df2a6d2f9f652986bd57dc61dbc31ee554157f353124c22d5285a678a4', 'runner.py': 'e68672b4e2b43ae981daf65462809c98232ba3a9248d634727fa812c4d3dd035', 'steering-quality-settings.json': '6f1b51cfac0e1e9792281c05103a79b76331291e5d1d5fe160c3e081287b9e4a', 'corpus.json': '602354e607a5738958b12f01913473aac6dd4e8ec08cef7f1dfd9023084b14a4', 'steering-training-receipt.json': '6367619cb08765ccc39395f05023cc69b13a3f0dfedba406bba45c338035ac12', 'direction.ffn.f32': '27d1ba7593c55f288ce4e214cf62e4f87eba7823422f48bca6e35a3f0dce603b', 'manifest.json': 'bb7c4fb8f2ff95607982757044bbbe8d2120cbc95d4c4588bcfbf02346eb0f19'}
assert expected['manifest.json'] == 'bb7c4fb8f2ff95607982757044bbbe8d2120cbc95d4c4588bcfbf02346eb0f19'
program = 'LABEL='+repr(LABEL)+'\nEXPECTED='+repr(expected)+'\n' + '''
from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,stat,subprocess
base=Path('/home/pop/workspace/synapse-lie');root=base/LABEL
assert os.getuid()==1000 and base.resolve()==base and base.stat().st_uid==os.getuid()
assert root.resolve()==root and root.stat().st_uid==os.getuid()
hashes={}
for name,expected in EXPECTED.items():
 p=root/name;fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
 with os.fdopen(fd,'rb') as f:
  before=os.fstat(f.fileno());assert stat.S_ISREG(before.st_mode) and before.st_uid==os.getuid() and before.st_size<=1048576
  actual=hashlib.file_digest(f,'sha256').hexdigest();after=os.fstat(f.fileno())
  assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
 assert actual==expected;hashes[name]=actual
m=json.loads((root/'manifest.json').read_text())
spec=importlib.util.spec_from_file_location('point_readonly',root/'runner.py')
point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert boot==m['verified_boot_id']
mount=json.loads(subprocess.check_output(['findmnt','--json','--target',str(base),'--output','UUID'],text=True,timeout=15))
assert mount.get('filesystems')==[{'uuid':'720d3f3a-db4b-4287-bf9c-77cc76bcb7cb'}] and base.stat().st_dev==66308
row=point.observe(98,gpu_observation_only=True)
q=subprocess.run(['systemctl','--user','show','llama-router.service','--property=ActiveState,SubState,MainPID'],capture_output=True,text=True,timeout=15)
assert q.returncode==0;service=dict(line.split('=',1) for line in q.stdout.splitlines())
pid=int(service['MainPID']);main_ticks=point.ticks(pid) if pid else None
path=base/'campaign.lock';fd=os.open(path,os.O_RDWR|os.O_NOFOLLOW|os.O_CLOEXEC);free=False
try:
 st=os.fstat(fd);live=path.stat();assert stat.S_ISREG(st.st_mode) and st.st_uid==os.getuid()
 assert (st.st_dev,st.st_ino)==(live.st_dev,live.st_ino)==(66308,105946405)
 try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);free=True
 except BlockingIOError:pass
finally:
 if free:fcntl.flock(fd,fcntl.LOCK_UN)
 os.close(fd)
q=subprocess.run(['docker','image','inspect',m['image'],'--format','{{.Id}}'],capture_output=True,text=True,timeout=15)
image={'exit_code':q.returncode,'id':q.stdout.strip(),'stderr':q.stderr}
bundle=Path(m['bundle']);assert bundle.resolve()==bundle and bundle.stat().st_uid==os.getuid()
bundle_sha=hashlib.sha256((bundle/'BUNDLE.json').read_bytes()).hexdigest();assert bundle_sha==m['bundle_manifest_sha256']
disk=os.statvfs(bundle);listeners=[]
for tcp in ('/proc/net/tcp','/proc/net/tcp6'):
 for line in Path(tcp).read_text().splitlines()[1:]:
  fields=line.split()
  if fields[3]=='0A' and int(fields[1].rsplit(':',1)[1],16)==8000:
   listeners.append({'table':tcp,'local_address':fields[1],'uid':int(fields[7]),'inode':int(fields[9])})
clients=set(row['kernel_kfd'])|{p['pid'] for p in row['kfd']}
foreign=sorted(clients-({pid} if service['ActiveState']=='active' else set()))
hot=[t for t in row['temperatures'] if t['guarded'] and t['value_c']>=t['limit_c']]
memory=m['memory_admission'];available=row['memory']['MemAvailable'];gtt=row['gpu']['mem_info_gtt_total'];used=row['gpu']['mem_info_gtt_used']
memory_valid=all(type(v) is int for v in (available,gtt,used)) and memory['expected_peak_gtt_bytes']<=gtt and available-max(memory['expected_peak_gtt_bytes']-used,0)>=memory['min_available_ram_bytes']
prepared=not (root/'result.json').exists() and not (root/'steering-quality').exists() and not (root/'steering-quality-review.json').exists()
r={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'READ_ONLY_NOT_ADMITTED',
 'boot_id':boot,'filesystem_uuid':mount['filesystems'][0]['uuid'],'source_hashes':hashes,'service':service,'router_start_ticks':main_ticks,
 'original_lease':{'path':str(path),'device':st.st_dev,'inode':st.st_ino,'free_briefly':free,'released':True},
 'observation':row,'foreign_compute_clients':foreign,'guarded_hot':hot,'http8000_listeners':listeners,'pinned_image':image,
 'free_disk_bytes':disk.f_bavail*disk.f_frsize,'bundle_manifest_sha256':bundle_sha,'exclusive_job_prepared':prepared,
 'projected_memory_admission_valid':memory_valid,'GPU_build_run_or_service_mutation':False,'standing_lease_waiter_reservation':False}
print(json.dumps(r))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':run.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':run.stdout,'stderr':run.stderr}
try:record['result']=json.loads(run.stdout)
except ValueError:pass
with Path('evidence/steering-conciseness-quality-point-20261008-r1-fresh-r1.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
if 'result' in record:
 r=record['result'];print(json.dumps({k:r[k] for k in ('state','at_utc','boot_id','service','original_lease','foreign_compute_clients','guarded_hot','http8000_listeners','pinned_image','free_disk_bytes','exclusive_job_prepared','projected_memory_admission_valid')}))
else:print(json.dumps(record))
raise SystemExit(run.returncode)
