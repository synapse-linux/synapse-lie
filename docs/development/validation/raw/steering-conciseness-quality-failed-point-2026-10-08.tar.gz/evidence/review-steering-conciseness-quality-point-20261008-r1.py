# SPDX-License-Identifier: MIT
"""Offline independent review of all collected original responses; never infer."""
from pathlib import Path
from types import SimpleNamespace
import datetime
import hashlib
import importlib.util
import json

root = Path.cwd()
base = root/'evidence/steering-conciseness-quality-point-20261008-r1'
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

collector = module('response_collector', root/'tools/strix-point-steering-quality-collect.py')
expected = 'bb7c4fb8f2ff95607982757044bbbe8d2120cbc95d4c4588bcfbf02346eb0f19'
before = collector.inventory(base, expected)
collection = collector.strict((base/'collection.json').read_bytes())
assert collection['exit_code'] == 0 and collection['all_local_content_reverified'] is True
assert collector.contents(before['files']) == collector.contents(collection['inventory']['files'])
manifest = collector.strict((base/'manifest.json').read_bytes())
job = collector.strict((base/'result.json').read_bytes())
profile = module('admitted_quality_profile', base/'strix-point-steering-quality-profile.py')
supervisor = profile.module('admitted_quality_supervision', base/'strix-point-steering-quality-run.py')
quality = supervisor.quality
config = quality.settings(quality.strict(profile.regular(base/'steering-quality-settings.json', 2**20)[0]))
data = quality.corpus(quality.strict(profile.regular(base/'corpus.json', 2**20)[0]))
bank, bank_content = profile.regular(base/'direction.ffn.f32', 16*2**20)
corpus_content = before['files']['corpus.json']
receipt = quality.strict(profile.regular(base/'steering-training-receipt.json', 2**20)[0])
provenance = profile.bank_source(receipt, config, data, corpus_content, bank_content,
                                 bank, manifest, quality)
assert config == manifest['steering_quality']
prepared = {'supervisor': supervisor, 'quality': quality, 'settings': config,
            'corpus': data, 'load_timeout': manifest['steering_quality_load_timeout_seconds'],
            'deadline': supervisor.container_timeout(config, manifest['steering_quality_load_timeout_seconds']),
            'identities': collection['inventory']['files']}
proof = profile.review(base, prepared, job['child_exit_code'])
assert proof == job['steering_quality_result']
assert proof == quality.strict((base/'steering-quality-review.json').read_bytes())
after = collector.inventory(base, expected)
assert before == after
record = {'state': 'COMPLETE_ORIGINAL_RESPONSE_WIRE_INDEPENDENTLY_VERIFIED',
          'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'manifest_sha256': expected, 'actual_exit_code': 0,
          'actual_supervisor_exit_code': job['exit_code'],
          'actual_container_exit_code': job['child_exit_code'],
          'independent_review': proof, 'bank_source': provenance,
          'all_collected_content_reverified': True,
          'quality_accepted': proof['state'] == 'PASSED',
          'quality_failure_is_retained_without_relabeled_acceptance': True,
          'GPU_or_model_inference_executed': False,
          'strong_closure_and_release_notifications_required': True}
with (root/'evidence/steering-conciseness-quality-point-20261008-r1-review-r1.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: record[key] for key in ('state', 'actual_exit_code',
      'actual_supervisor_exit_code', 'actual_container_exit_code', 'quality_accepted')}))
print(json.dumps({key: proof[key] for key in ('state', 'samples', 'correct_answers',
      'natural_stops', 'zero_parity_cases', 'conciseness_effect')}))
