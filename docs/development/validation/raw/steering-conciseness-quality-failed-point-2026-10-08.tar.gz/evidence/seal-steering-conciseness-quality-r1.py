# SPDX-License-Identifier: MIT
"""Seal all held-out observations, including failed quality and actual exits."""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import statistics
import subprocess
import tarfile

root = Path.cwd().resolve()
label = 'steering-conciseness-quality-point-20261008-r1'
job = root/'evidence'/label
expected = 'bb7c4fb8f2ff95607982757044bbbe8d2120cbc95d4c4588bcfbf02346eb0f19'

def load(relative):
    return json.loads((root/relative).read_text())

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def digest(stream):
    size, sha = 0, hashlib.sha256()
    while block := stream.read(2**20):
        size += len(block)
        sha.update(block)
    return {'bytes': size, 'sha256': sha.hexdigest()}

collector = module('quality_evidence_reader', root/'tools/strix-point-steering-quality-collect.py')
m = load('evidence/'+label+'/manifest.json')
r = load('evidence/'+label+'/result.json')
controller = load('evidence/'+label+'/controller-result.json')
collection = load('evidence/'+label+'/collection.json')
review = load('evidence/'+label+'-review-r1.json')
closed = load('evidence/'+label+'-closure-r1.json')
peer = load('evidence/'+label+'-peer-coordination-r3.json')
releases = load('evidence/'+label+'-release-notifications-r1.json')
actual_inventory = collector.inventory(job, expected)
assert collector.contents(actual_inventory['files']) == collector.contents(collection['inventory']['files'])
assert collection['exit_code'] == review['actual_exit_code'] == closed['actual_exit_code'] == 0
assert collection['all_local_content_reverified'] is True
assert review['all_collected_content_reverified'] is True
q = review['independent_review']
assert q == r['steering_quality_result'] == load('evidence/'+label+'/steering-quality-review.json')
assert q['state'] in ('PASSED', 'QUALITY_FAILED') and q['samples'] == len(q['scores']) == 70
code = 0 if q['state'] == 'PASSED' else 1
assert r['exit_code'] == r['child_exit_code'] == controller['exit_code'] == code
assert r['state'] == ('PASSED' if code == 0 else 'FAILED')
assert review['actual_supervisor_exit_code'] == review['actual_container_exit_code'] == code
assert review['quality_accepted'] is (code == 0)
assert r['model_attempted'] is True and r['model_stat_unchanged'] is True and r['cleanup_failures'] == []
run = load('evidence/'+label+'/steering-quality-result.json')
assert run['quality_review'] == q and run['state'] == q['state']
assert run['native_exit_codes'] == {'absent': 0, 'bank': 0}
assert run['cleanup_errors'] == [] and run['bank_identity_unchanged'] is True
assert run['bank_before'] == run['bank_after'] == collection['inventory']['files']['direction.ffn.f32']
assert set(run['phases']) == {'absent', 'bank'}
assert all(p['client_exit_code'] == 0 and p['server_exit_code'] in (0, -15) for p in run['phases'].values())
assert datetime.fromisoformat(run['phases']['absent']['retired_at']) <= datetime.fromisoformat(run['phases']['bank']['ready_at'])
assert peer['all_four_specific_current_161_non_use'] is True
assert peer['boot_filesystem_original_lease_declared_to_all_four'] is True
assert set(peer['owners']) == {'Point', 'DGX', 'Q2', 'GLM'}
assert len(releases['notifications']) == 4 and len({p['threadId'] for p in releases['notifications']}) == 4
assert all(p['result'].get('isError') is False for p in releases['notifications'])
c = closed['result']
assert c['state'] == 'WHOLE_CONTAINER_AND_EXACT_GPU_IDENTITIES_CLOSED_NO_STANDING_RESERVATION'
assert len(c['identities']) == 7 and all(p['exact_identity_absent'] for p in c['identities'])
assert c['container_cgroup']['exists'] is False and c['container_cgroup']['empty'] is True
assert len(c['whole_container_process_scans']) == 2
assert all(p['processes_checked'] > 0 and p['owned_cgroup_matches'] == p['unreadable'] == [] for p in c['whole_container_process_scans'])
assert c['original_lease'] == {'device': 66308, 'inode': 105946405, 'free_briefly': True, 'released': True}
assert c['foreign_compute_clients'] == c['guarded_hot'] == c['http_listeners_on_observed_ports'] == []
assert c['service']['ActiveState'] == 'active' and c['model_stats_reverified_unchanged'] is True
assert len(c['models_at_strong_closure']) == 4
assert c['collected_artifacts_reverified'] == collector.contents(collection['inventory']['files'])
source = subprocess.run(['git', 'diff', '--quiet', m['source_commit'], '--',
    'src', 'include', 'adapters', 'cmake', 'CMakeLists.txt', 'tools/native', 'tools/steering-build.c'])
assert source.returncode == 0
assert (job/'runner.py').read_bytes() == (root/'tools/strix-point-campaign.py').read_bytes()
for name in m['steering_quality_helpers']:
    assert (job/name).read_bytes() == (root/'tools'/name).read_bytes()
assert collector.artifact(root/m['qualified_build_receipt'], 16*2**20)[1]['sha256'] == m['qualified_build_receipt_sha256']
training = 'docs/development/validation/steering-conciseness-original100-point-2026-10-08.json'
assert collector.artifact(root/training, 2**20)[1]['sha256'] == m['steering_quality_training_receipt']['sha256']
assert review['bank_source']['training_pairs'] == 100

live_paths = sorted((root/'evidence').glob(label+'-live-[0-9]*.json'),
                    key=lambda p: int(p.stem.rsplit('-', 1)[1]))
live = [json.loads(p.read_text())['result'] for p in live_paths]
assert live and any(p['live_exact_supervisor'] and p['lease_fds'] == [3] and p['native_GPU_owners'] for p in live)
assert live[-1]['state'] == r['state'] and live[-1]['live_exact_supervisor'] is False
rows = [json.loads(line) for line in (job/'telemetry.jsonl').read_text().splitlines()]
names = ('k10temp', 'amdgpu', 'nvme')
peaks = {name: max(t['value_c'] for row in rows for t in row['temperatures'] if t['name'] == name) for name in names}
live_peaks = {name: max(t['value_c'] for row in live for t in row['observation']['temperatures'] if t['name'] == name) for name in names}
assert all(t['value_c'] < t['limit_c'] for row in rows for t in row['temperatures'] if t['guarded'])
assert all(t['value_c'] < t['limit_c'] for row in live for t in row['observation']['temperatures'] if t['guarded'])
owned_gpu = {(p['pid'], p['start_ticks']) for row in rows for p in row['kfd'] if r['container'] in p.get('cgroup', '')}
assert owned_gpu == {(p['server_identity']['pid'], p['server_identity']['start_ticks']) for p in run['phases'].values()}
wire = {phase: [json.loads(line) for line in (job/'steering-quality'/phase/'measurements.jsonl').read_text().splitlines()][1:-1]
        for phase in ('absent', 'bank')}
scales = [('absent', None), ('minus1', -1), ('minus05', -.5), ('zero', 0), ('plus05', .5), ('plus1', 1), ('plus2', 2)]
quality = module('frozen_response_oracle', job/'strix-point-steering-quality-gate.py')
assert scales[1:] == list(quality.SCALES)
descriptive = []
for name, scale in scales:
    selected = [v for k, v in q['scores'].items() if k.startswith(name+'-held-')]
    samples = [row for phase in wire.values() for row in phase if row['case'].startswith(name+'-held-')]
    assert len(selected) == len(samples) == 10
    words = [v['explanation_words'] for v in selected if v['correct']]
    descriptive.append({'label': name, 'ffn_scale': scale, 'attention_scale': 0 if scale is not None else None,
        'samples': 10, 'correct_answers': sum(v['correct'] for v in selected),
        'natural_stops': sum(v['natural_stop'] for v in selected),
        'median_explanation_words_among_correct': statistics.median(words) if words else None,
        'median_prompt_tokens': statistics.median(row['prompt_tokens'] for row in samples),
        'median_output_tokens': statistics.median(row['output_tokens'] for row in samples),
        'median_prefill_ms': statistics.median(row['server_timings']['prefill_ms'] for row in samples),
        'median_decode_ms': statistics.median(row['server_timings']['decode_ms'] for row in samples)})

members = {'evidence/'+label+'/'+name for name in collection['inventory']['files']}
members.update('evidence/'+label+'/'+name for name in (
    'plan.json', 'controller-result.json', 'controller-stdout.log', 'controller-stderr.log', 'collection.json'))
members.update(str(p.relative_to(root)) for p in (root/'evidence').glob(label+'-*.json'))
members.update(str(p.relative_to(root)) for pattern in ('launch-'+label+'*.py', 'before-'+label+'*.py')
    for p in (root/'evidence').glob(pattern))
members.update('evidence/'+name for name in (
    'observe-'+label+'.py', 'review-'+label+'.py', 'close-'+label+'-r1.py',
    'prepare-steering-conciseness-quality-r1.py', 'prepare-steering-conciseness-quality-operations-r1.py',
    'seal-steering-conciseness-quality-r1.py', 'steering-conciseness-quality-prepared-r1.json'))
members.update(('tools/strix-point-steering-quality-collect.py', 'tools/strix-point-steering-build-collect.py',
    'tools/strix-point-steering-quality-profile.py', 'tools/strix-point-steering-quality-run.py',
    'tools/strix-point-steering-quality-gate.py', 'tools/strix-point-campaign.py',
    'tests/test_strix_point_steering_quality_collection.py',
    'docs/development/protocols/STEERING-QUALITY-GPU-PROTOCOL.md', training, m['qualified_build_receipt'], 'LICENSE'))
identities = {name: {key: value[key] for key in ('bytes', 'sha256')}
              for name in sorted(members) for value in [collector.artifact(root/name, 80*2**20)[1]]}
total = sum(p['bytes'] for p in identities.values())
assert total < 256*2**20
archive = root/'docs/development/validation/raw/steering-conciseness-quality-point-2026-10-08.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', compresslevel=6, mtime=0) as compressed, \
        tarfile.open(fileobj=compressed, mode='w') as tar:
    for name, identity in identities.items():
        path = root/name
        info = tar.gettarinfo(str(path), arcname=name)
        assert info.isfile() and info.size == identity['bytes']
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        info.mtime = 0
        with path.open('rb') as stream:
            tar.addfile(info, stream)
raw_identity = {key: value for key, value in collector.artifact(archive, 80*2**20)[1].items() if key in ('bytes', 'sha256')}
seen = set()
with tarfile.open(archive, mode='r|gz') as tar:
    for member in tar:
        assert member.isfile() and member.name not in seen and member.name in identities
        seen.add(member.name)
        assert digest(tar.extractfile(member)) == identities[member.name]
        found = collector.artifact(root/member.name, 80*2**20)[1]
        assert all(found[key] == identities[member.name][key] for key in ('bytes', 'sha256'))
assert seen == set(identities)
receipt = {
    'schema': 'synapse-lie.original-steering-response-qualification.v1',
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'state': 'COMPLETE_ORIGINAL_RESPONSES_VERIFIED_COLLECTED_STRONGLY_CLOSED_'+q['state'],
    'quality_accepted': q['state'] == 'PASSED',
    'target': 'pop@192.168.5.161', 'platform': 'strix-point', 'job_label': label,
    'manifest_sha256': expected, 'runtime_source_commit': m['source_commit'],
    'coordinator_commit': m['runner_commit'], 'coordinator_sha256': m['runner_sha256'],
    'runtime_build_id': m['runtime_build_id'], 'upstream_source_pin': m['runtime_source_pin'],
    'bundle_manifest_sha256': m['bundle_manifest_sha256'], 'native_artifacts': m['artifacts'],
    'source_model': m['model_plan'], 'settings': m['steering_quality'],
    'training_receipt': training, 'training_receipt_sha256': m['steering_quality_training_receipt']['sha256'],
    'training_provenance': review['bank_source'],
    'actual_exits': {'controller': controller['exit_code'], 'supervisor': r['exit_code'],
        'container': r['child_exit_code'], 'native_absent_client': run['native_exit_codes']['absent'],
        'native_bank_client': run['native_exit_codes']['bank'],
        'absent_server_retirement': run['phases']['absent']['server_exit_code'],
        'bank_server_retirement': run['phases']['bank']['server_exit_code'],
        'collector': collection['exit_code'], 'independent_review': review['actual_exit_code'],
        'strong_closure': closed['actual_exit_code']},
    'supervisor_error': r.get('error'), 'quality': q, 'per_scale_observations': descriptive,
    'length_metric': 'Regex word count of parsed explanation, among correct answers only; failed content is retained in all seventy scores.',
    'duration_scope': 'Observed C1 natural-output request durations, not a matched fixed-output performance benchmark or general quality score.',
    'serial_phases': run['phases'], 'unchanged_bank': True, 'closure': c,
    'thermal': {'policy': m['thermal_policy'], 'native_phase_samples': len(rows), 'native_phase_peaks_c': peaks,
        'additional_saved_live_observations': len(live), 'additional_live_peaks_c': live_peaks,
        'maximum_observed_native_child_and_live_c': {name: max(peaks[name], live_peaks[name]) for name in names},
        'GPU_temperature_is_observation_only': True, 'all_observed_guarded_temperatures_within_limits': True,
        'continuous_sampling_scope': 'Owned container phase only; saved additional witnesses cover discrete post-native observations.'},
    'resources': {'max_observed_gtt_bytes': max(row['gpu']['mem_info_gtt_used'] for row in rows),
        'min_observed_available_ram_bytes': min(row['memory']['MemAvailable'] for row in rows),
        'observed_native_GPU_owner_OS_thread_counts': sorted({int(p['status']['Threads']) for row in rows for p in row['kfd']
            if r['container'] in p.get('cgroup', '') and 'Threads' in p.get('status', {})}),
        'worker_count_or_speedup_proof': False},
    'ownership': {'all_four_specific_current_non_use': True,
        'fresh_global_at_utc': load('evidence/'+label+'-fresh-r4.json')['result']['at_utc'],
        'boot_id': c['boot_id'], 'filesystem_uuid': c['filesystem_uuid'], 'original_lease': c['original_lease'],
        'actual_release_at_utc': r['lease_released_at'], 'strong_closure_at_utc': c['at_utc'],
        'all_four_verified_release_notifications': True, 'current_root_own_all_hosts': 'NONE',
        'standing_reservation_or_future_grant': False},
    'qualification_limits': ['One frozen arithmetic held-out corpus on one model/platform, seed and greedy AR profile only.',
        'No general reasoning or semantic explanation quality, MTP, vision, graph/correction/fault or other model/platform acceptance.',
        'No pure-inference reactive speedup, matched performance cost or long-context acceptance claim.'],
    'roadmap': {'open_items': [2, 3, 4, 5, 6, 7], 'terminal_bench_last': True, 'full_goal_complete': False},
    'raw': {'path': str(archive.relative_to(root)), **raw_identity, 'format': 'gzip tar of complete bounded original response evidence',
        'regular_members': len(identities), 'uncompressed_bytes': total, 'members': identities,
        'all_archived_and_current_members_verified': True,
        'original_training_capture_not_duplicated': True},
    'GPU_repeat_or_heavyweight_model_hash_conversion_tuning_install_or_publication': False}
dest = root/'docs/development/validation/steering-conciseness-quality-point-2026-10-08.json'
with dest.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({'receipt': str(dest.relative_to(root)), 'state': receipt['state'], 'quality_accepted': receipt['quality_accepted'],
    'correct_answers': q['correct_answers'], 'zero_parity_cases': q['zero_parity_cases'], 'conciseness_effect': q['conciseness_effect'],
    'per_scale_observations': descriptive, 'actual_exits': receipt['actual_exits'],
    'raw_bytes': raw_identity['bytes'], 'raw_members': len(identities), 'thermal': receipt['thermal']}))
