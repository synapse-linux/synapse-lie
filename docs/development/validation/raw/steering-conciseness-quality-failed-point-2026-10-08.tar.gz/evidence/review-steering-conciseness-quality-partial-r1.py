# SPDX-License-Identifier: MIT
"""Reconstruct available failed-cohort wire; never complete or accept missing cases."""
from pathlib import Path
import datetime
import importlib.util
import json

root = Path.cwd().resolve()
label = 'steering-conciseness-quality-point-20261008-r1'
base = root/'evidence'/label

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

collector = module('partial_collector', root/'tools/strix-point-steering-quality-collect.py')
profile = module('original_profile', base/'strix-point-steering-quality-profile.py')
supervisor = profile.module('original_supervision', base/'strix-point-steering-quality-run.py')
quality = supervisor.quality
manifest = json.loads((base/'manifest.json').read_text())
before = collector.inventory(base, 'bb7c4fb8f2ff95607982757044bbbe8d2120cbc95d4c4588bcfbf02346eb0f19')
collection = json.loads((base/'collection.json').read_text())
assert collection['exit_code'] == 0 and collection['all_local_content_reverified'] is True
assert collector.contents(before['files']) == collector.contents(collection['inventory']['files'])
config = quality.settings(json.loads((base/'steering-quality-settings.json').read_text()))
data = quality.corpus(json.loads((base/'corpus.json').read_text()))
training = json.loads((base/'steering-training-receipt.json').read_text())
bank, bank_identity = profile.regular(base/'direction.ffn.f32', 16*2**20)
provenance = profile.bank_source(training, config, data, before['files']['corpus.json'], bank_identity, bank, manifest, quality)
job = json.loads((base/'result.json').read_text())
run = json.loads((base/'steering-quality-result.json').read_text())
assert job['state'] == run['state'] == 'FAILED'
assert job['exit_code'] == job['child_exit_code'] == 1
assert run['native_exit_codes'] == {'absent': 0, 'bank': 1}
assert run['cleanup_errors'] == job['cleanup_failures'] == []
assert job['model_stat_unchanged'] is True and run['bank_identity_unchanged'] is True
assert run['bank_before'] == run['bank_after'] == collection['inventory']['files']['direction.ffn.f32']
snapshots = json.loads((base/'steering-quality/snapshots.json').read_text())
scores, ids, missing = {}, set(), []
actual_terminal, rows = {}, {}
for phase in ('absent', 'bank'):
    wanted = quality.requests(data, config, phase)
    actual = [json.loads(line) for line in (base/'steering-quality'/phase/'requests.jsonl').read_text().splitlines()]
    assert actual == wanted
    observed = [json.loads(line) for line in (base/'steering-quality'/phase/'measurements.jsonl').read_text().splitlines()]
    rows[phase] = observed[1:-1]
    assert observed[0]['event'] == 'identity' and observed[0]['model'] == config['model_id']
    actual_terminal[phase] = observed[-1]
    assert all(v['event'] == 'sample' for v in rows[phase])
    assert len(rows[phase]) <= len(wanted)
    for case, row in zip(wanted, rows[phase]):
        assert row['case'] == case['id'] and row['turn'] == row['rep'] == 0 and row['warmup'] is False
        assert row['request'] == {'model': config['model_id'], **case['body'], 'stream': True, 'stream_options': {'include_usage': True}}
        identifier, content = quality.wire(row, config)
        assert identifier not in ids
        ids.add(identifier)
        held = next(h for h in data['held_out'] if case['id'].endswith('-'+h['id']))
        try:
            answer = quality.strict(content)
        except (ValueError, RuntimeError):
            answer = None
        correct = (type(answer) is dict and set(answer) == {'answer', 'explanation'} and
                   type(answer['answer']) is str and answer['answer'] == held['answer'] and
                   type(answer['explanation']) is str and bool(quality.WORDS.findall(answer['explanation'])) and '\0' not in answer['explanation'])
        scores[case['id']] = {'correct': correct, 'natural_stop': row['finish_reason'] == 'stop',
            'explanation_words': len(quality.WORDS.findall(answer['explanation'])) if correct else None,
            'content': content, 'prompt_tokens': row['prompt_tokens'], 'output_tokens': row['output_tokens']}
        if phase == 'absent':
            quality.snapshot(snapshots[case['id']], identifier, None)
    missing.extend(case['id'] for case in wanted[len(rows[phase]):])
assert actual_terminal['absent'] == {'event': 'complete', 'exit_code': 0}
assert actual_terminal['bank'] == {'event': 'failed', 'exit_code': 1, 'error': 'HTTP request failed: status 429, No error'}
assert len(rows['absent']) == 10 and len(rows['bank']) == 58 and len(scores) == 68
assert missing == ['plus2-held-08', 'plus2-held-09']
assert set(snapshots) == {case['id'] for case in quality.requests(data, config, 'absent')}
parity = sum(all(scores['absent-'+h['id']][k] == scores['zero-'+h['id']][k]
    for k in ('content', 'prompt_tokens', 'output_tokens', 'natural_stop')) for h in data['held_out'])
assert before == collector.inventory(base, before['files']['manifest.json']['sha256'])
record = {'state': 'PARTIAL_ORIGINAL_RESPONSES_INDEPENDENTLY_RECONSTRUCTED_INFRASTRUCTURE_FAILURE',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'actual_exit_code': 0,
    'actual_supervisor_exit_code': 1, 'actual_container_exit_code': 1,
    'actual_native_exit_codes': run['native_exit_codes'], 'bank_source': provenance,
    'all_collected_content_reverified': True, 'observed_complete_SSE_samples': 68,
    'expected_samples': 70, 'correct_answers_in_observed_samples': sum(v['correct'] for v in scores.values()),
    'natural_stops_in_observed_samples': sum(v['natural_stop'] for v in scores.values()),
    'observed_absent_zero_wire_parity_cases': parity, 'missing_cases': missing,
    'retained_stored_snapshots': len(snapshots), 'bank_applied_policy_snapshots_available': False,
    'native_terminal_events': actual_terminal, 'scores': scores,
    'conciseness_effect': {'evaluated': False, 'passed': False}, 'quality_accepted': False,
    'failure_qualified_as_complete_quality_result': False,
    'GPU_or_model_inference_executed': False,
    'scope': 'Independently checked partial wire, declared requests and ten absent-policy snapshots only; bank application and the full matrix remain unqualified.'}
with (root/'evidence'/(label+'-partial-review-r1.json')).open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('scores','bank_source')}))
