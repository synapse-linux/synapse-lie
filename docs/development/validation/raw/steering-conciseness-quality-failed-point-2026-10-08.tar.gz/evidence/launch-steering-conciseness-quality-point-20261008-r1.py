# SPDX-License-Identifier: MIT
"""Launch exactly one fresh coordinated original70-response held-out steering campaign."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

root = Path.cwd()
label = 'steering-conciseness-quality-point-20261008-r1'
out = root/'evidence'/label
manifest = json.loads((out/'manifest.json').read_text())
expected_manifest = 'bb7c4fb8f2ff95607982757044bbbe8d2120cbc95d4c4588bcfbf02346eb0f19'
assert hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest() == expected_manifest
fresh = json.loads((root/'evidence'/(label+'-fresh-r4.json')).read_text())
peers = json.loads((root/'evidence'/(label+'-peer-coordination-r3.json')).read_text())
stage = json.loads((root/'evidence'/(label+'-stage-r1.json')).read_text())
assert stage['actual_exit_code'] == fresh['actual_exit_code'] == 0
assert peers['manifest_sha256'] == expected_manifest and peers['all_four_specific_current_161_non_use'] is True
assert peers['boot_filesystem_original_lease_declared_to_all_four'] is True
assert set(peers['owners']) == {'Point', 'DGX', 'Q2', 'GLM'}
assert all(value['specific_non_use_and_no_intent'] is True for value in peers['owners'].values())
r = fresh['result']
age = (datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(r['at_utc'])).total_seconds()
assert 0 <= age <= 180, 'Fresh global observation expired; no stale admission or restart'
assert r['original_lease']['free_briefly'] and r['original_lease']['released']
assert (r['original_lease']['device'], r['original_lease']['inode']) == (66308, 105946405)
assert r['boot_id'] == manifest['verified_boot_id']
assert r['filesystem_uuid'] == manifest['staging_filesystem_rebind']['filesystem_uuid']
assert not r['foreign_compute_clients'] and not r['guarded_hot'] and not r['http8000_listeners']
assert r['exclusive_job_prepared'] and r['projected_memory_admission_valid']
assert r['pinned_image']['exit_code'] == 0 and r['pinned_image']['id'] == manifest['image']
assert hashlib.sha256((out/'runner.py').read_bytes()).hexdigest() == manifest['runner_sha256']
assert set(r['source_hashes']) == {'strix-point-steering-quality-profile.py', 'steering-quality-settings.json', 'runner.py', 'strix-point-steering-quality-gate.py', 'steering-training-receipt.json', 'direction.ffn.f32', 'strix-point-steering-build-gate.py', 'corpus.json', 'strix-point-http-recall-gate.py', 'strix-point-steering-quality-run.py', 'manifest.json'}
for name, expected in r['source_hashes'].items():
    assert hashlib.sha256((out/name).read_bytes()).hexdigest() == expected
remote = '/home/pop/workspace/synapse-lie/'+label
argv = ['ssh', '-F', '/dev/null', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8',
        'pop@192.168.5.161', 'python3', '-B', remote+'/runner.py', remote]
plan = {'argv': argv, 'remote_root': remote, 'source_commit': manifest['source_commit'],
        'runner_sha256': manifest['runner_sha256'], 'manifest_sha256': expected_manifest,
        'fresh_preflight': 'evidence/'+label+'-fresh-r4.json',
        'peer_coordinated_enclosing_window_through_collection_oracle_and_strong_closure': True,
        'standing_future_window': False}
with (out/'plan.json').open('x') as stream:
    json.dump(plan, stream, indent=2)
    stream.write('\n')
with (out/'controller-stdout.log').open('x') as stdout, (out/'controller-stderr.log').open('x') as stderr:
    run = subprocess.run(argv, stdout=stdout, stderr=stderr)
with (out/'controller-result.json').open('x') as stream:
    json.dump({**plan, 'exit_code': run.returncode}, stream, indent=2)
    stream.write('\n')
try:
    result = json.loads((out/'controller-stdout.log').read_text())
    with (out/'result.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: result.get(key) for key in ('state', 'error', 'exit_code', 'child_exit_code',
                      'pid', 'start_ticks', 'container', 'lease', 'lease_released_at', 'model_attempted',
                      'cleanup_failures')}))
except (OSError, ValueError):
    print(json.dumps({'actual_exit_code': run.returncode, 'error': 'Preserved controller logs; remote completion unconfirmed'}))
raise SystemExit(run.returncode)
