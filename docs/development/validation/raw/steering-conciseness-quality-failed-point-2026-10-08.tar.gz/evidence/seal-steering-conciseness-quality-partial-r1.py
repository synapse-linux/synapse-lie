# SPDX-License-Identifier: MIT
"""Seal the actual incomplete failed job and all bounded original wire."""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import statistics
import subprocess
import tarfile

root = Path.cwd().resolve()
label = 'steering-conciseness-quality-point-20261008-r1'
job = root/'evidence'/label
spec = importlib.util.spec_from_file_location('partial_transfer', root/'tools/strix-point-steering-quality-collect.py')
collector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)

def load(relative):
    return json.loads((root/relative).read_text())

def identity(path, maximum=80*2**20):
    return {k:v for k,v in collector.artifact(path, maximum)[1].items() if k in ('bytes', 'sha256')}

def digest(stream):
    sha, size = hashlib.sha256(), 0
    while block := stream.read(2**20):
        sha.update(block)
        size += len(block)
    return {'bytes': size, 'sha256': sha.hexdigest()}

m = load('evidence/'+label+'/manifest.json')
r = load('evidence/'+label+'/result.json')
control = load('evidence/'+label+'/controller-result.json')
collected = load('evidence/'+label+'/collection.json')
review = load('evidence/'+label+'-partial-review-r1.json')
closed = load('evidence/'+label+'-closure-r1.json')
peers = load('evidence/'+label+'-peer-coordination-r3.json')
release = load('evidence/'+label+'-release-notifications-r1.json')
run = load('evidence/'+label+'/steering-quality-result.json')
assert r['exit_code'] == r['child_exit_code'] == control['exit_code'] == 1
assert r['state'] == 'FAILED' and r['model_attempted'] and r['model_stat_unchanged'] and r['cleanup_failures'] == []
assert collected['exit_code'] == review['actual_exit_code'] == closed['actual_exit_code'] == 0
assert review['state'] == 'PARTIAL_ORIGINAL_RESPONSES_INDEPENDENTLY_RECONSTRUCTED_INFRASTRUCTURE_FAILURE'
assert review['observed_complete_SSE_samples'] == 68 and review['expected_samples'] == 70
assert review['quality_accepted'] is False and review['bank_applied_policy_snapshots_available'] is False
assert run['native_exit_codes'] == {'absent': 0, 'bank': 1} and run['cleanup_errors'] == []
assert run['bank_before'] == run['bank_after'] == collected['inventory']['files']['direction.ffn.f32']
found = collector.inventory(job, 'bb7c4fb8f2ff95607982757044bbbe8d2120cbc95d4c4588bcfbf02346eb0f19')
assert collector.contents(found['files']) == collector.contents(collected['inventory']['files'])
c = closed['result']
assert c['state'] == 'WHOLE_CONTAINER_AND_EXACT_GPU_IDENTITIES_CLOSED_NO_STANDING_RESERVATION'
assert len(c['identities']) == 7 and all(v['exact_identity_absent'] for v in c['identities'])
assert c['container_cgroup']['exists'] is False and c['container_cgroup']['empty'] is True
assert c['collected_artifacts_reverified'] == collector.contents(found['files'])
assert len(c['whole_container_process_scans']) == 2
assert all(v['owned_cgroup_matches'] == v['unreadable'] == [] for v in c['whole_container_process_scans'])
assert c['original_lease'] == {'device': 66308, 'inode': 105946405, 'free_briefly': True, 'released': True}
assert c['foreign_compute_clients'] == c['guarded_hot'] == c['http_listeners_on_observed_ports'] == []
assert c['service']['ActiveState'] == 'active' and c['model_stats_reverified_unchanged']
assert peers['all_four_specific_current_161_non_use'] and peers['boot_filesystem_original_lease_declared_to_all_four']
assert len(release['notifications']) == 4 and len({n['threadId'] for n in release['notifications']}) == 4
assert all(n['result'].get('isError') is False for n in release['notifications'])
native = subprocess.run(['git', 'diff', '--quiet', m['source_commit'], '--',
    'src', 'include', 'adapters', 'cmake', 'CMakeLists.txt', 'tools/native', 'tools/steering-build.c'])
assert native.returncode == 0
telemetry = [json.loads(line) for line in (job/'telemetry.jsonl').read_text().splitlines()]
peaks = {name: max(t['value_c'] for row in telemetry for t in row['temperatures'] if t['name'] == name)
         for name in ('k10temp', 'amdgpu', 'nvme')}
assert all(t['value_c'] < t['limit_c'] for row in telemetry for t in row['temperatures'] if t['guarded'])
descriptive = []
for name, scale in [('absent', None), ('minus1', -1), ('minus05', -.5), ('zero', 0), ('plus05', .5), ('plus1', 1), ('plus2', 2)]:
    scores = [v for k,v in review['scores'].items() if k.startswith(name+'-held-')]
    words = [v['explanation_words'] for v in scores if v['correct']]
    descriptive.append({'label': name, 'ffn_scale_declared': scale, 'samples': len(scores), 'expected_samples': 10,
        'correct_answers': sum(v['correct'] for v in scores), 'natural_stops': sum(v['natural_stop'] for v in scores),
        'median_explanation_words_among_correct': statistics.median(words) if words else None})
members = {'evidence/'+label+'/'+name for name in found['files']}
members.update('evidence/'+label+'/'+name for name in ('plan.json', 'controller-result.json',
    'controller-stdout.log', 'controller-stderr.log', 'collection.json'))
members.update(str(p.relative_to(root)) for p in (root/'evidence').glob(label+'-*.json'))
members.update(str(p.relative_to(root)) for pattern in ('launch-'+label+'*.py', 'before-'+label+'*.py')
    for p in (root/'evidence').glob(pattern))
members.update('evidence/'+name for name in ('observe-'+label+'.py', 'close-'+label+'-r1.py',
    'review-steering-conciseness-quality-partial-r1.py', 'seal-steering-conciseness-quality-partial-r1.py',
    'review-'+label+'.py', 'seal-steering-conciseness-quality-r1.py',
    'prepare-steering-conciseness-quality-r1.py', 'prepare-steering-conciseness-quality-operations-r1.py',
    'steering-conciseness-quality-prepared-r1.json'))
members.update(('tools/strix-point-steering-quality-collect.py', 'tools/strix-point-steering-build-collect.py',
    'docs/development/protocols/STEERING-QUALITY-GPU-PROTOCOL.md',
    'docs/development/validation/steering-conciseness-original100-point-2026-10-08.json', m['qualified_build_receipt'], 'LICENSE'))
identities = {name: identity(root/name) for name in sorted(members)}
assert sum(v['bytes'] for v in identities.values()) < 256*2**20
archive = root/'docs/development/validation/raw/steering-conciseness-quality-failed-point-2026-10-08.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', compresslevel=6, mtime=0) as compressed, \
        tarfile.open(fileobj=compressed, mode='w') as tar:
    for name in sorted(members):
        info = tar.gettarinfo(str(root/name), arcname=name)
        assert info.isfile() and info.size == identities[name]['bytes']
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        info.mtime = 0
        with (root/name).open('rb') as stream:
            tar.addfile(info, stream)
raw_identity = identity(archive)
seen = set()
with tarfile.open(archive, mode='r|gz') as tar:
    for member in tar:
        assert member.isfile() and member.name not in seen and member.name in identities
        seen.add(member.name)
        assert digest(tar.extractfile(member)) == identities[member.name] == identity(root/member.name)
assert seen == set(identities)
receipt = {'schema': 'synapse-lie.original-steering-response-failure.v1',
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'state': 'PARTIAL_ORIGINAL_STEERING_RESPONSES_FAILED_COLLECTED_STRONGLY_CLOSED',
    'job_label': label, 'target': 'pop@192.168.5.161', 'platform': 'strix-point',
    'runtime_source_commit': m['source_commit'], 'manifest_sha256': found['files']['manifest.json']['sha256'],
    'coordinator_sha256': m['runner_sha256'], 'native_artifacts': m['artifacts'], 'source_model': m['model_plan'],
    'settings': m['steering_quality'], 'actual_exits': {'controller': control['exit_code'], 'supervisor': r['exit_code'],
        'container': r['child_exit_code'], 'native_absent_client': 0, 'native_bank_client': 1,
        'absent_server_retirement': run['phases']['absent']['server_exit_code'],
        'bank_server_retirement': run['phases']['bank']['server_exit_code'], 'collector': collected['exit_code'],
        'partial_independent_review': review['actual_exit_code'], 'strong_closure': closed['actual_exit_code']},
    'failure': review['native_terminal_events']['bank'], 'partial_quality': review, 'per_scale_observations': descriptive,
    'quality_accepted': False, 'complete_quality_result': False, 'unchanged_bank': True,
    'closure': c, 'ownership': {'all_four_specific_current_non_use': True,
        'all_four_verified_release_notifications': True, 'original_lease': c['original_lease'],
        'actual_release_at_utc': r['lease_released_at'], 'strong_closure_at_utc': c['at_utc'],
        'current_root_own_all_hosts': 'NONE', 'standing_reservation_or_future_grant': False},
    'thermal': {'policy': m['thermal_policy'], 'native_phase_samples': len(telemetry), 'peaks_c': peaks,
        'CPU_guard_c': 98, 'NVMe_guard_c': 85, 'GPU_temperature_is_observation_only': True},
    'resources': {'max_observed_gtt_bytes': max(row['gpu']['mem_info_gtt_used'] for row in telemetry),
        'min_observed_available_ram_bytes': min(row['memory']['MemAvailable'] for row in telemetry)},
    'qualification_limits': ['68/70 partial wire only; missing two cases and all sixty bank applied-policy snapshots.',
        'Only six of ten baseline arithmetic answers correct; twenty negative-scale outputs reach the token limit.',
        'HTTP429 body unavailable on original run; response-store-budget explanation is an inference until separately checked.',
        'No accepted steering quality, complete effect, general quality, comparative performance or reactive speedup.'],
    'raw': {'path': str(archive.relative_to(root)), **raw_identity, 'regular_members': len(identities),
        'members': identities, 'uncompressed_bytes': sum(v['bytes'] for v in identities.values()),
        'all_archived_and_current_members_verified': True, 'original_training_capture_not_duplicated': True},
    'roadmap': {'open_items': [2, 3, 4, 5, 6, 7], 'terminal_bench_last': True, 'full_goal_complete': False},
    'GPU_repeat_or_model_hash_conversion_tuning_install_or_publication': False}
dest = root/'docs/development/validation/steering-conciseness-quality-failed-point-2026-10-08.json'
with dest.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({'receipt': str(dest.relative_to(root)), 'state': receipt['state'],
    'samples': 68, 'quality_accepted': False, 'raw_bytes': raw_identity['bytes'], 'raw_members': len(identities),
    'actual_exits': receipt['actual_exits'], 'per_scale_observations': descriptive, 'thermal': receipt['thermal']}))
