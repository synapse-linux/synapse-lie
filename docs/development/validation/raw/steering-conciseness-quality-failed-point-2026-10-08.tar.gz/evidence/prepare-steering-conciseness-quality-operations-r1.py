# SPDX-License-Identifier: MIT
"""Prepare private response staging/admission/observation recipes only."""
from pathlib import Path
import ast
import hashlib
import json

root = Path.cwd()
parent = 'steering-conciseness-train100-point-20261008-r2'
label = 'steering-conciseness-quality-point-20261008-r1'
prepared = json.loads((root/'evidence/steering-conciseness-quality-prepared-r1.json').read_text())
assert prepared['label'] == label and prepared['actual_exit_code'] == 0
names = set(prepared['files'])
assert len(names) == 11
recipes = {}

def save(name, source):
    ast.parse(source)
    path = root/'evidence'/name
    with path.open('x') as stream:
        stream.write(source)
    recipes[name] = {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(source.encode()).hexdigest()}

stage = (root/'evidence'/('stage-'+parent+'.py')).read_text()
stage = stage.replace(parent, label)
stage = stage.replace('steering-conciseness-train100-prepared-r2.json', 'steering-conciseness-quality-prepared-r1.json')
old = "{'manifest.json','runner.py','steering-build-gate.py','target-prompts.txt','contrast-prompts.txt','corpus.json'}"
assert stage.count(old) == 1
stage = stage.replace(old, repr(names))
save('stage-'+label+'.py', stage)

fresh = (root/'evidence'/('before-'+parent+'-fresh-r1.py')).read_text()
fresh = fresh.replace(parent, label)
fresh = fresh.replace('3886b4da09bd8e4ed27f0be628554a90d6467ef4b9096d3e7f6b0967d1da2625', prepared['manifest_sha256'])
start = fresh.index('expected = {name:')
end = fresh.index('\nassert expected', start)
fresh = fresh[:start]+"expected = "+repr({name: value['sha256'] for name, value in prepared['files'].items()})+fresh[end:]
fresh = fresh.replace("not (root/'steering-build').exists() and not (root/'steering-build-review.json').exists()",
    "not (root/'steering-quality').exists() and not (root/'steering-quality-review.json').exists()")
save('before-'+label+'-fresh-r1.py', fresh)

launch = (root/'evidence'/('launch-'+parent+'.py')).read_text()
launch = launch.replace(parent, label)
launch = launch.replace('3886b4da09bd8e4ed27f0be628554a90d6467ef4b9096d3e7f6b0967d1da2625', prepared['manifest_sha256'])
old = "{'manifest.json', 'runner.py', 'steering-build-gate.py',\n                                 'target-prompts.txt', 'contrast-prompts.txt', 'corpus.json'}"
assert launch.count(old) == 1
launch = launch.replace(old, repr(names))
launch = launch.replace('original100-pair training campaign', 'original70-response held-out steering campaign')
save('launch-'+label+'.py', launch)

observe = (root/'evidence'/('observe-'+parent+'.py')).read_text()
observe = observe.replace(parent, label)
observe = observe.replace("('steering-build-review.json',)", "('steering-quality-result.json', 'steering-quality-review.json')")
start = observe.index("wire=root/'steering-build/build.jsonl'")
end = observe.index("log=root/'stdout.log'", start)
observe = observe[:start]+'''phase_counts={}
for phase in ('absent','bank'):
 path=root/'steering-quality'/phase/'measurements.jsonl'
 phase_counts[phase]=0
 if path.exists():
  with path.open() as stream:phase_counts[phase]=sum(1 for line in stream)
wire_rows=sum(phase_counts.values())
'''+observe[end:]
observe = observe.replace("'native_capture_rows':wire_rows", "'wire_rows':wire_rows,'phase_rows':phase_counts")
observe = observe.replace("'native_capture_rows', 'server_log_tail'", "'wire_rows', 'phase_rows', 'server_log_tail'")
observe = observe.replace('original prefill-only training job', 'original held-out response job')
save('observe-'+label+'.py', observe)

record = {'state': 'PRIVATE_ORIGINAL70_RESPONSE_OPERATIONS_PREPARED_NOT_EXECUTED',
    'label': label, 'manifest_sha256': prepared['manifest_sha256'], 'recipes': recipes,
    'historical_helpers_changed': False, 'GPU_remote_or_new_build_operation': False, 'actual_exit_code': 0}
with (root/'evidence/steering-conciseness-quality-operations-prepared-r1.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
