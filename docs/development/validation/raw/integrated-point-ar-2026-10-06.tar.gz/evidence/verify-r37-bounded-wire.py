#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Check already collected original wire values using exact rational bounds."""
from pathlib import Path
from fractions import Fraction
import datetime
import hashlib
import importlib.util
import json
import math
import re
import sys

mode = sys.argv[1]
assert mode in ('ar', 'mtp')
base = Path('evidence/context-r37-integer-' + mode + '-r1')
manifest = json.loads((base / 'manifest.json').read_text())
fixture = Path('tools/strix-point-schema-integer-gate.py')
assert hashlib.sha256(fixture.read_bytes()).hexdigest() == manifest['http_schema_integer_sha256']
spec = importlib.util.spec_from_file_location('frozen_cases_only', fixture)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
# Only frozen case names/inputs are reused; LIE and fixture validators are not.
cases = {json.dumps(bounds, sort_keys=True): name for name, bounds, *_ in module.CASES}
refusals = {json.dumps(bounds, sort_keys=True): name for name, bounds in module.REFUSALS}
outputs = {}
refused = []
wire = base / 'http-wire.jsonl'

def unique_object(pairs):
    assert len({key for key, _ in pairs}) == len(pairs), 'Duplicate JSON key'
    return dict(pairs)

def parsed(text):
    return json.loads(text, object_pairs_hook=unique_object,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))

def exact_bound(value):
    # The public schema's numeric leaf is binary64. Python's integer ratios
    # recover its exact mathematical value independently of either formatter.
    x = float(value)
    assert math.isfinite(x)
    numerator, denominator = x.as_integer_ratio()
    return Fraction(numerator, denominator)

for raw in wire.read_text().splitlines():
    row = parsed(raw)
    request = row.get('request')
    if row.get('method') != 'POST' or not isinstance(request, dict):
        continue
    responses = row['path'] == '/v1/responses'
    if responses:
        fmt = request.get('text', {}).get('format', {})
    elif row['path'] == '/v1/chat/completions':
        fmt = request.get('response_format', {}).get('json_schema', {})
    else:
        continue
    if fmt.get('name') != 'bounded_integer':
        continue
    schema = fmt['schema']['properties']['value']
    assert schema['type'] == 'integer'
    bounds = {key: value for key, value in schema.items() if key != 'type'}
    identity = json.dumps(bounds, sort_keys=True)
    api = 'responses' if responses else 'chat'
    if identity in refusals:
        assert row['status'] == 400 and parsed(row['body'])['error']['message']
        key = api + '_refusal_' + refusals[identity]
        assert key not in refused
        refused.append(key)
        continue
    assert identity in cases and row['status'] == 200
    stream = request['stream']
    assert type(stream) is bool
    if stream:
        events = []
        for frame in row['body'].strip().split('\n\n'):
            data = [line[6:] for line in frame.splitlines() if line.startswith('data: ')]
            assert len(data) == 1
            events.append('[DONE]' if data[0] == '[DONE]' else parsed(data[0]))
        if responses:
            assert events[-1]['type'] == 'response.completed'
            assert [event['sequence_number'] for event in events] == list(range(len(events)))
            body = events[-1]['response']
            text = ''.join(event['delta'] for event in events if event['type'] == 'response.output_text.delta')
            assert text == body['output'][0]['content'][0]['text']
            assert body['status'] == 'completed'
        else:
            assert events[-1] == '[DONE]' and events.count('[DONE]') == 1
            choices = [choice for event in events[:-1] for choice in event['choices']]
            assert all(choice['index'] == 0 for choice in choices)
            assert [choice['finish_reason'] for choice in choices if choice['finish_reason']] == ['stop']
            text = ''.join(choice['delta'].get('content') or '' for choice in choices)
    else:
        body = parsed(row['body'])
        if responses:
            assert body['status'] == 'completed'
            text = body['output'][0]['content'][0]['text']
        else:
            assert len(body['choices']) == 1 and body['choices'][0]['finish_reason'] == 'stop'
            text = body['choices'][0]['message']['content']
    value = parsed(text)
    assert type(value) is dict and set(value) == {'value'} and type(value['value']) is int
    assert re.fullmatch(r'\s*\{\s*"value"\s*:\s*-?(?:0|[1-9][0-9]*)\s*\}\s*', text)
    number = Fraction(value['value'])
    for bound_name, bound in bounds.items():
        exact = exact_bound(bound)
        assert {'minimum': number >= exact, 'maximum': number <= exact,
                'exclusiveMinimum': number > exact, 'exclusiveMaximum': number < exact}[bound_name]
    key = api + '_' + ('sse' if stream else 'json') + '_' + cases[identity]
    assert key not in outputs
    outputs[key] = {'text': text, 'value': value['value'], 'bounds': bounds}
assert len(outputs) == 60 and len(refused) == 6
assert set(outputs) | set(refused) == module.CHECKS
for api in ('chat', 'responses'):
    for name, *_ in module.CASES:
        assert outputs[api + '_json_' + name]['text'] == outputs[api + '_sse_' + name]['text']
result = {'state': 'EXACT_RATIONAL_WIRE_INTERVALS_VERIFIED_NOT_FULL_SAMPLER_ACCEPTANCE',
          'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'mode': mode,
          'valid_integer_outputs': 60, 'HTTP400_refusals': 6, 'JSON_SSE_replay_pairs': 30,
          'wire_sha256': hashlib.sha256(wire.read_bytes()).hexdigest(),
          'independent_math': 'Exact integer ratios of declared binary64 bounds; no LIE formatter or fixture validation called',
          'new_model_or_remote_operation': False}
target = Path('evidence/context-r37-' + mode + '-rational-wire-proof.json')
with target.open('x') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
print(json.dumps(result))
