#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Preserve a completed AR run; no inference, tests, remote access or build."""
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path('evidence/context-r37-integer-ar-r1')
OUT = Path('docs/development/validation/integrated-point-ar-2026-10-06.json')
RAW = Path('docs/development/validation/raw/integrated-point-ar-2026-10-06.tar.gz')
assert not OUT.exists() and not RAW.exists()

def read(path):
    return json.loads(Path(path).read_text())

def bound(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}

job = read(BASE / 'result.json')
controller = read(BASE / 'controller-result.json')
collection = read(BASE / 'collection.json')
http = read(BASE / 'http-result.json')
integer = read(BASE / 'http-schema-integer-result.json')
closure = read('evidence/context-r37-ar-closure-r1.json')
math = read('evidence/context-r37-ar-rational-wire-proof.json')
manifest = read(BASE / 'manifest.json')
build_path = Path('docs/development/validation/integrated-point-hip-build-2026-10-06.json')
host_path = Path('docs/development/validation/integrated-final-host-2026-10-06.json')
build, host = read(build_path), read(host_path)
assert job['state'] == http['state'] == integer['state'] == 'PASSED'
assert job['exit_code'] == job['child_exit_code'] == controller['exit_code'] == 0
assert http['server_exit_code'] == collection['exit_code'] == closure['actual_exit_code'] == 0
assert len(http['passed']) == 37 and len(integer['passed']) == 66
assert job['model_stat_unchanged'] is True and not job['cleanup_failures']
assert manifest['source_commit'] == build['source_commit']
assert manifest['bundle_manifest_sha256'] == build['independent_variant_verification']['bundle_sha256']
assert build['qualified_code_commit'] == host['source_commit']
assert math['valid_integer_outputs'] == 60 and math['HTTP400_refusals'] == 6
assert math['JSON_SSE_replay_pairs'] == 30
assert bound(BASE / 'http-wire.jsonl')['sha256'] == math['wire_sha256']
assert read('evidence/context-r37-ar-rational-wire-check/result.json')['exit_code'] == 0
closed = closure['result']
assert closed['original_lease']['released'] and closed['original_lease']['free_briefly']
assert closed['service']['ActiveState'] == 'active'
assert not closed['foreign_compute_clients'] and not closed['http8000_listeners']
for window in closed['owned_window_closures']:
    assert window['supervisor_identity_absent'] and window['container_init_identity_recorded']
    assert window['container_init_identity_absent'] and window['container_absent']
    assert window['label_listing_empty']
for name, item in collection['inventory']['files'].items():
    actual = bound(BASE / name)
    assert actual['sha256'] == item['sha256'] and actual['bytes'] == item['bytes']
assert len(collection['inventory']['files']) == 19
for name, item in host['frozen_sources'].items():
    assert bound(name)['sha256'] == item['sha256']

members = {}
def capture(path):
    item = bound(path)
    assert item['path'] not in members
    members[item['path']] = item

for folder in [BASE, Path('evidence/context-r37-ar-rational-wire-check')]:
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            capture(path)
for path in sorted(Path('evidence').glob('context-r37-ar-*')):
    if path.is_file():
        capture(path)
for name in ['evidence/context-r37-before-ar-r1.py', 'evidence/context-r37-before-ar-r1.json',
             'evidence/context-r37-peer-nonuse-ar-r1.json', 'evidence/context-r37-integer-ar-r1.json',
             'evidence/verify-r37-bounded-wire.py', 'evidence/seal-integrated-point-ar-r37.py',
             'evidence/functional-source-ready-r76.json', str(host_path), str(build_path)]:
    capture(name)
inventory = (json.dumps(members, indent=2) + '\n').encode()
with RAW.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, item in sorted(members.items()):
                assert bound(name) == item
                info = tarfile.TarInfo(name)
                info.mode, info.size = 0o644, item['bytes']
                with Path(name).open('rb') as source:
                    tar.addfile(info, source)
            info = tarfile.TarInfo('raw-inventory.json')
            info.mode, info.size = 0o644, len(inventory)
            tar.addfile(info, io.BytesIO(inventory))

receipt = {
    'schema': 'synapse-lie.integrated-point-ar.v1',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'SELECTED_ORIGINAL_WEIGHT_AR_COLLECTED_VERIFIED_CLOSED',
    'scope': 'Completed AR OpenAI/wire checks only; no full sampler, quality, fault, 1M or performance acceptance.',
    'source_commit': manifest['source_commit'], 'qualified_code_commit': host['source_commit'],
    'host_qualification': bound(host_path), 'coherent_HIP_build': bound(build_path),
    'current_source_hashes_verified': len(host['frozen_sources']),
    'host': '192.168.5.161', 'label': collection['label'], 'decode_mode': 'ar',
    'runtime_build_id': manifest['runtime_build_id'], 'image': manifest['image'],
    'bundle_sha256': manifest['bundle_manifest_sha256'], 'binaries': manifest['artifacts'],
    'model_plan': manifest['model_plan'], 'model_stat_unchanged': job['model_stat_unchanged'],
    'general_OpenAI_checks': len(http['passed']), 'bounded_integer_checks': len(integer['passed']),
    'independent_exact_rational_wire_verification': math,
    'supervisor_exit_code': job['exit_code'], 'container_child_exit_code': job['child_exit_code'],
    'controller_exit_code': controller['exit_code'], 'server_exit_code': http['server_exit_code'],
    'supervisor_identity': {'pid': job['pid'], 'start_ticks': job['start_ticks']},
    'container_identity': job['container'], 'fresh_closure': closed,
    'lease': job['lease'], 'lease_released_at_utc': job['lease_released_at'],
    'remote_temperature_peaks_C': read('evidence/context-r37-ar-collected-proof.json')['peak_C'],
    'thermal_policy': job['thermal_policy'], 'collected_remote_files_verified': 19,
    'preserved_local_observer_failure': read('evidence/context-r37-ar-observer-failure-r1.json'),
    'new_run_build_or_test_for_collection': False,
    'remaining_implementation_in_owned_functional_scope': [],
    'source_readiness_is_runtime_acceptance': False,
    'MTP_status': 'PREPARED_ONLY_NOT_ADMITTED_NOT_LAUNCHED_DEFERRED_BY_OWNER_SEQUENCE',
    'new_remote_campaign_queued': False, 'root_machine_reservation': False,
    'owner_sequence': ['complete_all_remaining_functional_implementation',
                       'qualify_integrated_runtime', 'matched_benchmarks', 'Terminal_Bench_last'],
    'open_task_numbers': [2, 3, 4, 5, 6, 7], 'publication': False, 'goal_complete': False,
    'portable_raw_archive': {**bound(RAW), 'members': len(members) + 1}, 'raw_artifacts': members}
with OUT.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({'receipt': bound(OUT), 'archive': bound(RAW),
                  'members': len(members) + 1, 'new_run_or_test': False}))
