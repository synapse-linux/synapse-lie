#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Freeze completed HOST codec controls; never run a model or remote action."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,re,subprocess,tarfile

OUT=Path('docs/development/validation/c17-schema-codec-host-2026-10-06.json')
ARCHIVE=Path('docs/development/validation/raw/c17-schema-codec-host-2026-10-06.tar.gz')
OLD=Path('docs/development/validation/c17-json-slot-host-2026-10-06.json')
assert not OUT.exists() and not ARCHIVE.exists()
def load(p):return json.loads(Path(p).read_text())
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def bound(p):
    p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
old=load(OLD)
assert sha(OLD)=='d28bdde72038348c93b2bdef776928cab4025d3b9ab92bfaa978ba4b6be45c77'
provider={name:sha(name) for name in old['private_provider_inventory']}
changed=sorted(name for name in provider if provider[name]!=old['private_provider_inventory'][name])
assert len(provider)==105 and changed==['adapters/gufo_schema_number.hpp','include/lie/schema_number.h','src/schema_number.c']
members={}
def capture(p,name=None):
    p=Path(p);name=name or str(p)
    assert name not in members and p.is_file() and not p.is_symlink()
    item=bound(p);item['raw_member']=name;members[name]=item;return item
tracked=subprocess.check_output(['git','ls-files','-z']).decode().split('\0')
frozen={}
for name in sorted(set(tracked)):
    if not name:continue
    p=Path(name)
    if name in provider or name in ['CMakeLists.txt','LICENSE'] or (name.startswith('third_party/')
        and ('NOTICE' in p.name or 'LICENSE' in p.name or name.endswith('-source.json'))) or (
        name.startswith(('src/','include/','adapters/','tests/','cmake/')) and (
        name.endswith(('.c','.h','.cpp','.hpp','.cmake','.json')) or p.name=='CMakeLists.txt')):
        frozen[name]=capture(name,'sources/'+name)
capture('third_party/README.md','sources/third_party/README.md')
assert 'adapters/gufo-state/schema-number-edits.json' in frozen
assert 'third_party/gufo-LICENSE' in frozen
assert 'third_party/ryu/LICENSE-Apache2' in frozen and 'third_party/ryu/LICENSE-Boost' in frozen
capture('build/schema-codec-provider-host/variant-files.json')
commands={};cpu_peak=0
for directory in sorted(Path('evidence').glob('schema-codec-*')):
    if not directory.is_dir() or not (directory/'result.json').is_file() or not (directory/'plan.json').is_file():continue
    r,p=load(directory/'result.json'),load(directory/'plan.json')
    commands[str(directory)]={'actual_exit_code':r['exit_code'],'child_exit_code':r['child_exit_code'],
                              'argv':r['argv'],'result':capture(directory/'result.json')}
    for sensor in p['sensors']:
        if sensor['name'] in ['k10temp','coretemp']:cpu_peak=max(cpu_peak,r['peak_c'].get(sensor['path'],0))
    for f in sorted(directory.iterdir()):
        if f.is_file() and f.name!='result.json':capture(f)
assert commands and all(c['actual_exit_code']==c['child_exit_code']==0 for c in commands.values())
counts={}
for name,count in [('core-release-ctest-r2',5),('core-asan-ctest-r1',5),('provider-ctest-r1',58),('provider-gates-r1',3)]:
    directory='evidence/schema-codec-'+name
    assert commands[directory]['actual_exit_code']==0
    assert f'100% tests passed out of {count}' in Path(directory+'/command.log').read_text()
    counts[name]=count
for folder in ['build/schema-codec-core-release','build/schema-codec-core-asan','build/schema-codec-provider-host']:
    capture(folder+'/CMakeCache.txt');capture(folder+'/build.ninja')
    capture(folder+'/Testing/Temporary/LastTest.log')
    assert not re.search(r'AddressSanitizer:|LeakSanitizer:|runtime error:',Path(folder+'/Testing/Temporary/LastTest.log').read_text())
asan=Path('build/schema-codec-core-asan/Testing/Temporary/LastTest.log').read_text()
assert '1581 independent oracles, 37 callback refusals, 18 allocation refusals' in asan
for f in sorted(Path('evidence').glob('schema-codec-*.py')):capture(f)
capture('evidence/seal-schema-codec-host-r1.py')
capture('evidence/verify-schema-codec-host-r1.py')
capture('evidence/schema-codec-read-discovery-failure-r1.json')
capture(OLD)
complete=[];unchanged_files=0
for group in old['complete_witnesses']:
    entry={'suite':group['suite'],'previous_hash_unchanged':True,'files':[]}
    for prior in group['files']:
        relative=Path(prior['path']).relative_to('build/json-slot-provider-host')
        p=Path('build/schema-codec-provider-host')/relative
        item=capture(p)
        assert item['sha256']==prior['sha256'] and item['bytes']==prior['bytes'],str(p)
        entry['files'].append(item);unchanged_files+=1
    complete.append(entry)
assert len(complete)==30 and unchanged_files==267
binaries=[]
for folder in ['build/schema-codec-core-release','build/schema-codec-core-asan']:
    for name in ['test-schema-number','test-binary64','test-schema-compile','test-schema-integer','test-json-slot','liblie_sampling.a']:
        binaries.append(bound(folder+'/'+name))
for name in ['candidate','reference','fallback']:
    binaries.append(bound('build/schema-codec-provider-host/lib'+name+'.a'))
    binaries.append(bound('build/schema-codec-provider-host/'+name+'-number-control-probe'))
physical={};aliases={};index={}
for name,item in sorted(members.items()):
    identity=(item['bytes'],item['sha256'])
    if identity in physical:
        aliases[name]=physical[identity]
        index[name]={'bytes':item['bytes'],'sha256':item['sha256'],'alias_of':physical[identity]}
    else:
        physical[identity]=name;index[name]={'bytes':item['bytes'],'sha256':item['sha256']}
index_data=(json.dumps(index,indent=2)+'\n').encode()
ARCHIVE.parent.mkdir(exist_ok=True)
with ARCHIVE.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,compresslevel=3) as z:
        with tarfile.open(fileobj=z,mode='w') as t:
            for name in sorted(set(members)-set(aliases)):
                p=Path(members[name]['path']);info=tarfile.TarInfo(name)
                info.mode=0o644;info.size=p.stat().st_size
                with p.open('rb') as f:t.addfile(info,f)
            info=tarfile.TarInfo('raw-inventory.json');info.mode=0o644;info.size=len(index_data)
            t.addfile(info,io.BytesIO(index_data))
receipt=dict(schema='synapse-lie.c17-schema-codec-host.v1',at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    state='HOST_PASSED_GPU_PENDING',source_parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    scope='Owned C17 schema-number default binary64 conversion and native error recording: initialized descriptions need no conversion callback; either override stays optional. Private C++ retains typed input and final exception projection/custom callback capture. HOST only; no original-weight/model-forward/GPU/performance qualification.',
    previous_host_receipt=bound(OLD),private_provider_inventory=provider,changed_provider_files=changed,unchanged_provider_files=102,
    immutable_upstream=old['immutable_upstream'],frozen_sources=frozen,actual_commands=commands,final_test_counts=counts,
    independent_C_checks=1581,callback_refusals=37,allocator_refusals=18,
    independent_oracles='Integer/rational grids, exact rational LCM, signed zero, minimum subnormal, maximum finite binary64, mixed custom/native hooks and overflow preserving output. Each selected callback/allocator site refused in both custom and native modes; zero remaining allocations.',
    complete_witnesses=complete,unchanged_previous_groups=30,unchanged_previous_files=267,
    private_cpp_hook_exception_controls=4,private_cpp_native_overflow_exception_preserved=True,
    private_cpp_numeric_bridge_allocations=0,
    sanitizer_execution={'ASan':True,'UBSan':True,'LSan':True,'execution':'Outside ptrace via explicit tool escalation','ASAN_UBSAN_LSAN_options_unset':True,'suppression':False},
    maximum_observed_local_CPU_C=cpu_peak,
    guards='Local Strix Halo395 CPU98/NVMe85/lower exposed limits; GPU masked/observe-only; no fan/clock/power changes.',
    binaries=binaries,retained_read_discovery_failures=bound('evidence/schema-codec-read-discovery-failure-r1.json'),
    ABI_state_cache_event_metrics_layout_changes=False,reactive_or_worker_policy_changes=False,new_dependency=False,
    native_product_default_tests_require_Python=False,
    pending=['Matching sealed HIP ON/OFF105/private-consumer build and selected original-weight AR37+66/MTP37+66 on .161 under fresh admission.',
             'Remaining typed schema/grammar construction/bootstrap/callback facades/model-controller and broader numeric/branch/fault/resource/quality/matched-cost gates.',
             'All six owned roadmap items; Terminal Bench remains last.'],
    new_remote_job_client_build_lease_waiter_reservation=False,root_157_158_use=False,all_six_owned_tasks_open=True,
    Terminal_Bench='STOPPED_COLLECTED_CLOSED_DEFERRED_LAST',publication=False,goal_complete=False,
    portable_raw_archive={**bound(ARCHIVE),'members':len(physical)+1,'actual_capture_paths':len(index),'exact_duplicate_aliases':len(aliases),
      'scope':'Complete sources, licenses, recipes, logs, telemetry and untruncated witnesses with SHA-verified duplicate aliases; binaries hashed only.'})
with OUT.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'receipt':str(OUT),'sha256':sha(OUT),'source_files':len(frozen),'provider_files':len(provider),
                 'unchanged_groups':30,'unchanged_captures':267,'archive_bytes':ARCHIVE.stat().st_size,
                 'archive_members':len(physical)+1,'aliases':len(aliases),'CPU_max_C':cpu_peak,'counts':counts}))
