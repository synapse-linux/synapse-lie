#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Independently inspect frozen HOST evidence; no rebuild or model execution."""
from pathlib import Path
import datetime,hashlib,json,re,subprocess,tarfile
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
path=Path('docs/development/validation/c17-schema-codec-host-2026-10-06.json')
r=json.loads(path.read_text())
assert r['state']=='HOST_PASSED_GPU_PENDING' and r['all_six_owned_tasks_open']
assert r['independent_C_checks']==1581 and r['callback_refusals']==37 and r['allocator_refusals']==18
assert r['final_test_counts']=={'core-release-ctest-r2':5,'core-asan-ctest-r1':5,'provider-ctest-r1':58,'provider-gates-r1':3}
assert not r['new_dependency'] and not r['reactive_or_worker_policy_changes']
assert not r['new_remote_job_client_build_lease_waiter_reservation'] and not r['publication']
assert len(r['private_provider_inventory'])==105 and len(r['changed_provider_files'])==3
for name,digest in r['private_provider_inventory'].items():assert sha(name)==digest,name
for name,item in r['frozen_sources'].items():assert sha(name)==item['sha256'] and Path(name).stat().st_size==item['bytes']
for name,command in r['actual_commands'].items():
    assert command['actual_exit_code']==command['child_exit_code']==(1 if name=='evidence/schema-codec-host-seal-r1' else 0)
    assert sha(command['result']['path'])==command['result']['sha256']
for group in r['complete_witnesses']:
    assert group['previous_hash_unchanged']
    for item in group['files']:assert sha(item['path'])==item['sha256'] and Path(item['path']).stat().st_size==item['bytes']
assert len(r['complete_witnesses'])==30 and sum(len(x['files']) for x in r['complete_witnesses'])==267
assert sha(r['previous_host_receipt']['path'])==r['previous_host_receipt']['sha256']
for item in r['binaries']:assert sha(item['path'])==item['sha256']
a=r['portable_raw_archive'];assert sha(a['path'])==a['sha256'] and Path(a['path']).stat().st_size==a['bytes']
with tarfile.open(a['path']) as t:
    members=t.getmembers();assert len(members)==a['members']
    by_name={m.name:m for m in members};assert len(by_name)==len(members)
    index=json.load(t.extractfile('raw-inventory.json'))
    assert len(index)==a['actual_capture_paths']
    assert sum('alias_of' in x for x in index.values())==a['exact_duplicate_aliases']
    verified={}
    for name,item in index.items():
        target=item.get('alias_of',name)
        assert target in by_name and by_name[target].isfile()
        assert not Path(target).is_absolute() and '..' not in Path(target).parts
        if target not in verified:
            f=t.extractfile(target);verified[target]=(by_name[target].size,hashlib.file_digest(f,'sha256').hexdigest())
        assert verified[target]==(item['bytes'],item['sha256'])
    for name,item in r['frozen_sources'].items():assert item['raw_member'] in index
    assert 'sources/third_party/gufo-LICENSE' in index and 'sources/LICENSE' in index
    assert 'sources/third_party/ryu/LICENSE-Apache2' in index and 'sources/third_party/ryu/LICENSE-Boost' in index
    assert 'sources/adapters/gufo-state/grammar-number-edits.json' in index
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();links=0
for name in changed:
    if not name.endswith('.md'):continue
    p=Path(name)
    for target in re.findall(r'\]\(([^)\s]+)\)',p.read_text()):
        if target.startswith(('http://','https://','mailto:','#')):continue
        assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target);links+=1
check=subprocess.run(['git','diff','--check'],capture_output=True,text=True);assert check.returncode==0
proof={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'PASSED','actual_exit_code':0,
       'receipt_sha256':sha(path),'sources':len(r['frozen_sources']),'provider_files':105,'groups':30,'captures':267,
       'portable_members':len(members),'aliases':a['exact_duplicate_aliases'],'documentation_links':links,
       'scope':'Local frozen-source/raw/command/witness inspection only; no tests, GPU build or inference rerun.',
       'all_six_owned_tasks_open':True,'Terminal_Bench':'STOPPED_COLLECTED_CLOSED_DEFERRED_LAST'}
out=Path('evidence/schema-codec-host-proof-r1.json');assert not out.exists();out.write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
