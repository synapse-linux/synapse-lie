# SPDX-License-Identifier: MIT
"""Seal the completed original RAM/SSD namespace proof; no GPU, model or tests."""
from pathlib import Path
import datetime,hashlib,json,tarfile

root=Path.cwd();dest=root/'docs/development/validation'
name='prefill-mtp-original-point-2026-10-07'
receipt_path=dest/(name+'.json');archive_path=dest/'raw'/(name+'.tar.gz')
assert not receipt_path.exists() and not archive_path.exists()
def read(rel):return json.loads((root/rel).read_text())
def ident(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':digest}
ready=read('evidence/context-r53-readiness.json');proof=read('evidence/context-r53-cache-proof.json')
guard=read('evidence/context-r53-review-guard/result.json')
assert proof['actual_exit_code']==guard['exit_code']==guard['child_exit_code']==0 and guard['reason'] is None
assert proof['all_ten_complete_outputs_equal'] and proof['unchanged_models_across_both_windows']
live_proof=read('evidence/context-r53-live-proof.json')
live_guard=read('evidence/context-r53-live-review-guard/result.json')
assert live_proof['actual_exit_code']==live_guard['exit_code']==live_guard['child_exit_code']==0
assert live_proof['serial_AR_complete_output_equal'] and live_proof['confirmed_output_ids']==proof['arms'][0]['confirmed_output_ids']
closures=[];models=None;witnesses={};manifest=None
for mode in ('live','ram','ssd'):
    folder='evidence/context-r53-prefill-'+mode+'-mtp-r1'
    m=read(folder+'/manifest.json');r=read(folder+'/result.json')
    closure=read('evidence/context-r53-'+mode+'-closure-r1.json')
    assert r['state']=='PASSED' and not r['cleanup_failures']
    assert read(folder+'/controller-result.json')['exit_code']==r['exit_code']==r['child_exit_code']==closure['actual_exit_code']==0
    assert r['models_before']==r['models_after'] and r['model_stat_unchanged'] is True
    if models is None:models=r['models_before'];manifest=m
    assert r['models_before']==models
    assert ident(root/m['qualified_build_receipt'])['sha256']==m['qualified_build_receipt_sha256']
    rows=[json.loads(line) for line in (root/folder/'measurements.jsonl').read_text().splitlines()]
    witnesses[mode]=[row for row in rows if row['event'] in ('prefill_cache_step','prefill_probe_complete','ssd_drained','prefill_transition','prefill_live_result','reactive','prefill_cancel')]
    closures.append({'mode':mode,'supervisor':{'pid':r['pid'],'start_ticks':r['start_ticks']},
       'client':{'pid':r['child_pid'],'start_ticks':r['child_start_ticks']},
       'container':r['container'],'container_init':closure['result']['owned_container_init_identity'],
       'lease_released_at_utc':r['lease_released_at'],
       'controller_exit_code':read(folder+'/controller-result.json')['exit_code'],
       'supervisor_exit_code':r['exit_code'],'native_child_exit_code':r['child_exit_code'],
       'idle_container_init_cleanup_exit_code':r['final_container_state']['ExitCode'],
       'strict_closure_actual_exit_code':closure['actual_exit_code'],'strict_closure':closure['result']})
files={}
for path in root.glob('evidence/context-r53-*'):
    if path.is_file():files[str(path.relative_to(root))]=path
    elif path.is_dir() and path.name in ('context-r53-prefill-live-mtp-r1','context-r53-prefill-ram-mtp-r1','context-r53-prefill-ssd-mtp-r1'):
        for child in path.rglob('*'):
            if child.is_file():files[str(child.relative_to(root))]=child
for finished_guard in ('context-r53-review-guard','context-r53-live-review-guard'):
    for path in (root/'evidence'/finished_guard).iterdir():
        if path.is_file():files[str(path.relative_to(root))]=path
for rel in ('evidence/verify-context-r53-cache.py','evidence/verify-context-r53-live.py','evidence/seal-context-r53-mtp.py',
            'tools/strix-point-campaign.py','tools/strix-point-bench-collect.py',
            'tools/core-bench.c','tools/thermal-run.py','src/prefix_cache.c','src/state_compression.c',
            'src/state_kvc.c','src/worker.c','include/lie/prefill.h',manifest['qualified_build_receipt']):files[rel]=root/rel
for mode in ('live','ram','ssd'):
    for stem in ('prepare-context-r53-','launch-context-r53-','observe-context-r53-'):
        rel='evidence/'+stem+mode+'.py';files[rel]=root/rel
files[manifest['serial_reference_receipt']]=root/manifest['serial_reference_receipt']
members={rel:ident(path) for rel,path in sorted(files.items())}
with tarfile.open(archive_path,'x:gz') as packed:
    for rel in members:packed.add(files[rel],arcname=rel,recursive=False)
with tarfile.open(archive_path,'r:gz') as packed:
    entries=packed.getmembers()
    assert len(entries)==len(members) and {p.name for p in entries}==set(members)
    for entry in entries:
        assert entry.isfile() and 'sealing-guard' not in entry.name and 'postseal-guard' not in entry.name
        with packed.extractfile(entry) as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
        assert {'bytes':entry.size,'sha256':digest}==members[entry.name]
        assert ident(files[entry.name])==members[entry.name]
peaks={};live_files=[]
for arm in [live_proof,*proof['arms']]:
    for sensor,value in arm['sampled_temperature_peaks_C'].items():peaks[sensor]=max(peaks.get(sensor,-100),value)
for path in sorted(root.glob('evidence/context-r53-*-live-r*.json')):
    observed=read(str(path.relative_to(root)));assert observed['actual_exit_code']==0
    live_files.append(str(path.relative_to(root)))
    for sensor in observed['result']['observation']['temperatures']:
        peaks[sensor['name']]=max(peaks.get(sensor['name'],-100),sensor['value_c'])
r={'schema':'synapse-lie.prefill-mtp-original-point.v1',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'SELECTED_ORIGINAL_MTP_LIVE_RAM_SSD_AND_SERIAL_PARITY_PASSED','scope':'Original Q4/Q8 PP8192/TG32/context16384/capacity8192: MTP live C2, RAM/SSD C1, complete outputs equal same-runtime AR. Functional only.',
 'compiled_source_commit':manifest['source_commit'],'native_client_code_checkpoint':manifest['native_client_code_checkpoint'],
 'engine_code_checkpoint':manifest['functional_code_checkpoint'],'qualification_runner_commit':manifest['runner_commit'],
 'qualified_HIP_build':{'path':manifest['qualified_build_receipt'],**ident(root/manifest['qualified_build_receipt'])},
 'host':'192.168.5.161','runtime_build_id':manifest['runtime_build_id'],'image':manifest['image'],
 'bundle_sha256':manifest['bundle_manifest_sha256'],'binaries':manifest['artifacts'],
 'qualification_runner_sha256':manifest['runner_sha256'],'model_plan':manifest['model_plan'],'serial_reference_receipt':{'path':manifest['serial_reference_receipt'],**ident(root/manifest['serial_reference_receipt'])},
 'original_model_stat_witnesses':models,'predictor_plan':manifest['predictor_plan'],'native_functional_witnesses':witnesses,
 'independent_saved_data_review':proof,'independent_live_review':live_proof,'offline_review_guard':guard,'offline_live_review_guard':live_guard,'readiness_and_source_continuity':ready,
 'fresh_global_preflights':{mode:read('evidence/context-r53-before-'+mode+'-r1.json') for mode in ('live','ram','ssd')},
 'peer_coordination':read('evidence/context-r53-peer-coordination.json'),
 'live_owner_observation_files':live_files,'combined_sampled_temperature_peaks_C':peaks,
 'process_service_lease_closures':closures,
 'packing_scope':'Exact DS4 payload is preserved raw in RAM/SSD. Generic aligned-state compression capability is ON; zero actual RAM packs. High-ratio packing is not qualified.',
 'new_GPU_build_model_run_for_sealing':False,'Python_product_dependency_added':False,
 'no_standing_remote_job_lease_window_waiter_reservation_handle_after_closure':True,
 'resource_scope':'Separate original-weight C1 probes sampled at1Hz; no allocator-exact fit or matched latency/throughput conclusion.',
 'selected_MTP_live_cache_serial_parity_verified':True,'broader_MTP_probabilities_vision_quality_fault_performance_qualified':False,
 'next_gate':'Broader original MTP numerical probability/filter/grammar/controller and steering/long-context quality/fault/resources; matched benchmarks then Terminal Bench last.',
 'open_task_numbers':[2,3,4,5,6,7],'goal_complete':False,'publication':False,
 'portable_raw_archive':{'path':'raw/'+archive_path.name,**ident(archive_path),'members':len(members)},
 'raw_artifacts':members}
with receipt_path.open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps({'receipt':str(receipt_path.relative_to(root)),'archive':r['portable_raw_archive'],'state':r['state']}))
