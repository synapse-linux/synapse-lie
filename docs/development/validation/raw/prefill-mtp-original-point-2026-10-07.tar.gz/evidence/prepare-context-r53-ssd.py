# SPDX-License-Identifier: MIT
"""Stage exclusive qualification inputs; no admission/model/service operation."""
from pathlib import Path
import base64,hashlib,json,subprocess
root=Path.cwd();label='context-r53-prefill-ssd-mtp-r1'
manifest=(root/'evidence'/(label+'-manifest.json')).read_bytes();m=json.loads(manifest)
tokens=(root/'evidence/context-r48-prefill-tokens.json').read_bytes();runner=(root/'tools/strix-point-campaign.py').read_bytes()
assert hashlib.sha256(tokens).hexdigest()==m['tokens_sha256'] and hashlib.sha256(runner).hexdigest()==m['runner_sha256']
files={'manifest.json':manifest,'tokens.json':tokens,'runner.py':runner}
encoded={n:base64.b64encode(data).decode() for n,data in files.items()}
program='LABEL='+repr(label)+'\nFILES='+repr(encoded)+'\nBUNDLE='+repr(m['bundle'])+'\nBUNDLE_SHA='+repr(m['bundle_manifest_sha256'])+'\n'+'''from pathlib import Path
import base64,hashlib,json,os
base=Path('/home/pop/workspace/synapse-lie');assert base.resolve()==base and base.stat().st_uid==os.getuid()==1000
lease=(base/'campaign.lock').stat();assert (lease.st_dev,lease.st_ino)==(66307,105946405)
bundle=Path(BUNDLE);assert bundle.resolve()==bundle and bundle.stat().st_uid==os.getuid()
assert hashlib.sha256((bundle/'BUNDLE.json').read_bytes()).hexdigest()==BUNDLE_SHA
job=base/LABEL;assert not job.exists() and not job.is_symlink();job.mkdir(mode=0o700)
for name,encoded in FILES.items():
 with (job/name).open('xb') as output:output.write(base64.b64decode(encoded))
print(json.dumps({'scope':'PREPARED_NOT_ADMITTED','root':str(job),'source_SHA256':{n:hashlib.sha256((job/n).read_bytes()).hexdigest() for n in FILES},'model_GPU_or_service_operation':False,'lease_waiter_or_reservation':False}))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
p=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
r={'argv':argv,'actual_exit_code':p.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':p.stdout,'stderr':p.stderr}
try:r['result']=json.loads(p.stdout)
except ValueError:pass
out=root/'evidence'/label;out.mkdir()
for name,data in files.items():(out/name).write_bytes(data)
(out/'preparation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r.get('result',r)))
raise SystemExit(p.returncode)
