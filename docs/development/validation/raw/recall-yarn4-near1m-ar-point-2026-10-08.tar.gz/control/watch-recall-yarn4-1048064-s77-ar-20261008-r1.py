# SPDX-License-Identifier: MIT
"""Observe only the frozen original live controller; never wait for admission."""
from pathlib import Path
import datetime,json,subprocess,time
root=Path.cwd();label='recall-yarn4-1048064-s77-ar-20261008-r1'
path=root/'evidence'/('watch-'+label+'-result-r1.json')
assert not path.exists()
records=[];deadline=time.monotonic()+72990;error=None;terminal=None
for index in range(3,2437):
 if time.monotonic()>=deadline:
  error='Observation deadline; original job was not restarted or stopped';break
 argv=['python3','-B','evidence/observe-recall-yarn4-1048064-native-progress-r1.py',str(index)]
 run=subprocess.run(argv,text=True,capture_output=True,timeout=40)
 entry={'index':index,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'actual_observer_exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
 records.append(entry)
 print(run.stdout.strip(),flush=True)
 if run.returncode:
  error='Read-only observer failed; actual exit retained; original GPU execution untouched'
  print(json.dumps({'observer_error':error,'actual_exit_code':run.returncode}),flush=True);break
 result=json.loads((root/'evidence'/(label+'-native-progress-'+str(index)+'.json')).read_text())['result']
 if result['state']=='ORIGINAL_CONTROLLER_TERMINAL_OBSERVED_NOT_STRONG_CLOSURE':
  terminal=result;break
 time.sleep(30)
record={'state':'TERMINAL_ORIGINAL_CONTROLLER_OBSERVED' if terminal else 'OBSERVER_FAILED_OR_BOUND_REACHED',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_terminal':terminal,
 'observations':records,'error':error,'actual_exit_code':0 if terminal else 1,
 'GPU_or_model_inference_restarted_or_stopped':False,'strong_closure_required':True}
with path.open('x') as stream:json.dump(record,stream,indent=2);stream.write(chr(10))
print(json.dumps({key:value for key,value in record.items() if key!='observations'}),flush=True)
raise SystemExit(record['actual_exit_code'])
