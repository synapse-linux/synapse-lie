# SPDX-License-Identifier: MIT
"""Read-only current identity/lease/container observation for own r70 build in the witnessed current boot."""
from pathlib import Path
import hashlib,json,subprocess
program="""from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess
base=Path('/home/pop/workspace/synapse-lie');root=base/'context-r70-build-r1'
r=json.loads((root/'result.json').read_text())
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='7a966774-3424-46c3-8045-34f759ea58a1'
assert hashlib.sha256((root/'runner.py').read_bytes()).hexdigest()=='104df341753e2e300d0953bb482c7e93773af6eceb46e5a9d5252126f440e854'
spec=importlib.util.spec_from_file_location('point',root/'runner.py');point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
try:live=point.ticks(r['pid'])==r['start_ticks']
except FileNotFoundError:live=False
fds=[]
if live:
 for p in Path('/proc').joinpath(str(r['pid']),'fd').iterdir():
  try:
   s=p.stat()
   if (s.st_dev,s.st_ino)==(66308,105946405):fds.append(int(p.name))
  except OSError:pass
state={}
if r.get('container'):
 q=subprocess.run(['docker','inspect','--format','{{json .State}}',r['container']],capture_output=True,text=True,timeout=15)
 state={'exit_code':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
compile_path=base/'rocm10-fedora-161/source-modern-r70/evidence/rocm10-point-modern-r70-compile/result.json'
compile_result=json.loads(compile_path.read_text()) if compile_path.exists() else None
compile_dir=compile_path.parent
stages={}
for name in ('provider','reference-provider','configure','link'):
 p=compile_dir/(name+'.exit')
 stages[name]={'started':(compile_dir/(name+'.command')).exists(),'exit':p.read_text().strip() if p.exists() else None}
provider_tails={}
for name in ('provider','reference-provider'):
 p=base/('rocm10-fedora-161/source-modern-r70/evidence/rocm10-point-modern-r70-'+name+'/build.log')
 if p.exists():
  with p.open('rb') as f:
   f.seek(max(0,p.stat().st_size-2400));provider_tails[name]=f.read().decode(errors='replace')
init_identity=None
if state.get('exit_code')==0:
 value=json.loads(state['stdout']); init_pid=value.get('Pid',0)
 if init_pid>0:
  try:init_identity={'pid':init_pid,'start_ticks':point.ticks(init_pid),'container':r['container'],'cgroup':(Path('/proc')/str(init_pid)/'cgroup').read_text()}
  except FileNotFoundError:pass
out={'stages':stages,'provider_tails':provider_tails,'container_init_observed_identity':init_identity,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'live_exact_supervisor':live,'pid':r['pid'],'start_ticks':r['start_ticks'],'state':r['state'],'lease':r.get('lease'),'original_lease_fds':fds,'container':state,'compile_result':compile_result,'model_attempted':r.get('model_attempted'),'observation':point.observe(98,gpu_observation_only=True)}
if live and r['state']=='ADMITTED':assert fds and not r['model_attempted']
print(json.dumps(out))
"""
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
r=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':r.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':r.stdout,'stderr':r.stderr}
try:record['result']=json.loads(r.stdout)
except ValueError:pass
with Path('evidence/context-r70-build-live-r2.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
if 'result' in record:
 v=record['result'];short={k:v[k] for k in ('at_utc','live_exact_supervisor','pid','start_ticks','state','original_lease_fds','model_attempted','container_init_observed_identity','stages')}
 if v['compile_result']:short['compile_result']={k:v['compile_result'].get(k) for k in ('state','exit_code','source_commit','binaries')}
 short['provider_tails']={k:t[-650:] for k,t in v['provider_tails'].items()}
 print(json.dumps(short))
else:print(json.dumps(record))
raise SystemExit(r.returncode)
