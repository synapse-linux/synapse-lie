# SPDX-License-Identifier: MIT
"""Verify a frozen portable steering build receipt; no remote operations."""
from pathlib import Path
import datetime, hashlib, json, tarfile

root = Path.cwd()
receipt = root / 'docs/development/validation/steering-build-point-build-2026-10-07.json'
record = json.loads(receipt.read_text())
archive = record['portable_raw_archive']
path = receipt.parent / archive['path']
assert path.stat().st_size == archive['bytes']
assert hashlib.sha256(path.read_bytes()).hexdigest() == archive['sha256']
assert record['state'] == 'BUILT_NOT_GPU_TESTED_COLLECTED_VERIFIED_CLOSED'
assert record['native_steering_builder_collector_learner_compiled_as_C17'] is True
assert record['native_steering_builder_primary_provider_link_verified'] is True
assert record['current_source_original_weight_qualification_completed'] is False
assert record['original_activations_or_learned_bank_quality_qualified'] is False
assert record['GPU_or_model_executed'] is False and record['original_weight_acceptance'] == 'OPEN'
assert record['complete_recipes'] == 43 and record['complete_recipe_replacements'] == 342
assert record['owned_steering_files_per_provider'] == 10
assert record['provider_build_steps'] == {'provider': [78, 78], 'reference-provider': [78, 78]}
assert len(record['consumer_binary_SHA256']) == 7 and 'lie-steering-build' in record['consumer_binary_SHA256']
assert record['open_task_numbers'] == [2, 3, 4, 5, 6, 7] and not record['goal_complete']
with tarfile.open(path) as package:
    members = package.getmembers()
    assert len(members) == archive['members'] == len(record['raw_artifacts']) + 1
    assert len({m.name for m in members}) == len(members)
    for member in members:
        assert member.isreg()
        data = package.extractfile(member).read()
        if member.name == 'raw-inventory.json':
            assert json.loads(data) == record['raw_artifacts']
            continue
        expected = record['raw_artifacts'][member.name]
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
        live = root / member.name
        assert live.is_file() and not live.is_symlink()
        assert live.stat().st_size == expected['bytes']
        assert hashlib.sha256(live.read_bytes()).hexdigest() == expected['sha256']
    coherence = json.loads(package.extractfile('evidence/context-r70-build-r1/coherence-evidence/collection.json').read())
    blocks = coherence['actual_selected_blocks']
    for name in ('steering_builder_C17_object', 'steering_direction_C17_object', 'steering_capture_C17_object'):
        assert '-std=c17' in blocks[name]
    link = blocks['steering_builder_primary_provider_link']
    assert 'liblie_gufo.a' in link and 'liblie_steering.a' in link
    assert 'rocm10-point-modern-r70-reference-provider/' not in link
    for name in ('libgufo_core.a', 'libgufo_qwen38_flash_next.a', 'libgufo_qwen38_flash_next_mmq.a'):
        assert name in link and 'rocm10-point-modern-r70-provider/' in link
    verification = json.loads(package.extractfile('evidence/context-r70-build-r1/compile-verification-r1/result.json').read())
    assert verification['exit_code'] == 0 and len(verification['recipes_verified']) == 43
    assert verification['owned_steering_files_per_variant'] == 10
result = {'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'actual_exit_code': 0,
    'all_archived_and_current_members_match': True, 'members': archive['members'],
    'archive_sha256': archive['sha256'], 'scope': 'Local completed evidence verification only',
    'remote_build_GPU_or_model_run': False}
with (root / 'evidence/context-r70-postseal.json').open('x') as stream:
    json.dump(result, stream, indent=2); stream.write('\n')
print(json.dumps(result))
