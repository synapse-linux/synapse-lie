# SPDX-License-Identifier: MIT
"""Seal already-collected, closed Point compilation; no build or model run."""
from pathlib import Path
import datetime, gzip, hashlib, io, json, re, subprocess, tarfile

root = Path.cwd()
base = root / 'evidence/context-r70-build-r1'
dest = root / 'docs/development/validation'
name = 'steering-build-point-build-2026-10-07'
out = dest / (name + '.json')
archive = dest / 'raw' / (name + '.tar.gz')
assert not out.exists() and not archive.exists()
def read(rel):
    return json.loads((root / rel).read_text())
def bound(path):
    assert path.is_file() and not path.is_symlink(), path
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': sha}
job = read('evidence/context-r70-build-r1/result.json')
controller = read('evidence/context-r70-build-r1/controller-result.json')
verification = read('evidence/context-r70-build-r1/compile-verification-r1/result.json')
seal = read('evidence/context-r70-source-seal.json')
bundle = read('evidence/context-r70-bundle-result.json')
closure = read('evidence/context-r70-build-closure-r1.json')
peers = read('evidence/context-r70-peer-coordination.json')
release = read('evidence/context-r70-peer-release-notifications.json')
assert job['state'] == 'PASSED'
assert job['exit_code'] == job['child_exit_code'] == controller['exit_code'] == 0
assert not job['model_attempted'] and not job['cleanup_failures']
assert verification['exit_code'] == closure['actual_exit_code'] == bundle['exit_code'] == 0
assert verification['source_commit'] == seal['source_commit'] == bundle['result']['metadata']['source_commit']
assert len(verification['recipes_verified']) == seal['provider_source']['recipes'] == 43
assert seal['provider_source']['edits'] == 342
assert verification['complete_variant_files_per_variant'] == seal['pristine_gufo_files_verified'] == 1019
assert verification['private_provider_files_per_variant'] == seal['owned_sampling_file_inventory'] == 122
assert verification['owned_steering_files_per_variant'] == seal['owned_steering_files'] == 10
assert seal['tracked_compiler_files_verified'] == 731
assert set(job['build_result']['binaries']) == set(seal['seven_required_consumer_targets'])
assert peers['explicit_current_161_non_use_from_all_three'] is True
assert peers['last_observed_boot_identity_declared_to_all_four'] is True
assert peers['separate_GLM_current_161_non_use'] is True
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == seal['source_commit']
changed = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], text=True).splitlines()
assert set(changed) == {'docs/PROGRESS.md', 'docs/BACKEND.md', 'docs/COORDINATION.md',
    'docs/development/STEERING.md', 'docs/reference/ABI.md', 'third_party/README.md', 'CHANGELOG.md'}
closed = closure['result']
assert peers['boot_id'] == closed['boot_id'] == '7a966774-3424-46c3-8045-34f759ea58a1'
assert (job['lease']['device'], job['lease']['inode']) == (66308, 105946405)
for stage in ('r1', 'r2'):
    assert read('evidence/context-r70-fresh-161-' + stage + '.json')['actual_exit_code'] == 0
assert job['runner_sha256'] == seal['runner_sha256']
assert closed['state'] == 'FRESH_SUCCESSFUL_BUILD_CLOSURE_NO_STANDING_RESERVATION'
assert closed['owned_supervisor_identity_absent'] and closed['owned_container_init_identity_absent']
assert closed['owned_container_init_identity_recorded'] and closed['recorded_container_cgroup']['absent']
assert len(closed['complete_cgroup_process_scans']) == 2
assert all(not scan['members'] and not scan['unreadable'] for scan in closed['complete_cgroup_process_scans'])
assert closed['original_lease']['free_briefly'] and closed['original_lease']['released']
assert not closed['foreign_compute_clients'] and not closed['http8000_listeners'] and not closed['guarded_hot']
assert closed['service']['ActiveState'] == 'active' and not closed['standing_lease_waiter_reservation']
rows = [json.loads(line) for line in (base / 'terminal-control/telemetry.jsonl').read_text().splitlines()]
peaks = {}
for row in rows:
    for sensor in row['temperatures']:
        peaks[sensor['name']] = max(peaks.get(sensor['name'], -40), sensor['value_c'])
        if sensor['guarded']:
            assert sensor['value_c'] < sensor['limit_c']
assert set(peaks) == {'nvme', 'amdgpu', 'k10temp'}
assert {pid for row in rows for pid in row['kernel_kfd']}.issubset({int(job['service_before']['MainPID'])})
for part, count in [('terminal-control/control-collection.json', 4),
                    ('compile-evidence/collection.json', 25), ('coherence-evidence/collection.json', 3)]:
    collection = json.loads((base / part).read_text())
    assert collection['exit_code'] == 0 and len(collection['files']) == count
    for rel, expected in collection['files'].items():
        assert bound(base / str(Path(part).parent) / rel) == expected
coherence = read('evidence/context-r70-build-r1/coherence-evidence/collection.json')
assert coherence['compiled_native_steering_builder_C17_primary_provider'] is True
assert coherence['compiled_native_capture_C17_primary_provider'] is True
for key in ('steering_builder_C17_object', 'steering_direction_C17_object', 'steering_capture_C17_object'):
    assert '-std=c17' in coherence['actual_selected_blocks'][key]
assert 'liblie_gufo.a' in coherence['actual_selected_blocks']['steering_builder_primary_provider_link']
assert 'liblie_steering.a' in coherence['actual_selected_blocks']['steering_builder_primary_provider_link']
build_steps = {}
for variant in ('provider', 'reference-provider'):
    text = (base / ('compile-evidence/evidence/rocm10-point-modern-r70-' + variant + '/build.log')).read_text()
    steps = re.findall(r'\[([0-9]+)/([0-9]+)\]', text)
    assert steps and tuple(map(int, steps[-1])) == (78, 78)
    build_steps[variant] = [78, 78]
host_receipts = []
for suffix in ('build', 'capture'):
    rel = 'docs/development/validation/steering-' + suffix + '-host-2026-10-07.json'
    identity = bound(root / rel)
    assert identity['sha256'] == seal['steering_' + suffix + '_host_receipt_sha256']
    host_receipts.append({'path': rel, **identity})
assert bound(root / 'evidence/context-source-modern-r70.tar.gz')['sha256'] == seal['archive_sha256']
assert len(release['peers']) == 4
assert all(peer['status'] == 'fulfilled' and not peer['value']['reply'].get('isError', False) for peer in release['peers'])
members = {}
def capture(path):
    members[str(path.relative_to(root))] = bound(path)
for path in base.rglob('*'):
    if path.is_file(): capture(path)
for path in (root / 'evidence').glob('*r70*'):
    if path.is_file() and not path.name.endswith('.tar.gz'): capture(path)
source_paths = ['tools/steering-build.c', 'include/lie/executor.h', 'include/lie/activation_observer.h',
    'include/lie/steering_direction.h', 'include/lie/steering_capture.h', 'src/steering_direction.c',
    'src/steering_capture.c', 'adapters/gufo_activation_observer.hpp', 'adapters/gufo.cpp',
    'tests/steering_build_executor.c', 'tests/test_steering_build.c', 'tests/test_steering_direction.c',
    'tests/test_steering_capture.c', 'tests/test_gufo_activation_observer.cpp',
    'CMakeLists.txt', 'cmake/point/Build.cmake', 'cmake/provider/Build.cmake',
    'cmake/provider/Source.cmake', 'tools/strix-point-campaign.py', 'tools/thermal-run.py',
    'third_party/gufo-source.json']
for rel in source_paths + [item['path'] for item in host_receipts] + ['README.md', 'CHANGELOG.md',
    'docs/BACKEND.md', 'docs/PROGRESS.md', 'docs/COORDINATION.md', 'docs/reference/ABI.md',
    'docs/development/STEERING.md', 'third_party/README.md',
    'evidence/context-source-modern-r70/SOURCE-FILES.sha256']:
    capture(root / rel)
for rel, sha in verification['recipes_verified'].items():
    assert bound(root / rel)['sha256'] == sha
    capture(root / rel)
inventory = (json.dumps(members, indent=2) + '\n').encode()
with archive.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as package:
            for rel, item in sorted(members.items()):
                assert bound(root / rel) == item
                info = tarfile.TarInfo(rel)
                info.mode, info.size = 0o644, item['bytes']
                with (root / rel).open('rb') as data: package.addfile(info, data)
            info = tarfile.TarInfo('raw-inventory.json')
            info.mode, info.size = 0o644, len(inventory)
            package.addfile(info, io.BytesIO(inventory))
result = {
    'schema': 'synapse-lie.steering-build-point-build.v1',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'BUILT_NOT_GPU_TESTED_COLLECTED_VERIFIED_CLOSED',
    'classification': 'COHERENT_DEVICE_HIDDEN_ROCM10_COMPILATION_NOT_INFERENCE',
    'source_commit': seal['source_commit'], 'code_checkpoint': seal['code_checkpoint'],
    'engine_code_checkpoint': seal['engine_code_checkpoint'], 'native_source_changed_after_compile': False,
    'host_receipts': host_receipts, 'host_checks': seal['native_client_tests'],
    'source_archive_sha256': seal['archive_sha256'], 'source_inventory_sha256': seal['source_files_sha256'],
    'tracked_compiler_files': 731, 'independently_pinned_gufo_files': 1019,
    'complete_recipes': 43, 'complete_recipe_replacements': 342,
    'owned_sampling_files_per_provider': 122, 'owned_steering_files_per_provider': 10,
    'private_C17_ON_OFF_coherent': True, 'provider_build_steps': build_steps,
    'native_steering_builder_collector_learner_compiled_as_C17': True,
    'native_steering_builder_primary_provider_link_verified': True,
    'native_sources': {n: bound(root / n) for n in source_paths},
    'consumer_binary_SHA256': job['build_result']['binaries'],
    'build_stages': {n: 0 for n in ['provider', 'reference-provider', 'configure', 'link']},
    'collected_artifacts': {'compile': 25, 'terminal_control': 4, 'coherence': 3},
    'controller_exit_code': controller['exit_code'], 'supervisor_exit_code': job['exit_code'],
    'child_exit_code': job['child_exit_code'],
    'supervisor_identity': {'pid': job['pid'], 'start_ticks': job['start_ticks']},
    'container_init_identity': {'pid': job['container_host_pid'], 'start_ticks': job['container_start_ticks']},
    'bundle': bundle['result'], 'lease': job['lease'], 'lease_released_at_utc': job['lease_released_at'],
    'fresh_closure': closed, 'telemetry_samples': len(rows),
    'CPU_GPU_NVMe_peak_C': [peaks['k10temp'], peaks['amdgpu'], peaks['nvme']],
    'peer_release_notifications': release,
    'preserved_failures': [], 'GPU_or_model_executed': False, 'model_hash_or_conversion': False,
    'installation_tuning_deployment_or_publication': False, 'performance_comparison': False,
    'original_weight_acceptance': 'OPEN', 'current_source_original_weight_qualification_completed': False,
    'original_activations_or_learned_bank_quality_qualified': False,
    'goal_complete': False, 'open_task_numbers': [2, 3, 4, 5, 6, 7],
    'portable_raw_archive': {'path': 'raw/' + archive.name, **bound(archive), 'members': len(members) + 1},
    'raw_artifacts': members,
}
with out.open('x') as stream:
    json.dump(result, stream, indent=2); stream.write('\n')
print(json.dumps({'receipt': str(out.relative_to(root)), 'archive': result['portable_raw_archive'],
    'build_exit_codes': [0, 0, 0], 'original_weight_acceptance': 'OPEN'}))
