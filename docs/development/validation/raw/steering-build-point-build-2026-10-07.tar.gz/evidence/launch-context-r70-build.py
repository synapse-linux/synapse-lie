# SPDX-License-Identifier: MIT
"""Launch the prepared coherent device-hidden Point build under original lease."""
from pathlib import Path
import datetime,hashlib,json,subprocess
root=Path.cwd();out=root/'evidence/context-r70-build-r1'
seal=json.loads((root/'evidence/context-r70-source-seal.json').read_text())
fresh=json.loads((root/'evidence/context-r70-fresh-161-r2.json').read_text())
assert fresh['actual_exit_code']==0;r=fresh['result']
peers=json.loads((root/'evidence/context-r70-peer-coordination.json').read_text())
assert peers['explicit_current_161_non_use_from_all_three'] is True
assert peers['last_observed_boot_identity_declared_to_all_four'] is True
assert peers['separate_GLM_current_161_non_use'] is True
assert peers['boot_id']=='7a966774-3424-46c3-8045-34f759ea58a1'
assert json.loads((root/'evidence/context-r70-source-stage.json').read_text())['exit_code']==0
age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(r['at_utc'])).total_seconds()
assert 0 <= age <= 180, 'Fresh preflight expired; never restart or admit from stale state'
assert r['original_lease']['free_briefly'] is True and r['original_lease']['released'] is True
assert (r['original_lease']['device'],r['original_lease']['inode'])==(66308,105946405)
assert not r['foreign_compute_clients'] and not r['guarded_hot'] and not r['http8000_listeners']
assert r['exclusive_job_prepared'] and r['sealed_source_present']
assert r['boot_id']=='7a966774-3424-46c3-8045-34f759ea58a1'
assert hashlib.sha256((out/'runner.py').read_bytes()).hexdigest()==seal['runner_sha256']
remote='/home/pop/workspace/synapse-lie/context-r70-build-r1'
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161',
      'python3','-B',remote+'/runner.py',remote]
plan={'argv':argv,'remote_root':remote,'source_commit':seal['source_commit'],
      'runner_sha256':seal['runner_sha256'],'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),
      'fresh_preflight':'evidence/context-r70-fresh-161-r2.json','standing_future_window':False}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with (out/'controller-stdout.log').open('x') as stdout,(out/'controller-stderr.log').open('x') as stderr:
    p=subprocess.run(argv,stdout=stdout,stderr=stderr)
record={**plan,'exit_code':p.returncode};(out/'controller-result.json').write_text(json.dumps(record,indent=2)+'\n')
try:
    result=json.loads((out/'controller-stdout.log').read_text())
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result.get(k) for k in ('state','error','exit_code','child_exit_code','pid','start_ticks','container','lease','lease_released_at','model_attempted','cleanup_failures')}))
except (OSError,ValueError):print(json.dumps({'actual_exit_code':p.returncode,'error':'Remote result unavailable; preserved controller logs'}))
raise SystemExit(p.returncode)
