# SPDX-License-Identifier: MIT
"""Seal current native steering compiler inputs; no remote build/model/GPU work."""
from pathlib import Path
import datetime,gzip,hashlib,json,re,shutil,subprocess,tarfile
root=Path.cwd();label='context-source-modern-r70';out=root/'evidence'/label;archive=out.with_suffix('.tar.gz')
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert commit=='4c703b3d604c6c877d6a2214d7aee0b15a013f61'
assert not subprocess.check_output(['git','status','--porcelain'])
assert not out.exists() and not archive.exists()
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
receipt_path=root/'docs/development/validation/steering-build-host-2026-10-07.json'
r=json.loads(receipt_path.read_text());raw=receipt_path.parent/r['raw']['path']
assert r['actual_exit_code']==0 and r['state']=='HOST_NATIVE_C17_BANK_BUILDER_PASSED_HIP_AND_ORIGINAL_CAPTURES_UNQUALIFIED'
assert r['CTest_count']=={'Debug':4,'ASan_UBSan_LSan':4} and not r['sanitizer_suppressions']
assert not r['new_GPU_or_remote_build_admitted'] and r['production_GPU_consumer_count_prepared']==7
assert sha(raw)==r['raw']['sha256']
for name,hash in r['source'].items():assert sha(root/name)==hash,name
core_path=root/'docs/development/validation/steering-capture-host-2026-10-07.json'
core=json.loads(core_path.read_text())
for name,hash in core['source'].items():
    if name!='CMakeLists.txt':assert sha(root/name)==hash,name
out.mkdir();copied=[];excluded=0
p=subprocess.Popen(['git','archive','--format=tar',commit],stdout=subprocess.PIPE)
try:
    with tarfile.open(fileobj=p.stdout,mode='r|') as t:
        for m in t:
            name=Path(m.name)
            assert not name.is_absolute() and '..' not in name.parts and (m.isfile() or m.isdir())
            if name.parts[0]=='docs':
                if m.isfile():excluded+=1
                continue
            t.extract(m,out,filter='data')
            if m.isfile():copied.append(m.name)
finally:p.stdout.close()
assert p.wait()==0
for name in copied:assert sha(out/name)==sha(root/name),name
upstream=root/'.deps/gufo-f783fedb';manifest=json.loads((out/'third_party/gufo-source.json').read_text())
pin='f783fedb9bea2ec7de941f6da4e02f4a4596b29e'
assert upstream.resolve()==upstream and manifest['commit']==pin and len(manifest['files'])==1019
for name,hash in manifest['files'].items():
    p=upstream/name;assert not p.is_symlink() and p.resolve().is_relative_to(upstream) and sha(p)==hash
    dest=out/'.deps/gufo-f783fedb'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    assert sha(dest)==hash
text=(out/'cmake/provider/Source.cmake').read_text()
recipes=re.search(r'set\(manifests ([^)]*)\)',text).group(1).split()
assert 'list(APPEND manifests activation-observer-edits.json)' in text
recipes+=['activation-observer-edits.json','kvc-edits.json']
assert len(recipes)==len(set(recipes))==43
files=dict(manifest['files']);changed={};edits=0;hashes={}
for name in recipes:
    p=out/'adapters/gufo-state'/name;recipe=json.loads(p.read_text());assert recipe['source_pin']==pin
    hashes[name]=sha(p)
    for edit in recipe['edits']:
        path=edit['path'];content=changed.get(path)
        if content is None:content=(upstream/path).read_text()
        assert edit['old'] and content.count(edit['old'])==1,(name,path)
        changed[path]=content.replace(edit['old'],edit['new'],1);edits+=1
        files[path]=hashlib.sha256(changed[path].encode()).hexdigest()
assert files==json.loads((root/'evidence/steering-capture-host-r1/variant-files.json').read_text())
assert len(changed)==23 and edits==342
prior_path=root/'evidence/context-r11-build-r2/result.json'
prior=json.loads(prior_path.read_text())['build_result'];zstd={}
for name,key in {'zstd.h':'zstd_header_sha256','zstd_errors.h':'zstd_errors_sha256','LICENSE':'zstd_license_sha256'}.items():
    p=root/'evidence/context-source-modern-r11/third_party/point-zstd-dev'/name
    assert p.is_file() and not p.is_symlink() and sha(p)==prior[key]
    dest=out/'third_party/point-zstd-dev'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);zstd[name]=sha(dest)
ryu=json.loads((out/'third_party/ryu-source.json').read_text())
for name,identity in ryu['files'].items():assert sha(out/'third_party/ryu'/name)==identity['sha256']
(out/'SOURCE-COMMIT.txt').write_text(commit+'\n');(out/'CODE-CHECKPOINT.txt').write_text(commit+'\n')
paths=sorted(p for p in out.rglob('*') if p.is_file());assert all(not p.is_symlink() for p in paths)
(out/'SOURCE-FILES.sha256').write_text(''.join(sha(p)+'  ./'+str(p.relative_to(out))+'\n' for p in paths))
with archive.open('xb') as f:
    with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as t:t.add(out,arcname=label)
record={'scope':'LOCAL_SEALED_COMPILER_INPUTS_NOT_REMOTE_BUILD_OR_GPU','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':commit,'code_checkpoint':commit,'engine_code_checkpoint':commit,'previous_goal_turn':'PROGRESS-4c703b3d-native-C17-paired-steering-builder-HOST-Debug4-SAN4','steering_build_host_receipt_sha256':sha(receipt_path),'steering_build_host_archive_sha256':sha(raw),'steering_capture_host_receipt_sha256':sha(core_path),'native_client_tests':r['CTest_count'],'provider_source':{'pristine_files':1019,'recipes':43,'edits':edits,'changed_files':len(changed),'recipe_sha256':hashes},'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'source_files_sha256':sha(out/'SOURCE-FILES.sha256'),'source_files':len(paths),'compile_helper_sha256':sha(out/'cmake/point/Build.cmake'),'runner_sha256':sha(out/'tools/strix-point-campaign.py'),'gufo_pin':pin,'pristine_gufo_files_verified':1019,'owned_sampling_file_inventory':122,'owned_steering_files':10,'zstd_prior_receipt_sha256':sha(prior_path),'zstd_development_sha256':zstd,'ryu_pin':ryu['commit'],'unchanged_Ryu_files_verified':len(ryu['files']),'tracked_compiler_files_verified':len(copied),'excluded_documentation_files':excluded,'seven_required_consumer_targets':['synapse-lie-server','synapse-lie-bench','synapse-lie-bench-gufo-reference','lie-hip-probe','lie-sampling-capture','lie-attention-qualify','lie-steering-build'],'remote_stage_build_or_GPU_run':False,'original_model_activation_or_learned_quality_qualified':False,'all_six_tasks_remain_open':True}
with (root/'evidence/context-r70-source-seal.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({k:record[k] for k in ('scope','source_commit','archive_bytes','source_files','tracked_compiler_files_verified','provider_source')}),flush=True)
