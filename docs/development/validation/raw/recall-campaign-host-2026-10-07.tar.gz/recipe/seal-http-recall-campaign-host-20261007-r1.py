# SPDX-License-Identifier: MIT
"""Seal local checking evidence only; never runs or admits GPU/model work."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT/'evidence/http-recall-campaign-host-2026-10-07-r1'
PUBLIC = ROOT/'docs/development/validation/recall-campaign-host-2026-10-07.json'
RAW = ROOT/'docs/development/validation/raw/recall-campaign-host-2026-10-07.tar.gz'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

assert not PUBLIC.exists() and not RAW.exists()
base = '90a884558c79ed696918e2ddfafefc3227659962'
native_paths = ['src', 'include', 'tools/native', 'tools/core-bench.c', 'tools/lie-bench.c',
                'CMakeLists.txt', 'cmake', 'third_party/gufo/CMakeLists.txt']
delta = subprocess.run(['git', 'diff', '--name-only', base, '--', *native_paths],
                       cwd=ROOT, capture_output=True, text=True, check=True)
assert not delta.stdout.strip(), delta.stdout
checks = [
    ('final coordinator and real native C wire fixtures', 'checks-native-r3.log', 18),
    ('same native C fixtures with unsuppressed ASan/UBSan/LSan', 'checks-native-asan-r1.log', 18),
    ('existing supervisor regression', 'campaign-regression-r2.log', 87)]
for _, name, count in checks:
    text = (WORK/name).read_text()
    assert f'Ran {count} tests' in text and '\nOK\n' in text
for name in ('native-ctest-r1.log', 'native-asan-ctest-r1.log'):
    assert '100% tests passed' in (WORK/name).read_text()
for name in ('native-build-r2', 'native-asan-build-r1'):
    value = json.loads((WORK/name/'result.json').read_text())
    assert value['exit_code'] == value['child_exit_code'] == 0 and value['reason'] is None
assert json.loads((WORK/'native-build-r1/result.json').read_text())['exit_code'] == 2
assert 'FAILED (errors=2)' in (WORK/'checks-native-r1.log').read_text()
for run in ('native-wire-r3', 'native-wire-asan-r1'):
    for kind, code in (('passed', 0), ('quality-failed', 1)):
        value = json.loads((WORK/run/kind/'fixture-wire.json').read_text())
        assert value['classification'] == 'HOST_SYNTHETIC_HTTP_NOT_MODEL_INFERENCE'
        assert value['client_exit_code'] == code and len(value['actual_fixture_requests']) == 5
        assert not (WORK/run/kind/'client.stderr.log').read_bytes()
sources = ['tools/strix-point-campaign.py', 'tools/strix-point-http-recall-gate.py',
           'tests/test_strix_point_http_recall.py',
           'docs/development/protocols/LONG-CONTEXT-RECALL-GPU-PROTOCOL.md', 'LICENSE']
members = [(path, 'host/'+str(path.relative_to(WORK)))
           for path in sorted(WORK.rglob('*')) if path.is_file() and not path.is_symlink()]
members += [(ROOT/name, 'source/'+name) for name in sources]
members.append((Path(__file__), 'recipe/'+Path(__file__).name))
inventory = [{'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path)} for path,name in members]
RAW.parent.mkdir(parents=True, exist_ok=True)
with tarfile.open(RAW, 'x:gz') as archive:
    for path, name in members:
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(RAW, 'r:gz') as archive:
    assert len(archive.getmembers()) == len(inventory)
    for item in inventory:
        data = archive.extractfile(item['path']).read()
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
result = {
    'schema': 'synapse-lie.recall-campaign-host.v1',
    'classification': 'HOST_CHECKING_CODE_AND_NATIVE_HTTP_FIXTURES_NOT_MODEL_INFERENCE',
    'state': 'HOST_PASSED_GPU_PENDING',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'worktree_parent_commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'native_source_base': base, 'native_source_delta': [],
    'checker_sources': {name:sha(ROOT/name) for name in sources if name != 'LICENSE'},
    'checks': [{'scope':scope,'log':name,'grouped_tests':count,'actual_exit_code':0}
               for scope,name,count in checks],
    'native_ctest': {'normal_checks':1,'sanitizer_checks':1,'actual_exit_codes':[0,0]},
    'sanitizers': {'address':True,'undefined':True,'leak_detection':True,'suppressions':False},
    'native_binaries_not_bundled': {
        'normal': sha(ROOT/'build/context-debug/synapse-lie-bench'),
        'asan_ubsan': sha(ROOT/'build/tool-http-asan/synapse-lie-bench')},
    'expected_native_fixture_exits': {'correct_answers':0,'wrong_first_answer_second_turn_retained':1},
    'preserved_failures': [
        {'actual_exit_code':2,'path':'host/native-build-r1/result.json',
         'cause':'Native bench linked successfully; initial stale Makefile lacked the newly generated recall test target. Next focused target invocation succeeds.'},
        {'actual_exit_code':1,'path':'host/checks-native-r1.log',
         'cause':'Coordinator used incorrect corpus metadata names. Real native client exported both complete corpora with expected exits0/1. Coordinator/fixtures corrected to unchanged native schema; original questions and oracles unchanged.'}],
    'raw': {'path':'raw/'+RAW.name,'bytes':RAW.stat().st_size,'sha256':sha(RAW),
            'members':len(inventory),'inventory':inventory},
    'scope_limits': ['Synthetic counters/replies are not tokenization, GPU, model quality or performance evidence.',
                     'No production ABI, model/kernel, reactive, state-format or metrics changes.',
                     'No model forward/hash, remote build, GPU job, lease or window admission.',
                     'Optional development Python coordinator; native products/default tests unchanged.'],
    'actual_exit_code':0}
with PUBLIC.open('x') as output:
    output.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'receipt':str(PUBLIC),'raw_members':len(inventory),
                  'raw_sha256':sha(RAW),'actual_exit_code':0}))
