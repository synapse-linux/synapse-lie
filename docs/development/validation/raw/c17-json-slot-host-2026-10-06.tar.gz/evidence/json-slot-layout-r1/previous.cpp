#include "/home/paperboy/workspace/projects/synapse-linux/synapse-lie/worktrees/context-million-openai/evidence/context-source-modern-r34/adapters/gufo_json_value.hpp"
#include <cstdio>
int main() { std::printf("%zu %zu %zu\n",sizeof(gufo::json::Value),sizeof(gufo::json::Value::Array),sizeof(gufo::json::Value::Object)); }
