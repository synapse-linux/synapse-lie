# SPDX-License-Identifier: MIT
"""Compile only sizeof metadata; no model/provider link or inference."""
from pathlib import Path
import json, subprocess

base=Path.cwd()
out=base/'evidence/json-slot-layout-r1'
out.mkdir(exist_ok=False)
values={}
commands=[]
for name,header in [('previous',base/'evidence/context-source-modern-r34/adapters/gufo_json_value.hpp'),
                    ('current',base/'adapters/gufo_json_value.hpp')]:
    assert header.is_file()
    source=out/(name+'.cpp')
    source.write_text('#include "'+str(header)+'"\n#include <cstdio>\nint main() { std::printf("%zu %zu %zu\\n",sizeof(gufo::json::Value),sizeof(gufo::json::Value::Array),sizeof(gufo::json::Value::Object)); }\n')
    argv=['c++','-std=c++20','-O0','-I',str(base/'include'),str(source),'-o',str(out/name)]
    compile_run=subprocess.run(argv,capture_output=True,text=True)
    commands.append({'argv':argv,'actual_exit_code':compile_run.returncode,'stdout':compile_run.stdout,'stderr':compile_run.stderr})
    assert compile_run.returncode==0,compile_run.stderr
    run=subprocess.run([str(out/name)],capture_output=True,text=True)
    commands.append({'argv':[str(out/name)],'actual_exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr})
    assert run.returncode==0
    values[name]=[int(value) for value in run.stdout.split()]
assert values['current']==values['previous']
result={'state':'HOST_LAYOUT_UNCHANGED','scope':'sizeof metadata of previous frozen owned facade and current owned facade; no runtime/model/numerical or performance qualification',
        'Value_Array_Object_bytes':values,'commands':commands}
with (out/'result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
