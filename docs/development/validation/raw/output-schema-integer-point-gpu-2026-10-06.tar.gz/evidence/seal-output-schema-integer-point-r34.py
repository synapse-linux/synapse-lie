#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Seal completed functional checks; no model, build or remote operation."""
from pathlib import Path
from decimal import Decimal
import datetime, gzip, hashlib, json, tarfile

BASE = Path('evidence')
COMMIT = '050ae82641f14565ddb201fafaf6905aeb28870c'
HOST = Path('docs/development/validation/output-schema-integer-host-2026-10-06.json')
OUT = Path('docs/development/validation/output-schema-integer-point-gpu-2026-10-06.json')
ARCHIVE = Path('docs/development/validation/raw/output-schema-integer-point-gpu-2026-10-06.tar.gz')

def load(p):
    return json.loads(Path(p).read_text())

def sha(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def bound(p):
    p = Path(p)
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}

assert not OUT.exists() and not ARCHIVE.exists()
host = load(HOST)
assert sha(HOST) == '8f6e6c6402150e41184fb45e6ba767ed29a00c45be0804839679a7d82ce902f3'
build = BASE/'context-r34-build-r1'
provider_paths = [build/f'compile-evidence/build/rocm10-point-modern-r34-{s}/BUILD-RECEIPT.json'
                  for s in ('provider', 'reference-provider')]
providers = [load(p) for p in provider_paths]
for p, selected in zip(providers, (True, False)):
    assert p['owned_sampling_files'] == host['private_provider_inventory']
    assert len(p['owned_sampling_files']) == 105
    assert p['c17_sampling'] is selected and p['hip_architecture'] == 'gfx1150'
compile_collection = load(build/'compile-evidence/collection-validation-r2.json')
coherence = load(build/'coherence-evidence/collection.json')
assert compile_collection['exit_code'] == coherence['exit_code'] == 0
assert compile_collection['reference_control_coherent_off']
assert coherence['whole_OFF_reference_archives']
assert coherence['compiled_frontend_primary_C17_ON'] and coherence['compiled_frontend_reference_C17_OFF']
for directory, record in [('compile-evidence', compile_collection), ('coherence-evidence', coherence)]:
    for name, identity in record['files'].items():
        p = build/directory/name
        assert p.stat().st_size == identity['bytes'] and sha(p) == identity['sha256']

runs = []
for mode, label in [('build', 'context-r34-build-r1'), ('ar', 'context-r34-integer-ar-r1'), ('mtp', 'context-r34-integer-mtp-r1')]:
    p = BASE/label
    r, c, m = load(p/'result.json'), load(p/'collection.json'), load(p/'manifest.json')
    controller = load(p/'controller-result.json')
    assert r['state'] == 'PASSED'
    assert r['exit_code'] == r['child_exit_code'] == c['exit_code'] == controller['exit_code'] == 0
    assert m['source_commit'] == COMMIT and r['ended_at'] and r['lease_released_at']
    assert not r['cleanup_failures'] and r['service_after']['ActiveState'] == 'active'
    assert (r['lease']['device'], r['lease']['inode']) == (66307, 105946405)
    assert not r['postflight_before_restore']['kernel_kfd']
    for name, identity in c['inventory']['files'].items():
        f = p/name
        assert f.stat().st_size == identity['bytes'] and sha(f) == identity['sha256']
    rows = [json.loads(line) for line in (p/'telemetry.jsonl').read_text().splitlines()]
    peaks = {}
    for row in rows:
        for t in row['temperatures']:
            peaks[t['name']] = max(peaks.get(t['name'], -100), t['value_c'])
            assert not t['guarded'] or t['value_c'] < t['limit_c']
    entry = dict(label=label, mode=mode, source_commit=COMMIT,
                 started_at=r['started_at'], ended_at=r['ended_at'],
                 supervisor_pid=r['pid'], supervisor_start_ticks=r['start_ticks'],
                 container=r['container'], original_lease=r['lease'],
                 lease_released_at=r['lease_released_at'], router_restored=r['service_after'],
                 actual_exit_code=0, child_exit_code=0, controller_exit_code=0,
                 peak_c=peaks, telemetry_rows=len(rows),
                 artifacts=[bound(p/name) for name in sorted(c['inventory']['files'])]
                           + [bound(p/'collection.json'), bound(p/'controller-result.json')])
    if mode == 'build':
        assert not r['model_attempted']
    else:
        h, integer = load(p/'http-result.json'), load(p/'http-schema-integer-result.json')
        assert r['model_attempted'] and r['model_stat_unchanged']
        assert h['state'] == integer['state'] == 'PASSED' and h['mode'] == mode
        assert h['server_exit_code'] == 0
        assert len(h['passed']) == len(set(h['passed'])) == 37
        assert h['schema_integer_checks'] == len(integer['passed']) == len(set(integer['passed'])) == 66
        assert set(integer['passed']) == set(integer['witnesses'])
        values = refusals = 0
        for name, w in integer['witnesses'].items():
            if '_refusal_' in name:
                assert w['status'] == 400 and w['error']['type'] == 'invalid_request_error'
                refusals += 1
                continue
            value = json.loads(w['text'], parse_int=Decimal, parse_float=Decimal)['value']
            assert value == Decimal(w['lexeme']) == Decimal(w['value'])
            assert value.is_finite() and value == value.to_integral_value()
            assert Decimal(w['low']) <= value <= Decimal(w['high'])
            for key, limit in w['bounds'].items():
                limit = Decimal.from_float(limit) if isinstance(limit, float) else Decimal(limit)
                if key == 'minimum': assert value >= limit
                elif key == 'maximum': assert value <= limit
                elif key == 'exclusiveMinimum': assert value > limit
                elif key == 'exclusiveMaximum': assert value < limit
            values += 1
        assert (values, refusals) == (60, 6)
        entry.update(checks=37, passed=h['passed'], integer_checks=66,
                     integer_exact_values=values, expected_HTTP400_refusals=refusals,
                     integer_witnesses=integer['witnesses'], server_exit_code=0,
                     model_stat_unchanged=True, server_argv=h['server_argv'],
                     gtt_peak_bytes=max(row['gpu']['mem_info_gtt_used'] for row in rows
                         if row['gpu']['mem_info_gtt_used'] is not None),
                     observed_process_threads_max=max((int(proc['status']['Threads'])
                         for row in rows for proc in row['dri']
                         if proc.get('status', {}).get('Threads')), default=None))
    runs.append(entry)
assert runs[1]['passed'] == runs[2]['passed']
final_path = BASE/'context-r34-mtp-closure-r1.json'
final = load(final_path)
assert final['actual_exit_code'] == 0
f = final['result']
assert f['state'] == 'FRESH_INTEGER_BUILD_AR_MTP_WINDOWS_CLOSED_NO_STANDING_RESERVATION'
assert f['original_lease']['free_briefly'] and f['original_lease']['released']
assert not f['foreign_compute_clients'] and not f['guarded_hot'] and not f['http8000_listeners']
assert len(f['owned_window_closures']) == 3
for run, closed in zip(runs, f['owned_window_closures']):
    assert run['label'] == closed['label'] and closed['supervisor_identity_absent']
    assert closed['container_absent'] and closed['container_init_identity_absent'] is True
    assert closed['container_init_identity_recorded'] and closed['label_listing_exit'] == 0
    assert closed['label_listing_empty']
    run['actual_window_retired'] = True
    run['closure'] = closed
source = load(BASE/'context-r34-source-seal.json')
bundle = load(BASE/'context-r34-bundle-result.json')
assert source['source_commit'] == bundle['result']['metadata']['source_commit'] == COMMIT
assert bundle['exit_code'] == 0
source_manifest = BASE/'context-source-modern-r34/SOURCE-FILES.sha256'
assert sha(source_manifest) == source['source_files_sha256']
assert len(source_manifest.read_text().splitlines()) == 2779

paths = {str(p) for pattern in ['context-r34-*.json', 'context-r34-*.py']
         for p in BASE.glob(pattern) if p.is_file() and not p.is_symlink()}
for run in runs:
    paths.update(a['path'] for a in run['artifacts'])
paths.update(str(p) for directory in ['compile-evidence', 'coherence-evidence']
             for p in (build/directory).rglob('*') if p.is_file() and not p.is_symlink())
paths.update([str(source_manifest), str(HOST), 'LICENSE', 'third_party/README.md',
              'evidence/seal-output-schema-integer-point-r34.py'])
inventory = [bound(p) for p in sorted(paths)]
ARCHIVE.parent.mkdir(exist_ok=True)
with ARCHIVE.open('xb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', mtime=0, compresslevel=3) as z:
        with tarfile.open(fileobj=z, mode='w') as t:
            for item in inventory:
                p = Path(item['path'])
                info = t.gettarinfo(str(p), arcname=str(p))
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                with p.open('rb') as content:
                    t.addfile(info, content)
receipt = dict(schema='synapse-lie.output-schema-integer-point-original-qualification.v1',
    at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), state='PASSED_WITH_STATED_SCOPE',
    source_commit=COMMIT, target='pop@192.168.5.161', gpu_target='gfx1150',
    model='Qwen3.8-Flash-Next UD-Q4_K_XL', upstream_pin=source['gufo_pin'],
    scope='Exact shared C17 integer membership and endpoint validation on original weights: 37 unchanged OpenAI checks plus 66 independent integer JSON/SSE checks in each AR/MTP mode. Rebuilt coherent ON/OFF105 providers and private consumers. Selected bounded integers only; no whole JSON Schema, model executor, independent probability/recall/quality/fault/performance qualification.',
    host_receipt=bound(HOST), source_capsule=bound(BASE/'context-r34-source-seal.json'),
    source_manifest=bound(source_manifest), bundle=bound(BASE/'context-r34-bundle-result.json'),
    provider_build_receipts=[bound(p) for p in provider_paths],
    compile_collection=bound(build/'compile-evidence/collection-validation-r2.json'),
    compiler_linker_coherence=bound(build/'coherence-evidence/collection.json'),
    compiled_provider_files=providers[0]['owned_sampling_files'],
    official_Gufo_HTTP_frontend_built=False, reference_control_coherent_off=True,
    runs=runs, binaries=bundle['result']['metadata']['artifacts'],
    coordination=[bound(p) for p in sorted(BASE.glob('context-r34-peer-*.json'))],
    fresh_preflights=[bound(BASE/n) for n in ['context-r34-fresh-161-r2.json',
                     'context-r34-before-ar-r1.json', 'context-r34-before-mtp-r1.json']],
    final_fresh_closure=bound(final_path),
    retained_collection_failure=bound(build/'compile-evidence/collection.json'),
    collection_failure_scope='Original collector exits1 after25 successful verified transfers because it compares the preceding HOST105 inventory. New local validation uses the matching current HOST105 inventory. No build/inference/transfer rerun.',
    retained_failures=[bound(p) for p in sorted(BASE.glob('context-r34-*failure*.json'))],
    previous_failed_GPU_result=bound('evidence/context-r33-integer-ar-r1/result.json'),
    previous_failed_GPU_portable_HOST_archive=bound('docs/development/validation/raw/output-schema-integer-host-2026-10-06.tar.gz'),
    new_inference_threads=0, existing_public_ABI_breaking_change=False,
    new_contract='Additive lie_schema_integer_compare within schema_integer ABI1; raw borrowed JSON numeric span, constant stack and exact represented finite binary64 bounds.',
    thermal_policy='CPU98/NVMe85/lower exposed guards; GPU observe-only. No fan/clock/power tuning.',
    KV_cache_payload_format_changed=False, root_157_158_non_use=True,
    Terminal_Bench='STOPPED_COLLECTED_CLOSED_DEFERRED_LAST',
    all_six_owned_tasks_open=True,
    pending=['Terminal Bench Core-19 last after functional changes and qualification.',
             'Independent 1M recall and native HTTP qualification.',
             'Matched Gufo/Halogen context, concurrency, resources, threads and graphs.',
             'Broader learned DS4 steering quality/faults/vision/cost.',
             'Independent original-weight sampling probabilities/filter/tool transitions/cost.',
             'Remaining C17 typed construction/bootstrap/callback errors/model-controller and broader numeric/branch/fault/resource/quality/cost qualification.'],
    general_fractional_bounds_numeric_enum_const_multipleOf_qualified=False,
    portable_archive=bound(ARCHIVE), portable_archive_inventory=inventory,
    publication=False, goal_complete=False)
with OUT.open('x') as out:
    json.dump(receipt, out, indent=2); out.write('\n')
print(json.dumps({'receipt': str(OUT), 'sha256': sha(OUT), 'archive_bytes': ARCHIVE.stat().st_size,
                  'archive_members': len(inventory), 'checks_per_mode': [37, 66],
                  'peaks_C': {r['mode']: r['peak_c'] for r in runs},
                  'threads_max': {r['mode']: r.get('observed_process_threads_max') for r in runs},
                  'all_six_tasks_open': True}))
