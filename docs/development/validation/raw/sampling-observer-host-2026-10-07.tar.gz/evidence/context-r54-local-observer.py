# SPDX-License-Identifier: MIT
"""Focused owned sampling-observer HOST checks; no GPU/model/build remote."""
from pathlib import Path
import datetime,json,os,subprocess,sys
root=Path.cwd();folder=root/'evidence/context-r54-local-observer'
folder.mkdir(exist_ok=False);commands=[]
def run(name,argv,env=None):
    with (folder/(name+'.log')).open('x') as log:
        p=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,env=env)
    r={'name':name,'argv':argv,'actual_exit_code':p.returncode}
    commands.append(r)
    with (folder/'commands.json').open('w') as f:json.dump(commands,f,indent=2);f.write('\n')
    print(json.dumps(r),flush=True)
    if p.returncode:raise SystemExit(p.returncode)
for mode in ('release','asan'):
    provider='build/sampling-observer-r1-'+mode
    native='build/sampling-observer-native-r1-'+mode
    flags=['-DCMAKE_BUILD_TYPE='+('Release' if mode=='release' else 'Debug'),
           '-DLIE_SANITIZERS='+('OFF' if mode=='release' else 'ON')]
    run(mode+'-provider-configure',['cmake','-S','tests/sampling','-B',provider,*flags])
    run(mode+'-provider-build',['cmake','--build',provider,'--parallel','2','--target',
                              'candidate-sampling-observer','fallback-sampling-observer'])
    env=os.environ.copy()
    if mode=='asan':
        env['ASAN_OPTIONS']='detect_leaks=1:halt_on_error=1'
        env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
    run(mode+'-provider-tests',['ctest','--test-dir',provider,'--output-on-failure',
                               '-R','^(candidate|fallback)-sampling-observer$'],env)
    run(mode+'-native-configure',['cmake','-S','.','-B',native,*flags])
    run(mode+'-native-build',['cmake','--build',native,'--parallel','2','--target','test-executor-abi'])
    run(mode+'-native-tests',['ctest','--test-dir',native,'--output-on-failure','-R','^executor-c-layout$'],env)
result={'schema':'synapse-lie.sampling-observer-host.v1',
        'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'actual_exit_code':0,'commands':commands,'GPU_model_remote_work':False,
        'classification':'HOST-NOT-INFERENCE'}
with (folder/'result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
