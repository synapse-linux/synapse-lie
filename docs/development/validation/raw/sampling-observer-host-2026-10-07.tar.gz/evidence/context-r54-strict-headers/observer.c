/* SPDX-License-Identifier: MIT */
#include "lie/sampling_observer.h"
_Static_assert(LIE_SAMPLING_OBSERVER_ABI == 1u, "observer ABI");
