# SPDX-License-Identifier: MIT
from pathlib import Path
import json,subprocess
folder=Path('evidence/context-r54-strict-headers');commands=[]
for name,argv in [('c17',['cc','-std=c17','-pedantic-errors','-Wall','-Wextra','-Werror','-Iinclude','-fsyntax-only',str(folder/'observer.c')]),
                  ('cpp17',['c++','-std=c++17','-pedantic-errors','-Wall','-Wextra','-Werror','-Iinclude','-fsyntax-only',str(folder/'observer.cpp')])]:
    with (folder/(name+'.log')).open('x') as f:run=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
    commands.append({'argv':argv,'actual_exit_code':run.returncode})
    if run.returncode:raise SystemExit(run.returncode)
with (folder/'result.json').open('x') as f:json.dump({'actual_exit_code':0,'commands':commands},f,indent=2);f.write('\n')
print(json.dumps({'strict_public_C17_Cpp17':True,'actual_exit_code':0}))
