# SPDX-License-Identifier: MIT
"""Seal finished HOST observation checks; no test, GPU, model or remote call."""
from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
root=Path.cwd();dest=root/'docs/development/validation';name='sampling-observer-host-2026-10-07'
receipt=dest/(name+'.json');archive=dest/'raw'/(name+'.tar.gz')
assert not receipt.exists() and not archive.exists()
def read(path):return json.loads((root/path).read_text())
def ident(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':digest}
first=read('evidence/context-r54-local-observer/commands.json')
failed=read('evidence/context-r54-local-observer-guard/result.json')
assert first[-1]['name']=='asan-provider-tests' and first[-1]['actual_exit_code']==8
assert failed['exit_code']==failed['child_exit_code']==8 and failed['reason'] is None
assert 'LeakSanitizer does not work under ptrace' in (root/'evidence/context-r54-local-observer/asan-provider-tests.log').read_text()
second=read('evidence/context-r54-local-observer-r2/result.json')
guard=read('evidence/context-r54-local-observer-r2-guard/result.json')
assert second['actual_exit_code']==guard['exit_code']==guard['child_exit_code']==0
assert len(second['commands'])==8 and all(r['actual_exit_code']==0 for r in second['commands'])
strict=read('evidence/context-r54-strict-headers/result.json')
strict_guard=read('evidence/context-r54-strict-headers-guard/result.json')
assert strict['actual_exit_code']==strict_guard['exit_code']==strict_guard['child_exit_code']==0
assert len(strict['commands'])==2 and all(r['actual_exit_code']==0 for r in strict['commands'])
owned=['adapters/gufo.cpp','adapters/gufo_sampling_observer.hpp','adapters/gufo-state/sampling-observer-edits.json',
       'include/lie/sampling_observer.h','src/executor_unavailable.c',
       'cmake/provider/Source.cmake','cmake/provider/Build.cmake','cmake/provider/Verify.cmake',
       'tests/provider_contract.cmake','tests/test_executor_abi.c','tests/sampling/observer.cpp','tests/sampling/CMakeLists.txt']
files={rel:root/rel for rel in owned}
for path in root.glob('evidence/context-r54-*'):
    if path.is_file():files[str(path.relative_to(root))]=path
    elif path.name in ('context-r54-local-observer','context-r54-local-observer-guard',
       'context-r54-local-observer-r2','context-r54-local-observer-r2-guard',
       'context-r54-strict-headers','context-r54-strict-headers-guard'):
        for child in path.iterdir():
            if child.is_file():files[str(child.relative_to(root))]=child
binary_inventory={};tests=[];variant=None
for mode in ('release','asan'):
    for kind,count in (('sampling-observer-r1-',2),('sampling-observer-native-r1-',4)):
        folder=root/'build'/(kind+mode);p=folder/'Testing/Temporary/LastTest.log';text=p.read_text()
        assert text.count('Test Passed.')==count and 'Test Failed.' not in text
        if count==2:assert text.count('SAMPLING_OBSERVER_LIFETIME_RNG_MASK_PROPOSAL_RESIDUAL_PASS_HOST_NOT_INFERENCE')==2
        files[str(p.relative_to(root))]=p
        tests.append({'configuration':mode,'scope':'observer-ON-OFF' if count==2 else 'ABI-and-source-receipt-target-provenance','passed':count,'failed':0})
        binaries=('candidate-sampling-observer','fallback-sampling-observer') if count==2 else ('test-executor-abi',)
        for binary in binaries:binary_inventory[str((folder/binary).relative_to(root))]=ident(folder/binary)
        if count==2:
            path=folder/'variant-files.json';v=read(str(path.relative_to(root)))
            assert len(v)==1019
            if variant is None:variant=v
            assert variant==v
            files[str(path.relative_to(root))]=path
            for rel in ('src/core/sampling.hpp','src/models/qwen38_flash_next/engine.cpp'):
                path=folder/'variant'/rel;assert ident(path)['sha256']==v[rel]
                files[str(path.relative_to(root))]=path
            files[str((folder/'CMakeCache.txt').relative_to(root))]=folder/'CMakeCache.txt'
for rel in ('CMakeLists.txt','include/lie/executor.h','include/lie/mtp.h','include/lie/sampling.h',
            'tools/thermal-run.py','evidence/seal-context-r54-observer.py'):
    files[rel]=root/rel
members={rel:ident(path) for rel,path in sorted(files.items())}
with tarfile.open(archive,'x:gz') as packed:
    for rel in members:packed.add(files[rel],arcname=rel,recursive=False)
with tarfile.open(archive,'r:gz') as packed:
    entries=packed.getmembers();assert len(entries)==len(members)
    for entry in entries:
        assert entry.isfile() and 'sealing-guard' not in entry.name and 'postseal-guard' not in entry.name
        with packed.extractfile(entry) as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
        assert {'bytes':entry.size,'sha256':digest}==members[entry.name]==ident(files[entry.name])
head=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
r={'schema':'synapse-lie.sampling-observer-host.v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
   'state':'OWNER_ONLY_OBSERVATION_HOST_PASSED_GPU_AND_CLIENT_INTEGRATION_PENDING','base_commit':head,
   'source_pin':'f783fedb9bea2ec7de941f6da4e02f4a4596b29e','observer_ABI':1,
   'classification':'HOST-NOT-INFERENCE','implementation_sources':{rel:members[rel] for rel in owned},
   'source_recipe_edits':5,'owned_sampling_file_inventory':122,'variant_files_verified':1019,
   'release_and_sanitizer_tests':tests,'strict_public_headers':strict,
   'initial_sandboxed_failure':{'guard':failed,'commands':first,'reason':'LeakSanitizer process introspection unavailable under sandbox ptrace; not suppressed.'},
   'final_unsuppressed_host_checks':second,'final_host_guard':guard,'strict_header_guard':strict_guard,
   'qualified_host_binary_inventory':binary_inventory,
   'semantic_scope':['target draw and RNG equivalence','compact proposal masses and RNG equivalence',
                     'accepted and rejected verification equivalence','grammar-mask projection',
                     'deferred correction does not draw again','borrowed lifetime and exceptional scope cleanup',
                     'unavailable ABI preserves output','source/recipe/target provenance refusals'],
   'C17_contract_Cpp_interop_only':True,'numerical_algorithm_changed':False,'new_thread_or_HTTP_option':False,
   'production_observer_requires_explicit_diagnostic_call':True,
   'existing_AR_capture_client_changed':False,'MTP_capture_writer_replay_complete':False,
   'adapter_entry_point_HIP_compilation_qualified':False,'GPU_original_weight_probabilities_qualified':False,
   'new_GPU_model_remote_operation':False,'Python_product_dependency_added':False,
   'next_gate':'Integrate native MTP writer and independent replay; coherent HIP build and original-weight numerical/controller qualification with fresh .161 admission.',
   'open_task_numbers':[2,3,4,5,6,7],'goal_complete':False,'publication':False,
   'portable_raw_archive':{'path':'raw/'+archive.name,**ident(archive),'members':len(members)},'raw_artifacts':members}
with receipt.open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps({'receipt':str(receipt.relative_to(root)),'archive':r['portable_raw_archive'],'state':r['state']}))
