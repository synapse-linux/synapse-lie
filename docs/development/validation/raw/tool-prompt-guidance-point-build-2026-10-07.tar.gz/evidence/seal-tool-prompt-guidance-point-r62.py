# SPDX-License-Identifier: MIT
"""Seal completed Point compilation evidence; no build/model/remote work."""
from pathlib import Path
import datetime, gzip, hashlib, io, json, subprocess, tarfile

root = Path.cwd()
base = root / 'evidence/context-r62-build-r1'
dest = root / 'docs/development/validation'
name = 'tool-prompt-guidance-point-build-2026-10-07'
out = dest / (name + '.json')
archive = dest / 'raw' / (name + '.tar.gz')
assert not out.exists() and not archive.exists()

def read(rel):
    return json.loads((root / rel).read_text())

def bound(path):
    assert path.is_file() and not path.is_symlink(), path
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': sha}

job = read('evidence/context-r62-build-r1/result.json')
controller = read('evidence/context-r62-build-r1/controller-result.json')
verification = read('evidence/context-r62-build-r1/compile-verification-r1/result.json')
seal = read('evidence/context-r62-source-seal.json')
bundle = read('evidence/context-r62-bundle-result.json')
closure = read('evidence/context-r62-build-closure-r2.json')
peers = read('evidence/context-r62-peer-coordination.json')
assert job['state'] == 'PASSED'
assert job['exit_code'] == job['child_exit_code'] == controller['exit_code'] == 0
assert job['model_attempted'] is False and not job['cleanup_failures']
assert verification['exit_code'] == closure['actual_exit_code'] == bundle['exit_code'] == 0
assert verification['source_commit'] == seal['source_commit'] == bundle['result']['metadata']['source_commit']
assert len(verification['recipes_verified']) == seal['provider_source']['recipes'] == 42
assert seal['provider_source']['edits'] == 338
assert verification['complete_variant_files_per_variant'] == seal['pristine_gufo_files_verified'] == 1019
assert verification['private_provider_files_per_variant'] == seal['owned_sampling_file_inventory'] == 122
assert seal['tracked_compiler_files_verified'] == 713
assert peers['explicit_current_161_non_use_from_all_three'] is True
assert peers['acknowledged_current_boot_rebind_from_all_three'] is True
assert subprocess.run(['git', 'rev-parse', 'HEAD'], check=True, capture_output=True,
                      text=True).stdout.strip() == seal['source_commit']
changed = subprocess.run(['git', 'diff', '--name-only', 'HEAD'], check=True,
                         capture_output=True, text=True).stdout.splitlines()
assert set(changed) == {'docs/PROGRESS.md', 'docs/BACKEND.md', 'docs/COORDINATION.md',
                        'docs/reference/ABI.md', 'third_party/README.md'}
closed = closure['result']
assert peers['boot_id'] == closed['boot_id'] == '7a966774-3424-46c3-8045-34f759ea58a1'
assert (job['lease']['device'],job['lease']['inode']) == (66308,105946405)
initial = read('evidence/context-r62-fresh-161-r1.json'); assert initial['actual_exit_code'] == 1
diagnosis = read('evidence/context-r62-lease-diagnosis-r1.json'); assert diagnosis['actual_exit_code'] == 0
assert diagnosis['result']['paths']['campaign.lock']['inode'] == 105946405
assert job['runner_sha256'] == seal['runner_sha256']
assert closed['state'] == 'FRESH_SUCCESSFUL_BUILD_CLOSURE_NO_STANDING_RESERVATION'
assert closed['owned_supervisor_identity_absent'] and closed['owned_container_init_identity_absent']
assert closed['original_lease']['free_briefly'] and closed['original_lease']['released']
assert not closed['foreign_compute_clients'] and not closed['http8000_listeners'] and not closed['guarded_hot']
assert closed['service']['ActiveState'] == 'active' and not closed['standing_lease_waiter_reservation']
rows = [json.loads(line) for line in (base / 'terminal-control/telemetry.jsonl').read_text().splitlines()]
peaks = {}
for row in rows:
    for sensor in row['temperatures']:
        peaks[sensor['name']] = max(peaks.get(sensor['name'], -40), sensor['value_c'])
        if sensor.get('guarded', True):
            assert sensor['value_c'] < sensor['limit_c']
assert set(peaks) == {'nvme', 'amdgpu', 'k10temp'}
assert peaks['k10temp'] < 98 and peaks['nvme'] < 85
assert {pid for row in rows for pid in row['kernel_kfd']}.issubset({int(job['service_before']['MainPID'])})
for part, count in [('terminal-control/control-collection.json', 4),
                    ('compile-evidence/collection.json', 25), ('coherence-evidence/collection.json', 3)]:
    collection = json.loads((base / part).read_text())
    assert collection['exit_code'] == 0 and len(collection['files']) == count
host_rel = 'docs/development/validation/tool-prompt-guidance-host-2026-10-07.json'
assert bound(root / host_rel)['sha256'] == seal['prompt_guidance_host_receipt_sha256']
assert bound(root / 'evidence/context-source-modern-r62.tar.gz')['sha256'] == seal['archive_sha256']
members = {}

def capture(path):
    members[str(path.relative_to(root))] = bound(path)

for path in base.rglob('*'):
    if path.is_file():
        capture(path)
for path in (root / 'evidence').glob('*r62*'):
    if path.is_file():
        capture(path)
for rel in [host_rel, 'README.md', 'docs/BACKEND.md', 'docs/PROGRESS.md',
            'docs/COORDINATION.md', 'docs/reference/ABI.md', 'third_party/README.md',
            'tools/thermal-run.py', 'tools/strix-point-campaign.py',
            'tools/strix-point-bench-collect.py', 'tools/sampling-capture.c',
            'tools/sampling-capture-mtp.h', 'tests/sampling/mtp_replay.hpp',
            'tests/sampling/mtp_replay_contract.cmake', 'CMakeLists.txt',
            'cmake/point/Build.cmake', 'cmake/provider/Build.cmake',
            'cmake/provider/Source.cmake', 'third_party/gufo-source.json']:
    capture(root / rel)
for rel, sha in verification['recipes_verified'].items():
    assert bound(root / rel)['sha256'] == sha
    capture(root / rel)
inventory = (json.dumps(members, indent=2) + '\n').encode()
with archive.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as package:
            for rel, item in sorted(members.items()):
                assert bound(root / rel) == item
                info = tarfile.TarInfo(rel)
                info.mode, info.size = 0o644, item['bytes']
                with (root / rel).open('rb') as data:
                    package.addfile(info, data)
            info = tarfile.TarInfo('raw-inventory.json')
            info.mode, info.size = 0o644, len(inventory)
            package.addfile(info, io.BytesIO(inventory))
result = {
    'schema': 'synapse-lie.tool-prompt-guidance-point-build.v1',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'BUILT_NOT_GPU_TESTED_COLLECTED_VERIFIED_CLOSED',
    'classification': 'COHERENT_DEVICE_HIDDEN_ROCM10_COMPILATION_NOT_INFERENCE',
    'source_commit': seal['source_commit'], 'code_checkpoint': seal['code_checkpoint'],
    'engine_code_checkpoint': seal['engine_code_checkpoint'],
    'native_source_changed_after_compile': False,
    'host_receipt': {'path': host_rel, **bound(root / host_rel)},
    'source_archive_sha256': seal['archive_sha256'],
    'source_inventory_sha256': seal['source_files_sha256'],
    'tracked_compiler_files': 713, 'independently_pinned_gufo_files': 1019,
    'complete_recipes': 42, 'complete_recipe_replacements': 338,
    'owned_sampling_files_per_provider': 122, 'private_C17_ON_OFF_coherent': True,
    'consumer_binary_SHA256': job['build_result']['binaries'],
    'build_stages': {n: 0 for n in ['provider', 'reference-provider', 'configure', 'link']},
    'collected_artifacts': {'compile': 25, 'terminal_control': 4, 'coherence': 3},
    'controller_exit_code': controller['exit_code'], 'supervisor_exit_code': job['exit_code'],
    'child_exit_code': job['child_exit_code'],
    'supervisor_identity': {'pid': job['pid'], 'start_ticks': job['start_ticks']},
    'container_init_identity': {'pid': job['container_host_pid'], 'start_ticks': job['container_start_ticks']},
    'bundle': bundle['result'], 'lease': job['lease'],
    'lease_released_at_utc': job['lease_released_at'], 'fresh_closure': closed,
    'CPU_GPU_NVMe_peak_C': [peaks['k10temp'], peaks['amdgpu'], peaks['nvme']],
    'peer_evidence': 'Fresh explicit own-state .161 non-use from Point, DGX and Q2; no future grant or standing window.',
    'preserved_failures': [{'path': 'evidence/context-r62-fresh-161-r1.json', 'actual_exit_code': 1, 'classification': 'READ_ONLY_PREFLIGHT_REFUSED_PREVIOUS_BOOT_LEASE_DEVICE_NO_BUILD_STARTED'}], 'live_packaging_guards_excluded': True,
    'GPU_or_model_executed': False, 'model_hash_or_conversion': False,
    'installation_tuning_deployment_or_publication': False,
    'original_weight_acceptance': 'OPEN', 'original_two_call_model_quality_failure_resolved': False, 'fixed_question_schema_or_acceptance_changed': False, 'performance_comparison': False,
    'goal_complete': False, 'open_task_numbers': [2, 3, 4, 5, 6, 7],
    'portable_raw_archive': {'path': 'raw/' + archive.name, **bound(archive), 'members': len(members) + 1},
    'raw_artifacts': members,
}
with out.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'receipt': str(out.relative_to(root)), 'archive': result['portable_raw_archive'],
                  'build_exit_codes': [0, 0, 0], 'original_weight_acceptance': 'OPEN'}))
