# SPDX-License-Identifier: MIT
"""Validate already-collected compilation metadata without remote work."""
from pathlib import Path
import hashlib, json, re, tarfile
from datetime import datetime, timezone

root = Path("evidence/context-r62-build-r1")
base = root / "compile-evidence"
out = root / "compile-verification-r1"
out.mkdir(exist_ok=False)
record = {
    "schema": "synapse-lie.point-compile-verification.v1",
    "at_utc": datetime.now(timezone.utc).isoformat(),
    "scope": "Local verification of collected build artifacts; no build or test campaign",
    "exit_code": 1,
    "remote_operation": False,
    "build_repeated": False,
    "model_attempted": False,
}
target = out / "result.json"
target.write_text(json.dumps(record, indent=2) + "\n")
def digest(data):
    return hashlib.sha256(data).hexdigest()
def load(path):
    return json.loads(Path(path).read_text())
collection = load(base / "collection.json")
assert collection["exit_code"] == 0 and collection["inventory_exit_code"] == 0
assert len(collection["files"]) == len(collection["commands"]) == 25
for name, identity in collection["files"].items():
    data = (base / name).read_bytes()
    assert len(data) == identity["bytes"] and digest(data) == identity["sha256"]
assert all(row["actual_exit_code"] == 0 for row in collection["commands"])
host = {"private_provider_inventory": {n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for m in re.finditer(r'foreach\(name IN ITEMS\s+([^)]*)\)',Path('cmake/provider/Build.cmake').read_text()) if len(m[1].split())==122 for n in m[1].split()}}
provider = load(base / "build/rocm10-point-modern-r62-provider/BUILD-RECEIPT.json")
reference = load(base / "build/rocm10-point-modern-r62-reference-provider/BUILD-RECEIPT.json")
pristine = load("third_party/gufo-source.json")
pin = "f783fedb9bea2ec7de941f6da4e02f4a4596b29e"
assert pristine["commit"] == pin and len(pristine["files"]) == 1019
source_text = Path("cmake/provider/Source.cmake").read_text()
recipes = re.search(r"set\(manifests ([^)]*)\)", source_text).group(1).split()
recipes.append("kvc-edits.json")
assert len(recipes) == len(set(recipes))
files = dict(pristine["files"])
changed = {}
for name, expected in files.items():
    path = Path(".deps/gufo-f783fedb") / name
    assert digest(path.read_bytes()) == expected
recipe_hashes = {}
for recipe in recipes:
    path = Path("adapters/gufo-state") / recipe
    data = path.read_bytes()
    recipe_hashes[str(path)] = digest(data)
    edits = json.loads(data)
    assert edits["source_pin"] == pin
    for edit in edits["edits"]:
        name = edit["path"]
        content = changed.get(name)
        if content is None:
            content = (Path(".deps/gufo-f783fedb") / name).read_bytes().decode("utf-8")
        old, new = edit["old"], edit["new"]
        assert old and content.count(old) == 1, (recipe, name)
        changed[name] = content.replace(old, new, 1)
        files[name] = digest(changed[name].encode("utf-8"))
seal = load("evidence/context-r62-source-seal.json")
with tarfile.open("evidence/context-source-modern-r62.tar.gz", "r:gz") as archive:
    members = archive.getmembers()
    def archived(path):
        matched = [m for m in members if m.name == path or m.name.endswith("/" + path)]
        assert len(matched) == 1 and matched[0].isreg(), path
        return archive.extractfile(matched[0]).read()
    assert digest(archived("SOURCE-FILES.sha256")) == seal["source_files_sha256"]
    for name, expected in recipe_hashes.items():
        assert digest(archived(name)) == expected
    for name in ["cmake/provider/Source.cmake", "cmake/provider/Build.cmake"]:
        assert archived(name) == Path(name).read_bytes()
for receipt in [provider, reference]:
    assert receipt["source_pin"] == pin
    assert receipt["variant_files"] == files
    assert receipt["owned_sampling_files"] == host["private_provider_inventory"]
    assert len(receipt["owned_sampling_files"]) == 122
    assert receipt["source_manifest_sha256"] == digest(Path("third_party/gufo-source.json").read_bytes())
    assert receipt["state"] == "LIBRARIES_BUILT_NOT_EXECUTED_NOT_INFERENCE_QUALIFIED"
    assert not receipt["gpu_execution"] and not receipt["installation"]
    assert all(row["exit_code"] == 0 for row in receipt["commands"])
    assert receipt["sampling_storage_edits_sha256"] == recipe_hashes["adapters/gufo-state/sampling-storage-edits.json"]
assert provider["c17_sampling"] is True and reference["c17_sampling"] is False
assert provider['sampling_observer_edits_sha256']==reference['sampling_observer_edits_sha256']==hashlib.sha256(Path('adapters/gufo-state/sampling-observer-edits.json').read_bytes()).hexdigest()

assert provider["attention_dispatch_stats"] is True and reference["attention_dispatch_stats"] is True
assert provider["long_context_wmma"] is True and reference["long_context_wmma"] is True
assert provider["owned_dispatch_files"] == reference["owned_dispatch_files"] == {name:digest(Path(name).read_bytes()) for name in ("src/dispatch.c","include/lie/dispatch.h")}
assert provider["attention_dispatch_edits_sha256"] == reference["attention_dispatch_edits_sha256"] == recipe_hashes["adapters/gufo-state/attention-dispatch-edits.json"]
compiled_path = base / "evidence/rocm10-point-modern-r62-compile/result.json"
compiled = load(compiled_path)
assert compiled["exit_code"] == 0 and compiled["state"] == "BUILT_NOT_GPU_TESTED"
assert compiled["reference_control_coherent_off"] is True
assert compiled["long_context_wmma"] is True
assert set(compiled["binaries"]) == {"synapse-lie-server", "synapse-lie-bench", "synapse-lie-bench-gufo-reference", "lie-hip-probe", "lie-sampling-capture", "lie-attention-qualify"}
assert compiled["source_commit"] == seal["source_commit"]
for variant, field in [
    ("provider", "provider_receipt_sha256"),
    ("reference-provider", "reference_provider_receipt_sha256"),
]:
    path = base / f"build/rocm10-point-modern-r62-{variant}/BUILD-RECEIPT.json"
    assert digest(path.read_bytes()) == compiled[field]
for stage in ["provider", "reference-provider", "configure", "link"]:
    assert (base / f"evidence/rocm10-point-modern-r62-compile/{stage}.exit").read_text().strip() == "0"
coherence = load(root / "coherence-evidence/collection.json")
assert coherence["exit_code"] == 0
assert coherence["compiled_native_capture_C17_primary_provider"] is True
assert coherence["compiled_native_attention_C17_HIP_primary_provider"] is True
bundle = load("evidence/context-r62-bundle-result.json")
assert bundle["exit_code"] == 0
metadata = bundle["result"]["metadata"]
assert metadata["compile_receipt_sha256"] == digest(compiled_path.read_bytes())
assert metadata["scope"] == "BUILT_NOT_GPU_TESTED"
for name, expected in compiled["binaries"].items():
    assert metadata["artifacts"]["runtime/bin/" + name] == expected
closure = load("evidence/context-r62-build-closure-r1.json")
assert closure["actual_exit_code"] == 0
closed = closure["result"]
assert closed["owned_supervisor_identity_absent"] and closed["owned_container_init_identity_absent"]
assert closed["original_lease"]["released"] and not closed["standing_lease_waiter_reservation"]
record.update({
    "exit_code": 0,
    "state": "BUILT_NOT_GPU_TESTED_COLLECTED_VERIFIED_CLOSED",
    "collected_artifacts_verified": 25,
    "private_provider_files_per_variant": 122,
    "complete_variant_files_per_variant": len(files),
    "recipes_verified": recipe_hashes,
    "full_variant_binding": "All recipe results independently reconstructed from pinned pristine files and exactly equal both recorded variant_files maps",
    "individual_recipe_fields_absent": [
        "schema_compiler_edits_sha256", "schema_string_edits_sha256", "schema_frontend_edits_sha256"
    ],
    "source_commit": compiled["source_commit"],
    "compile_receipt_sha256": digest(compiled_path.read_bytes()),
    "bundle_sha256": bundle["result"]["bundle_sha256"],
    "build_closure_at_utc": closed["at_utc"],
    "original_weight_qualification": False,
    "next_gpu_campaign_prepared_or_admitted": False,
})
target.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({key: record[key] for key in [
    "state", "exit_code", "collected_artifacts_verified",
    "private_provider_files_per_variant", "complete_variant_files_per_variant",
    "build_repeated", "remote_operation"
]}))

