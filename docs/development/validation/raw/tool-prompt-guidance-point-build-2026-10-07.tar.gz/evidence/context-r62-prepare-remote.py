# SPDX-License-Identifier: MIT
"""Prepare an exclusive build job. No process, lease, service or GPU admission."""
from pathlib import Path
import hashlib,json,subprocess
seal=json.loads(Path('evidence/context-r62-source-seal.json').read_text())
manifest=json.loads(Path('evidence/context-r62-build-manifest.json').read_text())
assert manifest['source_commit']==seal['source_commit'] and manifest['runner_sha256']==seal['runner_sha256']
expected={k:seal[k] for k in ('source_commit','code_checkpoint','runner_sha256','source_files_sha256','archive_sha256')}
program='EXPECTED='+repr(expected)+'\nMANIFEST='+repr(manifest)+'\n'+'''from pathlib import Path
import hashlib,json,os,shutil
base=Path('/home/pop/workspace/synapse-lie');source=base/'rocm10-fedora-161/source-modern-r62'
assert os.getuid()==1000 and base.resolve()==base and base.stat().st_uid==os.getuid()
assert source.resolve()==source and source.stat().st_uid==os.getuid()
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(source.with_suffix('.tar.gz'))==EXPECTED['archive_sha256']
assert sha(source/'SOURCE-FILES.sha256')==EXPECTED['source_files_sha256']
assert (source/'SOURCE-COMMIT.txt').read_text().strip()==EXPECTED['source_commit']
assert (source/'CODE-CHECKPOINT.txt').read_text().strip()==EXPECTED['code_checkpoint']
runner=source/'tools/strix-point-campaign.py'
assert not runner.is_symlink() and sha(runner)==EXPECTED['runner_sha256']
st=(base/'campaign.lock').stat();assert (st.st_dev,st.st_ino)==(66307,105946405) and st.st_uid==os.getuid()
job=base/'context-r62-build-r1';assert not job.exists() and not job.is_symlink()
job.mkdir(mode=0o700);shutil.copy2(runner,job/'runner.py')
with (job/'manifest.json').open('x') as stream:json.dump(MANIFEST,stream,indent=2);stream.write(chr(10))
assert sha(job/'runner.py')==EXPECTED['runner_sha256']
print(json.dumps({'scope':'PREPARED_EXCLUSIVE_BUILD_NOT_STARTED_OR_ADMITTED','job':str(job),
 'runner_sha256':sha(job/'runner.py'),'manifest_sha256':sha(job/'manifest.json'),
 'source_commit':MANIFEST['source_commit'],'original_lease_device':st.st_dev,'original_lease_inode':st.st_ino,
 'GPU_model_or_build_execution':False,'service_mutation':False,'standing_lease_waiter_or_reservation':False}))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
p=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
r={'argv':argv,'actual_exit_code':p.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':p.stdout,'stderr':p.stderr}
try:r['result']=json.loads(p.stdout)
except ValueError:pass
with Path('evidence/context-r62-job-prepared.json').open('x') as stream:json.dump(r,stream,indent=2);stream.write('\n')
if p.returncode==0:
    out=Path('evidence/context-r62-build-r1');out.mkdir()
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (out/'runner.py').write_bytes(Path('tools/strix-point-campaign.py').read_bytes())
print(json.dumps(r.get('result',r)))
raise SystemExit(p.returncode)
