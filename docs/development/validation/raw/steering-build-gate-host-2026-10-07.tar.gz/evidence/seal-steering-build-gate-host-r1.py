# SPDX-License-Identifier: MIT
"""Seal completed synthetic HOST checks; no build, remote or model operation."""
from pathlib import Path
import datetime, gzip, hashlib, io, json, re, subprocess, tarfile

root = Path.cwd()
base = root/'evidence/steering-build-gate-host-r1'
dest = root/'docs/development/validation'
name = 'steering-build-gate-host-2026-10-07'
receipt = dest/(name+'.json'); archive = dest/'raw'/(name+'.tar.gz')
assert not receipt.exists() and not archive.exists()
def bound(path):
    assert path.is_file() and not path.is_symlink(), path
    with path.open('rb') as stream: digest = hashlib.file_digest(stream,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':digest}
def read(path): return json.loads(path.read_text())
groups = ['debug-final-guard','sanitizer-final-guard','campaign-regression-guard',
          'native-debug-ctest-guard','native-sanitizer-ctest-guard']
records = {}
peaks = {}
for label in groups + ['debug-guard','debug-r2-guard','sanitizer-guard']:
    data = read(base/label/'result.json')
    assert data['exit_code']==data['child_exit_code']==(1 if label=='debug-guard' else 0)
    assert data['reason'] is None
    records[label] = data
    for path,value in data['peak_c'].items(): peaks[path] = max(peaks.get(path,-40),value)
for label,number in [('debug-final-guard',18),('sanitizer-final-guard',18),('campaign-regression-guard',89)]:
    text = (base/label/'command.log').read_text()
    assert re.search(r'Ran '+str(number)+r' tests in ',text) and text.rstrip().endswith('OK')
for label in ('native-debug-ctest-guard','native-sanitizer-ctest-guard'):
    text = (base/label/'command.log').read_text()
    assert '100% tests passed, 0 tests failed out of 1' in text
for label in ('sanitizer-final-guard','native-sanitizer-ctest-guard'):
    argv = records[label]['argv']
    assert 'ASAN_OPTIONS=detect_leaks=1:halt_on_error=1' in argv
    assert 'UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1' in argv
    assert not any('suppress' in arg.lower() for arg in argv)
process = read(base/'native-process.json')
assert process['actual_exit_code']==0 and process['classification']=='SYNTHETIC_C17_BORROWED_ROW_FIXTURE_NOT_INFERENCE'
original_runtime = read(dest/'steering-build-point-build-2026-10-07.json')
assert original_runtime['source_commit']=='4c703b3d604c6c877d6a2214d7aee0b15a013f61'
assert original_runtime['GPU_or_model_executed'] is False
native_paths = ['tools/steering-build.c','src/steering_direction.c','src/steering_capture.c',
    'include/lie/activation_observer.h','include/lie/steering_direction.h','include/lie/steering_capture.h',
    'include/lie/executor.h','adapters/gufo_activation_observer.hpp','adapters/gufo.cpp',
    'adapters/gufo-state/activation-observer-edits.json','tests/steering_build_executor.c',
    'tests/test_steering_build.c']
for rel in native_paths:
    committed = subprocess.check_output(['git','show','4c703b3d:'+rel])
    assert (root/rel).read_bytes()==committed
source_paths = ['tools/strix-point-campaign.py','tools/strix-point-steering-build-gate.py',
    'tests/test_strix_point_steering_build.py','tests/fixtures/steering-build-receipts.json',
    'docs/PROGRESS.md','docs/BACKEND.md','docs/COORDINATION.md','docs/development/STEERING.md']
binary_paths = [str(Path('build')/build/exe) for build in ('context-debug','tool-http-asan')
    for exe in ('test-steering-build','test-steering-build-contract')]
members = {}
def capture(path): members[str(path.relative_to(root))] = bound(path)
for path in base.rglob('*'):
    if path.is_file(): capture(path)
for rel in source_paths+native_paths+['tools/thermal-run.py',
    'docs/development/validation/steering-build-point-build-2026-10-07.json']:
    capture(root/rel)
capture(root/'evidence/seal-steering-build-gate-host-r1.py')
inventory = (json.dumps(members,indent=2)+'\n').encode()
with archive.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,compresslevel=3) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as package:
            for rel,item in sorted(members.items()):
                assert bound(root/rel)==item
                info = tarfile.TarInfo(rel); info.mode=0o644; info.size=item['bytes']
                with (root/rel).open('rb') as data: package.addfile(info,data)
            info = tarfile.TarInfo('raw-inventory.json'); info.mode=0o644; info.size=len(inventory)
            package.addfile(info,io.BytesIO(inventory))
result = {'schema':'synapse-lie.steering-build-gate-host.v1',
    'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state':'HOST_NATIVE_CAPTURE_ORACLE_AND_COORDINATION_PASSED_ORIGINAL_CAPTURES_UNQUALIFIED',
    'classification':'SYNTHETIC_HOST_CHECKING_CODE_NOT_INFERENCE',
    'source_basis_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'working_sources_bound_before_checkpoint':True,
    'runtime_source_commit':original_runtime['source_commit'],
    'native_production_or_numerical_sources_changed':False,'ABI_or_state_formats_changed':False,
    'sources':{rel:bound(root/rel) for rel in source_paths+native_paths},
    'synthetic_binaries':{rel:bound(root/rel) for rel in binary_paths},
    'checking_code_tests':{'Debug':18,'ASan_UBSan_LSan':18,'supervisor_regression':89},
    'focused_native_CTest':{'Debug':1,'ASan_UBSan_LSan':1,'native_process_cases_per_CTest':32},
    'native_fixture_invocations_per_checking_mode':3,'checks':records,'thermal_peak_c_by_sensor':peaks,
    'preserved_failures':[{'path':'evidence/steering-build-gate-host-r1/debug-guard',
        'actual_exit_code':1,'tests':17,'errors':6,
        'cause':'Test campaign manifest omitted required authorization; its first setup error caused subsequent reused-directory errors',
        'original_test_source':'evidence/steering-build-gate-host-r1/initial-test-source.py',
        'production_source_changed_to_pass':False}],
    'independent_oracle':'Raw LE-F32 branch means rounded F32; math.fsum contrasts and math.hypot unit normalization',
    'tolerances':{'relative':2e-6,'absolute':2e-8,'unit_norm_absolute':1e-6},
    'actual_original_weight_captures_or_learned_quality_qualified':False,
    'GPU_or_model_run_remote_build_heavyweight_hash_or_conversion':False,
    'default_product_build_tests_Python_free':True,'new_local_build_directories':[],
    'installation_tuning_deployment_push_or_merge':False,'performance_comparison':False,
    'root_remote_job_handle_lease_window_waiter_reservation':'NONE',
    'all_open_task_numbers':[2,3,4,5,6,7],'Terminal_Bench_last':True,'goal_complete':False,
    'portable_raw_archive':{'path':'raw/'+archive.name,**bound(archive),'members':len(members)+1},
    'raw_artifacts':members}
with receipt.open('x') as stream: json.dump(result,stream,indent=2); stream.write('\n')
with tarfile.open(archive) as package:
    assert len(package.getmembers())==len(members)+1
    for item in package.getmembers():
        assert item.isreg()
        data = package.extractfile(item).read()
        if item.name=='raw-inventory.json': assert json.loads(data)==members
        else:
            assert len(data)==members[item.name]['bytes']
            assert hashlib.sha256(data).hexdigest()==members[item.name]['sha256']
            assert bound(root/item.name)==members[item.name]
print(json.dumps({'receipt':str(receipt.relative_to(root)),'state':result['state'],
    'actual_exit_code':0,'portable_raw_archive':result['portable_raw_archive']}))
