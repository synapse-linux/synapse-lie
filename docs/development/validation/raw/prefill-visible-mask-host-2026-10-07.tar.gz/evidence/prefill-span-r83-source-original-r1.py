# SPDX-License-Identifier: MIT
"""Check the owned recipe delta against the independently pinned source."""
from pathlib import Path
import hashlib,json,re,subprocess
root=Path.cwd()
out=root/'evidence/prefill-span-r83-source'
out.mkdir(exist_ok=False)
pin=json.loads((root/'third_party/gufo-source.json').read_text())
cmake=(root/'cmake/provider/Source.cmake').read_text()
recipes=re.search(r'set\(manifests ([^\n]+)\)',cmake).group(1).split()
assert len(recipes)==41
old_attention=json.loads(subprocess.check_output(['git','show','1160cef2:adapters/gufo-state/attention-dispatch-edits.json'],text=True))
variants={}
for tag in ['old','candidate']:
    changed={}
    for recipe in recipes:
        data=old_attention if tag=='old' and recipe=='attention-dispatch-edits.json' else json.loads((root/'adapters/gufo-state'/recipe).read_text())
        assert data['source_pin']==pin['commit']
        for edit in data['edits']:
            name=edit['path']
            if name not in changed:
                source=root/'.deps/gufo-f783fedb'/name
                assert source.is_file() and not source.is_symlink()
                payload=source.read_bytes()
                assert hashlib.sha256(payload).hexdigest()==pin['files'][name]
                changed[name]=payload.decode()
            assert edit['old'] and changed[name].count(edit['old'])==1,(tag,recipe,name)
            changed[name]=changed[name].replace(edit['old'],edit['new'])
    variants[tag]=changed
changed_paths=[name for name in variants['old'] if variants['old'][name]!=variants['candidate'][name]]
target='src/models/qwen38_flash_next/kernels/rocm/kernels.hip.cpp'
assert changed_paths==[target]
old=variants['old'][target];new=variants['candidate'][target]
before='if (mask != nullptr && mask_words > kWmmaMaxMaskWords) {'
after='// The kernel scans only the visible words, keeping the full row stride.\n  // Its local_words[8] and union_words storage remain bounded by 2048.\n  if (mask != nullptr &&\n      !lie_attention_mask_span_fits(start_pos, n_tokens, ratio, mask_words,\n                                    kWmmaMaxMaskWords)) {'
assert old.count(before)==1 and old.replace(before,after)==new
for snippet in ['unsigned local_words[8];','__shared__ unsigned union_words[kListCapacity];','mask[size_t(query_start + r) * mask_words + w]','const unsigned word_count = (n_blocks + 31) / 32;','const unsigned words_per_thread = (word_count + 255) / 256;','constexpr std::uint32_t kWmmaMaxMaskWords = 2048;']:
    assert old.count(snippet)==new.count(snippet)==1
proof={
 'state':'CANONICAL_RECIPE_COMPOSITION_AND_HOST_POLICY_ONLY_NOT_HIP_OR_INFERENCE',
 'upstream_pin':pin['commit'],'recipes':len(recipes),'recipe_changed_paths':changed_paths,
 'kernel_body_and_allocation_pitch_unchanged':True,'live_word_workspace_capacity':2048,
 'C17_policy':'lie_attention_mask_span_fits; independently typed ratio, full pitch and workspace bounds',
 'actual_kernel_guard_difference_only':True,
 'changed_recipe':'adapters/gufo-state/attention-dispatch-edits.json',
 'bound_sources':{},'derived_sources':{},'no_GPU_model_build_or_forward':True,
 'matching_coherent_HIP_compilation_and_original_weight_qualification':'PENDING',
 'preserve_comparison_baseline':'Retain frozen r38 original-policy reference separately; rebuilding both arms with this guard cannot measure its benefit.'
}
for rel in ['include/lie/dispatch.h','src/dispatch.c','tests/test_attention_dispatch.c','adapters/gufo-state/attention-dispatch-edits.json']:
    p=root/rel;proof['bound_sources'][rel]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for tag,text in [('old',old),('candidate',new)]:
    p=out/(tag+'-kernels.hip.cpp');p.write_text(text)
    proof['derived_sources'][str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:proof[k] for k in ['state','recipes','recipe_changed_paths','kernel_body_and_allocation_pitch_unchanged','matching_coherent_HIP_compilation_and_original_weight_qualification']}))
