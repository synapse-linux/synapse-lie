#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Seal completed coherent HIP compilation and closure; no build/test/remote call."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import tarfile

OUT = Path('docs/development/validation/integrated-point-hip-build-2026-10-06.json')
ARCHIVE = Path('docs/development/validation/raw/integrated-point-hip-build-2026-10-06.tar.gz')
BASE = Path('evidence/context-r37-build-r1')
assert not OUT.exists() and not ARCHIVE.exists()

def read(path):
    return json.loads(Path(path).read_text())

def bound(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as f:
        sha = hashlib.file_digest(f, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha}

job = read(BASE / 'result.json')
controller = read(BASE / 'controller-result.json')
compile_proof = read(BASE / 'compile-verification-r1/result.json')
closure = read('evidence/context-r37-build-closure-r1.json')
seal = read('evidence/context-r37-source-seal.json')
bundle = read('evidence/context-r37-bundle-result.json')
host_path = Path('docs/development/validation/integrated-final-host-2026-10-06.json')
host = read(host_path)
assert job['state'] == 'PASSED' and job['exit_code'] == job['child_exit_code'] == controller['exit_code'] == 0
assert job['model_attempted'] is False and not job['cleanup_failures']
assert job['lease']['device'] == 66307 and job['lease']['inode'] == 105946405
assert compile_proof['state'] == 'BUILT_NOT_GPU_TESTED_COLLECTED_VERIFIED_CLOSED' and compile_proof['exit_code'] == 0
assert len(compile_proof['recipes_verified']) == 41
assert closure['actual_exit_code'] == 0 and closure['result']['owned_supervisor_identity_absent']
assert closure['result']['owned_container_init_identity_absent'] and closure['result']['original_lease']['released']
assert not closure['result']['foreign_compute_clients'] and not closure['result']['http8000_listeners']
assert not closure['result']['guarded_hot'] and closure['result']['service']['ActiveState'] == 'active'
assert bundle['exit_code'] == 0
assert compile_proof['source_commit'] == seal['source_commit'] == bundle['result']['metadata']['source_commit']
assert seal['code_checkpoint'] == host['source_commit']
assert bound(host_path)['sha256'] == seal['final_host_receipt_sha256']

rows = [json.loads(line) for line in (BASE / 'telemetry.jsonl').read_text().splitlines() if line.strip()]
assert rows
peaks = {}
for row in rows:
    for sensor in row['temperatures']:
        peaks[sensor['name']] = max(peaks.get(sensor['name'], 0), sensor['value_c'])
        if sensor.get('guarded', True):
            assert sensor['value_c'] < sensor['limit_c']
assert {pid for row in rows for pid in row['kernel_kfd']}.issubset({int(job['service_before']['MainPID'])})
assert job['service_after']['ActiveState'] == 'active' and job['lease_released_at']

members = {}
def capture(path):
    item = bound(path)
    assert item['path'] not in members
    members[item['path']] = item
    return item

for folder in [BASE, Path('evidence/context-r37-offline-compile-verification'),
               Path('evidence/context-r37-source-preparation')]:
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            capture(path)
for name in ['evidence/prepare-context-r37-source.py', 'evidence/stage-context-r37-source.py',
             'evidence/context-r37-source-seal.json', 'evidence/context-r37-source-stage.json',
             'evidence/context-r37-peer-coordination.json', 'evidence/context-r37-build-manifest.json',
             'evidence/context-r37-fresh-161-r1.py', 'evidence/context-r37-fresh-161-r1.json',
             'evidence/context-r37-fresh-161-r2.py', 'evidence/context-r37-fresh-161-r2.json',
             'evidence/seal-context-r37-bundle.py', 'evidence/context-r37-bundle-result.json',
             'evidence/collect-context-r37-compile.py', 'evidence/collect-context-r37-coherence.py',
             'evidence/verify-context-r37-compile.py', 'evidence/context-r37-build-closure-r1.py',
             'evidence/context-r37-build-closure-r1.json', 'evidence/seal-integrated-point-build-r37.py',
             str(host_path)]:
    capture(name)
for path in sorted(Path('evidence').glob('context-r37-build-live-r*')):
    if path.is_file():
        capture(path)
for name in ['cmake/provider/Build.cmake', 'cmake/provider/Source.cmake', 'cmake/provider/Verify.cmake',
             'cmake/point/Build.cmake', 'cmake/gufo-runtime/CMakeLists.txt',
             'src/dispatch.c', 'include/lie/dispatch.h', 'adapters/gufo.cpp', 'CMakeLists.txt']:
    assert bound(name)['sha256'] == host['frozen_sources'][name]['sha256']
    capture(name)
for name, sha in compile_proof['recipes_verified'].items():
    assert bound(name)['sha256'] == sha
    capture(name)

data = (json.dumps(members, indent=2) + '\n').encode()
with ARCHIVE.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, item in sorted(members.items()):
                assert bound(name) == item
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = item['bytes']
                with Path(name).open('rb') as f:
                    tar.addfile(info, f)
            info = tarfile.TarInfo('raw-inventory.json')
            info.mode = 0o644
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))

receipt = {
    'schema': 'synapse-lie.integrated-point-hip-build.v1',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'BUILT_NOT_GPU_TESTED_COLLECTED_VERIFIED_CLOSED',
    'scope': 'Final coherent private gfx1150 HIP compilation only; no model load, original-weight forward or performance/quality/fault acceptance.',
    'source_commit': seal['source_commit'], 'qualified_code_commit': host['source_commit'],
    'host_qualification': bound(host_path), 'source_seal': bound('evidence/context-r37-source-seal.json'),
    'source_archive_sha256': seal['archive_sha256'], 'source_inventory_sha256': seal['source_files_sha256'],
    'source_files': seal['source_files'], 'owned_source_files_verified': 650,
    'independently_pinned_gufo_files': 1019, 'private_sampler_files_per_provider': 120,
    'observer_files_per_provider': 2, 'attention_observer_enabled_in_both_providers': True,
    'private_C17_ON_OFF_consumer_coherence': True, 'complete_recipe_count_including_KVC': 41,
    'complete_variant_files_per_provider': 1019, 'independent_variant_verification': compile_proof,
    'build_stages': {stage: {'actual_exit_code': int((BASE / 'compile-evidence' /
        ('evidence/rocm10-point-modern-r37-compile/' + stage + '.exit')).read_text().strip())}
        for stage in ['provider', 'reference-provider', 'configure', 'link']},
    'supervisor_exit_code': job['exit_code'], 'container_child_exit_code': job['child_exit_code'],
    'controller_exit_code': controller['exit_code'],
    'collected_base_artifacts': 6, 'collected_compile_artifacts': 25, 'collected_coherence_artifacts': 3,
    'bundle': bundle['result'], 'image': bundle['result']['metadata']['image'],
    'supervisor_identity': {'pid': job['pid'], 'start_ticks': job['start_ticks']},
    'container_init_identity': {'pid': job['container_host_pid'], 'start_ticks': job['container_start_ticks']},
    'lease': job['lease'], 'lease_released_at_utc': job['lease_released_at'],
    'fresh_closure': closure['result'], 'maximum_observed_remote_CPU_C': peaks['k10temp'],
    'maximum_observed_remote_GPU_C_observe_only': peaks['amdgpu'], 'telemetry_samples': len(rows),
    'thermal_policy': 'CPU98/NVMe85/lower guards, GPU observe only; no tuning',
    'GPU_device_access_in_compiler': False, 'model_attempted': False,
    'model_hash_conversion_or_installation': False, 'new_GPU_test_or_benchmark': False,
    'new_test_or_build_for_collection': False, 'native_product_default_tests_require_Python': False,
    'root_job_client_build_lease_window_plan_waiter_reservation_handle_after_closure': False,
    'open_task_numbers': [2, 3, 4, 5, 6, 7], 'Terminal_Bench': 'STOPPED_COLLECTED_CLOSED_DEFERRED_LAST',
    'next_gate': 'Fresh peer/global/original-lease admission for current-source original-weight functional/quality/fault checks; matched benchmarks follow, Terminal Bench last',
    'publication': False, 'goal_complete': False,
    'portable_raw_archive': {**bound(ARCHIVE), 'members': len(members) + 1}, 'raw_artifacts': members}
with OUT.open('x') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
print(json.dumps({'receipt': str(OUT), 'receipt_sha256': bound(OUT)['sha256'],
                  'archive_sha256': bound(ARCHIVE)['sha256'], 'archive_members': len(members) + 1,
                  'CPU_peak_C': peaks['k10temp'], 'build_repeated': False, 'model_attempted': False}))
