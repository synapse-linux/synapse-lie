# SPDX-License-Identifier: MIT
"""Freeze the next saved-wire sealer using an actual live GPU witness."""
from pathlib import Path
import hashlib
import json
import sys

suffix = sys.argv[1]
assert suffix.isdecimal() and 1 <= int(suffix) <= 1000
label = 'recall-yarn4-523776-s77-ar-20261008-r1'
witness = Path('evidence')/(label+'-live-'+suffix+'.json')
live = json.loads(witness.read_text())
assert live['actual_exit_code'] == 0 and live['result']['live_exact_supervisor'] is True
value = live['result']
assert value['lease_fds'] and value['model_attempted'] is True
assert value['actual_live_init_identity'] and len(value['native_GPU_owners']) == 1
assert value['native_GPU_owners'][0]['cgroup'] == value['actual_live_init_identity']['cgroup']
parent = Path('evidence/seal-recall-yarn4-261632-s77-ar-20261008-r1.py')
source = parent.read_text()
for old, new in (
    ('recall-yarn4-261632-s77-ar-20261008-r1', label),
    ('recall-yarn4-near256k-ar-point-2026-10-08', 'recall-yarn4-near512k-ar-point-2026-10-08'),
    ("settings['size'] == 261632", "settings['size'] == 523776"),
    ('ORIGINAL_AR_YARN4_NEAR256K_', 'ORIGINAL_AR_YARN4_NEAR512K_'),
    ('at the stated near-256K physical target', 'at the stated near-512K physical target'),
    ('other seeds, 512K/786K/1M physical inputs', 'other seeds, 786K/1M physical inputs'),
    ("f'{LABEL}-live-3.json'", "f'{LABEL}-live-"+suffix+".json'"),
    ('prepare-seal-recall-yarn4-261632-r1.py', 'prepare-seal-recall-yarn4-523776-r1.py'),
    ("f'{LABEL}-proposal-notifications-r1.json', f'{LABEL}-peer-coordination-r1.json',",
     "f'{LABEL}-proposal-notifications-r1.json',")):
    assert old in source, old
    source = source.replace(old, new)
compile(source, '<frozen near512K saved-wire sealer>', 'exec')
output = Path('evidence')/('seal-'+label+'.py')
with output.open('x') as stream:
    stream.write(source)
record = {'parent': str(parent), 'parent_sha256': hashlib.sha256(parent.read_bytes()).hexdigest(),
          'derived': str(output), 'derived_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
          'actual_GPU_witness': str(witness), 'actual_GPU_witness_suffix': int(suffix),
          'actual_GPU_witness_sha256': hashlib.sha256(witness.read_bytes()).hexdigest(),
          'actual_GPU_identity': value['native_GPU_owners'][0],
          'saved_SSE_physical_phase_and_quality_oracle_unchanged': True,
          'actual_exit_code': 0}
with Path('evidence/recall-yarn4-523776-sealer-prepared-r1.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
