# SPDX-License-Identifier: MIT
"""Derive the next rung from the closed near-256K cohort; no GPU admission."""
from pathlib import Path
import hashlib
import json

parent = Path('evidence/prepare-recall-yarn4-261632-s77-ar-20261008-r1-local.py')
source = parent.read_text()
changes = (
    ("old='recall-yarn4-131072-s77-ar-20261008-r1'", "old='recall-yarn4-261632-s77-ar-20261008-r1'"),
    ("label='recall-yarn4-261632-s77-ar-20261008-r1'", "label='recall-yarn4-523776-s77-ar-20261008-r1'"),
    ('recall-yarn4-128k-ar-point-2026-10-08.json', 'recall-yarn4-near256k-ar-point-2026-10-08.json'),
    ('ORIGINAL_AR_YARN4_128K_PASSED_COLLECTED_INDEPENDENT_WIRE_VERIFIED_CLOSED',
     'ORIGINAL_AR_YARN4_NEAR256K_PASSED_COLLECTED_INDEPENDENT_WIRE_VERIFIED_CLOSED'),
    ('yarn4-128k-and-steering-quality-postseal-r1.json', 'yarn4-near256-and-supervision-postseal-r1.json'),
    ('size=261632,request_timeout_seconds=1800', 'size=523776,request_timeout_seconds=3600'),
    ('PREPARED_CURRENT_R70_YARN4_NEAR256K_RECALL_NOT_ADMITTED', 'PREPARED_CURRENT_R70_YARN4_NEAR512K_RECALL_NOT_ADMITTED'),
    ('physical target261632', 'physical target523776'),
    ('strongly closed current-r70 128K YaRN4 control', 'strongly closed current-r70 near256K YaRN4 control'),
    (".replace('YaRN4 128K recall qualification','YaRN4 near256K recall qualification')",
     ".replace('YaRN4 near256K recall qualification','YaRN4 near512K recall qualification')"))
for old, new in changes:
    assert old in source, old
    source = source.replace(old, new)
source = source.replace('Freeze the next YaRN4 rung after the current-r70 128K control passes.',
                        'Freeze the near512K YaRN4 rung after the current-r70 near256K control passes.')
source = source.replace('128K-control fit does not qualify this longer input.',
                        'Near256K-control fit does not qualify this longer input.')
compile(source, '<prepared near512K rung>', 'exec')
output = Path('evidence/prepare-recall-yarn4-523776-s77-ar-20261008-r1-local.py')
with output.open('x') as stream:
    stream.write(source)
print(json.dumps({'parent': str(parent), 'parent_sha256': hashlib.sha256(parent.read_bytes()).hexdigest(),
                  'derived': str(output), 'derived_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
                  'same_frozen_workload_and_oracle': True, 'actual_exit_code': 0}))
