# SPDX-License-Identifier: MIT
"""Prepare the unchanged saved-SSE oracle for the admitted near-256K job."""
from pathlib import Path
import hashlib
import json

parent = Path('evidence/seal-recall-yarn4-131072-s77-ar-20261008-r1.py')
source = parent.read_text()
for old, new in (
    ('recall-yarn4-131072-s77-ar-20261008-r1', 'recall-yarn4-261632-s77-ar-20261008-r1'),
    ('recall-yarn4-128k-ar-point-2026-10-08', 'recall-yarn4-near256k-ar-point-2026-10-08'),
    ("settings['size'] == 131072", "settings['size'] == 261632"),
    ('ORIGINAL_AR_YARN4_128K_', 'ORIGINAL_AR_YARN4_NEAR256K_'),
    ('at the stated 128K physical target', 'at the stated near-256K physical target'),
    ('other seeds, 256K/512K/786K/1M physical inputs', 'other seeds, 512K/786K/1M physical inputs'),
    ("f'{LABEL}-live-2.json'", "f'{LABEL}-live-3.json'"),
    ('prepare-seal-recall-yarn4-131072-r1.py', 'prepare-seal-recall-yarn4-261632-r1.py')):
    assert old in source, old
    source = source.replace(old, new)
needle = "         'prepare-seal-recall-yarn4-261632-r1.py', f'{LABEL}-release-notifications-r1.json']"
assert needle in source
source = source.replace(needle, "         'prepare-seal-recall-yarn4-261632-r1.py',\n"
    "         f'prepare-{LABEL}-from-parent.py', f'{LABEL}-admission-notifications-r1.json',\n"
    "         f'{LABEL}-proposal-notifications-r1.json', f'{LABEL}-peer-coordination-r1.json',\n"
    "         f'{LABEL}-release-notifications-r1.json']")
needle = "assert peers['separate_GLM_current_161_non_use'] and peers['last_observed_boot_identity_declared_to_all_four']\n"
assert needle in source
source = source.replace(needle, needle +
    "releases = read(ROOT/'evidence'/f'{LABEL}-release-notifications-r1.json')\n"
    "assert len(releases['results']) == 4\n"
    "assert len({r['value']['threadId'] for r in releases['results']}) == 4\n"
    "assert all(r['status'] == 'fulfilled' and not r['value']['result'].get('isError', False) for r in releases['results'])\n")
assert "f'{LABEL}-live-2.json'" not in source
assert "f'{LABEL}-live-3.json'" in source
compile(source, '<derived near-256K saved-wire sealer>', 'exec')
output = Path('evidence/seal-recall-yarn4-261632-s77-ar-20261008-r1.py')
with output.open('x') as stream:
    stream.write(source)
record = {'parent': str(parent), 'parent_sha256': hashlib.sha256(parent.read_bytes()).hexdigest(),
          'derived': str(output), 'derived_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
          'saved_SSE_physical_phase_and_quality_oracle_unchanged': True,
          'actual_GPU_witness_suffix': 3, 'requires_four_actual_release_deliveries': True,
          'actual_exit_code': 0}
with Path('evidence/recall-yarn4-261632-sealer-prepared-r1.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
