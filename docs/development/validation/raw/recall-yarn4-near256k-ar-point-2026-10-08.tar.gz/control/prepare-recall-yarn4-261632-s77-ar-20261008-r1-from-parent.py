# SPDX-License-Identifier: MIT
"""Prepare the next unchanged native recall workload from qualified128K."""
from pathlib import Path
import ast

old=Path('evidence/prepare-recall-yarn4-131072-s77-ar-20261008-r1-local.py')
text=old.read_text()
text=text.replace("old='recall-yarn4-8192-s77-ar-20261008-r1'\nlabel='recall-yarn4-131072-s77-ar-20261008-r1'", "old='recall-yarn4-131072-s77-ar-20261008-r1'\nlabel='recall-yarn4-261632-s77-ar-20261008-r1'")
text=text.replace('recall-yarn4-8k-ar-point-2026-10-08','recall-yarn4-128k-ar-point-2026-10-08')
text=text.replace('ORIGINAL_AR_YARN4_8K_','ORIGINAL_AR_YARN4_128K_')
text=text.replace('scaled-steering-and-yarn4-postseal-r1.json','yarn4-128k-and-steering-quality-postseal-r1.json')
text=text.replace('size=131072','size=261632').replace('physical target131072','physical target261632')
text=text.replace('PREPARED_CURRENT_R70_YARN4_128K_RECALL_NOT_ADMITTED','PREPARED_CURRENT_R70_YARN4_NEAR256K_RECALL_NOT_ADMITTED')
text=text.replace("replace('YaRN4 short recall qualification','YaRN4 128K recall qualification')", "replace('YaRN4 128K recall qualification','YaRN4 near256K recall qualification')")
text=text.replace('short control passes','128K control passes').replace('current-r70 short YaRN4 control','current-r70 128K YaRN4 control')
text=text.replace('Short-control fit does not qualify','128K-control fit does not qualify')
assert "size=261632" in text and 'size=131072' not in text
ast.parse(text)
with Path('evidence/prepare-recall-yarn4-261632-s77-ar-20261008-r1-local.py').open('x') as output:output.write(text)
