# SPDX-License-Identifier: MIT
"""Freeze the next YaRN4 rung after the current-r70 128K control passes."""
from pathlib import Path
import ast
import datetime
import hashlib
import importlib.util
import json
import subprocess

root=Path.cwd().resolve();evidence=root/'evidence'
old='recall-yarn4-131072-s77-ar-20261008-r1'
label='recall-yarn4-261632-s77-ar-20261008-r1'
checkpoint=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,data):
    with path.open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
control=root/'docs/development/validation/recall-yarn4-128k-ar-point-2026-10-08.json'
prior=json.loads(control.read_text())
assert prior['state']=='ORIGINAL_AR_YARN4_128K_PASSED_COLLECTED_INDEPENDENT_WIRE_VERIFIED_CLOSED'
assert prior['quality_summary']['passes']==2 and prior['actual_exit_code']==0
assert not prior['current_root_remote_jobs_handles_leases_windows_waiters_reservations']
assert json.loads((evidence/'yarn4-128k-and-steering-quality-postseal-r1.json').read_text())['actual_exit_code']==0
manifest=json.loads((evidence/(old+'-manifest.json')).read_text())
assert manifest['source_commit']==prior['runtime_source_commit']
spec=importlib.util.spec_from_file_location('recall',root/'tools/strix-point-http-recall-gate.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
settings=gate.settings(dict(manifest['http_recall'],size=261632,request_timeout_seconds=1800))
settings_path=evidence/(label+'-settings.json');write(settings_path,settings)
manifest.update(root_checkpoint=checkpoint,fixture_commit=checkpoint,
                prepared_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                distrobox_name='lie-'+label,http_recall=settings,
                http_recall_settings_sha256=sha(settings_path),
                canonical_HTTP_window_timeout_seconds=gate.container_timeout(settings),
                preceding_verified_control_receipt=str(control.relative_to(root)),
                preceding_verified_control_receipt_sha256=sha(control),
                purpose='Original-weight current-r70 AR YaRN4 recall at physical target261632, capacity1048576, seed77/chunk256/C1, two cold natural-stop turns/TG128/cacheoff and three unscored calibrations. Same frozen preset/questions/oracle as strongly closed current-r70 128K YaRN4 control. No matched performance, Terminal Bench, remote GPU build, conversion, heavyweight model hash, tuning, dependency installation or publication. Later sizes/seeds/modes need independent fresh admission.',
                memory_estimate_scope='110GiB conservative explicit GTT estimate for originalQ4/C1/YaRN4 capacity1048576/scratch256, minimum availableRAM1GiB. 128K-control fit does not qualify this longer input. Effective hostGTT112GiB unchanged.')
assert sha(root/'tools/strix-point-campaign.py')==manifest['runner_sha256']
assert sha(root/'tools/strix-point-http-recall-gate.py')==manifest['http_recall_gate_sha256']
assert sha(root/manifest['qualified_build_receipt'])==manifest['qualified_build_receipt_sha256']
delta=subprocess.run(['git','diff','--exit-code',manifest['source_commit'],'HEAD','--',
                      'src','include','adapters','cmake','CMakeLists.txt',':(glob)tools/*.c','tools/native'],
                     capture_output=True,text=True)
assert delta.returncode==0 and not delta.stdout
write(evidence/(label+'-manifest.json'),manifest)
ready=json.loads((evidence/(old+'-readiness.json')).read_text())
ready.update(at_utc=manifest['prepared_at_utc'],scope='PREPARED_CURRENT_R70_YARN4_NEAR256K_RECALL_NOT_ADMITTED',
             root_checkpoint=checkpoint,settings=settings)
ready['helpers']['http-recall-settings.json']={'source':str(settings_path.relative_to(root)),
                                               'bytes':settings_path.stat().st_size,'sha256':sha(settings_path)}
for row in ready['helpers'].values():assert sha(root/row['source'])==row['sha256']
write(evidence/(label+'-readiness.json'),ready)
wrappers={}
for name in ('prepare-'+old+'-remote.py','before-'+old+'-fresh-r1.py','launch-'+old+'.py',
             'observe-'+old+'.py','close-'+old+'-r1.py','close-'+old+'-r2.py'):
    data=(evidence/name).read_text();assert old in data
    data=data.replace(old,label).replace('YaRN4 128K recall qualification','YaRN4 near256K recall qualification')
    path=evidence/name.replace(old,label);ast.parse(data,filename=str(path))
    with path.open('x') as stream:stream.write(data)
    wrappers[path.name]={'bytes':path.stat().st_size,'sha256':sha(path)}
write(evidence/(label+'-preparation-recipes.json'),{
    'at_utc':manifest['prepared_at_utc'],'new_exclusive_helpers':wrappers,
    'historical_helpers_changed':False,'admitted':False,
    'remote_staging_executed':False,'future_window_reserved':False})
print(json.dumps({'state':'LOCALLY_PREPARED_NOT_ADMITTED','label':label,
                  'manifest_sha256':sha(evidence/(label+'-manifest.json')),
                  'root_checkpoint':checkpoint,'runtime_source':manifest['source_commit'],
                  'settings':settings,'container_timeout_seconds':manifest['canonical_HTTP_window_timeout_seconds'],
                  'GPU_or_remote_operation':False,'future_window_reserved':False}))
