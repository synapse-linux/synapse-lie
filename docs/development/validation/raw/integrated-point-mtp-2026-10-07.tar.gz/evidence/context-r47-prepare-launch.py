# SPDX-License-Identifier: MIT
from pathlib import Path
import hashlib,json,subprocess
program=Path('evidence/context-r47-prepare-remote.py').read_text()
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
r=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':r.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':r.stdout,'stderr':r.stderr}
try:record['result']=json.loads(r.stdout)
except ValueError:pass
with Path('evidence/context-r47-job-prepared.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record.get('result',record)))
raise SystemExit(r.returncode)
