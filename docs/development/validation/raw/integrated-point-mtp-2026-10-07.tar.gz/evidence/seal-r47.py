# SPDX-License-Identifier: MIT
"""Seal completed MTP HTTP evidence; no server, model, GPU or test launch."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import tarfile

root = Path.cwd()
name = 'integrated-point-mtp-2026-10-07'
dest = root / 'docs/development/validation'
receipt_path = dest / (name + '.json')
archive_path = dest / 'raw' / (name + '.tar.gz')
assert not receipt_path.exists() and not archive_path.exists()


def read(rel):
    return json.loads((root / rel).read_text())


def ident(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': sha}


def binding(rel):
    return {'path': rel, **ident(root / rel)}


job_rel = 'evidence/context-r47-integer-mtp-r1'
job = root / job_rel
collection = read(job_rel + '/collection.json')
assert collection['exit_code'] == 0
assert all(command['exit_code'] == 0 for command in collection['commands'])
assert len(collection['inventory']['files']) == 19
for rel, expected in collection['inventory']['files'].items():
    assert ident(job / rel) == expected, rel
for field in ('supervisor_absent', 'gpu_child_absent', 'owned_child_absent',
              'lease_free', 'model_stat_unchanged'):
    assert collection['inventory'][field] is True, field

manifest_rel = 'evidence/context-r47-integer-mtp-manifest.json'
manifest = read(manifest_rel)
assert manifest == read(job_rel + '/manifest.json')
ready = read('evidence/context-r47-readiness.json')
assert ready['compiled_source'] == manifest['source_commit']
assert ready['code_checkpoint'] == manifest['functional_code_checkpoint']
assert ready['head'] == manifest['runner_commit'] == manifest['fixture_commit']
assert all(rel == 'README.md' or rel.startswith('docs/')
           for rel in ready['changed_since_compiled_source'])
diff = subprocess.run(['git', 'diff', '--name-only', manifest['source_commit'],
                       manifest['runner_commit']], text=True, capture_output=True)
assert diff.returncode == 0
assert diff.stdout.splitlines() == ready['changed_since_compiled_source']

hip_rel = manifest['qualified_build_receipt']
hip = read(hip_rel)
assert ident(root / hip_rel)['sha256'] == manifest['qualified_build_receipt_sha256']
assert hip['source_commit'] == manifest['source_commit']
assert hip['code_checkpoint'] == manifest['functional_code_checkpoint']
assert hip['bundle']['bundle_sha256'] == manifest['bundle_manifest_sha256']
assert hip['bundle']['metadata']['artifacts'] == manifest['artifacts']
assert hip['bundle']['metadata']['image'] == manifest['image']
for label, filename in (('http_gate', 'http-gate.py'),
                        ('http_controls', 'http-controls.py'),
                        ('http_output_budget', 'http-output-budget.py'),
                        ('http_schema_integer', 'http-schema-integer.py')):
    sha = ident(job / filename)['sha256']
    assert sha == manifest[label + '_sha256'] == ready['unchanged_HTTP_helpers'][label]

r = read(job_rel + '/result.json')
h = read(job_rel + '/http-result.json')
ints = read(job_rel + '/http-schema-integer-result.json')
controller = read(job_rel + '/controller-exit.json')
assert r == read(job_rel + '/controller-terminal-result.json')
assert r['state'] == h['state'] == ints['state'] == 'PASSED'
assert controller['controller_actual_exit_code'] == r['exit_code'] == r['child_exit_code'] == h['server_exit_code'] == 0
for field in ('stdout', 'stderr'):
    descriptor = controller[field]
    assert ident(root / descriptor['path']) == {key: descriptor[key] for key in ('bytes', 'sha256')}
assert r['manifest_sha256'] == ident(root / manifest_rel)['sha256']
assert r['runner_sha256'] == ident(job / 'runner.py')['sha256']
assert r['model_attempted'] is True and not r['cleanup_failures']
assert len(set(h['passed'])) == len(h['passed']) == 37
assert len(set(ints['passed'])) == len(ints['passed']) == 66
assert h['mode'] == 'mtp' and h['schema_integer_checks'] == 66
assert len(r['models_before']) == 5 and r['models_before'] == r['models_after']
assert r['model_stat_unchanged'] is True
for key, rel in (('http_controls', 'http-controls-result.json'),
                 ('http_output_budget', 'http-output-budget-result.json'),
                 ('http_schema_integer', 'http-schema-integer-result.json')):
    assert r[key + '_sha256'] == ident(job / rel)['sha256']

closure_rel = 'evidence/context-r47-mtp-closure-r1.json'
closure = read(closure_rel)
assert closure['actual_exit_code'] == 0
c = closure['result']
assert c['state'] == 'FRESH_MTP_HTTP_WINDOW_CLOSED_NO_STANDING_RESERVATION'
assert c['original_lease']['device'] == r['lease']['device'] == 66307
assert c['original_lease']['inode'] == r['lease']['inode'] == 105946405
assert c['original_lease']['free_briefly'] is True and c['original_lease']['released'] is True
assert c['service']['ActiveState'] == 'active' and c['service']['SubState'] == 'running'
assert c['service']['MainPID'] == r['service_after']['MainPID']
assert not c['foreign_compute_clients'] and not c['guarded_hot'] and not c['http8000_listeners']
assert c['standing_lease_waiter_reservation'] is False
assert c['pinned_image']['id'] == manifest['image']
for window in c['owned_window_closures']:
    assert all(window[key] is True for key in ('supervisor_identity_absent',
               'container_init_identity_absent', 'container_absent', 'label_listing_empty'))
live = read('evidence/context-r47-mtp-live-r1.json')
assert live['actual_exit_code'] == 0

wire_rel = 'evidence/context-r47-mtp-rational-wire-proof.json'
wire = read(wire_rel)
assert wire['mode'] == 'mtp' and wire['valid_integer_outputs'] == 60
assert wire['HTTP400_refusals'] == 6 and wire['JSON_SSE_replay_pairs'] == 30
assert wire['wire_sha256'] == ident(job / 'http-wire.jsonl')['sha256']
review_rel = 'evidence/context-r47-collected-review.json'
review = read(review_rel)
assert review['actual_exit_code'] == 0
assert review['OpenAI_checks'] == 37 and review['integer_checks'] == 66
assert review['files_verified'] == 19 and review['model_stat_unchanged'] is True
assert review['plain_POST_MTP_drafted_sum'] > 0 and review['plain_POST_MTP_accepted_sum'] > 0
assert len(review['expected_AR_fallback']) == 4
guards = {}
for label, rel in (('exact_rational_wire', 'evidence/context-r47-mtp-rational-wire-guard/result.json'),
                   ('collected_counter_review', 'evidence/context-r47-collected-review-guard/result.json')):
    guard = read(rel)
    assert guard['exit_code'] == guard['child_exit_code'] == 0 and guard['reason'] is None
    guards[label] = {'result': binding(rel), **guard}
failure_rel = 'evidence/context-r47-counter-review-failure-r1.json'
failure = read(failure_rel)
assert failure['actual_exit_code'] == 1 and failure['GPU_or_HTTP_test_repeated'] is False
coordination = read('evidence/context-r47-peer-coordination.json')
assert coordination['stale_r37_manifest_launched'] is False
assert coordination['prepared_manifest_sha256'] == r['manifest_sha256']

files = {}
for path in root.glob('evidence/context-r47-*'):
    if path.is_dir():
        for child in path.rglob('*'):
            if child.is_file():
                files[str(child.relative_to(root))] = child
    elif path.is_file():
        files[str(path.relative_to(root))] = path
for rel in ('evidence/seal-r47.py', 'evidence/verify-r47-bounded-wire.py',
            'evidence/verify-r47-functional-review.py', hip_rel,
            'tools/strix-point-bench-collect.py', 'tools/strix-point-schema-integer-gate.py',
            'tools/thermal-run.py', 'src/core_input.c', 'src/worker.c',
            'src/wire.c', 'src/sampling.c'):
    files[rel] = root / rel
members = {rel: ident(path) for rel, path in sorted(files.items())}
archive_path.parent.mkdir(parents=True, exist_ok=True)
with tarfile.open(archive_path, 'x:gz') as archive:
    for rel in members:
        archive.add(files[rel], arcname=rel, recursive=False)
with tarfile.open(archive_path, 'r:gz') as archive:
    entries = archive.getmembers()
    assert len(entries) == len(members) and {entry.name for entry in entries} == set(members)
    for entry in entries:
        assert entry.isfile()
        stream = archive.extractfile(entry)
        assert stream is not None
        with stream:
            sha = hashlib.file_digest(stream, 'sha256').hexdigest()
        assert {'bytes': entry.size, 'sha256': sha} == members[entry.name]
        assert ident(files[entry.name]) == members[entry.name]

receipt = {
    'schema': 'synapse-lie.integrated-point-mtp.v1',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'SELECTED_CURRENT_R45_ORIGINAL_WEIGHT_MTP_ENABLED_HTTP_COLLECTED_VERIFIED_CLOSED',
    'scope': 'Functional OpenAI/wire qualification on an MTP-enabled server, including existing per-request AR fallback. Not full MTP probability/controller, quality, fault, long-context or performance acceptance.',
    'source_commit': manifest['source_commit'],
    'qualified_code_commit': manifest['functional_code_checkpoint'],
    'runner_commit': manifest['runner_commit'], 'fixture_commit': manifest['fixture_commit'],
    'source_continuity': {'result': binding('evidence/context-r47-readiness.json'),
                          'docs_only_changes_since_compiled_source': ready['changed_since_compiled_source'],
                          'actual_git_diff_exit_code': diff.returncode},
    'coherent_HIP_build': binding(hip_rel),
    'host': '192.168.5.161', 'label': 'context-r47-integer-mtp-r1',
    'decode_mode': 'mtp', 'runtime_build_id': manifest['runtime_build_id'],
    'image': manifest['image'], 'bundle_sha256': manifest['bundle_manifest_sha256'],
    'binaries': manifest['artifacts'],
    'model_plan': manifest['model_plan'], 'predictor_plan': manifest['predictor_plan'],
    'model_stat_unchanged': True, 'original_model_stat_witnesses': 5,
    'configuration': {'server_argv': h['server_argv'], 'context_tokens': 16384,
                       'prefill_chunk_tokens': 2048, 'prefill_capacity_tokens': 2048,
                       'max_active': 8, 'RAM_prefix_cache': False,
                       'API_port': h['api_port'], 'management_port': h['management_port'],
                       'ports_are_private_ephemeral_loopback': True},
    'general_OpenAI_checks': 37, 'bounded_integer_checks': 66,
    'passed_OpenAI_checks': h['passed'], 'passed_integer_checks': ints['passed'],
    'independent_exact_rational_wire_verification': wire, 'offline_review_guards': guards,
    'MTP_execution_observation': {key: review[key] for key in
        ('deduplicated_plain_POST_timing_count', 'plain_POST_MTP_timing_count',
         'plain_POST_MTP_drafted_sum', 'plain_POST_MTP_accepted_sum',
         'counter_scope', 'expected_AR_fallback')},
    'counter_review': binding(review_rel),
    'controller_exit_code': controller['controller_actual_exit_code'],
    'supervisor_exit_code': r['exit_code'], 'container_child_exit_code': r['child_exit_code'],
    'server_exit_code': h['server_exit_code'],
    'container_init_cleanup': {'exit_code': r['final_container_state']['ExitCode'],
        'scope': 'Idle distrobox init ends under owned container cleanup after server and HTTP helper exit0; separate from inference and controller exits.'},
    'supervisor_identity': {'pid': r['pid'], 'start_ticks': r['start_ticks']},
    'container_identity': r['container'], 'lease': r['lease'],
    'lease_released_at_utc': r['lease_released_at'],
    'fresh_closure': c, 'closure_actual_exit_code': closure['actual_exit_code'],
    'peer_coordination': coordination,
    'remote_temperature_peaks_C': review['peaks_c'],
    'telemetry_samples': review['telemetry_samples'],
    'sampled_resources': {'peak_gtt_bytes': review['sampled_peak_gtt_bytes'],
        'peak_system_used_ram_bytes': review['sampled_peak_system_used_ram_bytes'],
        'CPU_process_threads': review['sampled_compute_process_threads'],
        'scope': 'Sampled system/process observations, including HIP helper threads. Not allocation-exact engine accounting, reactive owner count or fit guarantee.'},
    'thermal_policy': manifest['thermal_policy'], 'collected_remote_files_verified': 19,
    'preserved_local_counter_review_failure': failure,
    'original_failed_inline_reviewer_source_archived': False,
    'new_GPU_test_build_or_model_run_for_sealing': False,
    'product_Python_dependency_added': False,
    'stale_r37_MTP_manifest_launched': False,
    'same_runtime_paired_AR37_plus_integer66_comparison': False,
    'MTP_target_distribution_controller_fault_quality_cost_qualified': False,
    'larger_prefill_chunks_qualified': False,
    'open_task_numbers': [2, 3, 4, 5, 6, 7],
    'next_gate': 'Original-weight larger-chunk parity/cache/cancel/fairness and actual MTP numerical/controller, quality, fault and resource acceptance; matched benchmarks then Terminal Bench last.',
    'no_standing_root_job_lease_waiter_window_reservation_handle_after_closure': True,
    'publication': False, 'goal_complete': False,
    'portable_raw_archive': {'path': 'raw/' + archive_path.name,
        **ident(archive_path), 'members': len(members)},
    'raw_artifacts': members,
}
with receipt_path.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({'receipt': str(receipt_path.relative_to(root)),
                  'archive': receipt['portable_raw_archive'],
                  'state': receipt['state'], 'new_GPU_or_HTTP_test': False}))
