# SPDX-License-Identifier: MIT
"""Verify collected own HTTP/provenance/counters; no server, model or GPU."""
from pathlib import Path
import datetime, hashlib, json

root = Path('evidence/context-r47-integer-mtp-r1')
collection = json.loads((root/'collection.json').read_text())
assert collection['exit_code'] == 0 and len(collection['inventory']['files']) == 19
for rel,expected in collection['inventory']['files'].items():
    p = root/rel
    assert p.is_file() and not p.is_symlink()
    with p.open('rb') as f: sha = hashlib.file_digest(f,'sha256').hexdigest()
    assert {'bytes':p.stat().st_size,'sha256':sha} == expected,rel
r = json.loads((root/'result.json').read_text())
h = json.loads((root/'http-result.json').read_text())
ints = json.loads((root/'http-schema-integer-result.json').read_text())
assert r == json.loads((root/'controller-terminal-result.json').read_text())
assert r['state'] == h['state'] == ints['state'] == 'PASSED'
assert r['exit_code'] == r['child_exit_code'] == h['server_exit_code'] == 0
assert r['models_before'] == r['models_after'] and r['model_stat_unchanged']
assert len(r['models_before']) == 5 and h['mode'] == 'mtp'
assert len(set(h['passed'])) == len(h['passed']) == 37
assert len(set(ints['passed'])) == len(ints['passed']) == 66
assert json.loads(Path('evidence/context-r47-mtp-rational-wire-proof.json').read_text())['valid_integer_outputs'] == 60
peaks = {}; n = 0; gtt = 0; ram = 0; threads = []; compute_ids = set()
for line in (root/'telemetry.jsonl').read_text().splitlines():
    row = json.loads(line); n += 1
    for t in row['temperatures']:
        peaks[t['name']] = max(peaks.get(t['name'],-100),t['value_c'])
    gtt = max(gtt,row['gpu']['mem_info_gtt_used'])
    ram = max(ram,row['memory']['MemTotal']-row['memory']['MemAvailable'])
    for proc in row['dri']:
        if r['container'] in proc.get('cgroup','') and 'Threads' in proc.get('status',{}):
            threads.append(int(proc['status']['Threads']))
            compute_ids.add((proc['pid'],proc['start_ticks']))
wire = [json.loads(line) for line in (root/'http-wire.jsonl').read_text().splitlines()]
timings = []; fallback = []; seen = set()
for index,row in enumerate(wire):
    # Stored-object metadata POSTs also return the original object's counters.
    # Count only creation endpoints, excluding updates/cancel/replay/GET views.
    if (row.get('method') != 'POST' or row.get('status') != 200 or
            row.get('path') not in ('/v1/chat/completions','/v1/responses')):
        continue
    try: body = json.loads(row['body'])
    except ValueError: continue
    if not isinstance(body,dict) or not isinstance(body.get('lie_timings'),dict):
        continue
    t = body['lie_timings']; request = row['request']
    assert body['id'] not in seen; seen.add(body['id'])
    assert t['schema'] == 'synapse-lie.request-timings.v1' and t['valid'] is True
    assert all(type(t[k]) is int and t[k] >= 0 for k in
               ('mtp_drafted_tokens','mtp_accepted_tokens','decode_tokens','prefill_tokens','max_decode_output_tokens'))
    assert t['mtp_accepted_tokens'] <= t['mtp_drafted_tokens']
    if t['decode_mode'] == 'ar':
        assert t['max_decode_output_tokens'] == 1
        assert t['mtp_drafted_tokens'] == t['mtp_accepted_tokens'] == 0
        assert request.get('stop') or request.get('logprobs') or request.get('logit_bias')
        fallback.append({'wire_row':index,'id':body['id'],'path':row['path'],
                         'reason_fields':[k for k in ('stop','logprobs','logit_bias') if request.get(k)]})
    else:
        assert t['decode_mode'] == 'mtp' and t['max_decode_output_tokens'] == 8
    timings.append({'wire_row':index,'id':body['id'],'path':row['path'],'timings':t})
mtp = [x for x in timings if x['timings']['decode_mode'] == 'mtp']
assert mtp and sum(x['timings']['mtp_drafted_tokens'] for x in mtp) > 0
assert sum(x['timings']['mtp_accepted_tokens'] for x in mtp) > 0
result = {
 'schema':'synapse-lie.current-MTP-HTTP-functional-review.v1',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'CURRENT_R45_MTP_ENABLED_HTTP37_PLUS_INTEGER66_COLLECTED_AND_REVIEWED_PASS',
 'actual_exit_code':0,'files_verified':19,
 'controller_supervisor_native_server_actual_exit_codes':[0,0,0,0],
 'OpenAI_checks':37,'integer_checks':66,'wire_rows':len(wire),
 'original_model_stat_witnesses':5,'model_stat_unchanged':True,'telemetry_samples':n,
 'peaks_c':peaks,'sampled_peak_gtt_bytes':gtt,'sampled_peak_system_used_ram_bytes':ram,
 'sampled_compute_process_threads':{'min':min(threads) if threads else None,
  'max':max(threads) if threads else None,
  'identities':[{'pid':p,'start_ticks':t} for p,t in sorted(compute_ids)],
  'scope':'Whole server process CPU threads including runtime helpers; not count of reactive device owners'},
 'deduplicated_plain_POST_timing_count':len(timings),'plain_POST_MTP_timing_count':len(mtp),
 'plain_POST_MTP_drafted_sum':sum(x['timings']['mtp_drafted_tokens'] for x in mtp),
 'plain_POST_MTP_accepted_sum':sum(x['timings']['mtp_accepted_tokens'] for x in mtp),
 'counter_scope':'Unique plain POST creation responses with one top-level timing object only; excludes metadata updates, cancel, GET/replay, SSE and hidden/multi-choice results. Not whole-run totals, acceptance rate or speed comparison.',
 'expected_AR_fallback':fallback,'plain_POST_timings':timings,
 'MTP_target_distribution_controller_quality_fault_resources_cost_qualified':False,
 'prefill_chunk_capacity_tokens':2048,'context':16384,'max_active':8,
 'RAM_prefix_cache':False,'new_GPU_model_CPU_forward':False
}
with Path('evidence/context-r47-collected-review.json').open('x') as f:
    json.dump(result,f,indent=2); f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('plain_POST_timings','expected_AR_fallback')}))
print('AR fallback count',len(fallback))
