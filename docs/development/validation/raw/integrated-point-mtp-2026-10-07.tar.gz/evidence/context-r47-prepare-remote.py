# SPDX-License-Identifier: MIT
MANIFEST={'authorization': {'kind': 'operator-one-shot-window', 'service': 'llama-router.service', 'stop_restore_authorized': True, 'quote': 'llama si può stoppaare'}, 'model_plan': {'schema': 'synapse-lie.model-source.v1', 'repository': 'unsloth/Qwen3.8-Flash-Next-GGUF', 'revision': '38bb39ee97821de2c9009abb7e93950eec396e66', 'target': 'pop@192.168.5.161', 'destination': '/home/pop/workspace/synapse-lie/models/qwen38-flash-next-ud-38bb39ee', 'total_bytes': 111334654784, 'files': [{'name': 'Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf', 'bytes': 10946624, 'sha256': '4448186216b3af4cc558bbce2c3213f01608f8f8b2e5267a9767971dd3ec8082', 'url': 'https://huggingface.co/unsloth/Qwen3.8-Flash-Next-GGUF/resolve/38bb39ee97821de2c9009abb7e93950eec396e66/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf'}, {'name': 'Qwen3.8-Flash-Next-UD-Q4_K_XL-00002-of-00004.gguf', 'bytes': 49859583136, 'sha256': '3f342f1c1580473f1ee94ddd5b28206e8c07a70fa1a366f59d1d6c922919a6c9', 'url': 'https://huggingface.co/unsloth/Qwen3.8-Flash-Next-GGUF/resolve/38bb39ee97821de2c9009abb7e93950eec396e66/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00002-of-00004.gguf'}, {'name': 'Qwen3.8-Flash-Next-UD-Q4_K_XL-00003-of-00004.gguf', 'bytes': 49376141504, 'sha256': '56758f40269cad5cd9b0d3d6fbae0f40f6d5be6de49e4ab392dbe83157d9cbd3', 'url': 'https://huggingface.co/unsloth/Qwen3.8-Flash-Next-GGUF/resolve/38bb39ee97821de2c9009abb7e93950eec396e66/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00003-of-00004.gguf'}, {'name': 'Qwen3.8-Flash-Next-UD-Q4_K_XL-00004-of-00004.gguf', 'bytes': 12087983520, 'sha256': '753bda48b98ba4f1636134a90a967de1b2d3908a236c026e464777342e53510a', 'url': 'https://huggingface.co/unsloth/Qwen3.8-Flash-Next-GGUF/resolve/38bb39ee97821de2c9009abb7e93950eec396e66/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00004-of-00004.gguf'}], 'verification': 'Independent official repository metadata agrees with historical SHA-256; target payloads not downloaded or hashed', 'metadata_receipt': 'evidence/strix-point-model-metadata-r1', 'metadata_sha256': '1866707f788ee7c6df4b6c94c8a3d82abc7cc377bdc5f22bdd4f7707b46c144b'}, 'stack': 'rocm10-fedora43', 'image': 'sha256:89c6f9da64694da226948bca7b50d5e4e38caab9e138cb5cbe8678b7778cbe7e', 'transport': 'distrobox', 'thermal_policy': 'cpu-98-nvme-85-gpu-observe-v1', 'thermal_ceiling_c': 98, 'thermal_policy_quote': 'è la CPU che deve avere il guard, non la gpu', 'staging_filesystem_rebind': {'boot_id': 'c82c90ed-7f94-4212-bc52-681c63eac395', 'filesystem_uuid': '720d3f3a-db4b-4287-bf9c-77cc76bcb7cb', 'previous_device': 66308, 'current_device': 66307}, 'verified_boot_id': 'c82c90ed-7f94-4212-bc52-681c63eac395', 'memory_admission': {'expected_peak_gtt_bytes': 107374182400, 'min_available_ram_bytes': 1073741824}, 'action': 'bench', 'source_commit': '2ec9798bf00f774fdaf3d9150ba79712dd88feaf', 'functional_code_checkpoint': 'd6431db85d3119e112ffd01c557aaacd6d7c2714', 'qualified_build_receipt': 'docs/development/validation/prefill-runtime-point-build-2026-10-07.json', 'qualified_build_receipt_sha256': '758439c6854417eb331501e8d63fd6916adf218c88f8a0bdb58f8b344c436212', 'runner_commit': '874129b3cee12bb3a4c0596029626eb8ab2ec7d5', 'fixture_commit': '874129b3cee12bb3a4c0596029626eb8ab2ec7d5', 'bundle': '/home/pop/workspace/synapse-lie/rocm10-fedora-161/bundle-modern-r45', 'bundle_manifest_sha256': '21bfff745f3a8283d7f9f29982ff3139b3aef9a9beabb445495df8abc98a9e10', 'artifacts': {'runtime/bin/lie-attention-qualify': '5de67e60a34eda1a555a7b0aad254de5a28e96f8bde3725dc67e4dc931e8b318', 'runtime/bin/lie-hip-probe': '184c9592fe99071b7cceb087eb0659e0c702b6800adc0f69a59ede84febd03d9', 'runtime/bin/lie-sampling-capture': '4c6feb40ab7ce1829efa9cab393cbdee63dabfd7a85fa61c1da9936e42148179', 'runtime/bin/synapse-lie-bench': '8e2ca0b1d75bebf0c83e534a245a7b7f5280a2e603ffab1dca941eb4e349db3e', 'runtime/bin/synapse-lie-bench-gufo-reference': '55176922bab2286915aa6c2bf998cbe42127327611a89a708f039534efc0d931', 'runtime/bin/synapse-lie-server': 'e06bd471c322f3eef315e8d545f38b54a2f129671a0ba0784b39179cc66e294d'}, 'runtime_build_id': 'rocm10-point-modern-r45-runtime', 'bench_profile': 'modern-http', 'decode_mode': 'mtp', 'distrobox_name': 'lie-context-r47-integer-mtp-r1', 'purpose': 'Final current-r45 MTP HTTP original-weight functional qualification after live prefill integration and coherent ROCm10 build: unchanged37 general OpenAI and66 bounded-integer JSON/SSE controls. Default2048 chunk/capacity,16384 context,eight active sequences,explicit Q8 predictor/draft7,private ephemeral loopback ports and RAM cache disabled. This is selected wire/control acceptance, not independent MTP probability/controller/fault/quality/resources or comparative performance; larger-chunk gates and benchmarks/TB remain later. New job/runtime bindings; stale r37 MTP plan is not launched.', 'memory_estimate_scope': '16K/eight-row workload budget, based on observed AR84.343GiB plus 15.657GiB for explicit2.595GiB Q8 predictor file and speculative/scratch headroom; sampled RAMfloor remains1GiB; not measuredpeak or OOM guarantee', 'prepared_at_utc': '2026-10-07T06:52:32.289473+00:00', 'prepared_manifest_not_admission': True, 'predictor_plan': {'schema': 'synapse-lie.model-source.v1', 'source': 'read-only original predictor on .157', 'target': 'pop@192.168.5.161', 'destination': '/home/pop/workspace/synapse-lie/models/qwen38-flash-next-mtp-q8-r1', 'total_bytes': 2786568256, 'files': [{'name': 'mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf', 'bytes': 2786568256, 'sha256': '5ff54097406a905cf3a724c709124ceb0e3e10235ee862298969e91c96fa96e6'}], 'verification': 'Destination receiver hashes all copied bytes against historical pinned SHA-256'}, 'http_gate_sha256': '4aa144c9484dd2d9c1c421841291acd7b40b7d90275f7577288ac01fb9494605', 'http_controls_sha256': '5a52223a674d850f4493794cc5cc190e807abd10b01adbe9faa29285fa0b54bd', 'http_output_budget_sha256': '46fe16867cc37ab0ec684b02c4a1ae87dbf412b108bb6c5f1f5f5d3975156311', 'http_schema_integer_sha256': '3864bbda9e20b9579be79c8c5b4847632f5fa5995f8142115a91da100521df5e', 'http_tool_gate': True, 'http_control_gate': True, 'http_output_budget_gate': True, 'http_schema_integer_gate': True}
EXPECTED_RUNNER='3fc07d171d64d9c0d2b73efc372a05170686d3f3fe0d5b1c094e8bdd5fe2deb1'
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
base=Path('/home/pop/workspace/synapse-lie')
assert os.getuid()==1000 and base.resolve()==base and base.stat().st_uid==os.getuid()
lease=base/'campaign.lock';st=lease.stat()
assert not lease.is_symlink() and (st.st_dev,st.st_ino)==(66307,105946405)
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
assert boot==MANIFEST['verified_boot_id']==MANIFEST['staging_filesystem_rebind']['boot_id']
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
source=base/'rocm10-fedora-161/source-modern-r45'
runner=source/'tools/strix-point-campaign.py'
assert not runner.is_symlink() and sha(runner)==EXPECTED_RUNNER
bundle=Path(MANIFEST['bundle']);assert bundle.resolve()==bundle
assert sha(bundle/'BUNDLE.json')==MANIFEST['bundle_manifest_sha256']
metadata=json.loads((bundle/'BUNDLE.json').read_text())
assert metadata['source_commit']==MANIFEST['source_commit'] and metadata['artifacts']==MANIFEST['artifacts']
for name,digest in MANIFEST['artifacts'].items():
 path=bundle/name;assert not path.is_symlink() and path.stat().st_uid==os.getuid()
 assert sha(path)==digest,name
model=Path(MANIFEST['model_plan']['destination']);assert model.resolve()==model and model.stat().st_uid==os.getuid()
receipt=model/'SOURCE.json';assert not receipt.is_symlink() and receipt.stat().st_size<65536
proof=json.loads(receipt.read_text());assert proof['result']['state']=='VERIFIED' and proof['plan']==MANIFEST['model_plan']
rows=[]
for row in MANIFEST['model_plan']['files']:
 path=model/row['name'];s=path.stat();assert path.is_file() and not path.is_symlink() and s.st_size==row['bytes'] and s.st_uid==os.getuid()
 rows.append({'name':row['name'],'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns})

predictor=Path(MANIFEST['predictor_plan']['destination'])
assert predictor.resolve()==predictor and predictor.stat().st_uid==os.getuid()
predictor_receipt=predictor/'SOURCE.json'
assert not predictor_receipt.is_symlink() and predictor_receipt.stat().st_size<65536
predictor_proof=json.loads(predictor_receipt.read_text())
assert predictor_proof['result']['state']=='VERIFIED' and predictor_proof['plan']==MANIFEST['predictor_plan']
assert len(predictor_proof['result']['files'])==len(MANIFEST['predictor_plan']['files'])==1
for expected,staged in zip(MANIFEST['predictor_plan']['files'],predictor_proof['result']['files']):
 path=predictor/expected['name'];s=path.stat()
 assert path.is_file() and not path.is_symlink() and s.st_size==expected['bytes'] and s.st_uid==os.getuid()
 assert staged['sha256']==expected['sha256']
 current={'path':str(path),'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
 assert all(current[k]==staged[k] for k in current if k!='device')
 assert current['device']==staged['device'] or (current['device'],staged['device'])==(66307,66308)
 rows.append(current)
helpers={'http-gate.py':('tools/strix-point-http-gate.py','http_gate_sha256'),
 'http-controls.py':('tools/strix-point-openai-controls.py','http_controls_sha256'),
 'http-output-budget.py':('tools/strix-point-output-budget-gate.py','http_output_budget_sha256'),
 'http-schema-integer.py':('tools/strix-point-schema-integer-gate.py','http_schema_integer_sha256')}
for name,(rel,key) in helpers.items():
 path=source/rel
 assert path.is_file() and not path.is_symlink() and path.stat().st_uid==os.getuid()
 assert sha(path)==MANIFEST[key]

inspected=subprocess.run(['docker','inspect',MANIFEST['distrobox_name']],capture_output=True,text=True,timeout=15)
assert inspected.returncode==1
job=base/'context-r47-integer-mtp-r1';assert not job.exists() and not job.is_symlink()
job.mkdir(mode=0o700)
shutil.copy2(runner,job/'runner.py')
for name,(rel,key) in helpers.items():shutil.copy2(source/rel,job/name)
with (job/'manifest.json').open('x') as stream:json.dump(MANIFEST,stream,indent=2);stream.write(chr(10))
record={'scope':'PREPARED_EXCLUSIVE_CURRENT_RUNTIME_MTP_HTTP_FUNCTIONAL_NOT_STARTED_OR_ADMITTED','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runner_sha256':sha(job/'runner.py'),'manifest_sha256':sha(job/'manifest.json'),'bundle_sha256':MANIFEST['bundle_manifest_sha256'],'boot_id':boot,'original_lease_device':st.st_dev,'original_lease_inode':st.st_ino,'model_stat_only':rows,'model_receipt_sha256':sha(receipt),'predictor_receipt_sha256':sha(predictor_receipt),'helper_sha256':{name:sha(job/name) for name in helpers},'GPU_run_model_hash_conversion_or_service_mutation':False,'standby_waiter_window_reservation':False}
with (job/'prepared.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write(chr(10))
print(json.dumps(record))
