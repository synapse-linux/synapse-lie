# SPDX-License-Identifier: MIT
"""Independently review and preserve a terminal original-weight partial gate."""
from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, tarfile

B = Path.cwd()
E = B / 'evidence'
J = E / 'context-r66-tools-ar-r1'
OUT = B / 'docs/development/validation/tool-transitions-ar-point-r4-2026-10-07.json'
RAW = B / 'docs/development/validation/raw/tool-transitions-ar-point-r4-2026-10-07.tar.gz'
assert not OUT.exists() and not RAW.exists()

def read(p): return json.loads(p.read_text())
def digest(p):
    assert p.is_file() and not p.is_symlink(), p
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def bound(p): return {'bytes': p.stat().st_size, 'sha256': digest(p)}

m, run, controller = (read(J / n) for n in ('manifest.json','result.json','controller-result.json'))
collection, http, tools = (read(J / n) for n in ('collection.json','http-result.json','http-tool-transitions-result.json'))
ready = read(E / 'context-r66-tools-readiness.json')
host_path, build_path = (B / ready[k]['path'] for k in ('HOST_receipt','HIP_receipt'))
host, build = read(host_path), read(build_path)
assert bound(host_path) == {k: ready['HOST_receipt'][k] for k in ('bytes','sha256')}
assert bound(build_path) == {k: ready['HIP_receipt'][k] for k in ('bytes','sha256')}
assert m['source_commit'] == build['source_commit'] == ready['runtime_source_commit'] == '64fa7c2a3928d0a53bf4cc4b6783b886348c8acc'
assert m['runner_commit'] == m['fixture_commit'] == ready['client_source_commit'] == '37ff4a6f72869fdc4d579a8e71b18d5bfc2dd4a4'
assert {Path(k).name:v for k,v in m['artifacts'].items()} == build['consumer_binary_SHA256']
assert len(m['artifacts']) == 6 and m['decode_mode'] == 'ar'
assert digest(J/'manifest.json') == run['manifest_sha256'] == controller['manifest_sha256']
for name, item in ready['helpers'].items():
    assert digest(J/name) == item['sha256'] == digest(B/item['source'])
for name, sha in host['current_unchanged_owned_provider_sources'].items(): assert digest(B/name) == sha
assert len(host['current_unchanged_owned_provider_sources']) == 130
assert run['state'] == http['state'] == tools['state'] == 'FAILED'
assert run['exit_code'] == run['child_exit_code'] == controller['exit_code'] == 1
assert http['server_exit_code'] == 0 and not run['cleanup_failures'] and run['model_attempted']
assert run['models_before'] == run['models_after'] and len(run['models_before']) == 4
assert run['model_stat_unchanged'] is True
assert http['passed'] == ['models','chat_json','chat_sse','responses_json','responses_sse']
expected = ['greedy_chat_auto-text_json','greedy_chat_auto-text_sse',
 'greedy_chat_prose-call_json','greedy_chat_prose-call_sse','greedy_chat_parallel_json',
 'greedy_chat_correlated_results_json','greedy_chat_parallel_sse','greedy_chat_correlated_results_sse',
 'greedy_chat_single_json','greedy_chat_single_sse','chat_refusal_orphan',
 'chat_refusal_missing','chat_refusal_duplicate','chat_refusal_unknown']
assert tools['passed'] == expected and set(tools['witnesses']) == set(expected)
assert tools['current_check'] == 'greedy_responses_auto-text_json'
assert tools['failure_kind'] == 'protocol_or_infrastructure' and tools['decode_mode'] == 'ar'
for name in expected[-4:]:
    w=tools['witnesses'][name]
    assert w['http_status'] == 400 and w['executor_before'] == w['executor_after']
for name in ('greedy_chat_correlated_results_json','greedy_chat_correlated_results_sse'):
    w=tools['witnesses'][name]
    assert json.loads(w['text']) == {'alpha':137,'beta':941} and w['calls'] == []
    assert w['timings']['valid'] and w['timings']['decode_mode'] == 'ar'
    assert w['timings']['mtp_drafted_tokens'] == w['timings']['mtp_accepted_tokens'] == 0
wire=[json.loads(line) for line in (J/'http-wire.jsonl').read_text().splitlines()]
posts=[row for row in wire if row['method']=='POST']
correlated=[row for row in posts if row['path']=='/v1/chat/completions'
 and row['request'].get('messages', [{}])[-1].get('content') ==
 'Return only one JSON object mapping alpha and beta to their returned integer values. Do not call functions.']
assert len(correlated)==2 and {r['request']['stream'] for r in correlated}=={False,True}
for row in correlated:
    request=row['request'];assert row['status']==200
    assert (request['seed'],request['temperature'],request['top_p'],request['top_k'],request['min_p'])==(123,0,1,0,0)
    assert request['tool_choice']=='none' and request['max_tokens']==512
    calls=request['messages'][1]['tool_calls'];assert len(calls)==2 and calls[0]['id']!=calls[1]['id']
    keys={call['id']:json.loads(call['function']['arguments'])['key'] for call in calls}
    results=request['messages'][2:-1];assert [r['tool_call_id'] for r in results]==[calls[1]['id'],calls[0]['id']]
    assert {keys[r['tool_call_id']]:json.loads(r['content'])['value'] for r in results}=={'alpha':137,'beta':941}
    if not request['stream']:
        answer=json.loads(row['body'])['choices'][0]['message']['content']
    else:
        chunks=[json.loads(line[6:]) for line in row['body'].splitlines() if line.startswith('data: ') and line!='data: [DONE]']
        answer=''.join(choice.get('delta',{}).get('content') or '' for chunk in chunks for choice in chunk.get('choices',[]))
    assert json.loads(answer)=={'alpha':137,'beta':941}
failure=posts[-1]
assert failure['path']=='/v1/responses' and failure['status']==400
assert failure['request']['seed']==123 and failure['request']['tool_choice']=='auto'
assert failure['request']['input']=='Do not call any function. Reply with only READY.'
assert json.loads(failure['body'])['error']['code']=='invalid_responses_request'
assert '"seed"' not in (B/'src/responses.c').read_text()
assert collection['exit_code']==0 and len(collection['inventory']['files'])==15
assert all(c['exit_code']==0 for c in collection['commands'])
for name,item in collection['inventory']['files'].items(): assert bound(J/name)==item
rows=[json.loads(line) for line in (J/'telemetry.jsonl').read_text().splitlines()]
peaks={kind:max(t['value_c'] for row in rows for t in row['temperatures'] if t['name']==name)
 for kind,name in [('CPU','k10temp'),('GPU','amdgpu'),('NVMe','nvme')]}
assert all(t['value_c']<t['limit_c'] for row in rows for t in row['temperatures'] if t['guarded'])
closure=read(E/'context-r66-tools-ar-closure-r1.json');assert closure['actual_exit_code']==0
closed=closure['result']
assert closed['state']=='WHOLE_CONTAINER_AND_EXACT_GPU_IDENTITIES_CLOSED_NO_STANDING_RESERVATION'
assert len(closed['identities'])==4 and all(p['exact_identity_absent'] for p in closed['identities'])
assert closed['container_cgroup']['exists'] is False
assert len(closed['whole_container_process_scans'])==2
assert all(not s['owned_cgroup_matches'] and not s['unreadable'] for s in closed['whole_container_process_scans'])
assert closed['original_lease']=={'device':66308,'inode':105946405,'free_briefly':True,'released':True}
assert closed['service']==run['service_after'] and closed['service']['ActiveState']=='active'
assert closed['http8000_listeners']==closed['foreign_compute_clients']==closed['guarded_hot']==[]
assert not (E/'context-r66-tools-mtp-r1/plan.json').exists()
assert not (E/'context-r66-tools-mtp-r1/result.json').exists()
files=set(p for p in J.iterdir() if p.is_file())
files.update(p for p in (E/'context-r66-tools-mtp-r1').iterdir() if p.is_file())
files.update(p for p in E.glob('*r66*') if p.is_file())
for name in ['README.md','CHANGELOG.md','docs/BACKEND.md','docs/PROGRESS.md','docs/COORDINATION.md',
 'docs/reference/ABI.md','third_party/README.md','docs/development/protocols/TOOL-TRANSITIONS-GPU-PROTOCOL.md',
 'tools/strix-point-tool-transition-gate.py','tools/strix-point-http-gate.py',
 'tools/strix-point-campaign.py','tools/strix-point-bench-collect.py',
 'src/responses.c','src/chat.c','src/chat_history.c','include/lie/chat_history.h',
 'adapters/gufo.cpp','adapters/gufo_chat.hpp','third_party/gufo-source.json']:
    files.add(B/name)
files.update([host_path,build_path])
inventory={str(p.relative_to(B)):bound(p) for p in sorted(files)}
with RAW.open('xb') as output:
    with gzip.GzipFile(fileobj=output,mode='wb',mtime=0,filename='') as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as package:
            for name,item in inventory.items():
                data=(B/name).read_bytes();assert hashlib.sha256(data).hexdigest()==item['sha256']
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
                package.addfile(info,io.BytesIO(data))
record={'schema':'synapse-lie.point-tool-transitions-failed.v1',
 'at_utc':datetime.now(timezone.utc).isoformat(),'state':'FAILED_PROTOCOL_COLLECTED_AND_CLOSED',
 'classification':'ORIGINAL_WEIGHT_SELECTED_AR_CHAT_PASS_RESPONSES_PROTOCOL_FAILURE_NOT_FULL_ACCEPTANCE',
 'native_runtime_source_commit':m['source_commit'],'client_source_commit':m['runner_commit'],
 'new_checks_passed':14,'new_checks_failed':1,'new_checks_unexecuted':56,'baseline_controls_passed':5,
 'selected_reversed_result_Chat_JSON_SSE_passed':True,'Chat_refusals_before_forward_verified':True,
 'failure':{'check':tools['current_check'],'classification':tools['failure_kind'],
   'request':failure['request'],'response':json.loads(failure['body']),
   'source_diagnosis':'Responses allowlist and normalization omit the supplied seed. Frozen workload unchanged; correction and requalification remain required.'},
 'actual_exits':{'controller':1,'supervisor':1,'helper':1,'server':0,'collector':0,'whole_container_closure':0},
 'coherent_HIP_build_receipt':{'path':str(build_path.relative_to(B)),**bound(build_path)},
 'checking_code_HOST_receipt':{'path':str(host_path.relative_to(B)),**bound(host_path)},
 'runtime_build_id':m['runtime_build_id'],'runtime_artifacts':m['artifacts'],
 'original_model_revision':m['model_plan']['revision'],'original_model_bytes':m['model_plan']['total_bytes'],
 'server_context':16384,'prefill_chunk':2048,'RAM_cache_enabled':False,'C1_sequential_requests':True,
 'models_stat_unchanged':True,'wire_rows_including_readiness':len(wire),'telemetry_samples':len(rows),
 'sampled_peak_C':peaks,'guards':{'CPU_C':98,'NVMe_C':85,'GPU':'observe-only'},
 'lease_released_at':run['lease_released_at'],'whole_container_closure':closed,
 'MTP_prepared_but_not_admitted_or_run':True,'frozen_workload_modified':False,
 'original_weight_full_gate_passed':False,'performance_claim':False,'Terminal_Bench_run':False,
 'model_payloads_newly_hashed':False,'product_Python_dependency':False,
 'native_source_modified':False,'new_HIP_build_or_model_conversion':False,'publication':False,
 'goal_complete':False,'open_task_numbers':[2,3,4,5,6,7],
 'portable_raw_archive':{'path':str(RAW.relative_to(B)),**bound(RAW),'regular_members':len(inventory)},
 'raw_artifacts':inventory}
with OUT.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'receipt':str(OUT.relative_to(B)),'new_checks':[14,1,56],
 'correlated_Chat_JSON_SSE_original_weight_passed':True,'archive':record['portable_raw_archive']}))
