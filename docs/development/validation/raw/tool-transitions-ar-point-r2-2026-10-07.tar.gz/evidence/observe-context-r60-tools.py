# SPDX-License-Identifier: MIT
"""Read only the exact known owned HTTP job; never restart or admit work."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys
mode,suffix=sys.argv[1:];assert mode in ('ar','mtp') and suffix.isdecimal()
label=f'context-r60-tools-{mode}-r1'
manifest=json.loads((Path('evidence')/label/'manifest.json').read_text())
program='LABEL='+repr(label)+'\nEXPECTED='+repr(manifest['runner_sha256'])+'\n'+'''
from pathlib import Path
import datetime,hashlib,json,subprocess
base=Path('/home/pop/workspace/synapse-lie');root=base/LABEL
assert root.resolve()==root and not (root/'runner.py').is_symlink()
assert hashlib.sha256((root/'runner.py').read_bytes()).hexdigest()==EXPECTED
r=json.loads((root/'result.json').read_text())
def ticks(pid):return int(Path('/proc/'+str(pid)+'/stat').read_text().rsplit(')',1)[1].split()[19])
def live(pid,start):
 try:return ticks(pid)==start
 except FileNotFoundError:return False
out={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':LABEL,'state':r['state'],
 'supervisor_pid':r['pid'],'supervisor_start_ticks':r['start_ticks'],'supervisor_live':live(r['pid'],r['start_ticks']),
 'native_init_pid':r.get('container_host_pid'),'native_init_start_ticks':r.get('container_start_ticks'),
 'child_pid':r.get('child_pid'),'child_start_ticks':r.get('child_start_ticks'),
 'ended_at':r.get('ended_at'),'lease_released_at':r.get('lease_released_at'),'error':r.get('error')}
if (root/'http-tool-transitions-result.json').is_file():
 h=json.loads((root/'http-tool-transitions-result.json').read_text());out['tool_state']=h['state'];out['checks_completed']=len(h['passed']);out['current_check']=h.get('current_check');out['tool_error']=h.get('error')
if (root/'http-result.json').is_file():
 h=json.loads((root/'http-result.json').read_text());out['HTTP_state']=h['state'];out['server_exit_code']=h.get('server_exit_code');out['HTTP_error']=h.get('error')
if r.get('container'):
 inspected=subprocess.run(['docker','inspect',r['container'],'--format','{{json .State}}'],capture_output=True,text=True,timeout=15)
 out['container_inspect_exit']=inspected.returncode
 if not inspected.returncode:
  state=json.loads(inspected.stdout);out['container_state']=state
  if state.get('Running') is True and type(state.get('Pid')) is int and state['Pid']>0:
   try:out['container_init_observed_identity']={'container':r['container'],'pid':state['Pid'],'start_ticks':ticks(state['Pid'])}
   except FileNotFoundError:pass
p=root/'telemetry.jsonl'
if p.is_file():
 rows=[json.loads(line) for line in p.read_text().splitlines()];out['samples']=len(rows)
 out['peak_C']={}
 for row in rows:
  for temp in row['temperatures']:
   name=temp['name'];out['peak_C'][name]=max(out['peak_C'].get(name,0),temp['value_c'])
print(json.dumps(out))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':run.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':run.stdout,'stderr':run.stderr}
try:record['result']=json.loads(run.stdout)
except ValueError:pass
out=Path(f'evidence/context-r60-tools-{mode}-live-{suffix}.json')
with out.open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record.get('result',record)))
raise SystemExit(run.returncode)
