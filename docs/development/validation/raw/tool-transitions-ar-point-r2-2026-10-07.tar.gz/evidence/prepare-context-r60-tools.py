# SPDX-License-Identifier: MIT
"""Bind the unchanged native runtime and qualified new clients; local only."""
from pathlib import Path
import datetime,hashlib,json,subprocess
root=Path.cwd()
def read(name):return json.loads((root/name).read_text())
def bound(name):
 p=root/name;assert p.is_file() and not p.is_symlink()
 return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def write(name,data):
 with (root/name).open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
head=subprocess.run(['git','rev-parse','HEAD'],check=True,capture_output=True,text=True).stdout.strip()
assert head=='9d060f61cfc4566af997a2c3ab9e6367381e27a8'
hostpath='docs/development/validation/tool-transitions-host-2026-10-07.json'
host=read(hostpath);assert host['actual_test_count']==121 and host['frozen_HTTP_check_count']==71
for name,identity in host['implementation_sources'].items():assert bound(name)==identity,name
for name,digest in host['current_unchanged_owned_provider_sources'].items():assert bound(name)['sha256']==digest,name
buildpath=host['qualified_HIP_receipt']['path'];assert bound(buildpath)=={k:host['qualified_HIP_receipt'][k] for k in ('bytes','sha256')}
build=read(buildpath)
assert build['source_commit']==host['native_runtime_source_commit'] and build['private_C17_ON_OFF_coherent'] is True
base=read('evidence/context-r58-mtp-tools-manifest.json')
runner=bound('tools/strix-point-campaign.py')
helpers={'runner.py':'tools/strix-point-campaign.py','http-gate.py':'tools/strix-point-http-gate.py',
         'http-tool-transitions.py':'tools/strix-point-tool-transition-gate.py'}
manifests={}
for mode in ('ar','mtp'):
 label=f'context-r60-tools-{mode}-r1';m=json.loads(json.dumps(base))
 for name in ('capture_mode','capture_row_budget','mtp_draft_tokens'):m.pop(name,None)
 if mode=='ar':m.pop('predictor_plan',None)
 m.update(root_checkpoint=head,source_commit=build['source_commit'],runner_commit=head,fixture_commit=head,
          runner_sha256=runner['sha256'],bench_profile='modern-http',decode_mode=mode,
          distrobox_name='lie-'+label,http_gate_sha256=bound(helpers['http-gate.py'])['sha256'],
          http_tool_transition_gate=True,http_tool_transitions_sha256=bound(helpers['http-tool-transitions.py'])['sha256'],
          http_tool_gate=False,http_control_gate=False,http_output_budget_gate=False,http_schema_integer_gate=False,
          qualified_tool_client_HOST_receipt=hostpath,qualified_tool_client_HOST_receipt_sha256=bound(hostpath)['sha256'],
          prepared_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),prepared_manifest_not_admission=True,
          purpose='Final current-runtime original-weight HTTP function/text/result transition qualification:71 frozen checks in both APIs JSON/SSE across greedy/DS4/filtered seed123,actual prose and parallel calls,distinct reversed results/stateless and retained continuation/eight pre-forward refusal oracles. Five historical baseline controls remain. Numerical runtime c662/r56 unchanged;development clients/runner9d060 bind separately. C1 sequential requests/context16384/chunk2048/cache0/private loopback ports. No benchmark or Terminal Bench;quality misses fail without changing questions.',
          memory_admission={'expected_peak_gtt_bytes':100*2**30,'min_available_ram_bytes':2**30},
          memory_estimate_scope='100GiB conservative admission estimate for original Q4 '+('plus original Q8 predictor ' if mode=='mtp' else '')+'and short C1 functional requests/context16384;not a measured peak or fit guarantee. Existing 112GiB GTT ceiling remains unchanged.')
 for obsolete in ('http_controls_sha256','http_output_budget_sha256','http_schema_integer_sha256'):
  m.pop(obsolete,None)
 write(f'evidence/context-r60-tools-{mode}-manifest.json',m);manifests[mode]=m
write('evidence/context-r60-tools-readiness.json',{
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'previous_goal_turn':'PROGRESS-9d060f61-121-HOST-checks-and-frozen-71-client-implemented',
 'scope':'QUALIFIED_CURRENT_DEVELOPMENT_CLIENT_PLUS_UNCHANGED_COHERENT_HIP_RUNTIME_NOT_ADMISSION',
 'client_source_commit':head,'runtime_source_commit':build['source_commit'],
 'HOST_receipt':{'path':hostpath,**bound(hostpath)},'HIP_receipt':{'path':buildpath,**bound(buildpath)},
 'helpers':{name:{'source':source,**bound(source)} for name,source in helpers.items()},
 'native_owned_files_verified':130,'new_GPU_remote_operation':False,'standing_window_reservation':False})
print(json.dumps({'local_prepared_modes':list(manifests),'runtime_source':build['source_commit'],'client_source':head,'checks_per_run':76,'GPU_operation':False}))
