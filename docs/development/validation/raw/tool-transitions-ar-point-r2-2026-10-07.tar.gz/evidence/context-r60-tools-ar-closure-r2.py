# SPDX-License-Identifier: MIT
"""Prove whole-container retirement plus all recorded GPU/launcher identities."""
from pathlib import Path
import hashlib,json,subprocess

base=Path('evidence/context-r60-tools-ar-r1')
job=json.loads((base/'result.json').read_text())
manifest=json.loads((base/'manifest.json').read_text())
assert job['state']=='FAILED' and job['exit_code']==job['child_exit_code']==1
assert job['model_stat_unchanged'] is True
assert job['container_host_pid']>0 and job['container_start_ticks']>0
assert job['ended_at'] and job['lease_released_at'] and not job['cleanup_failures']
cid=job['container'];assert len(cid)==64 and all(c in '0123456789abcdef' for c in cid)
rows=[json.loads(line) for line in (base/'telemetry.jsonl').read_text().splitlines()]
owned={}
for row in rows:
    for process in row['kfd']:
        if cid in process.get('cgroup',''):
            assert type(process['pid']) is int and type(process['start_ticks']) is int
            assert process['pid']>0 and process['start_ticks']>0
            assert process['cgroup'].strip()=='0::/system.slice/docker-'+cid+'.scope'
            owned[(process['pid'],process['start_ticks'])]=process
assert owned,'Need real contemporaneous GPU PID/start_ticks/cgroup witnesses'
inspected=[c for c in job['commands'] if c['argv'][:2]==['docker','inspect'] and '{{json .}}' in c['argv']]
assert len(inspected)==1 and inspected[0]['exit_code']==0
identity=json.loads(inspected[0]['stdout'])
assert identity['Id']==cid and identity['Config']['Labels']['synapse-lie.run']=='/home/pop/workspace/synapse-lie/'+base.name
assert identity['Image']==manifest['image']
assert job['final_container_state']['Running'] is False and job['final_container_state']['Status']=='exited'
old=subprocess.run(['git','show','2077700583a7a129d17b36dbf7aa2ffbbdd7c994:tools/strix-point-campaign.py'],capture_output=True,check=True).stdout
expected=hashlib.sha256(old).hexdigest()
program='JOB='+repr(job)+'\nOWNED='+repr(list(owned.values()))+'\nEXPECTED='+repr(expected)+'\nBOOT='+repr(manifest['verified_boot_id'])+'\n'+'''
from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,stat,subprocess
base=Path('/home/pop/workspace/synapse-lie');cid=JOB['container']
assert os.getuid()==1000 and base.resolve()==base and base.stat().st_uid==os.getuid()
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert boot==BOOT
runner=base/'context-r16-build-r1/runner.py'
with runner.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==EXPECTED
spec=importlib.util.spec_from_file_location('point',runner);point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
observation=point.observe(98,gpu_observation_only=True)
service=subprocess.run(['systemctl','--user','show','llama-router.service','--property=ActiveState,SubState,MainPID'],capture_output=True,text=True,timeout=15)
assert service.returncode==0;router=dict(line.split('=',1) for line in service.stdout.splitlines())
router_pid=int(router['MainPID'])
def alive(pid,start):
 try:return point.ticks(pid)==start
 except FileNotFoundError:return False
identities=[{'role':'supervisor','pid':JOB['pid'],'start_ticks':JOB['start_ticks']},
            {'role':'Distrobox launcher','pid':JOB['child_pid'],'start_ticks':JOB['child_start_ticks']}]
identities += [dict(role='observed container init',pid=JOB['container_host_pid'],start_ticks=JOB['container_start_ticks'])]
identities += [dict(role='observed native GPU owner',pid=p['pid'],start_ticks=p['start_ticks'],cgroup=p['cgroup']) for p in OWNED]
for p in identities:p['exact_identity_absent']=not alive(p['pid'],p['start_ticks'])
scans=[]
for pass_index in range(2):
 matches=[];unreadable=[];vanished=[];checked=0
 for path in Path('/proc').iterdir():
  if not path.name.isdecimal():continue
  try:cgroup=(path/'cgroup').read_text();checked+=1
  except FileNotFoundError:vanished.append(int(path.name));continue
  except (OSError,UnicodeError) as exc:unreadable.append({'pid':int(path.name),'error':str(exc)});continue
  if cid in cgroup:matches.append({'pid':int(path.name),'cgroup':cgroup})
 scans.append({'pass':pass_index,'processes_checked':checked,'owned_cgroup_matches':matches,'unreadable':unreadable,'vanished_during_read':vanished})
group=Path('/sys/fs/cgroup/system.slice/docker-'+cid+'.scope')
group_proof={'path':str(group),'exists':group.exists()}
if group.exists():
 group_proof['events']=(group/'cgroup.events').read_text()
 group_proof['procs']=(group/'cgroup.procs').read_text()
 group_proof['empty']=not group_proof['procs'].strip() and 'populated 0' in group_proof['events'].splitlines()
else:group_proof['empty']=True
container=subprocess.run(['docker','inspect',cid],capture_output=True,text=True,timeout=15)
listed=subprocess.run(['docker','ps','-aq','--filter','label=synapse-lie.run='+str(base/'context-r60-tools-ar-r1')],capture_output=True,text=True,timeout=15)
fd=os.open(base/'campaign.lock',os.O_RDWR|os.O_NOFOLLOW|os.O_CLOEXEC);free=False
try:
 lease=os.fstat(fd);live=(base/'campaign.lock').stat()
 assert stat.S_ISREG(lease.st_mode) and lease.st_uid==os.getuid()
 assert (lease.st_dev,lease.st_ino)==(live.st_dev,live.st_ino)==(66307,105946405)
 try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);free=True
 except BlockingIOError:pass
finally:
 if free:fcntl.flock(fd,fcntl.LOCK_UN)
 os.close(fd)
listeners=[]
for name in ('/proc/net/tcp','/proc/net/tcp6'):
 for line in Path(name).read_text().splitlines()[1:]:
  values=line.split()
  if values[3]=='0A' and int(values[1].rsplit(':',1)[1],16)==8000:listeners.append({'table':name,'local_address':values[1]})
clients=set(observation['kernel_kfd'])|{p['pid'] for p in observation['kfd']}
foreign=sorted(clients-({router_pid} if router['ActiveState']=='active' else set()))
hot=[p for p in observation['temperatures'] if p['guarded'] and p['value_c']>=p['limit_c']]
valid=all(p['exact_identity_absent'] for p in identities) and all(not p['owned_cgroup_matches'] and not p['unreadable'] for p in scans)
valid=valid and group_proof['empty'] and container.returncode==1 and listed.returncode==0 and not listed.stdout.strip()
valid=valid and free and not listeners and not foreign and not hot and router['ActiveState']=='active'
result={'state':'WHOLE_CONTAINER_AND_EXACT_GPU_IDENTITIES_CLOSED_NO_STANDING_RESERVATION' if valid else 'UNVERIFIED_FINAL_CLOSURE',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boot_id':boot,
 'evidence_scope':'Entire recorded container cgroup absent, all actual GPU PID/start_ticks and launcher/supervisor absent; no inferred missing-PID success',
 'observed_container_init_PID_available':True,'original_init_PID_absence_claimed':True,
 'identities':identities,'whole_container_process_scans':scans,'container_cgroup':group_proof,
 'container_inspect':{'exit_code':container.returncode,'stdout':container.stdout,'stderr':container.stderr},
 'label_listing':{'exit_code':listed.returncode,'stdout':listed.stdout,'stderr':listed.stderr},
 'original_lease':{'device':lease.st_dev,'inode':lease.st_ino,'free_briefly':free,'released':True},
 'service':router,'http8000_listeners':listeners,'foreign_compute_clients':foreign,'guarded_hot':hot,
 'observation':observation,'GPU_build_run_or_service_mutation':False,'standing_lease_waiter_reservation':False}
print(json.dumps(result));assert valid
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':run.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),
        'stdout':run.stdout,'stderr':run.stderr}
try:record['result']=json.loads(run.stdout)
except ValueError:pass
with Path('evidence/context-r60-tools-ar-closure-r2.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
r=record.get('result',record)
print(json.dumps({k:v for k,v in r.items() if k not in ('observation','stdout','whole_container_process_scans')}))
raise SystemExit(run.returncode)
