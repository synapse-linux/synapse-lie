#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Offline failed-run review and portable evidence seal; never launches a job."""
import gzip
import hashlib
import io
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path

B = Path(__file__).resolve().parents[1]
E = B / 'evidence'
J = E / 'context-r60-tools-ar-r1'
OUT = B / 'docs/development/validation/tool-transitions-ar-point-r2-2026-10-07.json'
RAW = B / 'docs/development/validation/raw/tool-transitions-ar-point-r2-2026-10-07.tar.gz'


def read(p):
    return json.loads(p.read_text())


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def bound(p):
    return {'path': str(p.relative_to(B)), 'bytes': p.stat().st_size, 'sha256': digest(p)}


assert not OUT.exists() and not RAW.exists(), 'Refuse replacement of a sealed receipt'
manifest = read(J / 'manifest.json')
run = read(J / 'result.json')
controller = read(J / 'controller-result.json')
collection = read(J / 'collection.json')
http = read(J / 'http-result.json')
tools = read(J / 'http-tool-transitions-result.json')
ready = read(E / 'context-r60-tools-readiness.json')
host_path = B / ready['HOST_receipt']['path']
build_path = B / ready['HIP_receipt']['path']
host, build = read(host_path), read(build_path)
assert digest(host_path) == ready['HOST_receipt']['sha256']
assert digest(build_path) == ready['HIP_receipt']['sha256']
assert manifest['source_commit'] == build['source_commit'] == ready['runtime_source_commit']
assert manifest['runner_commit'] == manifest['fixture_commit'] == ready['client_source_commit']
assert len(manifest['artifacts']) == 6
assert {Path(k).name: v for k, v in manifest['artifacts'].items()} == build['consumer_binary_SHA256']
assert manifest['decode_mode'] == 'ar' and manifest['http_tool_transition_gate'] is True
assert manifest['http_tool_gate'] is manifest['http_control_gate'] is False
assert manifest['http_output_budget_gate'] is manifest['http_schema_integer_gate'] is False
assert digest(J / 'manifest.json') == run['manifest_sha256'] == controller['manifest_sha256']
for name, record in ready['helpers'].items():
    assert digest(J / name) == record['sha256'] == digest(B / record['source'])
assert len(host['current_unchanged_owned_provider_sources']) == 130
for name, sha in host['current_unchanged_owned_provider_sources'].items():
    assert digest(B / name) == sha, name
assert run['state'] == http['state'] == tools['state'] == 'FAILED'
assert run['exit_code'] == run['child_exit_code'] == controller['exit_code'] == 1
assert http['server_exit_code'] == 0
assert run['cleanup_failures'] == [] and run['model_attempted'] is True
assert run['models_before'] == run['models_after'] and len(run['models_before']) == 4
assert run['model_stat_unchanged'] is True
assert http['passed'] == ['models', 'chat_json', 'chat_sse', 'responses_json', 'responses_sse']
expected = ['greedy_chat_auto-text_json', 'greedy_chat_auto-text_sse',
            'greedy_chat_prose-call_json', 'greedy_chat_prose-call_sse']
assert tools['passed'] == expected and set(tools['witnesses']) == set(expected)
assert tools['current_check'] == 'greedy_chat_parallel_json'
assert tools['failure_kind'] == 'model_quality'
assert tools['refusals_before_forward_verified'] is False
assert tools['decode_mode'] == 'ar'
for wire in ['json', 'sse']:
    assert tools['witnesses']['greedy_chat_auto-text_' + wire]['text'] == 'READY'
    assert tools['witnesses']['greedy_chat_auto-text_' + wire]['calls'] == []
    prose = tools['witnesses']['greedy_chat_prose-call_' + wire]
    assert prose['text'] == 'Checking values.\n\n'
    assert len(prose['calls']) == 1 and prose['calls'][0]['parsed_arguments'] == {'key': 'alpha'}
    assert prose['timings']['decode_mode'] == 'ar'
wire = [json.loads(line) for line in (J / 'http-wire.jsonl').read_text().splitlines()]
assert len(wire) == 72
failure = wire[-1]
request = failure['request']
assert failure['status'] == 200 and failure['path'] == '/v1/chat/completions'
assert request['messages'] == [{'role': 'user', 'content':
    'Call get_value exactly twice in this turn: once with key alpha and once with key beta. '
    'Both calls are independent and must be issued together. Do not explain.'}]
assert request['parallel_tool_calls'] is True and request['tool_choice'] == 'required'
assert request['stream'] is False and request['max_tokens'] == 512
assert (request['seed'], request['temperature'], request['top_p'], request['top_k'], request['min_p']) == (123, 0, 1, 0, 0)
response = json.loads(failure['body'])
choice = response['choices'][0]
calls = choice['message']['tool_calls']
assert choice['finish_reason'] == 'tool_calls' and len(calls) == 1
assert calls[0]['function']['name'] == 'get_value'
assert json.loads(calls[0]['function']['arguments']) == {'key': 'alpha'}
assert response['usage'] == {'prompt_tokens': 342, 'completion_tokens': 19, 'total_tokens': 361}
assert response['lie_timings']['valid'] is True and response['lie_timings']['decode_mode'] == 'ar'
assert response['lie_timings']['mtp_drafted_tokens'] == response['lie_timings']['mtp_accepted_tokens'] == 0
assert collection['exit_code'] == 0 and all(c['exit_code'] == 0 for c in collection['commands'])
assert len(collection['inventory']['files']) == 15
for name, record in collection['inventory']['files'].items():
    p = J / name
    assert p.stat().st_size == record['bytes'] and digest(p) == record['sha256'], name
telemetry = [json.loads(line) for line in (J / 'telemetry.jsonl').read_text().splitlines()]
assert len(telemetry) == 85
peak = {kind: max(t['value_c'] for row in telemetry for t in row['temperatures'] if t['name'] == name)
        for kind, name in [('CPU', 'k10temp'), ('GPU', 'amdgpu'), ('NVMe', 'nvme')]}
assert peak == {'CPU': 56.75, 'GPU': 61.0, 'NVMe': 62.85}
assert all(t['value_c'] < t['limit_c'] for row in telemetry for t in row['temperatures'] if t['guarded'])
close1 = read(E / 'context-r60-tools-ar-closure-r1.json')
close2 = read(E / 'context-r60-tools-ar-closure-r2.json')
assert close1['actual_exit_code'] == close2['actual_exit_code'] == 0
closed = close2['result']
assert closed['observed_container_init_PID_available'] is True
assert closed['original_init_PID_absence_claimed'] is True
assert len(closed['identities']) == 4 and all(x['exact_identity_absent'] for x in closed['identities'])
assert [(x['pid'], x['start_ticks']) for x in closed['identities']] == [
    (306760, 24997357), (306864, 24997433), (306973, 24997481), (308209, 25003915)]
assert closed['container_cgroup']['exists'] is False
assert len(closed['whole_container_process_scans']) == 2
assert all(x['processes_checked'] == 378 and x['owned_cgroup_matches'] == x['unreadable'] == []
           for x in closed['whole_container_process_scans'])
assert closed['container_inspect']['exit_code'] == 1 and run['container'] in closed['container_inspect']['stderr']
assert closed['label_listing']['exit_code'] == 0 and closed['label_listing']['stdout'] == ''
assert closed['service'] == run['service_after']
assert closed['service']['ActiveState'] == 'active' and closed['service']['MainPID'] == '308644'
assert closed['http8000_listeners'] == closed['foreign_compute_clients'] == closed['guarded_hot'] == []
assert closed['original_lease'] == {'device': 66307, 'inode': 105946405, 'free_briefly': True, 'released': True}
assert closed['standing_lease_waiter_reservation'] is False
assert not (E / 'context-r60-tools-mtp-r1/result.json').exists()
assert not (E / 'context-r60-tools-mtp-r1/plan.json').exists()

review = {
    'schema': 'synapse-lie.tool-transitions-failed-offline-review.v1',
    'at_utc': datetime.now(timezone.utc).isoformat(), 'review_exit_code': 0,
    'scope': 'Offline independent review of retained failed original-weight run; no job rerun',
    'collected_remote_files_verified': 15, 'unchanged_owned_provider_files_verified': 130,
    'native_runtime_source_commit': manifest['source_commit'],
    'client_source_commit': manifest['runner_commit'],
    'state': 'FAILED_MODEL_QUALITY_COLLECTED_AND_CLOSED',
    'new_checks_passed': 4, 'new_checks_failed': 1, 'new_checks_unexecuted': 66, 'baseline_controls_passed': 5,
    'failure': {'check': tools['current_check'], 'classification': tools['failure_kind'],
                'request': request, 'response': response,
                'cause': 'Model/template/grammar cause unresolved; parallel flag permits multiple calls but does not require two'},
    'actual_exits': {'controller': 1, 'supervisor': 1, 'helper': 1, 'server': 0, 'collector': 0,
                    'closure_r1': 0, 'whole_container_closure_r2': 0},
    'wire_rows_including_readiness': 72, 'telemetry_samples': 85, 'sampled_peak_C': peak,
    'models_stat_unchanged': True, 'model_payloads_newly_hashed': False,
    'lease_released_at': run['lease_released_at'], 'whole_container_closure': closed,
    'MTP_prepared_but_not_admitted_or_run': True,
    'frozen_workload_modified': False, 'GPU_retry': False,
    'original_weight_full_gate_passed': False, 'performance_claim': False, 'Terminal_Bench_run': False,
    'goal_complete': False, 'open_task_numbers': [2, 3, 4, 5, 6, 7],
}
review_path = E / 'context-r60-tools-ar-offline-review-r2.json'
assert not review_path.exists()
review_path.write_text(json.dumps(review, indent=2) + '\n')
files = set(p for p in J.iterdir() if p.is_file())
files.update(p for p in (E / 'context-r60-tools-mtp-r1').iterdir() if p.is_file())
files.update(p for p in E.glob('context-r60-*') if p.is_file())
files.update(E / n for n in ['prepare-context-r60-tools.py', 'launch-context-r60-tools-ar.py',
                            'launch-context-r60-tools-mtp.py', 'observe-context-r60-tools.py'])
files.update(B / n for n in ['docs/BACKEND.md', 'docs/PROGRESS.md', 'docs/COORDINATION.md',
    'docs/development/protocols/TOOL-TRANSITIONS-GPU-PROTOCOL.md',
    'tools/strix-point-tool-transition-gate.py', 'tools/strix-point-http-gate.py',
    'tools/strix-point-campaign.py', 'tools/strix-point-bench-collect.py'])
files.update([host_path, build_path, Path(__file__).resolve(), E / 'seal-tool-transitions-ar-point-r60.py'])
inventory = {str(p.relative_to(B)): {'bytes': p.stat().st_size, 'sha256': digest(p)} for p in sorted(files)}
with RAW.open('xb') as dest:
    with gzip.GzipFile(fileobj=dest, mode='wb', mtime=0, filename='') as gz:
        with tarfile.open(fileobj=gz, mode='w') as archive:
            for name in inventory:
                data = (B / name).read_bytes()
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                archive.addfile(info, io.BytesIO(data))
receipt = dict(review)
receipt.update({
    'schema': 'synapse-lie.point-tool-transitions-failed.v1',
    'classification': 'ORIGINAL_WEIGHT_SELECTED_AR_HTTP_FAILURE_NOT_FULL_ACCEPTANCE',
    'coherent_HIP_build_receipt': bound(build_path), 'checking_code_HOST_receipt': bound(host_path),
    'runtime_build_id': manifest['runtime_build_id'], 'runtime_artifacts': manifest['artifacts'],
    'source_checkpoint': manifest['runner_commit'],
    'server_context': 16384, 'prefill_chunk': 2048, 'RAM_cache_enabled': False,
    'C1_sequential_requests': True, 'server_max_active': 2,
    'original_model_revision': manifest['model_plan']['revision'],
    'original_model_bytes': manifest['model_plan']['total_bytes'],
    'guards': {'CPU_C': 98, 'NVMe_C': 85, 'GPU': 'observe-only'},
    'native_source_modified': False, 'product_Python_dependency': False,
    'new_HIP_build_or_model_conversion': False, 'publication': False,
    'preserved_offline_count_correction': read(E / 'context-r60-tools-ar-count-correction.json'),
    'standing_remote_job_lease_window_waiter_reservation': False,
    'portable_raw_archive': {**bound(RAW), 'regular_members': len(inventory)},
    'raw_artifacts': inventory,
})
OUT.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'review_exit_code': 0, 'state': receipt['state'], 'receipt': bound(OUT),
                  'raw_archive': receipt['portable_raw_archive']}))
