# SPDX-License-Identifier: MIT
"""Seal the native response-budget regression with all actual failed attempts."""
from pathlib import Path
import datetime, gzip, hashlib, importlib.util, json, subprocess, tarfile
root=Path.cwd().resolve()
spec=importlib.util.spec_from_file_location('capacity_archive_reader',root/'tools/strix-point-steering-quality-collect.py')
reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
def identity(path,maximum=80*2**20):
 return {k:v for k,v in reader.artifact(path,maximum)[1].items() if k in ('bytes','sha256')}
def load(path):return json.loads((root/path).read_text())
def digest(stream):
 sha,size=hashlib.sha256(),0
 while block:=stream.read(2**20):sha.update(block);size+=len(block)
 return {'bytes':size,'sha256':sha.hexdigest()}
stem='steering-quality-response-capacity'
successful=['host-debug-guard-r4','host-asan-guard-r1','profile-debug-guard-r1','profile-asan-guard-r1',
            'core-debug-guard-r1','core-asan-guard-r2','debug-build-guard-r1','asan-build-guard-r1']
failed=['host-debug-guard-r1','host-debug-guard-r2','host-debug-guard-r3','core-asan-guard-r1']
guards={suffix:load('evidence/'+stem+'-'+suffix+'/result.json') for suffix in successful+failed}
assert all(guards[k]['exit_code']==guards[k]['child_exit_code']==0 and guards[k]['reason'] is None for k in successful)
assert all(guards[k]['exit_code']==guards[k]['child_exit_code']==(8 if k=='core-asan-guard-r1' else 1) for k in failed)
cohorts={}
for mode,directory in [('Debug','host-debug-r4'),('ASan/UBSan','host-asan-r1')]:
 found={}
 for name in ('output256-ram64','output256-ram256','output512-ram256'):
  r=load('evidence/'+stem+'-'+directory+'/'+name+'.json')
  assert r['model_inference'] is False and r['server_exit_code']==0
  if name=='output256-ram64':
   assert r['retained_successful_records']==58 and r['observations'][-1]['status']==429
   assert r['observations'][-1]['body']['error']['code']=='response_store_full'
  else:
   assert r['retained_successful_records']==70 and all(v['status']==200 for v in r['observations'])
  found[name]={'records':r['retained_successful_records'],'output_budget':r['output_budget'],
   'response_store_mib':r['response_store_mib'],'last_status':r['observations'][-1]['status'],'actual_server_exit_code':r['server_exit_code']}
 cohorts[mode]=found
for mode,suffix in [('Debug','host-debug-guard-r4'),('ASan/UBSan','host-asan-guard-r1')]:
 assert 'Ran 13 tests' in (root/'evidence'/(stem+'-'+suffix)/'command.log').read_text()
for suffix in ('profile-debug-guard-r1','profile-asan-guard-r1'):
 assert 'Ran 17 tests' in (root/'evidence'/(stem+'-'+suffix)/'command.log').read_text()
native=subprocess.run(['git','diff','--quiet','4c703b3d604c6c877d6a2214d7aee0b15a013f61','--',
 'src','include','adapters','cmake','CMakeLists.txt','tools/native','tools/steering-build.c'])
assert native.returncode==0
members={str(p.relative_to(root)) for p in (root/'evidence').glob(stem+'-*/**/*') if p.is_file()}
members.update(('tools/strix-point-steering-quality-run.py','tools/strix-point-steering-quality-gate.py',
 'tests/test_strix_point_steering_quality_run.py','tests/test_strix_point_steering_quality_profile.py',
 'evidence/test_strix_point_steering_quality_run_before_capacity_failure_logging_r1.py',
 'evidence/seal-steering-quality-response-capacity-host-r1.py','LICENSE'))
identities={name:identity(root/name) for name in sorted(members)}
archive=root/'docs/development/validation/raw/steering-quality-response-capacity-host-2026-10-08.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',compresslevel=6,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
 for name in sorted(members):
  info=tar.gettarinfo(str(root/name),arcname=name);assert info.isfile() and info.size==identities[name]['bytes']
  info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with (root/name).open('rb') as stream:tar.addfile(info,stream)
raw_id=identity(archive);seen=set()
with tarfile.open(archive,mode='r|gz') as tar:
 for member in tar:
  assert member.isfile() and member.name not in seen and member.name in identities
  seen.add(member.name);assert digest(tar.extractfile(member))==identities[member.name]==identity(root/member.name)
assert seen==set(identities)
receipt={'schema':'synapse-lie.steering-response-capacity-host.v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'NATIVE_SYNTHETIC_RESPONSE_RETENTION_BOUNDARY_AND_COMPLETE_COHORT_VERIFIED_GPU_REPEAT_UNRUN',
 'classification':'HOST_SYNTHETIC_CPU_FIXTURE_NOT_MODEL_INFERENCE','actual_exit_code':0,
 'supervisor_checks_per_mode':13,'profile_checks_per_mode':17,'focused_CTests_per_mode':1,
 'native_record_cohorts':cohorts,'response_store_bound_mib':256,'response_store_records':128,
 'preserved_failure_exits':{k:guards[k]['exit_code'] for k in failed},
 'failure_reasons':{'host-debug-guard-r1':'Sandbox refuses socket creation before native server launch.',
  'host-debug-guard-r2':'Stale local fixture server refuses new command option; temporary server log was not retained.',
  'host-debug-guard-r3':'Same stale fixture server refusal, with actual Unknown option log retained.',
  'core-asan-guard-r1':'LeakSanitizer refuses sandbox ptrace; the same unsuppressed test passes outside ptrace.'},
 'successful_guard_results':guards,'native_fixture_binaries':{name:identity(root/name) for name in (
  'build/context-debug/test-synthetic-server','build/tool-http-asan/test-synthetic-server',
  'build/context-debug/test-synthetic-lie-bench','build/tool-http-asan/test-synthetic-lie-bench')},
 'supervisor_source':identity(root/'tools/strix-point-steering-quality-run.py'),
 'regression_source':identity(root/'tests/test_strix_point_steering_quality_run.py'),
 'runtime_source_commit':'4c703b3d604c6c877d6a2214d7aee0b15a013f61','native_source_comparison_actual_exit_code':native.returncode,
 'maximum_local_CPU_c':max(float(v) for g in guards.values() for path,v in g['peak_c'].items() if '/hwmon8/' in path),
 'new_build_directories_created':False,'default_product_dependency_changed':False,'GPU_model_or_remote_operation':False,
 'original_failure_receipt':'docs/development/validation/steering-conciseness-quality-failed-point-2026-10-08.json',
 'original_failure_reclassified_as_success':False,'original_HTTP429_body_was_not_captured':True,
 'original_root_cause_scope':'Native synthetic reproduction and source analysis strongly support response-store exhaustion; original status-only wire does not independently identify its error code.',
 'correctness_questions_scales_natural_stop_zero_parity_effect_thresholds_changed':False,
 'raw':{'path':str(archive.relative_to(root)),**raw_id,'regular_members':len(identities),'members':identities,
  'all_archived_and_current_members_verified':True},
 'roadmap':{'open_items':[2,3,4,5,6,7],'terminal_bench_last':True,'full_goal_complete':False}}
dest=root/'docs/development/validation/steering-quality-response-capacity-host-2026-10-08.json'
with dest.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps({'receipt':str(dest.relative_to(root)),'state':receipt['state'],'native_record_cohorts':cohorts,
 'checks_per_mode':{'supervisor':13,'profile':17,'focused_CTest':1},'raw_bytes':raw_id['bytes'],'raw_members':len(identities),
 'actual_exit_code':0,'maximum_local_CPU_c':receipt['maximum_local_CPU_c']}))
