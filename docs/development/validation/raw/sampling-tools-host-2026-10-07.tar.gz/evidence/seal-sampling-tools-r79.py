#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Seal finished local tooling evidence; no build/test/model or remote operation."""
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import stat
import tarfile

OUT = Path('docs/development/validation/sampling-tools-host-2026-10-07.json')
RAW = Path('docs/development/validation/raw/sampling-tools-host-2026-10-07.tar.gz')
assert not OUT.exists() and not RAW.exists()

def read(path):
    return json.loads(Path(path).read_text())

def bound(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha}

host_path = Path('docs/development/validation/integrated-final-host-2026-10-06.json')
host = read(host_path)
changed = [name for name, item in host['frozen_sources'].items() if bound(name)['sha256'] != item['sha256']]
assert sorted(changed) == ['CMakeLists.txt', 'adapters/gufo.cpp', 'include/lie/executor.h', 'tests/sampling/CMakeLists.txt']
prior = read('docs/development/validation/sampling-capture-host-2026-10-07.json')
libraries = {name: bound(name) for name in prior['read_only_existing_coherent_host_libraries']}
assert libraries == prior['read_only_existing_coherent_host_libraries']
commands, peaks = {}, {}
failures = ['evidence/sampling-tools-r79-release-build', 'evidence/sampling-tools-r79-release-build-r2']
for directory in sorted(Path('evidence').glob('sampling-tools-r79-*')):
    if not directory.is_dir():
        continue
    result = read(directory / 'result.json')
    commands[str(directory)] = result
    expected = 1 if str(directory) in failures else 0
    assert result['exit_code'] == result['child_exit_code'] == expected
    for path, value in result['peak_c'].items():
        peaks[path] = max(value, peaks.get(path, 0))
for suffix, count in [('release-ctest', 3), ('asan-ctest', 3), ('root-ctest', 1)]:
    log = (Path('evidence/sampling-tools-r79-' + suffix) / 'command.log').read_text()
    assert f'100% tests passed out of {count}' in log

tool_cases = ['policy', 'premature-stop', 'arguments', 'vocabulary-hash', 'vocabulary-truncated',
              'vocabulary-fifo', 'vocabulary-symlink', 'vocabulary-stop', 'vocabulary-piece', 'terminal']
text_cases = ['synthetic', 'token', 'SHA', 'truncated', 'terminal', 'generation', 'path', 'row-fifo', 'metadata-fifo']
witnesses = {}
for kind in ['release', 'asan']:
    base = Path('build/sampling-tools-r79-' + kind)
    witnesses[kind] = {}
    for mode, pattern, rows, cases in [('text', 'replay-*', 48, text_cases), ('tools', 'tools-replay-*', 36, tool_cases)]:
        roots = [p for p in base.glob(pattern) if (p / 'REFERENCE.txt').is_file()]
        assert len(roots) == 1
        root = roots[0]
        arms = {arm: bound(root / (arm + '.txt')) for arm in ['REFERENCE', 'CANDIDATE', 'FALLBACK']}
        assert len({item['sha256'] for item in arms.values()}) == 1
        text = (root / 'REFERENCE.txt').read_text()
        assert f'ROWS={rows} COMPLETE_OFFLINE_WITNESSES_NOT_FULL_ACCEPTANCE' in text
        for case in cases:
            assert (root / (case + '.exit')).read_text().strip() == '1'
            assert (root / (case + '.stderr')).read_text().startswith('Sampling replay: ')
        if mode == 'text':
            assert arms['REFERENCE']['sha256'] == '3e6b13a38005c57a56f6de189b2ae2c87457820b10ed45c3a1118c2d2ff3f5f4'
        else:
            assert text.count('allowed=') == 36 and text.count('tool=describe_stack ') == 6
        witnesses[kind][mode] = {'directory': str(root), 'rows': rows, 'complete_witness_lines': len(text.splitlines()),
                                 'arms': arms, 'expected_refusals_actual_exit1': cases}
for mode in ['text', 'tools']:
    assert witnesses['release'][mode]['arms']['REFERENCE']['sha256'] == witnesses['asan'][mode]['arms']['REFERENCE']['sha256']

members, special = {}, {}
def capture(path):
    path = Path(path)
    if path.is_symlink():
        special[str(path)] = {'kind': 'owned-symlink-refusal-fixture', 'target': str(path.readlink()),
                               'payload_bytes': 0, 'recreated_by': 'tests/sampling/tools_replay_contract.cmake'}
    elif path.is_file():
        item = bound(path)
        assert item['path'] not in members
        members[item['path']] = item
    elif stat.S_ISFIFO(path.stat().st_mode):
        special[str(path)] = {'kind': 'owned-FIFO-refusal-fixture', 'payload_bytes': 0,
                               'recreated_by': 'tests/test_sampling_capture.c --fifo'}
    else:
        raise ValueError('Unexpected evidence file type: ' + str(path))

sources = ['CMakeLists.txt', 'adapters/gufo.cpp', 'include/lie/executor.h', 'tools/sampling-capture.c',
           'tools/sampling-capture-format.h', 'tests/sampling/replay.cpp', 'tests/sampling/replay_contract.cmake',
           'tests/sampling/tools_replay_contract.cmake', 'tests/sampling/CMakeLists.txt',
           'tests/sampling_capture/CMakeLists.txt', 'tests/sampling_capture_executor.c', 'tests/test_sampling_capture.c']
for name in sources + [str(host_path), 'docs/development/validation/sampling-capture-host-2026-10-07.json',
                       'evidence/seal-sampling-tools-r79.py']:
    capture(name)
for root in sorted(Path('evidence').glob('sampling-tools-r79-*')):
    if root.is_dir():
        for path in sorted(root.rglob('*')):
            if not path.is_dir():
                capture(path)
for kind in ['release', 'asan', 'root-release']:
    base = Path('build/sampling-tools-r79-' + kind)
    for pattern in ['format-*', 'replay-*', 'tools-replay-*', 'sampling-capture-*']:
        for root in sorted(base.glob(pattern)):
            if root.is_dir():
                for path in sorted(root.rglob('*')):
                    if not path.is_dir():
                        capture(path)
    for name in ['CMakeCache.txt', 'CTestTestfile.cmake', 'build.ninja', 'Testing/Temporary/LastTest.log']:
        capture(base / name)
inventory = (json.dumps(members, indent=2) + '\n').encode()
with RAW.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', compresslevel=3, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name in sorted(members):
                tar.add(name, arcname=name, recursive=False)
            entry = tarfile.TarInfo('ARCHIVE-INVENTORY.json')
            entry.size = len(inventory)
            tar.addfile(entry, io.BytesIO(inventory))
receipt = {
    'schema': 'synapse-lie.sampling-tools-host.v1',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'STRICT_REQUIRED_FUNCTION_CAPTURE_REPLAY_FIXTURES_PASSED_NOT_INFERENCE',
    'base_commit': '65a50a95f46b258c585672b549141ee057ea65c6',
    'scope': 'Development tools plus owner-only stop-token metadata; synthetic fixtures only. GPU/MTP/quality/performance gates remain open.',
    'prior_qualified_runtime_source': 'd63b9b7bb2a8bd90a881cbced41f2b895fabc00f',
    'prior_host_receipt': bound(host_path),
    'existing_frozen_source_files_unchanged': len(host['frozen_sources']) - len(changed),
    'changed_existing_files': changed,
    'executor_ABI3_layout_core_HTTP_scheduler_numerical_algorithms_changed': False,
    'new_runtime_entry': 'lie_model_token_is_stop; owner-only metadata; no forward or sampler mutation',
    'new_runtime_entry_HIP_compiled_or_original_weight_qualified': False,
    'read_only_qualified_libraries': libraries,
    'source_files': {name: bound(name) for name in sources},
    'commands_actual_exits': commands,
    'preserved_initial_link_failures': failures,
    'link_correction': 'Focused validator uses exact C integer/transform helpers with unused sections eliminated. Main project links full lie_core dependencies without that fixture elimination.',
    'focused_checks': {'Release': '3/3', 'ASan_UBSan_LSan_unsuppressed': '3/3', 'main_project': '1/1'},
    'full_witnesses': witnesses,
    'peak_sensor_c': peaks,
    'GPU': 'masked; observed only',
    'archive': bound(RAW),
    'archive_regular_members': len(members) + 1,
    'archive_inventory': members,
    'owned_refusal_special_nodes': special,
    'new_GPU_remote_build_run_lease_reservation': False,
    'MTP': 'r37 prepared only; not admitted; not launched; deferred',
    'open_root_items': [2, 3, 4, 5, 6, 7],
    'Terminal_Bench': 'stopped; collected; closed; deferred last',
    'publication': False
}
OUT.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt': bound(OUT), 'archive': bound(RAW), 'regular_members': len(members) + 1,
                  'tool_witness_sha256': witnesses['release']['tools']['arms']['REFERENCE']['sha256'],
                  'new_test_build_model_remote_operation': False}))
