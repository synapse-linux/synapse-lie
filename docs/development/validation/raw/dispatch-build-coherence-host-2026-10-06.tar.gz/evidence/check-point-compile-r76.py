# SPDX-License-Identifier: MIT
"""Coordinator-only fixture; all compiler/subprocess work is mocked. NOT-BUILD."""
import contextlib, importlib.util, io, json, os, subprocess
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();case=root/'evidence/dispatch-r76-coordinator-fixture'
case.mkdir(exist_ok=False)
(case/'.deps/gufo-f783fedb').mkdir(parents=True)
(case/'third_party').mkdir()
(case/'third_party/gufo-source.json').write_text('{"fixture":"NOT-INFERENCE"}\n')
spec=importlib.util.spec_from_file_location('coordinator',root/'tools/strix-point-rocm10-compile.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=case
captured=[];exists=Path.exists
names=('synapse-lie-server','synapse-lie-bench','synapse-lie-bench-gufo-reference','lie-hip-probe')
def mock_run(argv,**kw):
 captured.append(list(argv))
 if argv[:3]==['cmake','--build','build/'+m.LINK_LABEL]:
  for name in names:
   p=case/'build'/m.LINK_LABEL/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('MOCKED, NOT-COMPILED, NOT-INFERENCE\n')
 if kw.get('stdout'):
  kw['stdout'].write(b'MOCKED COMMAND, NO COMPILER OR DEVICE WORK\n')
 return subprocess.CompletedProcess(argv,0,stdout='MOCK hipcc version; no compiler invoked\n')
def safe_exists(path):return False if str(path)=='/dev/kfd' else exists(path)
with patch.dict(os.environ,{'LIE_ROCM10_BUILD_WINDOW':'admitted'}),patch.object(Path,'exists',safe_exists),patch.object(m.subprocess,'run',mock_run),contextlib.redirect_stdout(io.StringIO()) as out:
 assert m.main()==0
record=json.loads((case/'evidence/rocm10-point-compile-r1/result.json').read_text())
commands={x['name']:x['argv'] for x in record['commands']}
assert set(commands)=={'libraries','reference-libraries','configure','link'}
a=commands['libraries'];b=commands['reference-libraries']
assert a[0]==b[0]=='cmake' and a[-2:]==b[-2:]==['-P','cmake/provider/Build.cmake']
for command in [a,b,commands['configure']]:
 for flag in ['-DLIE_GUFO_STATE_ACCESS=ON','-DLIE_DS4_RUNTIME_CACHE=ON','-DLIE_ATTENTION_DISPATCH_STATS=ON','-DLIE_HIP_ARCHITECTURE=gfx1150']:
  assert flag in command,(flag,command)
assert '-DLIE_C17_SAMPLING=ON' in a and '-DLIE_C17_SAMPLING=OFF' in b
assert not any('build-gufo.py' in value for command in captured for value in command)
actual=[x for x in captured if x[0]=='cmake'];assert len(actual)==4
fixture={'scope':'coordinator command fixture, NOT-BUILD, NOT-INFERENCE','subprocesses_mocked':True,'compiler_invoked':False,'gpu_access':False,'actual_exit_code':0,'captured_commands':captured,'source_commands':commands,'mock_record':record}
(case/'CONTROL-ONLY.json').write_text(json.dumps(fixture,indent=2)+'\n')
print('Canonical ON/OFF command route control PASS; compiler/subprocess mocked, NOT-BUILD')
