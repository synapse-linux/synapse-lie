# SPDX-License-Identifier: MIT
"""Seal only local metadata/control evidence; no model, compiler or remote action."""
from pathlib import Path
import hashlib,json,subprocess,tarfile,gzip,io
root=Path.cwd();sha=lambda x:hashlib.sha256(x).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert base=='bc0e9209abfaaa259ba4401d50c9644ee41929d6'
labels=['dispatch-r76-provider-before','dispatch-r76-release-provider','dispatch-r76-asan-provider','dispatch-r76-coordinator-control']
commands={x:json.loads((root/'evidence'/x/'result.json').read_text()) for x in labels}
for name,r in commands.items():assert r['exit_code']==r['child_exit_code']==(8 if name.endswith('before') else 0)
for kind in ['release','asan']:
 log=(root/f'evidence/dispatch-r76-{kind}-provider/command.log').read_text();assert '100% tests passed out of 3' in log
fixture=json.loads((root/'evidence/dispatch-r76-coordinator-fixture/CONTROL-ONLY.json').read_text())
assert fixture['subprocesses_mocked'] and not fixture['compiler_invoked'] and not fixture['gpu_access']
source_names=sorted(subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).splitlines());assert len(source_names)==8
source_files={name:sha((root/name).read_bytes()) for name in source_names}
# Source readiness maps the actual integrated paths, without claiming inference.
requirements={
 '3':{'feature':'1M context/RoPE, native recall and continuation','paths':['include/lie/rope.h','src/rope.c','src/worker.c','tools/native/recall.c','tools/native/http_bench.c','tools/native/http_transport.c'],'pending':'Original-weight long-context HTTP/recall qualification'},
 '4':{'feature':'Native core/http/depth/cohort benchmark methods, reports/graphs and prefill dispatch','paths':['tools/core-bench.c','tools/executor-bench.c','tools/native/http_curve.c','tools/native/http_multi.c','tools/native/report.c','tools/native/plot.c','include/lie/dispatch.h','src/dispatch.c'],'pending':'Actual HIP/GPU dispatch, matched 1M/C1/2/4/6/8 comparisons and reactive/instrumentation cost'},
 '5':{'feature':'Model-neutral banks, live/planned changes, retained frontier and RAM/SSD semantic identity','paths':['include/lie/steering.h','include/lie/steering_state.h','src/steering.c','src/steering_state.c','src/worker.c','adapters/gufo.cpp','adapters/gufo-state/steering-edits.json'],'pending':'Learned-direction quality, independent graph/correction/fault/vision and matched cost'},
 '6':{'feature':'Greedy/DS4 profiles, top-k/min-p, seeded AR/MTP and HTTP controls','paths':['include/lie/sampling.h','src/sampling.c','src/wire_options.c','adapters/gufo_sampling.hpp','adapters/gufo_distribution.hpp','tools/core-bench.c'],'pending':'Independent original-weight probabilities/filter/tool transitions and matched cost'},
 '7':{'feature':'Exactly three owned C17 sampler responsibilities: grammar/masking, history and compact speculative distributions with buffer ownership','paths':['src/grammar.c','src/sampling_history.c','src/sampling_distribution.c','src/sampling_storage.c','adapters/gufo_grammar.hpp','adapters/gufo_history.hpp','adapters/gufo_distribution.hpp','adapters/gufo_sampling_storage.hpp','cmake/provider/Source.cmake','cmake/provider/Verify.cmake'],'pending':'Coherent latest private HIP producer/consumer compilation, original-weight numerical/fault/resources/quality/cost; no full model/controller/kernel rewrite added'}}
for r in requirements.values():r['source_hashes']={p:sha((root/p).read_bytes()) for p in r['paths']}
ready={'state':'CURRENT_FUNCTIONAL_SOURCE_INTEGRATED_READY_FOR_COMBINED_QUALIFICATION_NOT_RUNTIME_ACCEPTANCE','base_commit':base,'requirements':requirements,'terminal_bench':'Item2 OPEN, stopped/collected/closed, deferred last','root_items_open':[2,3,4,5,6,7],'new_remote_action':False}
(root/'evidence/functional-source-ready-r76.json').write_text(json.dumps(ready,indent=2,sort_keys=True)+'\n')
peak=max(v for name,r in commands.items() for path,v in r['peak_c'].items() if any(s['path']==path and s['name'] in ['k10temp','coretemp'] for s in json.loads((root/'evidence'/name/'plan.json').read_text())['sensors']))
assert peak==78.625
artifacts=source_names+['evidence/functional-source-ready-r76.json','evidence/check-point-compile-r76.py','evidence/seal-dispatch-coherence-r76.py','evidence/dispatch-r76-native-test-inventory.json','build/dispatch-r75-release/provider-fixture-6b87f7a0950e/valid.log']
for name in labels:artifacts +=[p.relative_to(root).as_posix() for p in (root/'evidence'/name).rglob('*') if p.is_file()]
artifacts +=[p.relative_to(root).as_posix() for p in (root/'evidence/dispatch-r76-coordinator-fixture').rglob('*') if p.is_file()]
artifacts=sorted(set(artifacts));manifest={x:sha((root/x).read_bytes()) for x in artifacts}
archive_name='docs/development/validation/raw/dispatch-build-coherence-host-2026-10-06.tar.gz';archive=root/archive_name
assert not archive.exists()
with archive.open('xb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as t:
   for name in artifacts:
    data=(root/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data))
   data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();info=tarfile.TarInfo('ARTIFACT-SHA256.json');info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as t:
 for name,digest in manifest.items():assert sha(t.extractfile(name).read())==digest,name
receipt={'schema':'lie.focused-host-validation.v1','date_utc':'2026-10-06','base_commit':base,
 'state':'BUILD_METADATA_CONTROLS_PASS_SOURCE_READY_PRIVATE_HIP_GPU_PENDING',
 'scope':'Build selection/receipt/source/target controls and compiler-mocked coordinator; NOT-INFERENCE, NOT-HIP-COMPILATION',
 'source_files':source_files,'source_file_count':len(source_files),'commands':commands,
 'checks':{'release_configuration':{'passed':3,'total':3,'actual_exit_code':0},'sanitizer_configuration':{'passed':3,'total':3,'actual_exit_code':0},'c17_memory_instrumentation_for_these_cmake_controls':False,'compiler_mocked_coordinator_control':True},
 'preserved_failure':{'run':labels[0],'actual_ctest_exit_code':8,'reason':'Synthetic receipt omitted newly required observer identity; underlying verifier refusal exit1 recorded in valid.log'},
 'controls':['Boolean type required; string/number/null/object/array rejected','DefaultON and explicitOFF matching accepted; either mismatch refused','Missing identity, missing/short/extra inventory, source/header mutation refused','Recipe missing/hash/drift refused under selected state access','Canonical full CMake ON/OFF provider route with identical state/cache/dispatch/HIP options; all subprocesses mocked'],
 'functional_source_readiness':ready,
 'resources':{'cpu_peak_c':peak,'cpu_guard_c':98,'nvme_guard_c':85,'lower_sensor_limits_honored':True,'gpu_masked':True,'fan_clock_power_mutation':False},
 'compiler_invoked':False,'model_run':False,'remote_action':False,
 'sequencing':'Final combined local qualification, fresh .161 admission/coherent build, functional-quality-fault qualification, matched benchmarks, Terminal Bench last',
 'root_items_open':[2,3,4,5,6,7],
 'archive':{'path':archive_name,'sha256':sha(archive.read_bytes()),'members':len(manifest)+1,'file_hashes':manifest}}
p=root/'docs/development/validation/dispatch-build-coherence-host-2026-10-06.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'receipt_sha256':sha(p.read_bytes()),'archive_sha256':receipt['archive']['sha256'],'archive_members':len(manifest)+1,'source_ready_only':True,'actual_exit_code':0}))
