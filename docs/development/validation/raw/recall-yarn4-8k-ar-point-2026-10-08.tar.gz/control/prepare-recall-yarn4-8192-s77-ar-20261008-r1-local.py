# SPDX-License-Identifier: MIT
"""Freeze the short YaRN4 control on the current r70 runtime; no remote admission."""
from pathlib import Path
import ast
import datetime
import hashlib
import importlib.util
import json
import subprocess

root = Path.cwd().resolve()
evidence = root / 'evidence'
old = 'recall-native-8192-s77-ar-20261007-r1'
label = 'recall-yarn4-8192-s77-ar-20261008-r1'
checkpoint = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


tail_path = root / 'docs/development/validation/steering-build-tail16-point-2026-10-08.json'
tail = json.loads(tail_path.read_text())
assert tail['actual_exits']['strong_closure'] == 0
assert json.loads((evidence / 'steering-build-tail16-postseal-r1.json').read_text())['actual_exit_code'] == 0
manifest = json.loads((evidence / (old + '-manifest.json')).read_text())
current = json.loads((evidence / 'steering-build-multichunk-tail-point-20261008-r1/manifest.json').read_text())
for key in ('source_commit', 'functional_code_checkpoint', 'qualified_build_receipt',
            'qualified_build_receipt_sha256', 'bundle', 'bundle_manifest_sha256',
            'artifacts', 'runtime_build_id', 'runtime_source_pin', 'runner_commit'):
    manifest[key] = current[key]
assert manifest['source_commit'] == '4c703b3d604c6c877d6a2214d7aee0b15a013f61'
manifest['fixture_commit'] = manifest['runner_commit']
manifest['root_checkpoint'] = checkpoint
manifest['runner_sha256'] = sha(root / 'tools/strix-point-campaign.py')
assert manifest['runner_sha256'] == current['runner_sha256']
spec = importlib.util.spec_from_file_location('recall', root / 'tools/strix-point-http-recall-gate.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
settings = gate.settings(dict(manifest['http_recall'], context=1048576, rope_scaling='yarn4'))
settings_path = evidence / (label + '-settings.json')
write_json(settings_path, settings)
manifest.update(http_recall=settings, http_recall_settings_sha256=sha(settings_path),
                canonical_HTTP_window_timeout_seconds=gate.container_timeout(settings),
                prepared_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                distrobox_name='lie-' + label,
                memory_admission={'expected_peak_gtt_bytes': 110 * 1024**3,
                                  'min_available_ram_bytes': 1024**3},
                preceding_strongly_closed_receipt=str(tail_path.relative_to(root)),
                preceding_strongly_closed_receipt_sha256=sha(tail_path),
                purpose='Original-weight current-r70 AR YaRN4 short control: capacity1048576, physical target8192, seed77, chunk/scratch256, C1, two turns TG128, RAM0/SSDoff. Same frozen recall preset/questions/oracle, three unscored calibrations. Qualifies only this short scaled control; no 1M-input, performance comparison, Terminal Bench, conversion, heavyweight model hash, remote build, tuning, installation or publication. Each later size/seed/mode requires separately fresh admission.',
                memory_estimate_scope='110GiB conservative explicit GTT estimate for originalQ4/C1/YaRN4 capacity1048576 with scratch256, minimum availableRAM1GiB; not measured current fit. Historical109.183GiB GTT at physical1M is reference only. HostGTT112GiB unchanged; short input does not qualify long-input memory or recall.')
assert sha(root / manifest['qualified_build_receipt']) == manifest['qualified_build_receipt_sha256']
assert sha(root / 'tools/strix-point-http-recall-gate.py') == manifest['http_recall_gate_sha256']
assert sha(root / manifest['qualified_recall_client_HOST_receipt']) == manifest['qualified_recall_client_HOST_receipt_sha256']
delta = subprocess.run(['git', 'diff', '--exit-code', manifest['source_commit'], 'HEAD', '--',
                        'src', 'include', 'adapters', 'cmake', 'CMakeLists.txt',
                        'tools/steering-build.c', 'tools/executor-bench.c', 'tools/native'],
                       capture_output=True, text=True)
assert delta.returncode == 0 and not delta.stdout
write_json(evidence / (label + '-manifest.json'), manifest)
ready = json.loads((evidence / (old + '-readiness.json')).read_text())
ready.update(at_utc=manifest['prepared_at_utc'], scope='PREPARED_CURRENT_R70_YARN4_SHORT_RECALL_NOT_ADMITTED',
             root_checkpoint=checkpoint, runtime_source=manifest['source_commit'], settings=settings)
ready['HIP_receipt'] = {'path': manifest['qualified_build_receipt'],
                       'bytes': (root / manifest['qualified_build_receipt']).stat().st_size,
                       'sha256': manifest['qualified_build_receipt_sha256']}
ready['helpers']['http-recall-settings.json']['source'] = str(settings_path.relative_to(root))
for record in ready['helpers'].values():
    path = root / record['source']
    record.update(bytes=path.stat().st_size, sha256=sha(path))
write_json(evidence / (label + '-readiness.json'), ready)
wrappers = {}
for name in ('prepare-' + old + '-remote.py', 'before-' + old + '-fresh-r1.py',
             'launch-' + old + '.py', 'observe-' + old + '.py', 'close-' + old + '-r1.py'):
    data = (evidence / name).read_text()
    assert old in data
    data = data.replace(old, label).replace('bundle-modern-r68', 'bundle-modern-r70')
    if name.startswith('launch-'):
        data = data.replace('HTTP tool qualification', 'current-r70 YaRN4 short recall qualification')
    path = evidence / name.replace(old, label)
    ast.parse(data, filename=str(path))
    with path.open('x') as stream:
        stream.write(data)
    wrappers[path.name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
write_json(evidence / (label + '-preparation-recipes.json'), {
    'at_utc': manifest['prepared_at_utc'], 'new_exclusive_helpers': wrappers,
    'historical_helpers_changed': False, 'admitted': False,
    'remote_staging_executed': False, 'future_window_reserved': False})
print(json.dumps({'state': 'LOCALLY_PREPARED_NOT_ADMITTED', 'label': label,
                  'manifest_sha256': sha(evidence / (label + '-manifest.json')),
                  'runtime_source': manifest['source_commit'], 'settings': settings,
                  'memory_admission': manifest['memory_admission'],
                  'GPU_model_remote_build_or_reservation': False}))
