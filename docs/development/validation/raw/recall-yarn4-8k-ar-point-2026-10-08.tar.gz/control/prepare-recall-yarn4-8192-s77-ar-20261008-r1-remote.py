# SPDX-License-Identifier: MIT
"""Stage exclusive persistent owned jobs; no GPU, model hash or service work."""
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();plans={'ar':json.loads((root/'evidence/recall-yarn4-8192-s77-ar-20261008-r1-manifest.json').read_text())}
ready=json.loads((root/'evidence/recall-yarn4-8192-s77-ar-20261008-r1-readiness.json').read_text())
payload={name:(root/item['source']).read_bytes() for name,item in ready['helpers'].items()}
program='PLANS='+repr(plans)+'\nHELPERS='+repr(payload)+'\nBINDINGS='+repr(ready['helpers'])+'\n'+'''
from pathlib import Path
import datetime,hashlib,json,os,subprocess
base=Path('/home/pop/workspace/synapse-lie')
assert os.getuid()==1000 and base.resolve()==base and base.stat().st_uid==os.getuid()
lease=base/'campaign.lock';s=lease.stat();assert not lease.is_symlink() and (s.st_dev,s.st_ino)==(66308,105946405)
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
assert boot=='7a966774-3424-46c3-8045-34f759ea58a1'
mount=json.loads(subprocess.check_output(['findmnt','--json','--target',str(base),'--output','UUID'],text=True,timeout=15))
assert mount.get('filesystems')==[{'uuid':'720d3f3a-db4b-4287-bf9c-77cc76bcb7cb'}]
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
for name,data in HELPERS.items():assert hashlib.sha256(data).hexdigest()==BINDINGS[name]['sha256']
prepared=[]
for mode,m in PLANS.items():
 assert boot==m['verified_boot_id']==m['staging_filesystem_rebind']['boot_id']
 bundle=Path(m['bundle']);assert bundle.resolve()==bundle and bundle.stat().st_uid==os.getuid()
 assert sha(bundle/'BUNDLE.json')==m['bundle_manifest_sha256']
 metadata=json.loads((bundle/'BUNDLE.json').read_text())
 assert metadata['source_commit']==m['source_commit'] and metadata['artifacts']==m['artifacts']
 for name,digest in m['artifacts'].items():
  p=bundle/name;assert p.is_file() and not p.is_symlink() and p.stat().st_uid==os.getuid()
  assert sha(p)==digest,name
 models=[]
 identities=[(m['model_plan'],'1da4904abb2278498b08329038558e8fe20cf95611c64ffa62af00aee457745b')]
 if mode=='mtp':identities.append((m['predictor_plan'],'c4708d9b0289a11d2facb64346a36eb9879480908ec780589d961bf9a56262be'))
 for plan,expected in identities:
  directory=Path(plan['destination']);assert directory.resolve()==directory and directory.stat().st_uid==os.getuid()
  receipt=directory/'SOURCE.json';assert receipt.is_file() and not receipt.is_symlink() and receipt.stat().st_size<65536
  proof=json.loads(receipt.read_text());assert proof['result']['state']=='VERIFIED' and proof['plan']==plan and sha(receipt)==expected
  rows=[]
  for row in plan['files']:
   p=directory/row['name'];s=p.stat();assert p.is_file() and not p.is_symlink() and s.st_uid==os.getuid() and s.st_size==row['bytes']
   rows.append({'name':row['name'],'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns})
  models.append({'directory':str(directory),'SOURCE_sha256':expected,'stat_only':rows})
 label='recall-yarn4-8192-s77-ar-20261008-r1';job=base/label
 assert not job.exists() and not job.is_symlink()
 inspected=subprocess.run(['docker','inspect',m['distrobox_name']],capture_output=True,text=True,timeout=15)
 assert inspected.returncode==1
 job.mkdir(mode=0o700)
 with (job/'manifest.json').open('x') as stream:json.dump(m,stream,indent=2);stream.write(chr(10))
 for name,data in HELPERS.items():
  with (job/name).open('xb') as stream:stream.write(data)
  assert sha(job/name)==BINDINGS[name]['sha256']
 record={'scope':'PREPARED_NATIVE_C_RECALL_NOT_STARTED_OR_ADMITTED','mode':mode,
  'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(job),
  'manifest_sha256':sha(job/'manifest.json'),'helpers':BINDINGS,'boot_id':boot,
  'original_lease_device':66308,'original_lease_inode':105946405,'models_stat_only':models,
  'GPU_model_hash_conversion_service_or_build_operation':False,'standby_waiter_window_reservation':False}
 with (job/'prepared.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write(chr(10))
 prepared.append(record)
print(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'jobs':prepared,'GPU_operation':False}))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=60)
record={'argv':argv,'actual_exit_code':run.returncode,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),'stdout':run.stdout,'stderr':run.stderr}
try:record['result']=json.loads(run.stdout)
except ValueError:pass
with (root/'evidence/recall-yarn4-8192-s77-ar-20261008-r1-jobs-prepared.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
if run.returncode==0:
 for mode,m in plans.items():
  out=root/'evidence/recall-yarn4-8192-s77-ar-20261008-r1';out.mkdir()
  (out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
  for name,data in payload.items():(out/name).write_bytes(data)
 print(json.dumps({'actual_exit_code':0,'prepared_modes':list(plans),'GPU_operation':False}))
else:print(json.dumps(record))
raise SystemExit(run.returncode)
