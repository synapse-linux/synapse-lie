# SPDX-License-Identifier: MIT
"""Add fresh model-stat/artifact checks to the unchanged whole-cgroup closure."""
from pathlib import Path
import ast
import hashlib
import json

root = Path.cwd()
label = 'recall-yarn4-8192-s77-ar-20261008-r1'
old = root/'evidence'/('close-' + label + '-r1.py')
data = old.read_text()
assert data.count("manifest=json.loads((base/'manifest.json').read_text())") == 1
data = data.replace("manifest=json.loads((base/'manifest.json').read_text())",
                    "manifest=json.loads((base/'manifest.json').read_text())\ncollection=json.loads((base/'collection.json').read_text())\nassert collection['exit_code']==0")
assert data.count("'\\nOWNED='") == 1
data = data.replace("'\\nOWNED='", "'\\nINVENTORY='+repr(collection['inventory']['files'])+'\\nOWNED='")
checks = '''
model_stats=[]
for previous in JOB['models_before']:
 p=Path(previous['path']);assert p.resolve()==p and not p.is_symlink()
 s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid()
 model_stats.append({'path':str(p),'bytes':s.st_size,'device':s.st_dev,'inode':s.st_ino,
                     'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns})
assert model_stats==JOB['models_before']==JOB['models_after']
artifact_checks={}
for name,expected in INVENTORY.items():
 relative=Path(name);assert not relative.is_absolute() and '..' not in relative.parts
 p=base/'recall-yarn4-8192-s77-ar-20261008-r1'/relative
 assert p.resolve()==p and not p.is_symlink()
 before=p.stat();assert stat.S_ISREG(before.st_mode) and before.st_uid==os.getuid()
 assert before.st_size==expected['bytes'] and before.st_size<=64*1024*1024
 with p.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 after=p.stat();assert digest==expected['sha256']
 assert all(getattr(before,k)==getattr(after,k) for k in ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns'))
 artifact_checks[name]={'bytes':after.st_size,'sha256':digest}
assert len(artifact_checks)==18
'''
assert data.count('listeners=[]') == 1
data = data.replace('listeners=[]', checks + '\nlisteners=[]')
data = data.replace("'observation':observation,'GPU_build_run_or_service_mutation'",
                    "'model_stats_reverified_unchanged':True,'models_at_strong_closure':model_stats,\n 'collected_artifacts_reverified':artifact_checks,\n 'observation':observation,'GPU_build_run_or_service_mutation'")
data = data.replace(label + '-closure-r1.json', label + '-closure-r2.json')
path = root/'evidence'/('close-' + label + '-r2.py')
ast.parse(data, filename=str(path))
with path.open('x') as stream:
    stream.write(data)
result={'state':'ADDITIVE_STRONG_CLOSURE_PREPARED_NOT_EXECUTED',
        'historical_closure_recipe_not_rewritten':True,
        'original_recipe_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),
        'new_recipe_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'same_whole_cgroup_two_scan_identity_service_and_lease_conditions':True,
        'fresh_four_model_stats_and_all_eighteen_collected_hashes_added':True,
        'GPU_repeat_or_future_reservation':False}
with (root/'evidence/recall-yarn4-closure-preparation-r2.json').open('x') as stream:
    json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps(result))
