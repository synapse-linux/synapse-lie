#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Verify already-collected failed build; no build, test or remote operation."""
import hashlib,json,re
from pathlib import Path
root=Path('evidence/context-r42-build-r1');base=root/'compile-evidence'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
collection=load(base/'collection.json')
assert collection['inventory_exit_code']==0 and collection['exit_code']==1
assert len(collection['files'])==len(collection['commands'])==25
assert all(r['actual_exit_code']==0 for r in collection['commands'])
for name,b in collection['files'].items():
    p=base/name;assert p.stat().st_size==b['bytes'] and sha(p)==b['sha256']
host=load(Path('docs/development/validation/integrated-final-host-2026-10-06.json'))
providers=[load(base/'build'/('rocm10-point-modern-r42-'+v)/'BUILD-RECEIPT.json') for v in ('provider','reference-provider')]
manifest=load(Path('third_party/gufo-source.json'));expected=dict(manifest['files']);changed={}
recipes=re.search(r'set\(manifests ([^)]*)\)',Path('cmake/provider/Source.cmake').read_text()).group(1).split()+['kvc-edits.json']
assert len(recipes)==len(set(recipes))==41
for recipe in recipes:
    edits=load(Path('adapters/gufo-state')/recipe);assert edits['source_pin']==manifest['commit']
    for e in edits['edits']:
        name=e['path'];s=changed.get(name)
        if s is None:s=(Path('.deps/gufo-f783fedb')/name).read_text()
        assert e['old'] and s.count(e['old'])==1
        s=s.replace(e['old'],e['new'],1);changed[name]=s;expected[name]=hashlib.sha256(s.encode()).hexdigest()
dispatch={name:sha(Path(name)) for name in ('src/dispatch.c','include/lie/dispatch.h')}
for i,p in enumerate(providers):
    assert p['state']=='LIBRARIES_BUILT_NOT_EXECUTED_NOT_INFERENCE_QUALIFIED'
    assert p['variant_files']==expected and len(expected)==1019
    assert p['owned_sampling_files']==host['private_provider_inventory'] and len(p['owned_sampling_files'])==120
    assert p['owned_dispatch_files']==dispatch and p['attention_dispatch_stats'] is True
    assert p['c17_sampling'] is (i==0) and p['long_context_wmma'] is True
    assert p['gpu_execution'] is False and p['installation'] is False
    assert all(c['exit_code']==0 for c in p['commands'])
for stage in ('provider','reference-provider','configure','link'):
    assert (base/('evidence/rocm10-point-modern-r42-compile/'+stage+'.exit')).read_text().strip()==('1' if stage=='link' else '0')
compiled=load(base/'evidence/rocm10-point-modern-r42-compile/result.json')
assert compiled['state']=='FAILED' and compiled['failed_stage']=='link' and compiled['exit_code']==1
assert compiled['source_commit']=='c2a9697fbd23a25d3865dd48c472c1eb916b94f1'
link=(base/'evidence/rocm10-point-modern-r42-compile/link.stdout').read_text()
assert 'recompile with -fPIC' in link and 'lie-attention-qualify' in link
closure=load(Path('evidence/context-r42-failed-build-closure-r1.json'))
assert closure['actual_exit_code']==0 and closure['result']['state']=='FRESH_FAILED_BUILD_CLOSURE_NO_STANDING_RESERVATION'
r={'state':'FAILED_LINK_COLLECTED_INDEPENDENTLY_VERIFIED_CLOSED','exit_code':0,'actual_point_build_exit_code':1,
   'collection_actual_exit_code':1,'collection_failure':'25 files copied/hash-verified; stale pre-visible-mask observer hash comparison failed. Original collection record is preserved.',
   'files_verified':25,'provider_variant_files':1019,'private_sampling_files':120,'recipes':len(recipes),'current_dispatch_hashes':dispatch,
   'failed_link':'ROCm10 HIP Clang defaults to PIE; static provider/frontend contain non-PIC objects.',
   'source_commit':compiled['source_commit'],'gpu_execution':False,'model_attempted':False,'original_weight_qualified':False,
   'job_live':False,'lease_held':False,'service_restored':True,'closure':closure['result']}
out=Path('evidence/context-r42-failed-compile-verification-r1.json');assert not out.exists();out.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ('state','exit_code','actual_point_build_exit_code','files_verified','recipes','provider_variant_files','gpu_execution')}))
