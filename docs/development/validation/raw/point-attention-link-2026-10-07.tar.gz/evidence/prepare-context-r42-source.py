#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Seal current owned compiler inputs and independently pinned dependencies."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

root=Path.cwd(); label='context-source-modern-r42';out=root/'evidence'/label
archive=out.with_suffix('.tar.gz')
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert commit.startswith('c2a9697f') and not subprocess.check_output(['git','status','--porcelain'])
assert not out.exists() and not archive.exists()
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
attention_path=root/'docs/development/validation/attention-fixture-host-2026-10-07.json'
attention=json.loads(attention_path.read_text())
assert attention['source_commit']=='86cd4f78ad9f85068ab7e8e828d054c59ec37d2a'
assert attention['scopes']['gpu_execution'] is False
assert all(s['exit_code']==s['child_exit_code']==0 for s in attention['stages'])
long_path=root/'docs/development/validation/prefill-long-wmma-local-hip-2026-10-07.json'
long=json.loads(long_path.read_text())
assert long['source_commit']=='c9c79a7034136fdc99a38f4edd0a5b8677c81c1b'
assert long['GPU_program_or_model_execution'] is False
host_path=root/'docs/development/validation/integrated-final-host-2026-10-06.json'
host=json.loads(host_path.read_text())
assert host['final_test_counts']=={'release':101,'asan':101,'provider-release':67,'provider-asan':67,'core-icu-off':69}
changed=[name for name,b in host['frozen_sources'].items() if sha(root/name)!=b['sha256']]
# Bind all native client inputs from the completed HOST/compile receipt.
client_inputs={}
for name,b in attention['archive']['members'].items():
    if name.startswith('source/') and not name.startswith('source/docs/'):
        relative=name.removeprefix('source/')
        assert sha(root/relative)==b['sha256'],relative
        client_inputs[relative]=b
out.mkdir();excluded=[];copied=[]
proc=subprocess.Popen(['git','archive','--format=tar',commit],stdout=subprocess.PIPE)
try:
    with tarfile.open(fileobj=proc.stdout,mode='r|') as t:
        for m in t:
            p=Path(m.name)
            assert not p.is_absolute() and '..' not in p.parts and (m.isfile() or m.isdir())
            # Product docs and historical evidence are not compiler inputs.
            if p.parts[0]=='docs':
                if m.isfile():excluded.append(m.name)
                continue
            t.extract(m,out,filter='data')
            if m.isfile():copied.append(m.name)
finally:proc.stdout.close()
assert proc.wait()==0
for name in copied:assert sha(out/name)==sha(root/name),name
upstream=root/'.deps/gufo-f783fedb'
manifest=json.loads((out/'third_party/gufo-source.json').read_text())
assert manifest['commit']=='f783fedb9bea2ec7de941f6da4e02f4a4596b29e' and len(manifest['files'])==1019
assert upstream.resolve()==upstream and not upstream.is_symlink()
for name,digest in manifest['files'].items():
    p=upstream/name;assert not p.is_symlink() and p.resolve().is_relative_to(upstream)
    assert sha(p)==digest,name
    target=out/'.deps/gufo-f783fedb'/name;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(p,target);assert sha(target)==digest
prior_path=root/'evidence/context-r11-build-r2/result.json'
prior=json.loads(prior_path.read_text())['build_result']
zstd={}
for name,key in {'zstd.h':'zstd_header_sha256','zstd_errors.h':'zstd_errors_sha256','LICENSE':'zstd_license_sha256'}.items():
    p=root/'evidence/context-source-modern-r11/third_party/point-zstd-dev'/name
    assert p.is_file() and not p.is_symlink() and sha(p)==prior[key]
    target=out/'third_party/point-zstd-dev'/name;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(p,target);zstd[name]=sha(target)
ryu=json.loads((out/'third_party/ryu-source.json').read_text())
for name,b in ryu['files'].items():assert sha(out/'third_party/ryu'/name)==b['sha256']
(out/'SOURCE-COMMIT.txt').write_text(commit+'\n')
(out/'CODE-CHECKPOINT.txt').write_text(attention['source_commit']+'\n')
files=sorted(p for p in out.rglob('*') if p.is_file())
assert all(not p.is_symlink() for p in files)
(out/'SOURCE-FILES.sha256').write_text(''.join(sha(p)+'  ./'+str(p.relative_to(out))+'\n' for p in files))
with archive.open('xb') as f:
    with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as t:t.add(out,arcname=label)
record={'scope':'LOCAL_SEALED_COMPILER_INPUTS_NOT_REMOTE_BUILD_OR_GPU',
        'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit':commit,'code_checkpoint':attention['source_commit'],
        'numerical_provider_checkpoint':long['source_commit'],
        'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
        'source_files_sha256':sha(out/'SOURCE-FILES.sha256'),'source_files':len(files),
        'compile_helper_sha256':sha(out/'cmake/point/Build.cmake'),
        'runner_sha256':sha(out/'tools/strix-point-campaign.py'),
        'gufo_pin':manifest['commit'],'pristine_gufo_files_verified':1019,
        'zstd_prior_receipt_sha256':sha(prior_path),'zstd_development_sha256':zstd,
        'ryu_pin':ryu['commit'],'unchanged_Ryu_files_verified':len(ryu['files']),
        'preceding_host_receipt_sha256':sha(host_path),'preceding_HOST_files_unchanged':len(host['frozen_sources'])-len(changed),
        'changed_since_preceding_HOST':changed,'long_workspace_receipt_sha256':sha(long_path),
        'attention_receipt_sha256':sha(attention_path),'attention_frozen_inputs':client_inputs,
        'tracked_compiler_files_verified':len(copied),'excluded_compiler_unneeded_documentation':excluded,
        'six_required_consumer_targets':['synapse-lie-server','synapse-lie-bench','synapse-lie-bench-gufo-reference','lie-hip-probe','lie-sampling-capture','lie-attention-qualify'],
        'remote_stage_build_or_GPU_run':False,'all_six_tasks_remain_open':True}
with (root/'evidence/context-r42-source-seal.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({k:record[k] for k in ('scope','source_commit','archive_bytes','source_files','tracked_compiler_files_verified','pristine_gufo_files_verified','preceding_HOST_files_unchanged')}))
