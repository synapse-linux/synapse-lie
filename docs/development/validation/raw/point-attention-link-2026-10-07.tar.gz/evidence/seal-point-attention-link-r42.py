#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Package closed failure and corrected local links; no build/test/remote work."""
import datetime,hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path.cwd();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert commit.startswith('60370fc3') and not subprocess.check_output(['git','status','--porcelain'])
receipt=root/'docs/development/validation/point-attention-link-2026-10-07.json'
archive=receipt.parent/'raw/point-attention-link-2026-10-07.tar.gz'
assert not receipt.exists() and not archive.exists()
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
job=load(root/'evidence/context-r42-build-r1/result.json')
controller=load(root/'evidence/context-r42-build-r1/controller-result.json')
closed=load(root/'evidence/context-r42-failed-build-closure-r1.json')
proof=load(root/'evidence/context-r42-failed-compile-verification-r1.json')
assert job['state']=='FAILED' and job['exit_code']==job['child_exit_code']==controller['exit_code']==1
assert not job['model_attempted'] and not job['cleanup_failures'] and job['lease_released_at']
assert closed['actual_exit_code']==proof['exit_code']==0
assert closed['result']['state']=='FRESH_FAILED_BUILD_CLOSURE_NO_STANDING_RESERVATION'
assert proof['recipes']==41 and proof['files_verified']==25
telemetry=[json.loads(s) for s in (root/'evidence/context-r42-build-r1/telemetry.jsonl').read_text().splitlines()]
peaks={}
for row in telemetry:
    for t in row['temperatures']:
        peaks[t['name']]=max(peaks.get(t['name'],-40),t['value_c'])
        if t.get('guarded',True):assert t['value_c']<t['limit_c']
    assert set(row['kernel_kfd'])|{x['pid'] for x in row['kfd']} <= {int(job['service_before']['MainPID'])}
members={}
def add(p,name=None):
    p=Path(p);assert p.is_file() and not p.is_symlink()
    key=name or str(p.relative_to(root));assert key not in members
    members[key]={'path':p,'bytes':p.stat().st_size,'sha256':sha(p)}
for p in sorted((root/'evidence/context-r42-build-r1').rglob('*')):
    if p.is_file():add(p)
for p in sorted((root/'evidence').glob('context-r42-*')):
    if p.is_file():add(p)
for p in sorted((root/'evidence/point-attention-link-r42-package').iterdir()):
    if p.is_file():add(p)
for name in ('prepare-context-r42-source.py','stage-context-r42-source.py','collect-context-r42-failed-compile.py',
             'verify-context-r42-failed-compile-r1.py','seal-point-attention-link-r42.py'):
    add(root/'evidence'/name)
add(root/'evidence/context-source-modern-r42/CMakeLists.txt','source/CMakeLists.failed-c2a9697f.txt')
add(root/'CMakeLists.txt','source/CMakeLists.corrected.txt')
add(root/'LICENSE','source/LICENSE');add(root/'tools/thermal-run.py','source/tools/thermal-run.py')
checks=[];binaries={}
for mode in ('on','off'):
    for stage in ('configure','build'):
        directory=root/'evidence'/('attention-link-r2-'+mode+'-'+stage)
        r=load(directory/'result.json');assert r['exit_code']==r['child_exit_code']==0 and r['reason'] is None
        checks.append({'label':directory.name,**r})
        for p in sorted(directory.iterdir()):
            if p.is_file():add(p)
    build=root/'build'/('attention-link-r2-'+mode)
    for name in ('CMakeCache.txt','build.ninja','lie-attention-qualify'):add(build/name,'local/'+mode+'/'+name)
    rows=(build/'build.ninja').read_text().splitlines()
    i=next(i for i,s in enumerate(rows) if s.startswith('build lie-attention-qualify:'));j=i
    while j<len(rows) and rows[j].strip():j+=1
    assert any('LINK_FLAGS = -no-pie' in s for s in rows[i:j])
    config=(root/'evidence'/('attention-link-r2-'+mode+'-configure')/'command.log').read_text()
    assert 'amdgpu-arch' not in config and 'Failed to get device count' not in config
    b=build/'lie-attention-qualify';binaries[mode]={'bytes':b.stat().st_size,'sha256':sha(b),'executed':False,'link_mode':'non-PIE'}
inventory={name:{k:v[k] for k in ('bytes','sha256')} for name,v in members.items()}
data=(json.dumps(inventory,indent=2)+'\n').encode()
with tarfile.open(archive,'w:gz',compresslevel=3) as t:
    for name,b in sorted(members.items()):
        info=tarfile.TarInfo(name);info.mode=0o644;info.size=b['bytes']
        with b['path'].open('rb') as f:t.addfile(info,f)
    info=tarfile.TarInfo('raw-inventory.json');info.mode=0o644;info.size=len(data);t.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as t:
    assert len(t.getmembers())==len(inventory)+1
    for m in t:
        assert m.isfile()
        with t.extractfile(m) as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
        if m.name=='raw-inventory.json':assert digest==hashlib.sha256(data).hexdigest()
        else:assert m.size==inventory[m.name]['bytes'] and digest==inventory[m.name]['sha256']
r={'schema':'synapse-lie.point-attention-link.v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
   'state':'FAILED_POINT_LINK_CLOSED_LOCAL_CORRECTION_COMPILED','source_commit':commit,
   'failed_point_source_commit':'c2a9697fbd23a25d3865dd48c472c1eb916b94f1',
   'scope':'Failed ROCm10 final link plus corrected local HIP7.2 ON/OFF links. No GPU/model/numerical/performance acceptance.',
   'point_actual_exit_codes':{'provider':0,'reference-provider':0,'configure':0,'link':1,'supervisor':1,'container':1,'controller':1},
   'failure':'HIP Clang on Fedora defaults to PIE, while verified static provider and frontend objects are non-PIC.',
   'correction':'HIP Clang native qualification link explicitly selects -no-pie; HIP package GPU_TARGETS is pinned to the verified architecture before package loading.',
   'current_point_build_verified_files':25,'reconstructed_recipe_count':41,'provider_variant_files':1019,
   'failed_collection_actual_exit_code':1,'collection_correction':'All25 transfer hashes verify; separate verifier binds current dispatch hashes rather than stale HOST hashes. Original failed collection record is retained.',
   'original_lease':job['lease'],'lease_released_at':job['lease_released_at'],'closure':closed['result'],
   'remote_temperature_peaks_c':peaks,'local_checks':checks,'local_artifacts':binaries,
   'CPU_guard':'98C/NVMe85C/lower limits; GPU observe only','GPU_execution':False,'model_attempted':False,
   'remote_current_source_link_qualification':False,'public_ABI_HTTP_reactive_numerical_changed':False,
   'root_remote_job_lease_window_reservation_handle_after_closure':False,'open_root_acceptance_items':[2,3,4,5,6,7],
   'next_gate':'Fresh current-source ROCm10 build/admission; GPU component and original-weight qualification afterward. Matched benchmarks then Terminal Bench last.',
   'archive':{'file':'raw/'+archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'verified_members':len(inventory)+1,'members':inventory}}
receipt.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'receipt':str(receipt.relative_to(root)),'members':len(inventory)+1,'archive_bytes':archive.stat().st_size,'remote_peak_c':peaks,'corrected_source_commit':commit,'gpu_execution':False}))
