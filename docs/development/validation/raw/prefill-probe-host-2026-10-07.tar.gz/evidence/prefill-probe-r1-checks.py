#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Focused local native-only controls; no model forward or GPU execution."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root=Path.cwd()
kind=sys.argv[1]
assert kind in ('release','asan')
label='prefill-probe-r1-'+kind
out=root/'evidence'/(label+'-checks')
out.mkdir()
build=root/'build'/label
env=dict(os.environ,LC_ALL='C',HIP_VISIBLE_DEVICES='-1',ROCR_VISIBLE_DEVICES='-1',
         CUDA_VISIBLE_DEVICES='-1',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
         UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',LSAN_OPTIONS='exitcode=23')
result=dict(classification='HOST-NOT-INFERENCE',gpu_execution=False,model_access=False,
            commands=[],state='RUNNING',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save(): (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
def run(name,argv):
    row=dict(name=name,argv=list(map(str,argv)),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    with (out/(name+'.log')).open('xb') as log:
        p=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    row['exit_code']=p.returncode
    result['commands'].append(row)
    result['state']='FAILED' if p.returncode else 'RUNNING'
    save()
    print(name+': '+str(p.returncode),flush=True)
    if p.returncode: raise SystemExit(p.returncode)
save()
cfg=['cmake','-S',str(root),'-B',str(build),'-G','Ninja',
     '-DCMAKE_BUILD_TYPE='+('Debug' if kind=='asan' else 'Release'),
     '-DLIE_BUILD_ID='+label,'-DLIE_LEGACY_PYTHON_TESTS=OFF','-DLIE_GUFO_RUNTIME=OFF']
if kind=='asan': cfg+=['-DLIE_SANITIZERS=ON','-DCMAKE_C_FLAGS=-fno-pie','-DCMAKE_EXE_LINKER_FLAGS=-no-pie']
run('configure',cfg)
targets=['test-prefill-bench','test-synthetic-lie-bench','test-native-bench',
         'test-core-prefill','test-core-prefill-kvc','test-core-events',
         'test-synthetic-server','test-ssd-http-server','test-steered-lie-bench',
         'synapse-lie-bench','synapse-lie-bench-report']
run('build',['cmake','--build',str(build),'--parallel','2','--target']+targets)
names=['prefill-native-probe-contract','native-benchmark-contract',
       'core-prefill-runtime','core-prefill-kvc-runtime','core-semantic-events']
run('ctest',['ctest','--test-dir',str(build),'--output-on-failure','--parallel','1',
             '--no-tests=error','-R','^('+'|'.join(names)+')$'])
artifacts={}
for target in targets:
    path=build/target
    artifacts[target]=dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
result.update(state='PASS',artifacts=artifacts,expected_tests=len(names),
              ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
save()
