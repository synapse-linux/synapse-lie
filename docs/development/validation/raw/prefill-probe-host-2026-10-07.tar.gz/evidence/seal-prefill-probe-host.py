# SPDX-License-Identifier: MIT
"""Seal completed local qualification-client checks. No remote/model/GPU work."""
from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
root=Path.cwd()
name='prefill-probe-host-2026-10-07'
dest=root/'docs/development/validation'
receipt=dest/(name+'.json');archive=dest/'raw'/(name+'.tar.gz')
assert not receipt.exists() and not archive.exists()

def load(rel):return json.loads((root/rel).read_text())
def ident(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':digest}

files={}
def include(path):
    assert path.is_file() and not path.is_symlink()
    files[str(path.relative_to(root))]=path

native=[]
for kind,cpu in (('release',75.125),('asan',76.25)):
    label='prefill-probe-r2-'+kind
    check=load('evidence/'+label+'-checks/result.json')
    guard=load('evidence/'+label+'-guard/result.json')
    assert check['state']=='PASS' and check['expected_tests']==5
    assert all(r['exit_code']==0 for r in check['commands'])
    assert guard['exit_code']==guard['child_exit_code']==0 and guard['reason'] is None
    assert max(guard['peak_c'].values())==cpu
    for binary,expected in check['artifacts'].items():
        assert ident(root/'build'/label/binary)==expected
    fixtures=list((root/'build'/label).glob('prefill-probe-*'))
    assert len(fixtures)==1
    folder=fixtures[0]
    for mode in ('ar','mtp'):
        for probe in ('live','ram','ssd'):
            rows=[json.loads(line) for line in (folder/(probe+'-'+mode+'.jsonl')).read_text().splitlines()]
            assert rows[0]['synthetic'] is True and rows[0]['prefill_probe']==probe
            assert rows[-1]=={'event':'complete','exit_code':0}
            complete=next(r for r in rows if r['event']=='prefill_probe_complete')
            assert complete['baseline_output_ids']==list(range(32))
    for path in folder.rglob('*'):
        if path.is_file():include(path)
    include(root/'build'/label/'Testing/Temporary/LastTest.log')
    native.append({'configuration':kind,'actual_exit_code':0,'child_exit_code':0,
                   'tests_passed':5,'CPU_peak_C':cpu,'check_receipt':'evidence/'+label+'-checks/result.json',
                   'sanitizers':{'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1',
                                'UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1',
                                'LSAN_OPTIONS':'exitcode=23'} if kind=='asan' else None,
                   'artifact_identities':check['artifacts']})

for path in (root/'evidence').glob('prefill-probe-*'):
    if path.is_dir():
        for child in path.rglob('*'):
            if child.is_file():include(child)
    elif path.is_file():include(path)
failed=load('evidence/prefill-probe-r1-release-checks/result.json')
assert failed['state']=='FAILED' and failed['commands'][-1]['exit_code']==8
assert load('evidence/prefill-probe-r1-release-guard/result.json')['exit_code']==8
first=root/'build/prefill-probe-r1-release'
for folder in first.glob('prefill-probe-*'):
    for path in folder.rglob('*'):
        if path.is_file():include(path)
include(first/'Testing/Temporary/LastTest.log')
first_supervisor=load('evidence/prefill-probe-r2-supervisor-guard/result.json')
assert first_supervisor['exit_code']==first_supervisor['child_exit_code']==1
supervisor=load('evidence/prefill-probe-r3-supervisor-guard/result.json')
assert supervisor['exit_code']==supervisor['child_exit_code']==0 and supervisor['reason'] is None
assert 'Ran 82 tests' in (root/'evidence/prefill-probe-r3-supervisor-guard/command.log').read_text()

source_files=['CMakeLists.txt','tools/core-bench.c','tools/native/report.c','tools/bench-report.py',
              'tools/strix-point-campaign.py','tests/test_prefill_bench.c',
              'tests/test_strix_point_campaign.py','tests/fixtures/prefill-probe-receipts.json',
              'tests/bench_executor.c','tools/thermal-run.py']
for rel in source_files+['README.md','docs/BACKEND.md','docs/PROGRESS.md',
                        'docs/guides/BENCHMARKS.md','docs/reference/METRICS.md',
                        'evidence/seal-prefill-probe-host.py']:
    include(root/rel)
raw={rel:ident(path) for rel,path in sorted(files.items())}
archive.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(archive,'w:gz') as tar:
    for rel,path in sorted(files.items()):tar.add(path,arcname=rel,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(raw)
    for member in tar.getmembers():
        data=tar.extractfile(member).read();expected=raw[member.name]
        assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
        assert ident(root/member.name)==expected
result={'schema':'synapse-lie.prefill-probe-host.v1',
        'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'classification':'HOST_SYNTHETIC_AND_MOCKED_CLIENT_CONTRACTS_NOT_INFERENCE',
        'before_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'scope':'Native C17 functional client, report separation and optional campaign validation only',
        'modes':['live','ram','ssd'],'per_native_configuration':{
            'positive_AR_MTP_probes':6,'CLI_refusals_actual_exit2':14,
            'deliberately_failed_prefill_actual_exit1':1,'functional_reports_refused':6},
        'native_checks':native,'optional_mocked_supervisor':{
            'tests_passed':82,'actual_exit_code':0,'child_exit_code':0,
            'CPU_peak_C':max(supervisor['peak_c'].values()),
            'fixture_identity_transform':'Copies explicitly labelled mocked; synthetic flags set false and context/build ID changed for strict receipt-path tests. Stored fixture originals remain unmodified synthetic=true.'},
        'preserved_failures':[
            {'kind':'Source-preparation script failure before mutation','actual_script_exit_code':1,
             'receipt':'evidence/prefill-probe-source-preparation-failure-r1.json'},
            {'kind':'Native CTest negative-argument fixture error and sandbox loopback refusal',
             'actual_ctest_exit_code':8,'actual_guard_exit_code':8,
             'correction':'Corrected negative-case argument construction; owned private-loopback fixtures rerun with authorized sandbox escalation.'},
            {'kind':'Optional supervisor invalid AR-batch requirement for MTP and duplicate completion admission',
             'actual_test_exit_code':1,'actual_guard_exit_code':1,
             'correction':'MTP execution proven by drafted/accepted counts rather than AR batches; completion must occur exactly once.'}],
        'public_ABI_engine_scheduler_provider_or_numerical_changed':False,
        'new_inference_threads':0,'Python_product_dependency_added':False,
        'GPU_execution':False,'remote_operation':False,'model_access':False,
        'original_weight_live_RAM_SSD_acceptance':'OPEN; new coherent client build and fresh coordinated admission required',
        'performance_comparison':False,'goal_complete':False,'open_task_numbers':[2,3,4,5,6,7],
        'source_files':{rel:raw[rel] for rel in source_files},
        'portable_raw_archive':{'path':'raw/'+archive.name,**ident(archive),'members':len(raw)},
        'raw_artifacts':raw}
receipt.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'receipt':str(receipt.relative_to(root)),'archive':result['portable_raw_archive'],
                  'native':{'release':5,'asan':5},'mocked_supervisor':82,'actual_exit_code':0}))
