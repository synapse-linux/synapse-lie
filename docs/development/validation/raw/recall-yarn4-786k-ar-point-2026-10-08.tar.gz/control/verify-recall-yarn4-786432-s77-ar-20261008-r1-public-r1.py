# SPDX-License-Identifier: MIT
"""Verify all sealed original wire and immutable portable members offline."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,tarfile
root=Path.cwd()
receipt=json.loads((root/'docs/development/validation/recall-yarn4-786k-ar-point-2026-10-08.json').read_text())
label=receipt['job_label'];job=root/'evidence'/label
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
raw=receipt['raw'];archive_path=root/'docs/development/validation'/raw['path']
assert archive_path.stat().st_size==raw['bytes'] and sha(archive_path)==raw['sha256']
inventory={value['path']:value for value in raw['inventory']};seen=set()
assert len(inventory)==raw['members']
with tarfile.open(archive_path,'r|gz') as archive:
 for member in archive:
  assert member.isfile() and member.name in inventory and member.name not in seen
  seen.add(member.name);expected=inventory[member.name]
  stream=archive.extractfile(member);digest=hashlib.sha256();size=0
  while block:=stream.read(2**20):digest.update(block);size+=len(block)
  assert size==expected['bytes'] and digest.hexdigest()==expected['sha256']
  kind,relative=member.name.split('/',1)
  assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
  if kind=='job':current=job/relative
  elif kind in ('control','recipe'):current=root/'evidence'/relative
  elif kind=='source':current=root/(relative if relative=='LICENSE' else 'tools/'+relative)
  else:raise AssertionError('Unknown bounded archive member')
  assert current.is_file() and not current.is_symlink()
  assert current.stat().st_size==size and sha(current)==expected['sha256']
assert seen==set(inventory)
manifest=json.loads((job/'manifest.json').read_text())
assert sha(job/'manifest.json')==receipt['manifest_sha256']
assert sha(job/'runner.py')==manifest['runner_sha256']==sha(root/'tools/strix-point-campaign.py')
spec=importlib.util.spec_from_file_location('frozen_recall',job/'http-recall-gate.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
rows=gate.json_lines(job/'measurements.jsonl',32*2**20)
cases=gate.json_lines(job/'requests.jsonl',8*2**20)
proof=gate.validate(rows,cases,receipt['settings'],'ar')
assert proof['quality_summary']==receipt['quality_summary']
code=0 if proof['state']=='PASSED' else 1
assert receipt['state']=='ORIGINAL_AR_YARN4_786K_'+proof['state']+'_COLLECTED_INDEPENDENT_WIRE_VERIFIED_CLOSED'
exits=receipt['actual_exit_codes']
assert all(exits[key]==code for key in ('controller','supervisor','helper','native_client'))
assert all(exits[key]==0 for key in ('server','collector','strong_closure','independent_review_seal'))
closure=receipt['closure']
assert len(closure['identities'])==5 and all(value['exact_identity_absent'] for value in closure['identities'])
assert closure['container_cgroup']['exists'] is False and closure['container_cgroup']['empty'] is True
assert closure['original_lease']=={'device':66308,'inode':105946405,'free_briefly':True,'released':True}
assert closure['service']['ActiveState']=='active' and not closure['http_listeners_on_observed_ports']
assert closure['foreign_compute_clients']==closure['guarded_hot']==[]
assert len(closure['collected_artifacts_reverified'])==18 and len(closure['models_at_strong_closure'])==4
assert receipt['peak_C_by_sensor']['k10temp']<98 and receipt['peak_C_by_sensor']['nvme']<85
assert receipt['roadmap']=={'open_items':[2,3,4,5,6,7],'terminal_bench_last':True,'full_goal_complete':False}
guard=json.loads((root/'evidence/recall-yarn4-786k-public-seal-guard-r1/result.json').read_text())
assert guard['exit_code']==guard['child_exit_code']==0 and guard['reason'] is None
native=subprocess.run(['git','diff','--quiet',manifest['source_commit'],'--',
 'src','include','adapters','cmake','CMakeLists.txt','tools/native','tools/steering-build.c'])
assert native.returncode==0
record={'state':'SEALED_ORIGINAL_786K_RECALL_WIRE_AND_ALL_MEMBERS_VERIFIED',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit_code':0,
 'original_quality_state':proof['state'],'original_native_exit_code':code,'portable_members':len(seen),
 'all_archived_and_current_members_match':True,'native_source_comparison_actual_exit_code':native.returncode,
 'GPU_or_model_inference_repeated':False,'full_goal_complete':False,'terminal_bench':'LAST'}
with (root/'evidence/recall-yarn4-786k-postseal-r1.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write(chr(10))
print(json.dumps(record))
