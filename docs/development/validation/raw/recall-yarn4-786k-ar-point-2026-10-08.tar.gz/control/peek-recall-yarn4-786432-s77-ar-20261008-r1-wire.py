# SPDX-License-Identifier: MIT
"""Read completed saved rows from the original live run; never control it."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

label = 'recall-yarn4-786432-s77-ar-20261008-r1'
suffix = sys.argv[1]
assert suffix.isdecimal() and int(suffix) > 0
program = '''
from pathlib import Path
import datetime,hashlib,json,os
base=Path('/home/pop/workspace/synapse-lie')
root=base/'recall-yarn4-786432-s77-ar-20261008-r1'
assert os.getuid()==1000 and root.resolve()==root
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='7a966774-3424-46c3-8045-34f759ea58a1'
assert hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()=='4fc4b1e5dbf0b6124ebf67025ffd97d5d6652dfaa5d8da507002801890186cb2'
assert hashlib.sha256((root/'runner.py').read_bytes()).hexdigest()=='e68672b4e2b43ae981daf65462809c98232ba3a9248d634727fa812c4d3dd035'
job=json.loads((root/'result.json').read_text())
assert job['pid']==203585 and job['start_ticks']==7125960
assert job['container']=='05e19a0bd97f4a16e18ba6ebb17222d98102e0550652e6ce96165136dfe6aed2'
path=root/'measurements.jsonl'
rows=[];incomplete=0
if path.exists():
 assert path.is_file() and not path.is_symlink() and path.stat().st_size<=32*2**20
 with path.open() as stream:
  for line in stream:
   if not line.endswith(chr(10)):incomplete+=1;continue
   value=json.loads(line)
   if value.get('event')=='sample':
    rows.append({key:value.get(key) for key in ('event','turn','prompt_tokens','output_tokens','finish_reason','quality','assistant','server_timings','first_output_seconds','wall_seconds')})
print(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'COMPLETED_SAVED_ROWS_OBSERVED_NOT_FULL_COHORT_ACCEPTANCE',
 'original_supervisor_state':job['state'],'saved_samples':rows,
 'incomplete_rows_not_interpreted':incomplete,
 'GPU_generation_or_control_mutation':False,'independent_complete_wire_review_pending':True}))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',
      'pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),
        'actual_exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
try:
    record['result']=json.loads(run.stdout)
except ValueError:
    pass
with Path('evidence',label+'-wire-peek-'+suffix+'.json').open('x') as stream:
    json.dump(record,stream,indent=2)
    stream.write('\n')
print(json.dumps(record.get('result',record)))
raise SystemExit(run.returncode)
