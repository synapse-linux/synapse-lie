# SPDX-License-Identifier: MIT
"""Prepare private read-only/launch/review recipes; execute no remote operation."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import subprocess

root = Path.cwd()
evidence = root/'evidence'
label = 'recall-yarn4-786432-s77-ar-20261008-r1'
parent = 'recall-yarn4-523776-s77-ar-20261008-r1'
quality = 'steering-conciseness-quality-point-20261008-r2'
manifest_path = evidence/(label+'-manifest.json')
manifest_bytes = manifest_path.read_bytes()
manifest_sha = hashlib.sha256(manifest_bytes).hexdigest()
assert manifest_sha == '4fc4b1e5dbf0b6124ebf67025ffd97d5d6652dfaa5d8da507002801890186cb2'
manifest = json.loads(manifest_bytes)
ready = json.loads((evidence/(label+'-readiness.json')).read_text())
native = subprocess.run(['git', 'diff', '--quiet', manifest['source_commit'], '--',
    'src', 'include', 'adapters', 'cmake', 'CMakeLists.txt', 'tools/native', 'tools/steering-build.c'])
assert native.returncode == 0
expected = {name: item['sha256'] for name, item in ready['helpers'].items()}
for name, item in ready['helpers'].items():
    data = (root/item['source']).read_bytes()
    assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
expected['manifest.json'] = manifest_sha
recipes = {}

# Use the current admitted runner, not an older unrelated observation helper.
fresh = (evidence/('before-'+quality+'-fresh-r1.py')).read_text()
fresh = fresh.replace(quality, label)
start = fresh.index('expected = ')
end = fresh.index('\nprogram = ', start)
fresh = fresh[:start]+'expected = '+repr(expected)+'\nassert expected["manifest.json"] == '+repr(manifest_sha)+fresh[end:]
old = "prepared=not (root/'result.json').exists() and not (root/'steering-quality').exists() and not (root/'steering-quality-review.json').exists()"
assert old in fresh
fresh = fresh.replace(old, "prepared=not (root/'result.json').exists() and not (root/'http-started.marker').exists() and not (root/'http-recall-result.json').exists()")
fresh = fresh.replace('frozen original capture window', 'frozen current-r70 786K recall window')
recipes['before-'+label+'-fresh-r1.py'] = fresh

launch = (evidence/('launch-'+quality+'.py')).read_text().replace(quality, label)
launch = launch.replace('bfdb4a3962fe2ab49d0a4da73026921022f05702f1ccc27b6fe975e6fdb8cee1', manifest_sha)
launch = launch.replace("(label+'-stage-r1.json')", "(label+'-jobs-prepared.json')")
old = "assert set(r['source_hashes']) == "
start = launch.index(old)
end = launch.index('\n', start)
launch = launch[:start]+old+repr(set(expected))+launch[end:]
launch = launch.replace('original70-response held-out steering campaign', 'current-r70 786K recall campaign')
marker = "r = fresh['result']"
assert marker in launch
launch = launch.replace(marker, """previous = json.loads((root/'evidence'/'steering-conciseness-quality-point-20261008-r2-closure-r1.json').read_text())
releases = json.loads((root/'evidence'/'steering-conciseness-quality-point-20261008-r2-release-notifications-r1.json').read_text())
assert previous['actual_exit_code'] == 0
assert previous['result']['state'] == 'WHOLE_CONTAINER_AND_EXACT_GPU_IDENTITIES_CLOSED_NO_STANDING_RESERVATION'
assert len(releases['notifications']) == 4
assert {value['name'] for value in releases['notifications']} == {'Point', 'DGX', 'Q2', 'GLM'}
assert all(not value['result'].get('isError', False) for value in releases['notifications'])
r = fresh['result']""")
recipes['launch-'+label+'.py'] = launch

observer = (evidence/('observe-'+parent+'.py')).read_text().replace(parent, label)
observer = observer.replace("if alive and job['state']=='ADMITTED':assert lease_fds", "if alive:assert lease_fds")
recipes['observe-'+label+'.py'] = observer

closure = (evidence/('close-'+parent+'-r2.py')).read_text().replace(parent, label)
old = "old=subprocess.run(['git','show','2077700583a7a129d17b36dbf7aa2ffbbdd7c994:tools/strix-point-campaign.py'],capture_output=True,check=True).stdout\nexpected=hashlib.sha256(old).hexdigest()"
assert old in closure
closure = closure.replace(old, "old=(base/'runner.py').read_bytes();expected=hashlib.sha256(old).hexdigest()\nassert expected==manifest['runner_sha256']")
closure = closure.replace("runner=base/'context-r16-build-r1/runner.py'", "runner=base/'"+label+"/runner.py'")
marker = "assert owned,'Need real contemporaneous GPU PID/start_ticks/cgroup witnesses'"
assert marker in closure
closure = closure.replace(marker, marker+"\nhelper=json.loads((base/'http-recall-result.json').read_text())\nassert set(owned)=={(helper['server_identity']['pid'],helper['server_identity']['start_ticks'])}\nassert helper['server_exit_code']==0 and not helper['cleanup_errors']\nports=sorted({8000,helper['api_port'],helper['management_port']})")
closure = closure.replace("+'\\nEXPECTED='+repr(expected)", "+'\\nCLIENT='+repr(helper['client_identity'])+'\\nPORTS='+repr(ports)+'\\nEXPECTED='+repr(expected)")
marker = "identities += [dict(role='observed native GPU owner',pid=p['pid'],start_ticks=p['start_ticks'],cgroup=p['cgroup']) for p in OWNED]"
assert marker in closure
closure = closure.replace(marker, marker+"\nidentities += [dict(role='native HTTP client',pid=CLIENT['pid'],start_ticks=CLIENT['start_ticks'])]")
closure = closure.replace("int(values[1].rsplit(':',1)[1],16)==8000", "int(values[1].rsplit(':',1)[1],16) in PORTS")
closure = closure.replace("'http8000_listeners':listeners", "'http_listeners_on_observed_ports':listeners,'observed_ports':PORTS")
marker = "boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert boot==BOOT"
assert marker in closure
closure = closure.replace(marker, marker+"\nmount=json.loads(subprocess.check_output(['findmnt','--json','--target',str(base),'--output','UUID'],text=True,timeout=15))\nassert mount.get('filesystems')==[{'uuid':'720d3f3a-db4b-4287-bf9c-77cc76bcb7cb'}] and base.stat().st_dev==66308")
closure = closure.replace("'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boot_id':boot,", "'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boot_id':boot,'filesystem_uuid':mount['filesystems'][0]['uuid'],")
closure = closure.replace(label+'-closure-r2.json', label+'-closure-r1.json')
recipes['close-'+label+'-r1.py'] = closure

seal = (evidence/('seal-'+parent+'.py')).read_text().replace(parent, label)
seal = seal.replace('recall-yarn4-near512k', 'recall-yarn4-786k')
seal = seal.replace('NEAR512K', '786K').replace('near-512K', '786K')
seal = seal.replace("settings['size'] == 523776", "settings['size'] == 786432")
seal = seal.replace(label+'-closure-r2.json', label+'-closure-r1.json')
seal = seal.replace(label+'-peer-coordination-r2.json', label+'-peer-coordination-r1.json')
start = seal.index("assert len(peers['peer_declarations'])")
end = seal.index("live = read(", start)
seal = seal[:start]+"""assert peers['manifest_sha256'] == sha(JOB/'manifest.json')
assert peers['all_four_specific_current_161_non_use'] is True
assert peers['boot_filesystem_original_lease_declared_to_all_four'] is True
assert set(peers['owners']) == {'Point', 'DGX', 'Q2', 'GLM'}
assert all(value['specific_non_use_and_no_intent'] for value in peers['owners'].values())
releases = read(ROOT/'evidence'/f'{LABEL}-release-notifications-r1.json')
assert len(releases['notifications']) == 4
assert {value['name'] for value in releases['notifications']} == {'Point', 'DGX', 'Q2', 'GLM'}
assert len({value['threadId'] for value in releases['notifications']}) == 4
assert all(not value['result'].get('isError', False) for value in releases['notifications'])
"""+seal[end:]
start = seal.index('names = [')
end = seal.index('parts += [(Path(__file__)', start)
seal = seal[:start]+"""names = [f'{LABEL}-manifest.json', f'{LABEL}-settings.json', f'{LABEL}-readiness.json',
         f'{LABEL}-local-preparation-r1.json', f'{LABEL}-operations-prepared-r1.json',
         f'{LABEL}-jobs-prepared.json', f'{LABEL}-peer-coordination-r1.json',
         f'{LABEL}-peer-raw-r1.json', f'{LABEL}-proposal-notifications-r1.json',
         f'{LABEL}-release-notifications-r1.json', f'{LABEL}-closure-r1.json',
         f'before-{LABEL}-fresh-r1.json', f'before-{LABEL}-fresh-r1.py',
         f'launch-{LABEL}.py', f'observe-{LABEL}.py', f'close-{LABEL}-r1.py',
         f'prepare-{LABEL}-remote.py', f'prepare-{LABEL}-local.py',
         'prepare-recall-yarn4-786432-operations-r1.py']
names += [p.name for p in sorted((ROOT/'evidence').glob(f'{LABEL}-live-*.json'))]
parts += [(ROOT/'evidence'/name, 'control/'+name) for name in names]
"""+seal[end:]
seal = seal.replace("'four_current_peer_declarations':peers['peer_declarations']", "'four_current_peer_declarations':peers['owners']")
seal = seal.replace('Does not qualify other seeds, 786K/1M physical inputs, other profiles or MTP.', 'Does not qualify other seeds, 1M physical inputs, other profiles or MTP.')
seal = seal.replace("'closure':closure['result'],", "'closure':closure['result'],'job_label':LABEL,'manifest_sha256':sha(JOB/'manifest.json'),")
seal = seal.replace("'actual_exit_code':0}", "'roadmap':{'open_items':[2,3,4,5,6,7],'terminal_bench_last':True,'full_goal_complete':False},\n 'actual_exit_code':0}")
recipes['seal-'+label+'.py'] = seal

for name, text in recipes.items():
    ast.parse(text, filename=name)
    with (evidence/name).open('x') as stream:
        stream.write(text)
record = {'state':'PRIVATE_CURRENT_R70_786K_RECALL_OPERATIONS_PREPARED_UNEXECUTED',
    'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'label':label,
    'manifest_sha256':manifest_sha, 'native_source_comparison_actual_exit_code':native.returncode,
    'recipes':{name:{'bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest()} for name,text in recipes.items()},
    'uses_current_exact_job_runner':True, 'closure_requires_exact_native_server_and_client_and_three_ports':True,
    'preceding_quality_run_must_be_strongly_closed_and_all_four_releases_delivered_before_launch':True,
    'GPU_remote_or_future_window_operation':False, 'historical_helpers_changed':False,
    'actual_exit_code':0}
with (evidence/(label+'-operations-prepared-r1.json')).open('x') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record))
