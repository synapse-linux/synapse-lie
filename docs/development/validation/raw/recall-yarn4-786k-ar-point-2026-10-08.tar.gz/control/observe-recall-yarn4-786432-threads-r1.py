# SPDX-License-Identifier: MIT
"""Read two bounded /proc snapshots of this exact GPU server only."""
from pathlib import Path
import hashlib
import json
import subprocess

program = '''
from pathlib import Path
import datetime,hashlib,json,os,time
base=Path('/home/pop/workspace/synapse-lie')
root=base/'recall-yarn4-786432-s77-ar-20261008-r1'
assert os.getuid()==1000 and root.resolve()==root
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='7a966774-3424-46c3-8045-34f759ea58a1'
assert hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()=='4fc4b1e5dbf0b6124ebf67025ffd97d5d6652dfaa5d8da507002801890186cb2'
job=json.loads((root/'result.json').read_text())
assert (job['pid'],job['start_ticks'])==(203585,7125960)
container='05e19a0bd97f4a16e18ba6ebb17222d98102e0550652e6ce96165136dfe6aed2'
assert job['container']==container
pid=205318;start_ticks=7135478;process=Path('/proc')/str(pid)
def fields(path):return path.read_text().rsplit(')',1)[1].split()
def snapshot():
 before=fields(process/'stat');assert int(before[19])==start_ticks
 status=dict(line.split(':',1) for line in (process/'status').read_text().splitlines())
 assert int(status['Uid'].split()[0])==1000
 cgroup=(process/'cgroup').read_text()
 assert cgroup.strip()=='0::/system.slice/docker-'+container+'.scope'
 tasks=[];gone=[]
 for path in sorted((process/'task').iterdir(),key=lambda p:int(p.name)):
  try:
   row=fields(path/'stat');name=(path/'comm').read_text().strip()
  except FileNotFoundError:gone.append(int(path.name));continue
  tasks.append({'tid':int(path.name),'start_ticks':int(row[19]),'comm':name,
     'state':row[0],'user_ticks':int(row[11]),'system_ticks':int(row[12])})
 assert int(fields(process/'stat')[19])==start_ticks
 return {'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
   'monotonic_ns':time.monotonic_ns(),'status_threads':int(status['Threads']),
   'process_user_ticks':int(before[11]),'process_system_ticks':int(before[12]),
   'pid':pid,'start_ticks':start_ticks,'cgroup':cgroup,'tasks':tasks,
   'exited_tasks_during_read':gone}
first=snapshot();time.sleep(10);second=snapshot()
old={(row['tid'],row['start_ticks']):row for row in first['tasks']}
hz=os.sysconf('SC_CLK_TCK');elapsed=(second['monotonic_ns']-first['monotonic_ns'])/1e9
deltas=[]
for row in second['tasks']:
 previous=old.get((row['tid'],row['start_ticks']))
 if previous is None:continue
 ticks=row['user_ticks']+row['system_ticks']-previous['user_ticks']-previous['system_ticks']
 assert ticks>=0
 deltas.append({'tid':row['tid'],'comm':row['comm'],'cpu_ticks':ticks,
   'cpu_seconds':ticks/hz,'one_logical_CPU_percent':100*ticks/hz/elapsed})
print(json.dumps({'state':'TWO_EXACT_OWN_SERVER_PROC_THREAD_SNAPSHOTS_OBSERVED',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'original_supervisor_identity':{'pid':job['pid'],'start_ticks':job['start_ticks']},
 'server_identity':{'pid':pid,'start_ticks':start_ticks,'container':container},
 'clock_ticks_per_second':hz,'observed_seconds':elapsed,'snapshots':[first,second],
 'same_TID_CPU_deltas':sorted(deltas,key=lambda row:row['cpu_ticks'],reverse=True),
 'GPU_or_control_or_inference_request_mutation':False,
 'thread_roles_or_scheduler_speedup_claimed':False}))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',
      'pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'program_sha256':hashlib.sha256(program.encode()).hexdigest(),
        'actual_exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
try:
    record['result']=json.loads(run.stdout)
except ValueError:
    pass
path=Path('evidence/recall-yarn4-786432-s77-ar-20261008-r1-threads-r1.json')
with path.open('x') as stream:
    json.dump(record,stream,indent=2)
    stream.write('\n')
result=record.get('result',{})
print(json.dumps({'actual_exit_code':run.returncode,'state':result.get('state'),
    'observed_seconds':result.get('observed_seconds'),
    'thread_counts':[row['status_threads'] for row in result.get('snapshots',[])],
    'highest_CPU_threads':result.get('same_TID_CPU_deltas',[])[:5],
    'stderr':run.stderr}))
raise SystemExit(run.returncode)
