# SPDX-License-Identifier: MIT
"""Prepare the next frozen recall rung locally while the quality job runs."""
from pathlib import Path
import ast
import datetime
import hashlib
import importlib.util
import json
import subprocess

root = Path.cwd().resolve()
evidence = root/'evidence'
old = 'recall-yarn4-523776-s77-ar-20261008-r1'
label = 'recall-yarn4-786432-s77-ar-20261008-r1'
checkpoint = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
dirty = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], text=True).splitlines()
assert set(dirty) <= {'docs/COORDINATION.md', 'docs/PROGRESS.md'}
assert not subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).strip()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')

control = root/'docs/development/validation/recall-yarn4-near512k-ar-point-2026-10-08.json'
prior = json.loads(control.read_text())
assert prior['state'] == 'ORIGINAL_AR_YARN4_NEAR512K_PASSED_COLLECTED_INDEPENDENT_WIRE_VERIFIED_CLOSED'
assert prior['quality_summary']['passes'] == 2 and prior['actual_exit_code'] == 0
assert json.loads((evidence/'yarn4-near512-postseal-r2.json').read_text())['actual_exit_code'] == 0
manifest = json.loads((evidence/(old+'-manifest.json')).read_text())
assert manifest['source_commit'] == prior['runtime_source_commit']
native = subprocess.run(['git', 'diff', '--quiet', manifest['source_commit'], '--',
    'src', 'include', 'adapters', 'cmake', 'CMakeLists.txt', 'tools/native', 'tools/steering-build.c'])
assert native.returncode == 0
spec = importlib.util.spec_from_file_location('frozen_recall', root/'tools/strix-point-http-recall-gate.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
settings = gate.settings(dict(manifest['http_recall'], size=786432, request_timeout_seconds=7200))
settings_path = evidence/(label+'-settings.json')
write(settings_path, settings)
runner = root/'tools/strix-point-campaign.py'
assert sha(runner) == 'e68672b4e2b43ae981daf65462809c98232ba3a9248d634727fa812c4d3dd035'
assert sha(root/'tools/strix-point-http-recall-gate.py') == manifest['http_recall_gate_sha256']
assert sha(root/manifest['qualified_build_receipt']) == manifest['qualified_build_receipt_sha256']
dispatch_receipt = root/'docs/development/validation/steering-quality-campaign-host-2026-10-08.json'
manifest.update(root_checkpoint=checkpoint, fixture_commit=checkpoint,
    runner_commit='50c57efb2b73dca938fa6d55a02a95884c994513', runner_sha256=sha(runner),
    prepared_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    distrobox_name='lie-'+label, http_recall=settings,
    http_recall_settings_sha256=sha(settings_path),
    canonical_HTTP_window_timeout_seconds=gate.container_timeout(settings),
    preceding_verified_control_receipt=str(control.relative_to(root)),
    preceding_verified_control_receipt_sha256=sha(control),
    coordinator_HOST_dispatch_receipt=str(dispatch_receipt.relative_to(root)),
    coordinator_HOST_dispatch_receipt_sha256=sha(dispatch_receipt),
    purpose='Original-weight current-r70 AR YaRN4 recall at physical target786432, capacity1048576, seed77/chunk256/C1, two cold natural-stop turns/TG128/cacheoff and three unscored calibrations. Same frozen preset/questions/oracle as the strongly closed current-r70 near512K control. Prepared locally during the separate steering quality window; no admission or future reservation. No matched performance, Terminal Bench, remote GPU build, model conversion/hash, tuning, installation or publication.',
    memory_estimate_scope='Conservative 110GiB explicit GTT estimate for originalQ4/C1/YaRN4 capacity1048576/scratch256, minimum availableRAM1GiB; earlier fit does not qualify this larger physical input. Fresh 112GiB hostGTT and projected RAM admission required.')
actual_runner_commit = subprocess.check_output(['git', 'log', '-1', '--format=%H', '--', 'tools/strix-point-campaign.py'], text=True).strip()
assert subprocess.check_output(['git', 'show', actual_runner_commit+':tools/strix-point-campaign.py']) == runner.read_bytes()
manifest['runner_commit'] = actual_runner_commit
write(evidence/(label+'-manifest.json'), manifest)
ready = json.loads((evidence/(old+'-readiness.json')).read_text())
ready.update(at_utc=manifest['prepared_at_utc'], scope='PREPARED_CURRENT_R70_YARN4_786K_RECALL_NOT_ADMITTED',
    root_checkpoint=checkpoint, settings=settings, local_pending_documentation=dirty,
    native_source_equal_qualified_runtime=True, future_window_reservation=False,
    concurrent_root_scope='Separate original70 steering quality window on .161; no overlap authorized')
for name, source in [('runner.py', runner), ('http-recall-settings.json', settings_path)]:
    ready['helpers'][name] = {'source': str(source.relative_to(root)), 'bytes': source.stat().st_size, 'sha256': sha(source)}
for row in ready['helpers'].values():
    assert sha(root/row['source']) == row['sha256']
write(evidence/(label+'-readiness.json'), ready)
remote_recipe = (evidence/('prepare-'+old+'-remote.py')).read_text().replace(old, label)
ast.parse(remote_recipe)
with (evidence/('prepare-'+label+'-remote.py')).open('x') as stream:
    stream.write(remote_recipe)
record = {'state': 'LOCALLY_PREPARED_NOT_ADMITTED', 'label': label,
    'at_utc': manifest['prepared_at_utc'], 'manifest_sha256': sha(evidence/(label+'-manifest.json')),
    'root_checkpoint': checkpoint, 'native_source': manifest['source_commit'],
    'runner_commit': actual_runner_commit, 'runner_sha256': sha(runner),
    'settings': settings, 'container_timeout_seconds': gate.container_timeout(settings),
    'same_frozen_workload_and_oracle': True, 'native_source_comparison_actual_exit_code': native.returncode,
    'GPU_remote_or_future_window_operation': False, 'current_quality_job_is_not_restarted': True}
write(evidence/(label+'-local-preparation-r1.json'), record)
print(json.dumps(record))
