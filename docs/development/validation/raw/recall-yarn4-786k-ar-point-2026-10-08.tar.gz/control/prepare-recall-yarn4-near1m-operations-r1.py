# SPDX-License-Identifier: MIT
"""Prepare one final-rung recipe set locally; do not stage or admit it."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import subprocess

root = Path.cwd()
evidence = root/'evidence'
parent = 'recall-yarn4-786432-s77-ar-20261008-r1'
label = 'recall-yarn4-1048064-s77-ar-20261008-r1'
expected_manifest = '57e76ff82c844e75b8c43990fea7a2cf7534b203801cfea6e459bd2aeefc9132'
manifest_bytes = (evidence/(label+'-manifest.json')).read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest() == expected_manifest
manifest = json.loads(manifest_bytes)
ready = json.loads((evidence/(label+'-readiness.json')).read_text())
assert manifest['http_recall']['size'] == 1048064
assert manifest['http_recall']['context'] == 1048576
assert not (evidence/(label+'-jobs-prepared.json')).exists()
native = subprocess.run(['git', 'diff', '--quiet', manifest['source_commit'], '--',
    'src', 'include', 'adapters', 'cmake', 'CMakeLists.txt',
    'tools/native', 'tools/steering-build.c'])
assert native.returncode == 0
expected = {}
for name, item in ready['helpers'].items():
    data = (root/item['source']).read_bytes()
    assert len(data) == item['bytes']
    assert hashlib.sha256(data).hexdigest() == item['sha256']
    expected[name] = item['sha256']
expected['manifest.json'] = expected_manifest
recipes = {}
sources = {}

def original(name):
    data = (evidence/name).read_bytes()
    sources[name] = {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()}
    return data.decode().replace(parent, label).replace('786K', 'near-1M')

fresh = original('before-'+parent+'-fresh-r1.py')
start = fresh.index('expected = ')
end = fresh.index('\nprogram = ', start)
fresh = fresh[:start]+'expected = '+repr(expected)+\
    '\nassert expected["manifest.json"] == '+repr(expected_manifest)+fresh[end:]
recipes['before-'+label+'-fresh-r1.py'] = fresh

launch = original('launch-'+parent+'.py')
launch = launch.replace('4fc4b1e5dbf0b6124ebf67025ffd97d5d6652dfaa5d8da507002801890186cb2', expected_manifest)
launch = launch.replace('steering-conciseness-quality-point-20261008-r2', parent)
marker = "r = fresh['result']"
assert marker in launch
launch = launch.replace(marker, """sealed = json.loads((root/'docs/development/validation/recall-yarn4-786k-ar-point-2026-10-08.json').read_text())
postcheck = json.loads((root/'evidence/recall-yarn4-786k-postseal-r1.json').read_text())
assert sealed['job_label'] == 'recall-yarn4-786432-s77-ar-20261008-r1'
assert sealed['actual_exit_codes']['strong_closure'] == sealed['actual_exit_codes']['independent_review_seal'] == 0
assert postcheck['actual_exit_code'] == 0 and postcheck['all_archived_and_current_members_match'] is True
r = fresh['result']""")
recipes['launch-'+label+'.py'] = launch
recipes['observe-'+label+'.py'] = original('observe-'+parent+'.py')
recipes['close-'+label+'-r1.py'] = original('close-'+parent+'-r1.py')

for name, text in recipes.items():
    ast.parse(text, filename=name)
    with (evidence/name).open('x') as stream:
        stream.write(text)
record = {
    'state':'PRIVATE_NEAR1M_OPERATIONS_PREPARED_UNEXECUTED_NOT_ADMITTED',
    'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'label':label, 'manifest_sha256':expected_manifest,
    'native_source_comparison_actual_exit_code':native.returncode,
    'source_recipes':sources,
    'recipes':{name:{'bytes':len(text.encode()),
        'sha256':hashlib.sha256(text.encode()).hexdigest()} for name,text in recipes.items()},
    'preceding_786K_requires_collection_independent_review_strong_closure_four_releases_and_postseal':True,
    'future_specific_peer_global_and_original_lease_checks_required':True,
    'GPU_remote_or_future_window_operation':False,
    'existing_manifest_runner_gate_native_or_historical_artifact_changed':False,
    'actual_exit_code':0}
with (evidence/(label+'-operations-prepared-r1.json')).open('x') as stream:
    json.dump(record,stream,indent=2)
    stream.write('\n')
print(json.dumps(record))
