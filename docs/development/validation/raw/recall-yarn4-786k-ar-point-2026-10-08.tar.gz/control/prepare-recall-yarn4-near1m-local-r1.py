# SPDX-License-Identifier: MIT
"""Prepare the protocol's final YaRN4 rung locally; grant no next GPU window."""
from pathlib import Path
import ast
import datetime
import hashlib
import importlib.util
import json
import subprocess

root = Path.cwd().resolve()
evidence = root/'evidence'
preceding = 'recall-yarn4-786432-s77-ar-20261008-r1'
label = 'recall-yarn4-1048064-s77-ar-20261008-r1'
checkpoint = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
dirty = subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).splitlines()
assert set(dirty) <= {'docs/COORDINATION.md','docs/PROGRESS.md'}
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).strip()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def write(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')

manifest = json.loads((evidence/(preceding+'-manifest.json')).read_text())
assert sha(evidence/(preceding+'-manifest.json')) == '4fc4b1e5dbf0b6124ebf67025ffd97d5d6652dfaa5d8da507002801890186cb2'
native = subprocess.run(['git','diff','--quiet',manifest['source_commit'],'--',
    'src','include','adapters','cmake','CMakeLists.txt','tools/native','tools/steering-build.c'])
assert native.returncode == 0
spec = importlib.util.spec_from_file_location('bound_recall_settings',root/'tools/strix-point-http-recall-gate.py')
gate = importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
settings = gate.settings(dict(manifest['http_recall'],size=1048064,request_timeout_seconds=14400))
assert settings['size']+2*128+256 == settings['context'] == 1048576
assert gate.client_timeout(settings) == 72030 and gate.container_timeout(settings) == 72990
settings_path = evidence/(label+'-settings.json');write(settings_path,settings)
runner = root/'tools/strix-point-campaign.py'
assert sha(runner) == manifest['runner_sha256'] == 'e68672b4e2b43ae981daf65462809c98232ba3a9248d634727fa812c4d3dd035'
assert sha(root/'tools/strix-point-http-recall-gate.py') == manifest['http_recall_gate_sha256']
assert sha(root/manifest['qualified_build_receipt']) == manifest['qualified_build_receipt_sha256']
control = root/manifest['preceding_verified_control_receipt']
prior = json.loads(control.read_text())
assert sha(control) == manifest['preceding_verified_control_receipt_sha256']
assert prior['state'] == 'ORIGINAL_AR_YARN4_NEAR512K_PASSED_COLLECTED_INDEPENDENT_WIRE_VERIFIED_CLOSED'
assert prior['quality_summary']['passes'] == 2
at = datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest.update(root_checkpoint=checkpoint,fixture_commit=checkpoint,prepared_at_utc=at,
    distrobox_name='lie-'+label,http_recall=settings,
    http_recall_settings_sha256=sha(settings_path),
    canonical_HTTP_window_timeout_seconds=gate.container_timeout(settings),
    preceding_locally_prepared_manifest='evidence/'+preceding+'-manifest.json',
    preceding_locally_prepared_manifest_sha256=sha(evidence/(preceding+'-manifest.json')),
    preceding_786K_recall_is_currently_unqualified=True,
    purpose='Original-weight current-r70 AR YaRN4 recall at physical target1048064, capacity1048576, seed77/chunk256/C1, two cold natural-stop turns/TG128/cacheoff and three unscored calibrations. Same frozen preset/questions/oracle as the strongly closed near512K control and currently running 786K rung. Prepared locally only, without remote staging, admission or future reservation. No matched performance, Terminal Bench, remote GPU build, model conversion/hash, tuning, installation or publication.')
write(evidence/(label+'-manifest.json'),manifest)
ready = json.loads((evidence/(preceding+'-readiness.json')).read_text())
ready.update(at_utc=at,scope='PREPARED_CURRENT_R70_YARN4_NEAR1M_RECALL_NOT_ADMITTED',
    root_checkpoint=checkpoint,settings=settings,local_pending_documentation=dirty,
    native_source_equal_qualified_runtime=True,future_window_reservation=False,
    concurrent_root_scope='Separate original786K recall window on .161; no overlap or next admission authorized')
ready['helpers']['http-recall-settings.json'] = {'source':str(settings_path.relative_to(root)),
    'bytes':settings_path.stat().st_size,'sha256':sha(settings_path)}
for item in ready['helpers'].values():
    assert (root/item['source']).stat().st_size == item['bytes'] and sha(root/item['source']) == item['sha256']
write(evidence/(label+'-readiness.json'),ready)
recipe = (evidence/('prepare-'+preceding+'-remote.py')).read_text().replace(preceding,label)
ast.parse(recipe)
with (evidence/('prepare-'+label+'-remote.py')).open('x') as stream:
    stream.write(recipe)
record = {'state':'LOCALLY_PREPARED_FINAL_PROTOCOL_RUNG_NOT_ADMITTED',
    'at_utc':at,'label':label,'manifest_sha256':sha(evidence/(label+'-manifest.json')),
    'root_checkpoint':checkpoint,'runtime_source':manifest['source_commit'],
    'settings':settings,'continuation_and_output_reserve':512,
    'native_source_comparison_actual_exit_code':native.returncode,
    'request_timeout_seconds':14400,'client_timeout_seconds':72030,'container_timeout_seconds':72990,
    'prior_786K_is_live_and_not_restarted':True,'GPU_remote_or_future_window_operation':False,
    'all_frozen_recall_quality_criteria_preserved':True,'actual_exit_code':0}
write(evidence/(label+'-local-preparation-r1.json'),record)
print(json.dumps(record))
