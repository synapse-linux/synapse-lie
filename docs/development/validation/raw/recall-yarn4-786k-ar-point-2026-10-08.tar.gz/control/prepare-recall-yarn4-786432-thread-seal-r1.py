# SPDX-License-Identifier: MIT
"""Retain closed read-only thread and early-wire observations in the final seal."""
from pathlib import Path
import ast
import datetime
import hashlib
import json

root = Path.cwd()
evidence = root/'evidence'
label = 'recall-yarn4-786432-s77-ar-20261008-r1'
source = evidence/('seal-'+label+'-r3.py')
original = source.read_bytes()
threads_path = evidence/(label+'-threads-r1.json')
threads = json.loads(threads_path.read_text())
assert threads['actual_exit_code'] == 0
assert threads['result']['GPU_or_control_or_inference_request_mutation'] is False
assert threads['result']['thread_roles_or_scheduler_speedup_claimed'] is False
text = original.decode()
marker = "near1m = read(ROOT/'evidence/recall-yarn4-1048064-s77-ar-20261008-r1-local-preparation-r1.json')"
assert marker in text
text = text.replace(marker, """threads = read(ROOT/'evidence'/(LABEL+'-threads-r1.json'))
assert threads['actual_exit_code'] == 0
thread_view = threads['result']
assert thread_view['GPU_or_control_or_inference_request_mutation'] is False
assert thread_view['thread_roles_or_scheduler_speedup_claimed'] is False
assert (thread_view['server_identity']['pid'],thread_view['server_identity']['start_ticks']) == (gpu['pid'],gpu['start_ticks'])
assert thread_view['server_identity']['container'] == job['container']
assert len(thread_view['snapshots']) == 2 and thread_view['observed_seconds'] >= 10
assert thread_view['clock_ticks_per_second'] > 0
for value in thread_view['snapshots']:
    assert (value['pid'],value['start_ticks']) == (gpu['pid'],gpu['start_ticks'])
    assert value['cgroup'].strip() == '0::/system.slice/docker-'+job['container']+'.scope'
    assert value['status_threads'] == len(value['tasks']) > 0
    assert not value['exited_tasks_during_read']
"""+marker)
marker = "parts += [(ROOT/'evidence'/name, 'control/'+name) for name in names]"
assert marker in text
text = text.replace(marker, """names += ['observe-recall-yarn4-786432-threads-r1.py', LABEL+'-threads-r1.json',
          'peek-'+LABEL+'-wire.py',
          'prepare-recall-yarn4-786432-thread-seal-r1.py', LABEL+'-thread-seal-prepared-r1.json',
          'seal-'+LABEL+'-r3.py',
          'prepare-recall-yarn4-near1m-operations-r1.py',
          'prepare-recall-yarn4-near1m-seal-r1.py',
          'recall-yarn4-1048064-s77-ar-20261008-r1-operations-prepared-r1.json',
          'recall-yarn4-1048064-s77-ar-20261008-r1-seal-review-prepared-r1.json']
names += [path.name for path in sorted((ROOT/'evidence').glob(LABEL+'-wire-peek-*.json'))]
assert len(names) == len(set(names))
"""+marker)
marker = " 'next_near1M_local_preparation':near1m,"
assert marker in text
text = text.replace(marker, """ 'sampled_server_threads':{
     'scope':'Two read-only own-process snapshots, not application-role attribution or bottleneck diagnosis.',
     'process_totals':[value['status_threads'] for value in thread_view['snapshots']],
     'observed_seconds':thread_view['observed_seconds'],
     'same_TID_CPU_deltas':thread_view['same_TID_CPU_deltas'],
     'model_owner_count_from_source':1,
     'thread_roles_or_reactive_speedup_qualified':False},
"""+marker)
name = 'seal-'+label+'-r4.py'
ast.parse(text,filename=name)
with (evidence/name).open('x') as stream:
    stream.write(text)
record = {
    'state':'PRIVATE_OFFLINE_786K_THREAD_AND_EARLY_WIRE_SEAL_PREPARED_UNEXECUTED',
    'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'original_r3_preserved':{'path':source.name,'bytes':len(original),
        'sha256':hashlib.sha256(original).hexdigest()},
    'recipe':{'path':name,'bytes':len(text.encode()),
        'sha256':hashlib.sha256(text.encode()).hexdigest()},
    'closed_read_only_thread_record_sha256':hashlib.sha256(threads_path.read_bytes()).hexdigest(),
    'native_manifest_runner_gate_workload_criteria_or_original_GPU_run_changed':False,
    'GPU_remote_or_future_window_operation':False,'actual_exit_code':0}
with (evidence/(label+'-thread-seal-prepared-r1.json')).open('x') as stream:
    json.dump(record,stream,indent=2)
    stream.write('\n')
print(json.dumps(record))
