# SPDX-License-Identifier: MIT
"""Prepare a monitor for the already admitted job; preserve old observations."""
from pathlib import Path
import ast
import datetime
import hashlib
import json

evidence = Path('evidence')
previous = evidence/'observe-recall-yarn4-786432-native-progress-r1.py'
text = previous.read_text()
old = "assert job['state']=='RUNNING_DISTROBOX' and point.ticks(job['pid'])==job['start_ticks']\ncid=job['container'];assert len(cid)==64"
new = """assert (job['pid'],job['start_ticks'])==(203585,7125960)
cid=job['container'];assert cid=='05e19a0bd97f4a16e18ba6ebb17222d98102e0550652e6ce96165136dfe6aed2'
if job['state'] in ('PASSED','FAILED'):
 assert job['ended_at'] and job['lease_released_at']
 print(json.dumps({'state':'ORIGINAL_CONTROLLER_TERMINAL_OBSERVED_NOT_STRONG_CLOSURE',
  'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'original_job_state':job['state'],'original_supervisor_exit_code':job['exit_code'],
  'original_container_exit_code':job['child_exit_code'],'lease_release_at':job['lease_released_at'],
  'GPU_or_generation_request_or_control_mutation':False}))
 raise SystemExit(0)
assert job['state']=='RUNNING_DISTROBOX' and point.ticks(job['pid'])==job['start_ticks']"""
assert old in text
text = text.replace(old,new)
old = 'assert len(owners)==1'
new = """if not owners:
 print(json.dumps({'state':'ORIGINAL_SUPERVISOR_LIVE_WITH_NO_OBSERVED_GPU_OWNER',
  'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'supervisor':{'pid':job['pid'],'start_ticks':job['start_ticks']},
  'model_attempted':job.get('model_attempted'),'observation':observation,
  'GPU_or_generation_request_or_control_mutation':False}))
 raise SystemExit(0)
assert len(owners)==1"""
assert old in text
text = text.replace(old,new)
old = "    value=record['result'];view=value['read_only_llm_snapshot']"
new = """    value=record['result']
    if 'read_only_llm_snapshot' not in value:
        print(json.dumps({key:item for key,item in value.items() if key!='observation'}))
        raise SystemExit(run.returncode)
    view=value['read_only_llm_snapshot']"""
assert old in text
text = text.replace(old,new)
name = 'observe-recall-yarn4-786432-native-progress-r2.py'
ast.parse(text,filename=name)
with (evidence/name).open('x') as stream:
    stream.write(text)
watch = '''# SPDX-License-Identifier: MIT
"""Observe only the frozen original live controller; never wait for admission."""
from pathlib import Path
import datetime,json,subprocess,time
root=Path.cwd();label='recall-yarn4-786432-s77-ar-20261008-r1'
path=root/'evidence'/('watch-'+label+'-result-r1.json')
assert not path.exists()
records=[];deadline=time.monotonic()+36990;error=None;terminal=None
for index in range(3,1237):
 if time.monotonic()>=deadline:
  error='Observation deadline; original job was not restarted or stopped';break
 argv=['python3','-B','evidence/observe-recall-yarn4-786432-native-progress-r2.py',str(index)]
 run=subprocess.run(argv,text=True,capture_output=True,timeout=40)
 entry={'index':index,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'actual_observer_exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
 records.append(entry)
 print(run.stdout.strip(),flush=True)
 if run.returncode:
  error='Read-only observer failed; actual exit retained; original GPU execution untouched'
  print(json.dumps({'observer_error':error,'actual_exit_code':run.returncode}),flush=True);break
 result=json.loads((root/'evidence'/(label+'-native-progress-'+str(index)+'.json')).read_text())['result']
 if result['state']=='ORIGINAL_CONTROLLER_TERMINAL_OBSERVED_NOT_STRONG_CLOSURE':
  terminal=result;break
 time.sleep(30)
record={'state':'TERMINAL_ORIGINAL_CONTROLLER_OBSERVED' if terminal else 'OBSERVER_FAILED_OR_BOUND_REACHED',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_terminal':terminal,
 'observations':records,'error':error,'actual_exit_code':0 if terminal else 1,
 'GPU_or_model_inference_restarted_or_stopped':False,'strong_closure_required':True}
with path.open('x') as stream:json.dump(record,stream,indent=2);stream.write(chr(10))
print(json.dumps({key:value for key,value in record.items() if key!='observations'}),flush=True)
raise SystemExit(record['actual_exit_code'])
'''
watch_name = 'watch-recall-yarn4-786432-s77-ar-20261008-r1.py'
ast.parse(watch,filename=watch_name)
with (evidence/watch_name).open('x') as stream:
    stream.write(watch)
record = {'state':'READ_ONLY_MONITOR_PREPARED_FOR_ORIGINAL_LIVE_CONTROLLER_ONLY',
    'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'original_controller_handle':92498,'original_supervisor':{'pid':203585,'start_ticks':7125960},
    'actual_container_id':'05e19a0bd97f4a16e18ba6ebb17222d98102e0550652e6ce96165136dfe6aed2',
    'recipes':{name:{'bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest()},
        watch_name:{'bytes':len(watch.encode()),'sha256':hashlib.sha256(watch.encode()).hexdigest()}},
    'old_observer_source_preserved_sha256':hashlib.sha256(previous.read_bytes()).hexdigest(),
    'GPU_or_model_inference_or_control_mutation':False,'actual_exit_code':0}
with (evidence/'recall-yarn4-786k-progress-watch-prepared-r1.json').open('x') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record))
