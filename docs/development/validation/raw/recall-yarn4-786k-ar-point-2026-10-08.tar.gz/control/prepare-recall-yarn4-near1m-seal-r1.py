# SPDX-License-Identifier: MIT
"""Prepare offline final-rung wire review with unchanged quality criteria."""
from pathlib import Path
import ast
import datetime
import hashlib
import json

root = Path.cwd()
evidence = root/'evidence'
parent = 'recall-yarn4-786432-s77-ar-20261008-r1'
label = 'recall-yarn4-1048064-s77-ar-20261008-r1'
sources = {}

def original(name):
    data = (evidence/name).read_bytes()
    sources[name] = {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()}
    return data.decode().replace(parent, label).replace('786k', 'near1m').replace('786K', 'NEAR1M')

seal = original('seal-'+parent+'-r2.py')
seal = seal.replace("settings['size'] == 786432", "settings['size'] == 1048064")
start = seal.index('names = [')
end = seal.index('names += [p.name', start)
seal = seal[:start]+"""names = [f'{LABEL}-manifest.json', f'{LABEL}-settings.json', f'{LABEL}-readiness.json',
         f'{LABEL}-local-preparation-r1.json', f'{LABEL}-operations-prepared-r1.json',
         f'{LABEL}-jobs-prepared.json', f'{LABEL}-peer-coordination-r1.json',
         f'{LABEL}-peer-raw-r1.json', f'{LABEL}-proposal-notifications-r1.json',
         f'{LABEL}-release-notifications-r1.json', f'{LABEL}-closure-r1.json',
         f'{LABEL}-fresh-r1.json', f'before-{LABEL}-fresh-r1.py',
         f'launch-{LABEL}.py', f'observe-{LABEL}.py', f'close-{LABEL}-r1.py',
         f'prepare-{LABEL}-remote.py', 'prepare-recall-yarn4-near1m-local-r1.py',
         'prepare-recall-yarn4-near1m-operations-r1.py',
         'prepare-recall-yarn4-near1m-seal-r1.py',
         f'{LABEL}-seal-review-prepared-r1.json', f'verify-{LABEL}-public-r1.py']
"""+seal[end:]
seal = seal.replace('one seed/YaRN4 profile at the stated NEAR1M physical target',
    'one seed/YaRN4 profile at the stated 1048064 physical target')
seal = seal.replace('Does not qualify other seeds, 1M physical inputs, other profiles or MTP.',
    'Does not qualify other seeds, other RoPE profiles or MTP.')
seal = seal.replace('Configured1048576 capacity is not a physical1M-input or long-recall result.',
    'Only the observed physical prompt counts are qualified; reserved context headroom is not input.')
assert "settings['size'] == 1048064" in seal
assert '786432' not in seal and '786k' not in seal and '786K' not in seal
name = 'seal-'+label+'-r1.py'
ast.parse(seal, filename=name)
with (evidence/name).open('x') as stream:
    stream.write(seal)

review_name = 'verify-'+label+'-public-r1.py'
review = original('verify-'+parent+'-public-r1.py')
assert '786432' not in review and '786k' not in review and '786K' not in review
ast.parse(review, filename=review_name)
with (evidence/review_name).open('x') as stream:
    stream.write(review)

record = {
    'state':'PRIVATE_NEAR1M_INDEPENDENT_WIRE_SEAL_AND_POSTCHECK_PREPARED_UNEXECUTED',
    'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'label':label, 'source_recipes':sources,
    'recipes':{name:{'bytes':len(seal.encode()),
        'sha256':hashlib.sha256(seal.encode()).hexdigest()},
        review_name:{'bytes':len(review.encode()),
            'sha256':hashlib.sha256(review.encode()).hexdigest()}},
    'independently_reassembles_saved_SSE_and_frozen_oracles':True,
    'preserves_actual_original_quality_failure_if_any':True,
    'requires_collected_artifact_hashes_five_exact_identities_whole_cgroup_three_ports_original_lease_and_four_releases':True,
    'whole_roadmap_remains_open_and_terminal_bench_last':True,
    'original_786K_or_near1M_manifest_runner_gate_workload_threshold_native_or_model_changed':False,
    'GPU_remote_or_future_window_operation':False, 'actual_exit_code':0}
with (evidence/(label+'-seal-review-prepared-r1.json')).open('x') as stream:
    json.dump(record,stream,indent=2)
    stream.write('\n')
print(json.dumps(record))
