# SPDX-License-Identifier: MIT
"""Prepare offline archival of existing live observations and near1M inputs."""
from pathlib import Path
import ast
import datetime
import hashlib
import json

root = Path.cwd();evidence = root/'evidence'
label = 'recall-yarn4-786432-s77-ar-20261008-r1'
original = evidence/('seal-'+label+'-r2.py')
prepared = json.loads((evidence/(label+'-seal-review-prepared-r1.json')).read_text())
data = original.read_bytes()
assert hashlib.sha256(data).hexdigest() == prepared['recipes'][original.name]['sha256']
text = data.decode()
marker = "parts = [(p,'job/'+p.name) for p in sorted(JOB.iterdir()) if p.is_file() and not p.is_symlink()]"
assert marker in text
text = text.replace(marker,"""watch = read(ROOT/'evidence'/('watch-'+LABEL+'-result-r1.json'))
assert watch['actual_exit_code'] == 0 and watch['state'] == 'TERMINAL_ORIGINAL_CONTROLLER_OBSERVED'
assert watch['original_terminal']['original_supervisor_exit_code'] == job['exit_code']
assert watch['GPU_or_model_inference_restarted_or_stopped'] is False
progress_paths = sorted((ROOT/'evidence').glob(LABEL+'-native-progress-*.json'),
                        key=lambda path:int(path.stem.rsplit('-',1)[1]))
progress = [read(path) for path in progress_paths]
views = [record['result'] for record in progress if record['actual_exit_code'] == 0 and
         'read_only_llm_snapshot' in record.get('result',{})]
assert views
for record in views:
    assert record['GPU_or_generation_request_or_control_mutation'] is False
    assert record['matched_performance_or_reactive_speedup_qualification'] is False
    view = record['read_only_llm_snapshot']
    assert view['schema'] == 'synapse-lie.llm.v1'
    assert view['backend']['synthetic'] is False
    assert view['backend']['engine'] == 'gufo-embedded-f783fedb'
    assert view['backend']['context_tokens'] == settings['context']
    assert view['scheduler']['mode'] == 'single-owner-reactive-ready-batch'
    assert view['cache']['enabled'] is view['cache']['ssd_enabled'] is False
    assert (record['actual_GPU_server']['pid'],record['actual_GPU_server']['start_ticks']) == (gpu['pid'],gpu['start_ticks'])
    assert record['actual_GPU_server']['cgroup'].strip() == '0::/system.slice/docker-'+job['container']+'.scope'
    for sensor in record['observation']['temperatures']:
        if sensor['guarded']: assert sensor['value_c'] < sensor['limit_c']
    assert type(record['actual_GET_wall_ns']) is int and record['actual_GET_wall_ns'] > 0
inflight = [record for record in views if record['read_only_llm_snapshot']['scheduler']['executor']['phase'] == 'prefill'
           and record['read_only_llm_snapshot']['scheduler']['executor']['prefill_started'] > record['read_only_llm_snapshot']['scheduler']['executor']['prefill_returned']]
assert inflight
near1m = read(ROOT/'evidence/recall-yarn4-1048064-s77-ar-20261008-r1-local-preparation-r1.json')
assert near1m['state'] == 'LOCALLY_PREPARED_FINAL_PROTOCOL_RUNG_NOT_ADMITTED'
assert near1m['GPU_remote_or_future_window_operation'] is False
assert not (ROOT/'evidence/recall-yarn4-1048064-s77-ar-20261008-r1-jobs-prepared.json').exists()
"""+marker)
marker = "names += [p.name for p in sorted((ROOT/'evidence').glob(f'{LABEL}-live-*.json'))]"
assert marker in text
text = text.replace(marker,marker+"""
names += [path.name for path in progress_paths]
names += ['watch-'+LABEL+'-result-r1.json','watch-'+LABEL+'.py',
          'observe-recall-yarn4-786432-native-progress-r1.py',
          'observe-recall-yarn4-786432-native-progress-r2.py',
          'prepare-recall-yarn4-786432-progress-watch-r1.py',
          'recall-yarn4-786k-progress-watch-prepared-r1.json',
          'prepare-recall-yarn4-786432-progress-seal-r1.py',
          f'{LABEL}-progress-seal-prepared-r1.json',
          f'seal-{LABEL}-r2.py',
          'prepare-recall-yarn4-near1m-local-r1.py',
          'recall-yarn4-1048064-s77-ar-20261008-r1-local-preparation-r1.json',
          'recall-yarn4-1048064-s77-ar-20261008-r1-manifest.json',
          'recall-yarn4-1048064-s77-ar-20261008-r1-settings.json',
          'recall-yarn4-1048064-s77-ar-20261008-r1-readiness.json',
          'prepare-recall-yarn4-1048064-s77-ar-20261008-r1-remote.py']
""")
marker = " 'settings':settings,'three_unscored_calibrations':3,'quality_summary':proof['quality_summary'],"
assert marker in text
text = text.replace(marker,marker+"""
 'read_only_C_core_progress':{
     'observations':len(progress), 'successful_native_views':len(views),
     'actual_observer_exits':[record['actual_exit_code'] for record in progress],
     'prefill_inflight_views':len(inflight),
     'maximum_loopback_GET_wall_ms':max(record['actual_GET_wall_ns'] for record in views)/1e6,
     'actual_same_server_identity':{'pid':gpu['pid'],'start_ticks':gpu['start_ticks']},
     'end_to_end_read_responsiveness_observed':True,
     'matched_performance_or_reactive_speedup_qualified':False,
     'scope':'Discrete read-only loopback core snapshots during owner dispatch intervals; no request, live setter or inference restart.'},
 'next_near1M_local_preparation':near1m,
""")
name = 'seal-'+label+'-r3.py'
ast.parse(text,filename=name)
with (evidence/name).open('x') as stream:stream.write(text)
record = {'state':'PRIVATE_OFFLINE_PROGRESS_ARCHIVE_RECIPE_PREPARED_UNEXECUTED',
    'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'prior_unexecuted_source_preserved':{'path':original.name,'sha256':hashlib.sha256(data).hexdigest()},
    'recipe':{'path':name,'bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest()},
    'native_runtime_manifest_helper_inputs_workload_or_criteria_changed':False,
    'GPU_remote_or_future_window_operation':False,'actual_exit_code':0}
with (evidence/(label+'-progress-seal-prepared-r1.json')).open('x') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record))
