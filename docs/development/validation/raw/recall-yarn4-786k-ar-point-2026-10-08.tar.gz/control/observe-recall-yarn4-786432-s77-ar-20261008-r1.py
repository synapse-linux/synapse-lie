# SPDX-License-Identifier: MIT
"""Observe the exact owned AR job; never restart or acquire its lease."""
from pathlib import Path
import hashlib, json, subprocess, sys

suffix = sys.argv[1]
assert suffix.isdecimal() and int(suffix) > 0
manifest = json.loads(Path('evidence/recall-yarn4-786432-s77-ar-20261008-r1/manifest.json').read_text())
program = 'EXPECTED=' + repr(manifest['runner_sha256']) + '\n' + '''
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess
base=Path('/home/pop/workspace/synapse-lie');root=base/'recall-yarn4-786432-s77-ar-20261008-r1'
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='7a966774-3424-46c3-8045-34f759ea58a1'
assert root.resolve()==root and root.stat().st_uid==os.getuid()==1000
assert hashlib.sha256((root/'runner.py').read_bytes()).hexdigest()==EXPECTED
spec=importlib.util.spec_from_file_location('point',root/'runner.py');point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
job=json.loads((root/'result.json').read_text())
try:alive=point.ticks(job['pid'])==job['start_ticks']
except FileNotFoundError:alive=False
lease_fds=[]
if alive:
 for path in (Path('/proc')/str(job['pid'])/'fd').iterdir():
  try:
   identity=path.stat()
   if (identity.st_dev,identity.st_ino)==(66308,105946405):lease_fds.append(int(path.name))
  except FileNotFoundError:pass
state=None;init=None
if job.get('container'):
 run=subprocess.run(['docker','inspect','--format','{{json .State}}',job['container']],capture_output=True,text=True,timeout=15)
 state={'actual_exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
 if run.returncode==0:
  current=json.loads(run.stdout);pid=current.get('Pid',0)
  if pid>0:
   try:init={'pid':pid,'start_ticks':point.ticks(pid),'cgroup':(Path('/proc')/str(pid)/'cgroup').read_text()}
   except FileNotFoundError:pass
parts={}
for name in ('http-recall-result.json',):
 path=root/name
 if path.exists():parts[name]=json.loads(path.read_text())
wire=root/'measurements.jsonl';wire_rows=0
if wire.exists():
 with wire.open() as stream:wire_rows=sum(1 for line in stream)
log=root/'server.log';tail=''
if log.exists():
 with log.open('rb') as stream:
  stream.seek(max(0,log.stat().st_size-1600));tail=stream.read().decode(errors='replace')
observation=point.observe(98,gpu_observation_only=True)
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':job['state'],
 'live_exact_supervisor':alive,'supervisor_identity':{'pid':job['pid'],'start_ticks':job['start_ticks']},
 'lease_fds':lease_fds,'container':state,'actual_live_init_identity':init,
 'model_attempted':job.get('model_attempted'),'native_GPU_owners':[p for p in observation['kfd'] if job.get('container') and job['container'] in p['cgroup']],
 'wire_rows':wire_rows,'partial_or_final_receipts':parts,'server_log_tail':tail,'observation':observation}
if alive:assert lease_fds
print(json.dumps(result))
'''
argv = ['ssh', '-F', '/dev/null', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8',
        'pop@192.168.5.161', 'python3 -B -']
run = subprocess.run(argv, input=program, text=True, capture_output=True, timeout=45)
record = {'argv': argv, 'actual_exit_code': run.returncode,
          'program_sha256': hashlib.sha256(program.encode()).hexdigest(),
          'stdout': run.stdout, 'stderr': run.stderr}
try:
    record['result'] = json.loads(run.stdout)
except ValueError:
    pass
with Path(f'evidence/recall-yarn4-786432-s77-ar-20261008-r1-live-{suffix}.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
if 'result' in record:
    value = record['result']
    summary = {name: value[name] for name in ('at_utc', 'state', 'live_exact_supervisor',
               'supervisor_identity', 'lease_fds', 'actual_live_init_identity',
               'model_attempted', 'native_GPU_owners', 'wire_rows', 'server_log_tail')}
    summary['receipts'] = {name: {field: data.get(field) for field in
                          ('state', 'current_check', 'passed', 'failure_kind', 'error')}
                          for name, data in value['partial_or_final_receipts'].items()}
    summary['sensors'] = value['observation']['temperatures']
    print(json.dumps(summary))
else:
    print(json.dumps(record))
raise SystemExit(run.returncode)
