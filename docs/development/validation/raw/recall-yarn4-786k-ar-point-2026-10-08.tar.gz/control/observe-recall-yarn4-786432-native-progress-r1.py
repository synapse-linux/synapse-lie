# SPDX-License-Identifier: MIT
"""Read an actual owned server's C-core counters; no request, setter or retry."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

label = 'recall-yarn4-786432-s77-ar-20261008-r1'
suffix = sys.argv[1]
assert suffix.isdecimal() and int(suffix) > 0
local = Path('evidence')/label
manifest = json.loads((local/'manifest.json').read_text())
assert hashlib.sha256((local/'manifest.json').read_bytes()).hexdigest() == '4fc4b1e5dbf0b6124ebf67025ffd97d5d6652dfaa5d8da507002801890186cb2'
program = 'LABEL='+repr(label)+'\nEXPECTED='+repr(manifest['runner_sha256'])+'\n'+'''
from pathlib import Path
import datetime,hashlib,http.client,importlib.util,json,os,time
base=Path('/home/pop/workspace/synapse-lie');root=base/LABEL
assert os.getuid()==1000 and root.resolve()==root and root.stat().st_uid==os.getuid()
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='7a966774-3424-46c3-8045-34f759ea58a1'
assert hashlib.sha256((root/'runner.py').read_bytes()).hexdigest()==EXPECTED
spec=importlib.util.spec_from_file_location('current_owned_observation',root/'runner.py')
point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
job=json.loads((root/'result.json').read_text())
assert job['state']=='RUNNING_DISTROBOX' and point.ticks(job['pid'])==job['start_ticks']
cid=job['container'];assert len(cid)==64
observation=point.observe(98,gpu_observation_only=True)
owners=[p for p in observation['kfd'] if p['cgroup'].strip()=='0::/system.slice/docker-'+cid+'.scope']
assert len(owners)==1
owner=owners[0];pid,start=owner['pid'],owner['start_ticks']
assert point.ticks(pid)==start
argv=(Path('/proc')/str(pid)/'cmdline').read_bytes()
assert 0<len(argv)<=16384
argv=[value.decode() for value in argv.split(bytes([0])) if value]
assert Path(argv[0]).name=='synapse-lie-server'
assert argv.count('--management-port')==1 and argv.count('--management-host')==1
port=int(argv[argv.index('--management-port')+1])
assert 1<=port<=65535 and argv[argv.index('--management-host')+1]=='127.0.0.1'
connection=http.client.HTTPConnection('127.0.0.1',port,timeout=3)
begin=time.monotonic_ns()
try:
 connection.request('GET','/actuator/llm')
 response=connection.getresponse();body=response.read(1048577)
finally:connection.close()
elapsed=time.monotonic_ns()-begin
assert point.ticks(pid)==start and len(body)<=1048576 and response.status==200
view=json.loads(body)
assert view['schema']=='synapse-lie.llm.v1' and view['backend']['synthetic'] is False
assert view['backend']['engine']=='gufo-embedded-f783fedb' and view['backend']['model']=='qwen3.8-flash-next'
assert view['backend']['context_tokens']==1048576 and view['backend']['rope_scaling']=='yarn4'
assert view['scheduler']['mode']=='single-owner-reactive-ready-batch'
assert view['cache']['enabled'] is view['cache']['ssd_enabled'] is False
record={'state':'OWNED_C_CORE_PROGRESS_OBSERVED_NOT_COMPLETION',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'supervisor':{'pid':job['pid'],'start_ticks':job['start_ticks']},
 'actual_GPU_server':owner,'management_port':port,'http_status':response.status,
 'actual_GET_wall_ns':elapsed,'read_only_llm_snapshot':view,
 'observation':observation,'GPU_or_generation_request_or_control_mutation':False,
 'matched_performance_or_reactive_speedup_qualification':False}
print(json.dumps(record))
'''
argv = ['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',
        'pop@192.168.5.161','python3 -B -']
run = subprocess.run(argv,input=program,text=True,capture_output=True,timeout=30)
record = {'argv':argv,'actual_exit_code':run.returncode,
    'program_sha256':hashlib.sha256(program.encode()).hexdigest(),
    'stdout':run.stdout,'stderr':run.stderr}
try:
    record['result']=json.loads(run.stdout)
except ValueError:
    pass
with Path('evidence/'+label+'-native-progress-'+suffix+'.json').open('x') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
if 'result' in record:
    value=record['result'];view=value['read_only_llm_snapshot']
    print(json.dumps({'at_utc':value['at_utc'],'state':value['state'],'ready':view['ready'],
        'scheduler':view['scheduler'],'read_only_GET_wall_ms':value['actual_GET_wall_ns']/1e6,
        'temperatures':value['observation']['temperatures']}))
else:
    print(json.dumps(record))
raise SystemExit(run.returncode)
