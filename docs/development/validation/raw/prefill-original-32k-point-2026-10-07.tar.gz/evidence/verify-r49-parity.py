# SPDX-License-Identifier: MIT
"""Verify completed original-weight prefill arms, exact IDs and actual exits."""
from pathlib import Path
import datetime
import hashlib
import json
import struct

root = Path.cwd()
ready = json.loads(Path('evidence/context-r49-readiness.json').read_text())
source_tokens = json.loads(Path(ready['tokens_file']).read_text())
arms = []
outputs = []


def ident(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': digest}


for chunk in ready['selected_chunks']:
    label = 'context-r49-prefill-' + str(chunk) + '-r1'
    folder = Path('evidence') / label
    collection = json.loads((folder / 'collection.json').read_text())
    assert collection['exit_code'] == 0
    assert all(command['exit_code'] == 0 for command in collection['commands'])
    for rel, expected in collection['inventory']['files'].items():
        assert ident(folder / rel) == expected, (chunk, rel)
    controller = json.loads((folder / 'controller-result.json').read_text())
    result = json.loads((folder / 'result.json').read_text())
    assert result == json.loads((folder / 'controller-stdout.log').read_text())
    assert result['state'] == 'PASSED'
    assert controller['exit_code'] == result['exit_code'] == result['child_exit_code'] == 0
    assert result['model_stat_unchanged'] is True
    assert len(result['models_before']) == 4 and result['models_before'] == result['models_after']
    manifest = json.loads((folder / 'manifest.json').read_text())
    assert ident(folder / 'tokens.json')['sha256'] == manifest['tokens_sha256'] == ready['tokens_sha256']
    assert ident(folder / 'runner.py')['sha256'] == result['runner_sha256'] == ready['new_supervisor_source_sha256']
    assert manifest['source_commit'] == ready['compiled_source']
    assert manifest['prefill_capacity'] == ready['reservation'] == 32768
    rows = [json.loads(line) for line in (folder / 'measurements.jsonl').read_text().splitlines()]
    assert rows[-1] == {'event': 'complete', 'exit_code': 0}
    identity = [row for row in rows if row.get('event') == 'identity']
    inputs = [row for row in rows if row.get('event') == 'input']
    jobs = [row for row in rows if row.get('event') == 'job']
    samples = [row for row in rows if row.get('event') == 'sample']
    assert len(identity) == len(inputs) == len(jobs) == len(samples) == 1
    identity, input_row, job, sample = identity[0], inputs[0], jobs[0], samples[0]
    assert identity['synthetic'] is False and identity['mode'] == 'ar'
    assert identity['execution'] == 'shared-reactive-core' and identity['cache_policy'] == 'off'
    assert identity['context_capacity'] == 65536
    assert identity['prefill_chunk'] == chunk and identity['prefill_capacity'] == 32768
    assert identity['eos_policy'] == 'ignore' and identity['generation']['temperature'] == 0
    assert input_row['physical_ids'] == source_tokens and input_row['prompt_tokens'] == 32768
    physical_sha = hashlib.sha256(b''.join(struct.pack('<i', token) for token in source_tokens)).hexdigest()
    assert input_row['physical_ids_sha256'] == physical_sha
    assert job['prompt_tokens'] == job['prefill_tokens'] == 32768
    assert job['output_tokens'] == sample['output_tokens'] == 32 and len(job['output_ids']) == 32
    assert all(type(token) is int and 0 <= token < 248320 for token in job['output_ids'])
    assert job['prefill_chunk'] == chunk and job['prefill_capacity'] == 32768 and job['prefill_revision'] == 1
    assert job['prefill_calls'] == (32768 + chunk - 1) // chunk
    assert job['cached_tokens'] == job['ssd_cached_tokens'] == 0
    assert job['mtp_drafted_tokens'] == job['mtp_accepted_tokens'] == 0 and job['finish'] == 'length'
    dispatch = sample['prefill_attention_dispatch']
    assert dispatch['supported'] is True and dispatch['exact'] is True
    assert dispatch['pending'] is False and dispatch['overflowed'] is False
    assert dispatch['confirmed_batches'] == job['prefill_calls'] and dispatch['unconfirmed_batches'] == 0
    assert dispatch['confirmed']['geometry_refusals'] == dispatch['confirmed']['mask_pitch_refusals'] == 0
    assert dispatch['confirmed']['attention_rows'] == 12 * 32768
    closure_path = Path('evidence/context-r49-' + str(chunk) + '-closure-r1.json')
    closure = json.loads(closure_path.read_text())
    assert closure['actual_exit_code'] == 0
    assert closure['result']['state'] == 'FRESH_PREFILL_PARITY_WINDOW_CLOSED_NO_STANDING_RESERVATION'
    assert closure['result']['original_lease']['free_briefly'] is True
    peaks = {}; gtt = 0; telemetry_count = 0
    for line in (folder / 'telemetry.jsonl').read_text().splitlines():
        row = json.loads(line); telemetry_count += 1
        gtt = max(gtt, row['gpu']['mem_info_gtt_used'])
        for temperature in row['temperatures']:
            name = temperature['name']
            peaks[name] = max(peaks.get(name, -100), temperature['value_c'])
    arms.append({'chunk_tokens': chunk, 'capacity_tokens': 32768,
        'prefill_calls': job['prefill_calls'], 'output_ids': job['output_ids'],
        'physical_input_ids_sha256': physical_sha,
        'confirmed_prefill_dispatch': dispatch, 'sampled_peak_gtt_bytes': gtt,
        'temperature_peaks_C': peaks, 'telemetry_samples': telemetry_count,
        'controller_supervisor_native_exit_codes': [controller['exit_code'],result['exit_code'],result['child_exit_code']],
        'collected_remote_files_verified': len(collection['inventory']['files']),
        'closure': str(closure_path), 'closure_at_utc': closure['result']['at_utc']})
    outputs.append(job['output_ids'])
assert all(output == outputs[0] for output in outputs)
proof = {'schema': 'synapse-lie.prefill-original-parity.v1',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'ORIGINAL_WEIGHT_PP32768_TG32_CHUNKS2048_16384_32768_EXACT_GREEDY_PARITY',
    'actual_exit_code': 0, 'arms': arms, 'physical_input_ids_equal': True,
    'confirmed_output_ids_equal': True, 'model_stat_unchanged': True,
    'live_change_cache_cancel_fairness_quality_fault_cost_qualified': False,
    'new_GPU_HTTP_or_model_run': False, 'open_task_numbers': [2,3,4,5,6,7],
    'performance_comparison': False, 'goal_complete': False}
with Path('evidence/context-r49-parity-proof.json').open('x') as stream:
    json.dump(proof,stream,indent=2);stream.write('\n')
print(json.dumps({key:value for key,value in proof.items() if key != 'arms'}))
print(json.dumps([{key:arm[key] for key in ('chunk_tokens','prefill_calls','sampled_peak_gtt_bytes',
                  'temperature_peaks_C','collected_remote_files_verified')} for arm in arms]))
