# SPDX-License-Identifier: MIT
"""Independent saved-data review of original live-prefill witnesses; no inference."""
from pathlib import Path
import datetime, hashlib, json, struct

root=Path.cwd();folder=root/'evidence/context-r51-prefill-live-ar-r1'
def read(path):return json.loads(path.read_text())
def ident(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':digest}
def integer(row,key,wanted=None,minimum=0):
    value=row[key]
    assert type(value) is int and value>=minimum,(key,value)
    assert wanted is None or value==wanted,(key,value,wanted)
    return value
def choice(row,chunk,revision):
    integer(row,'chunk_tokens',chunk);integer(row,'capacity_tokens',32768)
    integer(row,'revision',revision)

m=read(folder/'manifest.json');r=read(folder/'result.json')
c=read(folder/'controller-result.json');collection=read(folder/'collection.json')
assert collection['exit_code']==0 and all(q['exit_code']==0 for q in collection['commands'])
for path,wanted in collection['inventory']['files'].items():assert ident(folder/path)==wanted,path
assert c['exit_code']==r['exit_code']==r['child_exit_code']==0 and r['state']=='PASSED'
assert r==json.loads((folder/'controller-stdout.log').read_text())
assert r['model_attempted'] is True and r['model_stat_unchanged'] is True
assert len(r['models_before'])==4 and r['models_before']==r['models_after']
assert not r['cleanup_failures'] and r['ended_at'] and r['lease_released_at']
assert r['lease']['device']==66307 and r['lease']['inode']==105946405
assert r['final_container_state']['OOMKilled'] is False
assert ident(folder/'runner.py')['sha256']==m['runner_sha256']==r['runner_sha256']
assert ident(folder/'tokens.json')['sha256']==m['tokens_sha256']
assert ident(root/m['qualified_build_receipt'])['sha256']==m['qualified_build_receipt_sha256']
build=read(root/m['qualified_build_receipt'])
assert build['source_commit']==m['source_commit']=='cb75a48fad340a3b25fadd0e6ed5c45b1fa2edcf'
assert build['bundle']['bundle_sha256']==m['bundle_manifest_sha256']
assert build['bundle']['metadata']['artifacts']==m['artifacts']
tokens=read(folder/'tokens.json');assert len(tokens)==32768
assert all(type(token) is int and 0<=token<248320 for token in tokens)
rows=[json.loads(line) for line in (folder/'measurements.jsonl').read_text().splitlines()]
assert rows and all(type(row) is dict for row in rows)
def events(name,count=1):
    selected=[row for row in rows if row.get('event')==name]
    assert len(selected)==count,(name,len(selected));return selected
identity=events('identity')[0]
assert identity['schema']=='synapse-lie.core-bench.v1'
assert identity['execution']=='shared-reactive-core' and identity['synthetic'] is False
assert identity['mode']=='ar' and identity['prefill_probe']=='live'
assert identity['build_id']==m['runtime_build_id']=='rocm10-point-modern-r50-runtime'
assert identity['input_kind']=='physical-tokens' and identity['cache_policy']=='off'
assert identity['generation']==m['generation'] and identity['generation']['temperature']==0
assert identity['eos_policy']=='ignore' and not identity['mtp_model'] and not identity['vision_model']
for key,value in {'users':2,'context_capacity':65536,'prefill_chunk':2048,
                  'prefill_capacity':32768,'warmups':0,'repetitions':1,
                  'output_limit':32,'prefix_cache_bytes':0,'ssd_quota_bytes':0}.items():integer(identity,key,value)
source=events('input')[0];assert source['physical_ids']==tokens
integer(source,'prompt_tokens',32768)
physical_sha=hashlib.sha256(b''.join(struct.pack('<i',token) for token in tokens)).hexdigest()
assert source['physical_ids_sha256']==physical_sha
jobs=events('job',2);samples=events('sample',2)
output=jobs[0]['output_ids'];assert len(output)==32
assert all(type(token) is int and 0<=token<248320 for token in output)
for step,(job,sample) in enumerate(zip(jobs,samples,strict=True)):
    assert job['output_ids']==output and job['finish']=='length'
    for key,value in {'rep':step,'warmup':0,'user':0,'prompt_tokens':32768,
                      'output_tokens':32,'prefill_tokens':32768,'prefill_calls':16,
                      'prefill_chunk':2048,'prefill_capacity':32768,'prefill_revision':1 if step==0 else 3,
                      'cached_tokens':0,'ssd_cached_tokens':0,'mtp_drafted_tokens':0,'mtp_accepted_tokens':0}.items():integer(job,key,value)
    for key,value in {'rep':step,'warmup':0,'users':1,'output_tokens':32}.items():integer(sample,key,value)
transition=events('prefill_transition')[0]
assert transition['same_owner_call_observed'] is True and transition['immutable_admissions'] is True
started=integer(transition,'prefill_started_before',minimum=1)
returned=integer(transition,'prefill_returned_before')
assert started>returned
integer(transition,'prefill_started_after',started);integer(transition,'prefill_returned_after',returned)
choice(transition['initial_core'],2048,1);choice(transition['current_core'],2048,3)
choice(transition['active_job'],2048,1);choice(transition['queued_job'],32768,2)
peer=events('prefill_live_result')[0]
choice(peer['active_job'],2048,1);choice(peer['peer_job'],32768,2)
integer(peer,'active_prefill_calls',16);integer(peer,'peer_prefill_calls',1)
integer(peer,'peer_prompt_tokens',32768);integer(peer,'peer_output_tokens',32)
assert peer['complete_peer_output_equal'] is True and peer['peer_output_ids']==output
reactive=events('reactive')[0]
assert reactive['synthetic'] is False and reactive['scope']=='direct-c-core-held-loan-peer-cancel'
assert 0<integer(reactive,'held_output_tokens',minimum=1)<32
integer(reactive,'held_borrowed_tokens',minimum=1)
for key,value in {'held_output_blocked':1,'peer_output_tokens':32,'completed_delta':1,
                  'cancelled_delta':1,'mtp_drafted_delta':0,'mtp_accepted_delta':0}.items():integer(reactive,key,value)
integer(reactive,'decode_batches_delta',minimum=1)
cancel=events('prefill_cancel')[0]
assert cancel['same_owner_call_observed'] is True and cancel['retired'] is True
for key,value in {'cancel_during_prefill_delta':1,'cancelled_delta':1,'failed_delta':0,'output_tokens':0}.items():integer(cancel,key,value)
cancel_calls=integer(cancel,'completed_prefill_calls',minimum=1)
assert cancel_calls<=16
cancel_tokens=integer(cancel,'completed_prefill_tokens')
# A returned numerical call can retire on cancellation before committing its
# prompt frontier. Calls and committed tokens intentionally have different scope.
assert cancel_tokens<=32768 and cancel_tokens<=cancel_calls*2048
complete=events('prefill_probe_complete')[0]
assert complete['mode']=='live' and complete['synthetic'] is False and complete['baseline_output_ids']==output
integer(complete,'prompt_tokens',32768);integer(complete,'output_tokens',32)
assert events('complete')[0]==rows[-1]=={'event':'complete','exit_code':0}
assert type(rows[-1]['exit_code']) is int
closure=read(root/'evidence/context-r51-closure-r1.json')
assert closure['actual_exit_code']==0
closed=closure['result'];assert closed['state']=='FRESH_LIVE_PREFILL_CLOSURE_NO_STANDING_RESERVATION'
for key in ('owned_supervisor_identity_absent','owned_client_identity_absent','owned_container_init_identity_recorded','owned_container_init_identity_absent'):assert closed[key] is True
assert closed['original_lease']['free_briefly'] is True and closed['original_lease']['released'] is True
assert not closed['foreign_compute_clients'] and not closed['guarded_hot'] and not closed['http8000_listeners']
assert closed['service']['ActiveState']=='active'
peaks={};peak_gtt=0;available=None;telemetry_count=0
for line in (folder/'telemetry.jsonl').read_text().splitlines():
    row=json.loads(line);telemetry_count+=1
    peak_gtt=max(peak_gtt,row['gpu']['mem_info_gtt_used'])
    ram=row['memory']['MemAvailable'];available=ram if available is None else min(available,ram)
    for sensor in row['temperatures']:
        peaks[sensor['name']]=max(peaks.get(sensor['name'],-100),sensor['value_c'])
        if sensor['guarded']:assert sensor['value_c']<sensor['limit_c']
assert telemetry_count and available>=m['memory_admission']['min_available_ram_bytes']
proof={'schema':'synapse-lie.prefill-live-saved-review.v1',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'actual_exit_code':0,'state':'SELECTED_ORIGINAL_AR_LIVE_PREFILL_PASSED',
 'scope':'Original Q4 PP32768/TG32/C2 live selection/credit/loan/cancellation and C1 recovery; functional only.',
 'source_commit':m['source_commit'],'physical_input_ids_sha256':physical_sha,
 'confirmed_output_ids':output,'active_prefill_calls':16,'peer_prefill_calls':1,
 'same_inflight_call_immutable_admissions_verified':True,'full_peer_baseline_fresh_output_equal':True,
 'borrowed_credit_peer_progress_verified':True,'prefill_cancel_zero_output_recovery_verified':True,
 'sampled_temperature_peaks_C':peaks,'sampled_peak_gtt_bytes':peak_gtt,
 'sampled_minimum_available_ram_bytes':available,'telemetry_samples':telemetry_count,
 'model_stats_unchanged':True,'strict_process_service_lease_closure_verified':True,
 'RAM_SSD_MTP_quality_performance_qualified':False,'new_GPU_or_model_run':False,
 'open_task_numbers':[2,3,4,5,6,7],'goal_complete':False}
with (root/'evidence/context-r51-live-proof.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\n')
print(json.dumps(proof))
