# SPDX-License-Identifier: MIT
"""Seal finished original live-prefill evidence; never run inference or tests."""
from pathlib import Path
import datetime, hashlib, json, tarfile

root=Path.cwd();dest=root/'docs/development/validation'
name='prefill-live-original-point-2026-10-07'
receipt_path=dest/(name+'.json');archive_path=dest/'raw'/(name+'.tar.gz')
assert not receipt_path.exists() and not archive_path.exists()
def read(rel):return json.loads((root/rel).read_text())
def ident(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':digest}
folder='evidence/context-r51-prefill-live-ar-r1'
m=read(folder+'/manifest.json');r=read(folder+'/result.json')
proof=read('evidence/context-r51-live-proof.json')
guard=read('evidence/context-r51-review-guard/result.json')
closure=read('evidence/context-r51-closure-r1.json')
assert proof['actual_exit_code']==guard['exit_code']==guard['child_exit_code']==closure['actual_exit_code']==0
assert guard['reason'] is None and r['state']=='PASSED' and not r['cleanup_failures']
assert r['models_before']==r['models_after'] and r['model_stat_unchanged'] is True
assert ident(root/m['qualified_build_receipt'])['sha256']==m['qualified_build_receipt_sha256']
files={}
for path in root.glob('evidence/context-r51-*'):
    if path.is_file():files[str(path.relative_to(root))]=path
    elif path.is_dir() and path.name=='context-r51-prefill-live-ar-r1':
        for child in path.rglob('*'):
            if child.is_file():files[str(child.relative_to(root))]=child
# Review has ended. Sealing/postseal guards remain excluded because they run now/later.
for path in (root/'evidence/context-r51-review-guard').iterdir():
    if path.is_file():files[str(path.relative_to(root))]=path
for rel in ('evidence/prepare-context-r51-live.py','evidence/launch-context-r51-live.py',
            'evidence/observe-context-r51-live.py','evidence/verify-context-r51-live.py',
            'evidence/seal-context-r51-live.py','tools/strix-point-campaign.py',
            'tools/strix-point-bench-collect.py','tools/core-bench.c',
            'tools/thermal-run.py','src/sampling.c','src/worker.c',
            'include/lie/prefill.h',m['qualified_build_receipt']):files[rel]=root/rel
members={rel:ident(path) for rel,path in sorted(files.items())}
with tarfile.open(archive_path,'x:gz') as packed:
    for rel in members:packed.add(files[rel],arcname=rel,recursive=False)
with tarfile.open(archive_path,'r:gz') as packed:
    entries=packed.getmembers()
    assert len(entries)==len(members) and {p.name for p in entries}==set(members)
    for entry in entries:
        assert entry.isfile() and 'sealing-guard' not in entry.name and 'postseal-guard' not in entry.name
        with packed.extractfile(entry) as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
        assert {'bytes':entry.size,'sha256':digest}==members[entry.name]
        assert ident(files[entry.name])==members[entry.name]
live_files=[];peaks=dict(proof['sampled_temperature_peaks_C'])
for path in sorted(root.glob('evidence/context-r51-live-r*.json')):
    observed=read(str(path.relative_to(root)));assert observed['actual_exit_code']==0
    live_files.append(str(path.relative_to(root)))
    for sensor in observed['result']['observation']['temperatures']:
        peaks[sensor['name']]=max(peaks.get(sensor['name'],-100),sensor['value_c'])
rows=[json.loads(line) for line in (root/folder/'measurements.jsonl').read_text().splitlines()]
transitions={row['event']:row for row in rows if row['event'] in ('prefill_transition','prefill_live_result','reactive','prefill_cancel','prefill_probe_complete')}
receipt={'schema':'synapse-lie.prefill-live-original-point.v1',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':proof['state'],'scope':proof['scope'],
 'compiled_source_commit':m['source_commit'],'native_client_code_checkpoint':m['native_client_code_checkpoint'],
 'engine_code_checkpoint':m['functional_code_checkpoint'],'qualification_runner_commit':m['runner_commit'],
 'qualified_HIP_build':{'path':m['qualified_build_receipt'],**ident(root/m['qualified_build_receipt'])},
 'host':'192.168.5.161','runtime_build_id':m['runtime_build_id'],
 'image':m['image'],'bundle_sha256':m['bundle_manifest_sha256'],'binaries':m['artifacts'],
 'qualification_runner_sha256':m['runner_sha256'],'model_plan':m['model_plan'],
 'original_model_stat_witnesses':r['models_before'],'native_functional_witnesses':transitions,
 'independent_saved_data_review':proof,'offline_review_guard':guard,
 'fresh_global_preflight':read('evidence/context-r51-before-live-r1.json'),
 'peer_coordination':read('evidence/context-r51-peer-coordination.json'),
 'live_owner_observation_files':live_files,'combined_sampled_temperature_peaks_C':peaks,
 'process_service_lease_closure':{'supervisor':{'pid':r['pid'],'start_ticks':r['start_ticks']},
    'client':{'pid':r['child_pid'],'start_ticks':r['child_start_ticks']},
    'container':r['container'],'container_init':closure['result']['owned_container_init_identity'],
    'lease_released_at_utc':r['lease_released_at'],
    'controller_exit_code':read(folder+'/controller-result.json')['exit_code'],
    'supervisor_exit_code':r['exit_code'],'native_child_exit_code':r['child_exit_code'],
    'idle_container_init_cleanup_exit_code':r['final_container_state']['ExitCode'],
    'strict_closure_actual_exit_code':closure['actual_exit_code'],'strict_closure':closure['result']},
 'new_GPU_build_model_run_for_sealing':False,'Python_product_dependency_added':False,
 'no_standing_remote_job_lease_window_waiter_reservation_handle_after_closure':True,
 'resource_scope':'Sampled 1Hz original-weight C2 with cold C1 baseline/recovery; not allocator-exact fit or matched performance.',
 'RAM_SSD_MTP_vision_broader_quality_fault_performance_qualified':False,
 'next_gate':'Original-weight RAM/SSD chunk namespace and MTP qualification; remaining steering/temperature/long-context quality, faults/resources; matched benchmarks then Terminal Bench last.',
 'open_task_numbers':[2,3,4,5,6,7],'goal_complete':False,'publication':False,
 'portable_raw_archive':{'path':'raw/'+archive_path.name,**ident(archive_path),'members':len(members)},
 'raw_artifacts':members}
with receipt_path.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'receipt':str(receipt_path.relative_to(root)),'archive':receipt['portable_raw_archive'],'state':receipt['state']}))
