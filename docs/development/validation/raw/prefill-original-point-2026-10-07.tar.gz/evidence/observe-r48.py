# SPDX-License-Identifier: MIT
"""Observe exact already launched prefill owner; never admit or restart."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

chunk, observation = int(sys.argv[1]), int(sys.argv[2])
assert chunk in (2048, 4096, 8192) and 1 <= observation <= 30
label = 'context-r48-prefill-' + str(chunk) + '-r1'
expected = hashlib.sha256(Path('tools/strix-point-campaign.py').read_bytes()).hexdigest()
program = 'LABEL=' + repr(label) + '\nEXPECTED=' + repr(expected) + '\n' + '''
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess
root=Path('/home/pop/workspace/synapse-lie')/LABEL
r=json.loads((root/'result.json').read_text())
assert hashlib.sha256((root/'runner.py').read_bytes()).hexdigest()==EXPECTED
spec=importlib.util.spec_from_file_location('point',root/'runner.py')
point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
try: alive=point.ticks(r['pid'])==r['start_ticks']
except FileNotFoundError: alive=False
fds=[]
if alive:
 for path in Path('/proc').joinpath(str(r['pid']),'fd').iterdir():
  try:
   st=path.stat()
   if (st.st_dev,st.st_ino)==(66307,105946405):fds.append(int(path.name))
  except FileNotFoundError:pass
init=None
if r.get('container'):
 q=subprocess.run(['docker','inspect','--format','{{json .State}}',r['container']],capture_output=True,text=True,timeout=15)
 if q.returncode==0:
  state=json.loads(q.stdout);pid=state.get('Pid',0)
  if pid>0:
   try:init={'pid':pid,'start_ticks':point.ticks(pid),'container':r['container']}
   except FileNotFoundError:pass
progress=[]
path=root/'distrobox.stderr.log'
if path.exists():
 for line in path.read_text().splitlines():
  if not line.startswith('{'):continue
  try:v=json.loads(line)
  except json.JSONDecodeError:continue
  if v.get('event')=='core_progress':progress.append(v)
obs=point.observe(98,gpu_observation_only=True)
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'label':LABEL,'state':r['state'],'supervisor_pid':r['pid'],'supervisor_start_ticks':r['start_ticks'],
 'live_exact_supervisor':alive,'original_lease_fds':fds,'container_init_observed_identity':init,
 'active_owner_observed':bool(alive and fds and r['state'] in ('ADMITTED','RUNNING_DISTROBOX')),
 'model_attempted':r.get('model_attempted'),
 'actual_terminal_exit_code':r.get('exit_code') if r['state'] in ('PASSED','FAILED') and r.get('ended_at') else None,
 'error':r.get('error'),'bench_result':r.get('bench_result'),
 'progress_snapshots':len(progress),'last_progress':progress[-1] if progress else None,
 'observation':obs,'new_GPU_job_build_or_restart':False}
print(json.dumps(result))
'''
argv = ['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',
        'pop@192.168.5.161','python3 -B -']
process = subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
r = {'argv':argv,'actual_exit_code':process.returncode,
     'program_sha256':hashlib.sha256(program.encode()).hexdigest(),
     'stdout':process.stdout,'stderr':process.stderr}
try:r['result']=json.loads(process.stdout)
except ValueError:pass
out=Path('evidence/context-r48-'+str(chunk)+'-live-r'+str(observation)+'.json')
with out.open('x') as stream:json.dump(r,stream,indent=2);stream.write('\n')
if 'result' in r:
    result = r['result']
    view = {key:value for key,value in result.items() if key != 'observation'}
    view['current_temperatures_C']={t['name']:t['value_c'] for t in result['observation']['temperatures']}
    print(json.dumps(view))
else:print(json.dumps(r))
raise SystemExit(process.returncode)
