# SPDX-License-Identifier: MIT
"""Seal completed chunk-parity qualification; no GPU, model, build or test."""
from pathlib import Path
import datetime
import hashlib
import json
import tarfile

root=Path.cwd()
dest=root/'docs/development/validation'
name='prefill-original-point-2026-10-07'
receipt_path=dest/(name+'.json')
archive_path=dest/'raw'/(name+'.tar.gz')
assert not receipt_path.exists() and not archive_path.exists()


def read(rel):return json.loads((root/rel).read_text())


def ident(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':sha}


ready=read('evidence/context-r48-readiness.json')
proof=read('evidence/context-r48-parity-proof.json')
guard=read('evidence/r48-parity-review-guard/result.json')
assert proof['actual_exit_code']==guard['exit_code']==guard['child_exit_code']==0
assert guard['reason'] is None and len(proof['arms'])==3
assert proof['physical_input_ids_equal'] and proof['confirmed_output_ids_equal']
assert proof['model_stat_unchanged'] and not proof['performance_comparison']
manifest=read('evidence/context-r48-prefill-2048-r1-manifest.json')
hip_rel=manifest['qualified_build_receipt']
hip=read(hip_rel)
assert ident(root/hip_rel)['sha256']==manifest['qualified_build_receipt_sha256']
assert hip['source_commit']==manifest['source_commit']==ready['compiled_source']
assert hip['code_checkpoint']==manifest['functional_code_checkpoint']==ready['functional_code_checkpoint']
assert hip['bundle']['bundle_sha256']==manifest['bundle_manifest_sha256']
assert hip['bundle']['metadata']['artifacts']==manifest['artifacts']
assert ident(root/'tools/strix-point-campaign.py')['sha256']==ready['new_supervisor_source_sha256']
states=[]
models=None
for chunk in ready['selected_chunks']:
    job='evidence/context-r48-prefill-'+str(chunk)+'-r1'
    r=read(job+'/result.json')
    controller=read(job+'/controller-result.json')
    closure=read('evidence/context-r48-'+str(chunk)+'-closure-r1.json')
    assert r['state']=='PASSED'
    assert controller['exit_code']==r['exit_code']==r['child_exit_code']==closure['actual_exit_code']==0
    assert r==json.loads((root/job/'controller-stdout.log').read_text())
    assert r['models_before']==r['models_after'] and not r['cleanup_failures']
    if models is None:models=r['models_before']
    assert models==r['models_before']
    m=read(job+'/manifest.json')
    for key in ('source_commit','functional_code_checkpoint','runner_commit','fixture_commit',
                'bundle_manifest_sha256','image','artifacts','tokens_sha256','prefill_capacity'):
        assert m[key]==manifest[key]
    c=closure['result']
    assert c['state']=='FRESH_PREFILL_PARITY_WINDOW_CLOSED_NO_STANDING_RESERVATION'
    assert c['original_lease']['free_briefly'] is True
    states.append({'chunk_tokens':chunk,'supervisor_identity':{'pid':r['pid'],'start_ticks':r['start_ticks']},
        'container_identity':r['container'],'lease_released_at_utc':r['lease_released_at'],
        'controller_exit_code':controller['exit_code'],'supervisor_exit_code':r['exit_code'],
        'native_child_exit_code':r['child_exit_code'],
        'idle_container_init_cleanup_exit_code':r['final_container_state']['ExitCode'],
        'fresh_closure':c,'closure_actual_exit_code':closure['actual_exit_code']})
files={}
for path in root.glob('evidence/context-r48-*'):
    if path.is_dir():
        for child in path.rglob('*'):
            if child.is_file():files[str(child.relative_to(root))]=child
    elif path.is_file():files[str(path.relative_to(root))]=path
for rel in ('evidence/observe-r48.py','evidence/verify-r48-parity.py','evidence/seal-r48.py',
            'tools/strix-point-campaign.py','tests/test_strix_point_campaign.py',
            'tools/strix-point-launch.py','tools/strix-point-bench-collect.py','tools/core-bench.c',
            'tools/thermal-run.py','src/core_input.c','src/worker.c',hip_rel,
            'docs/development/validation/prefill-supervisor-host-2026-10-07.json'):
    files[rel]=root/rel
for path in (root/'evidence/r48-parity-review-guard').iterdir():
    if path.is_file():files[str(path.relative_to(root))]=path
members={rel:ident(path) for rel,path in sorted(files.items())}
with tarfile.open(archive_path,'x:gz') as archive:
    for rel in members:archive.add(files[rel],arcname=rel,recursive=False)
with tarfile.open(archive_path,'r:gz') as archive:
    entries=archive.getmembers()
    assert len(entries)==len(members) and {entry.name for entry in entries}==set(members)
    for entry in entries:
        assert entry.isfile()
        with archive.extractfile(entry) as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
        assert {'bytes':entry.size,'sha256':sha}==members[entry.name]
        assert ident(files[entry.name])==members[entry.name]
receipt={
    'schema':'synapse-lie.prefill-original-point.v1',
    'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state':proof['state'],'scope':'Selected original-weight PP8192/TG32 greedy token parity at fixedcontext16384/C1/capacity8192; functional qualification only, not throughput comparison or complete chunk acceptance.',
    'source_commit':ready['compiled_source'],'functional_code_checkpoint':ready['functional_code_checkpoint'],
    'supervisor_and_fixture_commit':ready['current_head'],
    'source_continuity':ready,'coherent_HIP_build':{'path':hip_rel,**ident(root/hip_rel)},
    'host':'192.168.5.161','runtime_build_id':manifest['runtime_build_id'],
    'image':manifest['image'],'bundle_sha256':manifest['bundle_manifest_sha256'],'binaries':manifest['artifacts'],
    'model_plan':manifest['model_plan'],'original_model_stat_witnesses':models,
    'arms':proof['arms'],'physical_input_ids_equal':True,'confirmed_output_ids_equal':True,
    'unchanged_model_stats_across_all_three_windows':True,
    'offline_review_guard':guard,'process_service_lease_closures':states,
    'peer_coordination':read('evidence/context-r48-peer-coordination.json'),
    'preserved_preflight_sandbox_SSH_exit_code':read('evidence/context-r48-before-prefill-r1.json')['actual_exit_code'],
    'approved_fresh_preflight_exit_code':read('evidence/context-r48-before-prefill-r2.json')['actual_exit_code'],
    'observer_display_correction':read('evidence/context-r48-observer-display-correction.json'),
    'larger32768_live_change_cache_cancel_fairness_quality_fault_cost_qualified':False,
    'sampled_resource_scope':'1Hz GTT and CPU/NVMe/GPU observations; not allocation-exact accounting or general memory-fit guarantee.',
    'thermal_policy':manifest['thermal_policy'],
    'new_GPU_build_or_model_run_for_sealing':False,'Python_product_dependency_added':False,
    'no_standing_root_job_lease_waiter_window_reservation_handle_after_closure':True,
    'next_gate':'Original-weight32K chunk capacity/parity and live-change/queued-job/cache/cancel/fairness acceptance; remaining MTP numerical, steering and long-context quality/fault/resource gates; then matched benchmarks and Terminal Bench last.',
    'open_task_numbers':[2,3,4,5,6,7],'goal_complete':False,'publication':False,
    'portable_raw_archive':{'path':'raw/'+archive_path.name,**ident(archive_path),'members':len(members)},
    'raw_artifacts':members}
with receipt_path.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps({'receipt':str(receipt_path.relative_to(root)),
    'archive':receipt['portable_raw_archive'],'state':receipt['state']}))
