# SPDX-License-Identifier: MIT
"""Grouped CPU fixtures; no GPU/model work; reuse the two routine build directories."""
from pathlib import Path
import json,os,subprocess,sys,datetime
root=Path(__file__).resolve().parents[1]
os.chdir(root)
out=root/'evidence/steering-capture-host-r1';out.mkdir(exist_ok=False)
records=[]
pattern='^(steering-direction-learning-lifetimes|steering-activation-collection-lifetimes|steering-activation-span-contract|steering-bank-format-identity-lifetimes|steering-policy-history-cache-lifetimes|steering-model-admission-retained-forward|native-provider-verification|native-provider-source-paths)$'
for mode,build,sanitize in [('Debug','build/context-debug',False),('ASan_UBSan_LSan','build/tool-http-asan',True)]:
 flags=['-fsanitize=address,undefined','-fno-omit-frame-pointer'] if sanitize else []
 binary=build+'/test-gufo-activation-observer-host-fixture'
 commands=[
  ['cmake','-S','.','-B',build],
  ['cmake','--build',build,'--parallel','2','--target','test-steering-direction','test-steering-capture','test-steering-activation','test-steering','test-steering-policy','test-steering-forward'],
  ['ctest','--test-dir',build,'--output-on-failure','-R',pattern],
  ['c++','-std=c++20','-Wall','-Wextra','-Wpedantic','-Werror','-UNDEBUG',*flags,'-Iinclude','-Iadapters','tests/test_gufo_activation_observer.cpp',build+'/liblie_steering.a','-lcrypto','-lm','-pthread','-o',binary],
  [binary]]
 for i,command in enumerate(commands,1):
  guard=out/(mode+'-'+str(i))
  env=dict(os.environ,LC_ALL='C',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
  argv=[sys.executable,'-B','tools/thermal-run.py','--output',str(guard),'--timeout','600','--limit-c','98','--',*command]
  run=subprocess.run(argv,capture_output=True,text=True,env=env,check=False)
  (out/(mode+'-'+str(i)+'.stdout')).write_text(run.stdout)
  (out/(mode+'-'+str(i)+'.stderr')).write_text(run.stderr)
  record={'mode':mode,'command':command,'guard':str(guard.relative_to(root)),'actual_exit_code':run.returncode}
  if (guard/'result.json').is_file():record['result']=json.loads((guard/'result.json').read_text())
  records.append(record)
  (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
  print(json.dumps(record),flush=True)
  if run.returncode:raise SystemExit(run.returncode)
print(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit_code':0,'commands':len(records),'classification':'CPU fixtures only; original-weight activation capture, learned quality, HIP compilation and matched cost pending.'}),flush=True)
