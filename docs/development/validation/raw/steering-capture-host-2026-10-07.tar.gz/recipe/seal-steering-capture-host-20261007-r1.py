# SPDX-License-Identifier: MIT
"""Seal HOST-only collection/learning checks; no GPU or learned-quality claim."""
import datetime,hashlib,json,re,tarfile
from pathlib import Path
root=Path.cwd();base=root/'evidence/steering-capture-host-r1'
public=root/'docs/development/validation/steering-capture-host-2026-10-07.json'
raw=public.parent/'raw/steering-capture-host-2026-10-07.tar.gz'
assert not public.exists() and not raw.exists()
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
commands=[];failed=[];peaks={}
for plan in sorted(base.glob('*/plan.json')):
 guard=plan.parent;result=read(guard/'result.json');record={'guard':str(guard.relative_to(root)),**result}
 assert result['exit_code']==result['child_exit_code'] and result['reason'] is None
 for sensor,temp in result['peak_c'].items():peaks[sensor]=max(peaks.get(sensor,-100),temp)
 if guard.name in ('adapter-syntax-0','adapter-syntax-1','adapter-syntax-0-r2','adapter-syntax-1-r2'):
  assert result['exit_code']==1;failed.append(record)
 else:
  assert result['exit_code']==0;commands.append(record)
assert len(commands)==17 and len(failed)==4
names=['steering-direction-learning-lifetimes','steering-activation-collection-lifetimes','steering-activation-span-contract','steering-bank-format-identity-lifetimes','steering-policy-history-cache-lifetimes','steering-model-admission-retained-forward','native-provider-verification','native-provider-source-paths']
for mode in ('Debug','ASan_UBSan_LSan'):
 log=(base/(mode+'-3')/'command.log').read_text()
 assert '100% tests passed out of 8' in log
 for name in names:assert any(name in line and 'Passed' in line for line in log.splitlines())
 assert 'PASS (borrowed host fixtures; no GPU copies)' in (base/(mode+'-5')/'command.log').read_text()
for mode in ('Debug','ASan'):
 log=(base/('abi-'+mode+'-test')/'command.log').read_text()
 assert '100% tests passed out of 1' in log and 'executor-c-layout' in log
for on in (0,1):
 assert 'hip/hip_fp16.h' in (base/('adapter-syntax-'+str(on))/'command.log').read_text()
 assert 'LIE_MTP' in (base/('adapter-syntax-'+str(on)+'-r2')/'command.log').read_text()
 assert not (base/('adapter-syntax-'+str(on)+'-r3')/'command.log').read_text()
assert '23 changed files' in (base/'variant/command.log').read_text()
source=['CMakeLists.txt','adapters/gufo.cpp','adapters/gufo_activation_observer.hpp','adapters/gufo-state/activation-observer-edits.json','cmake/provider/Source.cmake','cmake/provider/Build.cmake','cmake/provider/Verify.cmake','include/lie/activation_observer.h','include/lie/steering_capture.h','include/lie/steering_direction.h','src/steering_capture.c','src/steering_direction.c','src/executor_unavailable.c','tests/test_steering_capture.c','tests/test_steering_direction.c','tests/test_gufo_activation_observer.cpp','tests/test_executor_abi.c','tests/provider_contract.cmake','LICENSE','third_party/gufo-source.json','third_party/gufo-LICENSE','third_party/gufo-NOTICE','third_party/gufo-THIRD_PARTY_NOTICES.md']
source+= [str(p.relative_to(root)) for p in sorted((root/'adapters/gufo-state').glob('*-edits.json')) if str(p.relative_to(root)) not in source]
parts=[(root/p,'source/'+p) for p in source]
parts +=[(p,'host/'+str(p.relative_to(base))) for p in sorted(base.rglob('*')) if p.is_file() and not p.is_symlink()]
parts +=[(root/'evidence/run-steering-capture-host-r1.py','recipe/run-steering-capture-host-r1.py'),(root/'tools/thermal-run.py','recipe/thermal-run.py'),(Path(__file__),'recipe/'+Path(__file__).name)]
assert len({name for _,name in parts})==len(parts)
inventory=[{'path':name,'bytes':path.stat().st_size,'sha256':digest(path)} for path,name in parts]
with tarfile.open(raw,'x:gz') as t:
 for p,name in parts:t.add(p,arcname=name,recursive=False)
with tarfile.open(raw,'r:gz') as t:
 assert len(t.getmembers())==len(inventory)
 for item in inventory:
  data=t.extractfile(item['path']).read()
  assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
binaries={}
for b in ('build/context-debug','build/tool-http-asan'):
 for name in ('test-steering-direction','test-steering-capture','test-steering-activation','test-steering','test-steering-policy','test-steering-forward','test-executor-abi','test-gufo-activation-observer-host-fixture'):
  p=root/b/name;binaries[str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':digest(p)}
receipt={'schema':'synapse-lie.steering-capture-host.v1','state':'HOST_C17_CAPTURE_DIRECTION_AND_BORROWED_SCOPE_PASSED_PROVIDER_SYNTAX_PASSED_GPU_UNQUALIFIED','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Synthetic finite/nonfinite/cancellation/geometry/token/duplicate/lifetime/budget and analytic paired-direction fixtures; no original-weight CPU or GPU forward.', 'successful_commands':commands,'preserved_failed_syntax_probes':failed,'failure_correction':'First probes omit the installed ROCm include path; second omit CMake-defined LIE_MTP/LIE_VISION. Final plain C++ syntax uses installed headers and complete selected feature macros, without source changes or GPU execution.','CTest_count':{'Debug':9,'ASan_UBSan_LSan':9},'borrowed_scope_fixture_count':{'Debug':1,'ASan_UBSan_LSan':1},'sanitizer_options':['detect_leaks=1:halt_on_error=1','halt_on_error=1:print_stacktrace=1'],'sanitizer_suppression_options':[],'exact_pinned_variant_changed_files':23,'upstream_pin':'f783fedb9bea2ec7de941f6da4e02f4a4596b29e','reused_build_directories':['build/context-debug','build/tool-http-asan'],'new_build_directories':[],'peak_C_by_sensor':peaks,'source':{p:digest(root/p) for p in source},'binaries':binaries,'raw':{'path':'raw/'+raw.name,'bytes':raw.stat().st_size,'sha256':digest(raw),'members':len(parts),'inventory':inventory},'remaining_gates':['Native paired-prompt bank builder','Coherent full HIP provider/consumer build','Original-weight completed last-token captures and uninstrumented parity','Learned-bank quality, graph/correction/fault/resource and matched cost'],'existing_executor_request_core_layouts_and_DS4_payloads_changed':False,'new_GPU_or_remote_build_admitted':False,'original_weight_new_capture_or_learned_quality_qualified':False,'goal_complete':False,'actual_exit_code':0}
with public.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'receipt':str(public),'raw_bytes':raw.stat().st_size,'raw_members':len(parts),'raw_sha256':digest(raw),'actual_exit_code':0,'CTest_count':receipt['CTest_count'],'borrowed_scope_fixture_count':receipt['borrowed_scope_fixture_count'],'successful_commands':len(commands),'preserved_failed_commands':len(failed)}))
