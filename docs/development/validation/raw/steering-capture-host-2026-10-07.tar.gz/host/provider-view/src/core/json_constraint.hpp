#ifndef GUFO_CORE_JSON_CONSTRAINT_HPP_
#define GUFO_CORE_JSON_CONSTRAINT_HPP_

#include "lie/grammar.h"
#include "lie/grammar_vocabulary.h"

#include <bitset>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <span>
#include <string>
#include <vector>

#include "src/core/json.hpp"
#include "src/core/json_schema_lexeme.hpp"
#if LIE_C17_SAMPLING
#include "gufo_grammar_state.hpp"
#include "lie/schema_compile.h"
#include <string_view>
#endif

namespace gufo::sampling {

// Byte grammar: token boundaries may split UTF-8 characters and JSON escapes.
// Programs and vocabulary tries are immutable and shared; stacks belong to a
// request and are copied along with its sampler during speculative
// verification.
class JsonConstraint {
public:
  struct Stack {
    std::vector<std::uint32_t> symbols;
    std::string lexeme;
    auto operator<=>(const Stack&) const = default;
  };
#if LIE_C17_SAMPLING
  using State = lie_gufo::RequestGrammarState;
#else
  using State = std::vector<Stack>;
#endif
  using Sequence = std::vector<std::uint32_t>;
  using Rule = std::vector<Sequence>;

  static std::shared_ptr<const JsonConstraint> Compile(
      const json::Value& schema, bool strict);
  static std::shared_ptr<const JsonConstraint> Object();
  static std::shared_ptr<const JsonConstraint> WithReasoning(
      std::shared_ptr<const JsonConstraint> answer);
  using Tool = std::pair<std::string, std::shared_ptr<const JsonConstraint>>;
  static std::shared_ptr<const JsonConstraint> WithTools(
      std::shared_ptr<const JsonConstraint> answer, std::vector<Tool> tools,
      bool required, bool parallel = false);

  [[nodiscard]] State Start() const;
  [[nodiscard]] State Advance(const State& state, unsigned char byte) const;
  [[nodiscard]] bool Complete(const State& state) const;
#if LIE_C17_SAMPLING
  [[nodiscard]] std::string_view prompt() const {
    size_t bytes = 0;
    const char *text = lie_schema_prompt_bytes(prompt_.get(), &bytes);
    return {text, bytes};
  }
#else
  [[nodiscard]] const std::string& prompt() const { return prompt_; }
#endif

private:
  JsonConstraint() = default;
#if LIE_C17_SAMPLING
  static std::shared_ptr<const JsonConstraint> CompileNative(
      const json::Value&, bool strict, bool object_only);
#endif
  friend class JsonConstraintCompiler;
  friend class ConstraintVocabulary;
  friend struct TokenConstraint;
  State CanonicalMaskState(const State& state, std::size_t token_bytes) const;
  State Expand(State state) const;
#if !LIE_C17_SAMPLING
  std::vector<Rule> rules_;
  std::vector<std::bitset<256>> classes_;
#endif
#if LIE_C17_SAMPLING
  lie_gufo::LexemeTable lexemes_;
#else
  std::vector<std::shared_ptr<const JsonSchemaLexeme>> lexemes_;
#endif
  std::uint32_t root_{0};
#if LIE_C17_SAMPLING
  std::shared_ptr<const lie_schema_prompt> prompt_;
#else
  std::string prompt_;
#endif
  bool stop_only_when_complete_{true};
#if !LIE_C17_SAMPLING
  void BuildC17Program();
#endif
  std::shared_ptr<const lie_grammar_program> c17_program_;
};

class ConstraintVocabulary {
public:
  struct Piece {
    std::string text;
    bool stop{false};
  };
  using Reader = std::function<Piece(std::uint32_t)>;
  explicit ConstraintVocabulary(std::uint32_t size, const Reader& reader);

  [[nodiscard]] std::vector<std::uint8_t> Allowed(
      const JsonConstraint& grammar, const JsonConstraint::State& state) const;
  [[nodiscard]] JsonConstraint::State Accept(const JsonConstraint& grammar,
                                             const JsonConstraint::State& state,
                                             std::uint32_t token) const;
  [[nodiscard]] std::size_t size() const {
    return c17_vocabulary_ ? lie_vocabulary_size(c17_vocabulary_.get()) : pieces_.size();
  }

private:
  friend struct TokenConstraint;
  struct Edge {
    std::uint32_t child;
    unsigned char byte;
  };
  struct Node {
    std::vector<Edge> edges;
    std::vector<std::uint32_t> tokens;
  };
  std::vector<Node> trie_{1};
  std::vector<Piece> pieces_;
  std::size_t max_token_bytes_{0};
  std::shared_ptr<const lie_grammar_vocabulary> c17_vocabulary_;
};

struct TokenConstraint {
  std::shared_ptr<const JsonConstraint> grammar;
  std::shared_ptr<const ConstraintVocabulary> vocabulary;
  [[nodiscard]] std::shared_ptr<const std::vector<std::uint8_t>> Allowed(
      const JsonConstraint::State& state) const;

private:
  mutable std::mutex mutex_;
  mutable std::map<JsonConstraint::State,
                   std::shared_ptr<const std::vector<std::uint8_t>>>
      masks_;
  mutable std::shared_ptr<lie_grammar_mask_cache> c17_masks_;
};

}  // namespace gufo::sampling

#endif
