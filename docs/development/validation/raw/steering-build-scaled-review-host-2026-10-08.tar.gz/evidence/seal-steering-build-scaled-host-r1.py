# SPDX-License-Identifier: MIT
"""Preserve bounded streamed-review HOST checks without duplicating GPU payloads."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import tarfile

root=Path.cwd().resolve()
public=root/'docs/development/validation/steering-build-scaled-review-host-2026-10-08.json'
archive=public.parent/'raw/steering-build-scaled-review-host-2026-10-08.tar.gz'
assert not public.exists() and not archive.exists()
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(path.read_text())
guards={}
paths=[]
for name in ('steering-build-scaled-host-debug-r1','steering-build-scaled-host-asan-r1',
             'steering-build-scaled-campaign-guard-r1','steering-build-scaled-ctest-debug-r1',
             'steering-build-scaled-ctest-asan-r1','steering-build-streamed-original-guard-r1'):
    directory=root/'evidence'/name
    result=read(directory/'result.json')
    assert result['exit_code']==result['child_exit_code']==0 and result['reason'] is None
    log=(directory/'command.log').read_text()
    if '-host-' in name:assert 'Ran 21 tests' in log and '\nOK\n' in log
    if '-campaign-' in name:assert 'Ran 89 tests' in log and '\nOK\n' in log
    if '-ctest-' in name:assert '100% tests passed, 0 tests failed out of 1' in log
    guards[name]=result
    paths.extend(sorted(directory.iterdir()))
review_path=root/'evidence/steering-build-streamed-original-review-r1.json'
review=read(review_path)
assert review['actual_exit_code']==0 and len(review['cohorts'])==2
assert all(c['captured_rows']==1536 and c['exactly_matches_qualified_independent_review'] for c in review['cohorts'])
assert [c['one_token_tails'] for c in review['cohorts']]==[0,4]
helper=root/'tools/strix-point-steering-build-gate.py'
assert sha(helper)==review['helper_sha256']
native_delta=subprocess.run(['git','diff','--exit-code','4c703b3d604c6c877d6a2214d7aee0b15a013f61','--',
                             'src','include','adapters','cmake','CMakeLists.txt',
                             ':(glob)tools/*.c','tools/native'],capture_output=True,text=True)
assert native_delta.returncode==0 and not native_delta.stdout
source_names=('tools/strix-point-steering-build-gate.py','tests/test_strix_point_steering_build.py',
              'tests/steering_build_executor.c','tests/test_steering_build.c','tools/steering-build.c',
              'src/steering_capture.c','src/steering_direction.c','include/lie/activation_observer.h',
              'include/lie/steering_capture.h','include/lie/steering_direction.h',
              'tests/fixtures/steering-build-receipts.json','tools/thermal-run.py',
              'tools/strix-point-campaign.py','tests/test_strix_point_campaign.py','CMakeLists.txt','LICENSE')
paths.extend(root/name for name in source_names)
paths.extend((review_path,root/'evidence/verify-steering-streamed-original-r1.py',Path(__file__).resolve()))
references=[]
for name in ('steering-build-original-point-2026-10-08','steering-build-tail16-point-2026-10-08'):
    path=public.parent/(name+'.json');receipt=read(path)
    payload=root/receipt['raw']['path']
    assert sha(payload)==receipt['raw']['sha256']
    paths.append(path)
    references.append({'path':str(path.relative_to(root)),'sha256':sha(path),
                       'existing_archive':receipt['raw']['path'],'archive_sha256':sha(payload),
                       'payload_not_duplicated':True})
paths=sorted(set(paths))
members={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths}
with tarfile.open(archive,'x:gz') as tar:
    for path in paths:
        assert path.is_file() and path.resolve()==path
        tar.add(path,arcname=str(path.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    found=tar.getmembers();assert len(found)==len(members)
    for entry in found:
        assert entry.isfile() and entry.name in members
        data=tar.extractfile(entry).read();expected=members[entry.name]
        assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
fixtures={}
for mode,build in (('debug','context-debug'),('asan','tool-http-asan')):
    path=root/'build'/build/'test-steering-build'
    fixtures[mode]={'path':str(path.relative_to(root)),'bytes':path.stat().st_size,
                    'sha256':sha(path),'classification':'SYNTHETIC_C17_NOT_INFERENCE'}
receipt={'schema':'synapse-lie.steering-scaled-review-host.v1',
         'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'state':'HOST_BOUNDED_STREAMED_REVIEW_VERIFIED_NOT_INFERENCE',
         'source_checkpoint_before_change':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
         'bounds':{'max_pairs':128,'max_output_bytes':512*2**20,'context_max':8192,
                   'raw_hash_and_pread_max_block_bytes':2**20,
                   'native_host_limit_excludes_development_reviewer':True},
         'tests':{'debug':21,'unsuppressed_native_asan_ubsan_lsan':21,
                  'campaign_regression':89,'focused_native_ctest_per_mode':1,
                  'analytic_native_cli_children_per_mode':4,
                  'hundred_pair_native_fixture_per_mode':{'pairs':100,'rows':800,'layers':2,'width':2,'ffn_branches':2}},
         'verified_refusals':['raw replacement after hashing','raw truncation after hashing',
                              'descriptor release on refusal','existing finite/completion/forged-bank and input checks'],
         'frozen_original_reconstruction':review,
         'all_native_product_sources_byte_unchanged_at_4c703b3d':True,
         'runtime_rebuild_or_new_GPU_execution':False,
         'learned_response_quality_or_matched_performance_qualified':False,
         'native_python_dependency_added':False,'fixture_bindings':fixtures,
         'actual_guard_results':guards,'existing_payload_references':references,
         'raw':{'path':str(archive.relative_to(root)),'bytes':archive.stat().st_size,
                 'sha256':sha(archive),'regular_members':len(members),'members':members},
         'roadmap':{'open_items':[2,3,4,5,6,7],'terminal_bench_last':True,'full_goal_complete':False}}
with public.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps({'state':receipt['state'],'regular_members':len(members),
                  'raw_bytes':archive.stat().st_size,'actual_exit_code':0,'GPU_repeat':False}))
