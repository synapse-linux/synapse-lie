# SPDX-License-Identifier: MIT
"""Check the streamed oracle against both already qualified original cohorts."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json

root = Path.cwd().resolve()
spec = importlib.util.spec_from_file_location('streamed', root/'tools/strix-point-steering-build-gate.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
results = []
for label in ('steering-build-original-pairs-point-20261007-r1',
              'steering-build-multichunk-tail-point-20261008-r1'):
    job_root = root/'evidence'/label
    manifest = json.loads((job_root/'manifest.json').read_text())
    job = json.loads((job_root/'result.json').read_text())
    assert job['exit_code'] == job['child_exit_code'] == 0
    settings = gate.validate_settings(manifest['steering_build'])
    sources, pairs = gate.input_pair(job_root, settings['max_pairs'])
    assert sources == manifest['steering_build_inputs']
    reviewed = gate.validate(job_root/'steering-build', settings, sources, pairs,
                            job['child_exit_code'], manifest['runtime_build_id'],
                            manifest['runtime_source_pin'], job['steering_build_command'][2])
    saved = json.loads((job_root/'steering-build-review.json').read_text())
    assert reviewed == saved == job['steering_build_result']
    results.append({'label':label,'captured_rows':reviewed['captured_rows'],
                    'exactly_matches_qualified_independent_review':True,
                    'one_token_tails':sum(p['one_token_tail'] for p in reviewed['prompts'])})
record = {'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'state':'STREAMED_ORACLE_MATCHES_BOTH_FROZEN_ORIGINAL_REVIEWS',
          'actual_exit_code':0, 'cohorts':results,
          'helper_sha256':hashlib.sha256((root/'tools/strix-point-steering-build-gate.py').read_bytes()).hexdigest(),
          'new_GPU_execution_or_model_hash':False, 'learned_response_quality_qualified':False}
with (root/'evidence/steering-build-streamed-original-review-r1.json').open('x') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record))
