#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Seal already-finished local supervisor checks; never run tests or remote work."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

OUT=Path('docs/development/validation/sampling-capture-supervisor-host-2026-10-07.json')
RAW=Path('docs/development/validation/raw/sampling-capture-supervisor-host-2026-10-07.tar.gz')
assert not OUT.exists() and not RAW.exists()
def read(p):return json.loads(Path(p).read_text())
def bound(p):
    p=Path(p);assert p.is_file() and not p.is_symlink()
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
host_path=Path('docs/development/validation/sampling-tools-host-2026-10-07.json')
build_path=Path('docs/development/validation/integrated-point-capture-hip-build-2026-10-07.json')
host=read(host_path);build=read(build_path)
unchanged={name:bound(name) for name in host['source_files']}
assert unchanged==host['source_files'] and len(unchanged)==12
assert build['source_commit']=='df0780dd7601421f7097315702275c2349e7ed20'
assert build['native_capture_C17_primary_provider_link_verified']
assert build['state']=='BUILT_NOT_GPU_TESTED_COLLECTED_VERIFIED_CLOSED'
native_delta=subprocess.run(['git','diff','--name-only',build['source_commit'],'--',
    'CMakeLists.txt','src','include','adapters','cmake','tools/sampling-capture.c',
    'tools/sampling-capture-format.h','tests/sampling','tests/sampling_capture'],
    capture_output=True,text=True,check=True)
assert not native_delta.stdout.strip()
folders=[Path('evidence/sampling-capture-supervisor-r81-'+name) for name in
         ('controls-r1','controls-r2','regressions')]
commands={};peaks={}
for folder,count in zip(folders,(14,15,7),strict=True):
    result=read(folder/'result.json')
    assert result['exit_code']==result['child_exit_code']==0 and result['reason'] is None
    assert f'Ran {count} tests' in (folder/'command.log').read_text()
    commands[str(folder)]={**result,'focused_control_count':count,'scope':'CPU-only mocked transport/metadata; no model or GPU'}
    for path,value in result['peak_c'].items():peaks[path]=max(peaks.get(path,0),value)
sources=['tools/strix-point-campaign.py','tools/strix-point-bench-collect.py',
         'tests/test_sampling_capture_campaign.py']
members={}
for folder in folders:
    for path in sorted(folder.iterdir()):
        members[str(path)]=bound(path)
for path in sources+[str(host_path),str(build_path),'evidence/seal-sampling-capture-supervisor-r81.py']:
    members[path]=bound(path)
inventory=(json.dumps(members,indent=2)+'\n').encode()
with RAW.open('xb') as file:
    with gzip.GzipFile(fileobj=file,mode='wb',mtime=0,compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,item in sorted(members.items()):
                assert bound(name)==item
                header=tarfile.TarInfo(name);header.mode=0o644;header.size=item['bytes']
                archive.addfile(header,io.BytesIO(Path(name).read_bytes()))
            header=tarfile.TarInfo('raw-inventory.json');header.mode=0o644;header.size=len(inventory)
            archive.addfile(header,io.BytesIO(inventory))
receipt={'schema':'synapse-lie.sampling-capture-supervisor-host.v1',
    'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state':'LOCAL_SUPERVISOR_PREPARATION_CHECKED_NOT_GPU_QUALIFIED',
    'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'scope':'Optional .161 orchestration, native capture structure and partial artifact collection only',
    'source_files':{name:bound(name) for name in sources},'commands_actual_exits':commands,
    'focused_capture_controls':15,'focused_existing_regressions':7,
    'earlier_14_control_pass_preserved':True,'preserved_failures':[],
    'maximum_observed_local_CPU_C':peaks['/sys/class/hwmon/hwmon8/temp1_input'],
    'sensor_peaks_C':peaks,'thermal_policy':'CPU98/NVMe85/lower; GPU masked/observe only',
    'refusal_coverage':['synthetic/stale/wrong-mode/typed identity','incomplete/unordered/duplicate/extra completion',
        'row hash/length/path/token/frontier','generation/prompt/vocabulary/constraint drift',
        'provisional call/incomplete EOS/claimed live EOS ID','invalid required-call arguments',
        'duplicate JSON keys/nonfinite numbers/boolean token IDs','FIFO/symlink/oversize',
        'collector unknown paths and existing local hash drift'],
    'failure_data':'Collect bounded empty/partial artifacts and raw rows written before unsuccessful decode',
    'model_stat_failure_cleanup_checked':True,'possible_model_attempt_marker_checked':True,
    'native_source_files_unchanged':unchanged,'unchanged_native_source_git_diff_actual_exit':native_delta.returncode,
    'native_sanitizer_qualification':bound(host_path),'matching_HIP_build':bound(build_path),
    'executor_core_ABI_HTTP_reactive_numerical_code_changed':False,
    'new_native_C_CXX_change_or_build':False,
    'sanitizer_repeat':'Not repeated: optional Python-only orchestration; all 12 previously qualified native sources are unchanged',
    'new_GPU_remote_model_build_test_lease_reservation':False,'product_default_tests_require_Python':False,
    'structural_receipt_closes_probability_mask_MTP_quality_performance_gates':False,
    'root_live_handles':[],'root_remote_jobs_leases_reservations':[],
    'open_root_items':[2,3,4,5,6,7],'Terminal_Bench':'DEFERRED_LAST',
    'next_phase':'Final integrated original-weight qualification after functional preparation; fresh peer/global/original-lease admission required',
    'publication':False,'goal_complete':False,'archive':{**bound(RAW),'members':len(members)+1},
    'archive_inventory':members}
with OUT.open('x') as file:json.dump(receipt,file,indent=2);file.write('\n')
print(json.dumps({'receipt':str(OUT),'receipt_sha256':bound(OUT)['sha256'],'archive_sha256':bound(RAW)['sha256'],
    'archive_members':len(members)+1,'focused_checks':'15 capture + 7 existing mocked checks','CPU_peak_C':receipt['maximum_observed_local_CPU_C']}))
