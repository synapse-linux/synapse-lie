# SPDX-License-Identifier: MIT
"""Fresh read-only Point ownership/lease/resource observation; no admission."""
from pathlib import Path
import hashlib, json, subprocess

runner = subprocess.run(['git','show','2077700583a7a129d17b36dbf7aa2ffbbdd7c994:tools/strix-point-campaign.py'],capture_output=True,check=True).stdout
expected = hashlib.sha256(runner).hexdigest()
program = 'EXPECTED_BUNDLE='+repr(expect)+'\nEXPECTED_BUNDLE_SHA='+repr(sha)+'\nEXPECTED_RUNNER=' + repr(expected) + '\n' + '''
from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,stat,subprocess
base=Path('/home/pop/workspace/synapse-lie')
assert os.getuid()==1000 and base.resolve()==base and base.stat().st_uid==os.getuid()
runner=base/'context-r16-build-r1'/'runner.py'
assert not runner.is_symlink() and runner.stat().st_uid==os.getuid()
with runner.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
assert actual==EXPECTED_RUNNER
spec=importlib.util.spec_from_file_location('point_readonly',runner)
point=importlib.util.module_from_spec(spec);spec.loader.exec_module(point)
row=point.observe(98,gpu_observation_only=True)
service_run=subprocess.run(['systemctl','--user','show','llama-router.service',
                           '--property=ActiveState,SubState,MainPID'],capture_output=True,text=True,timeout=15)
assert service_run.returncode==0
service=dict(line.split('=',1) for line in service_run.stdout.splitlines())
pid=int(service['MainPID']);main_ticks=point.ticks(pid) if pid else None
path=base/'campaign.lock';fd=os.open(path,os.O_RDWR|os.O_NOFOLLOW|os.O_CLOEXEC)
free=False
try:
 st=os.fstat(fd);live=path.stat()
 assert stat.S_ISREG(st.st_mode) and st.st_uid==os.getuid()
 assert (st.st_dev,st.st_ino)==(live.st_dev,live.st_ino)==(66307,105946405)
 try:
  fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);free=True
 except BlockingIOError:pass
finally:
 if free:fcntl.flock(fd,fcntl.LOCK_UN)
 os.close(fd)
image_run=subprocess.run(['docker','image','inspect',
 'sha256:89c6f9da64694da226948bca7b50d5e4e38caab9e138cb5cbe8678b7778cbe7e',
 '--format','{{.Id}}'],capture_output=True,text=True,timeout=15)
image={'exit_code':image_run.returncode,'id':image_run.stdout.strip(),'stderr':image_run.stderr}
dest=base/'rocm10-fedora-161'
assert dest.resolve()==dest and dest.stat().st_uid==os.getuid()
disk=os.statvfs(dest)
listeners=[]
for tcp in ('/proc/net/tcp','/proc/net/tcp6'):
 for line in Path(tcp).read_text().splitlines()[1:]:
  fields=line.split()
  if fields[3]=='0A' and int(fields[1].rsplit(':',1)[1],16)==8000:
   listeners.append({'table':tcp,'local_address':fields[1],'uid':int(fields[7]),'inode':int(fields[9])})
kernel=set(row['kernel_kfd']);clients=kernel|{p['pid'] for p in row['kfd']}
foreign=sorted(clients-({pid} if service['ActiveState']=='active' else set()))
guarded_hot=[t for t in row['temperatures'] if t['guarded'] and t['value_c']>=t['limit_c']]
r={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'READ_ONLY_NOT_ADMITTED','boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
 'runner_sha256':actual,'service':service,'router_start_ticks':main_ticks,
 'original_lease':{'path':str(path),'device':st.st_dev,'inode':st.st_ino,'free_briefly':free,'released':True},
 'observation':row,'foreign_compute_clients':foreign,'guarded_hot':guarded_hot,
 'http8000_listeners':listeners,'pinned_image':image,
 'free_disk_bytes':disk.f_bavail*disk.f_frsize,
 'exclusive_campaign_destination_absent':not (base/'context-r44-attention-r1').exists(),
 'bundle_present':(dest/'bundle-modern-r43/BUNDLE.json').is_file(),
 'sealed_source_present':(dest/'source-modern-r43/SOURCE-FILES.sha256').is_file() and (dest/'source-modern-r43.tar.gz').is_file(),
 'GPU_build_run_or_service_mutation':False,'standing_lease_waiter_reservation':False}
bundle=dest/'bundle-modern-r43';meta=bundle/'BUNDLE.json'
assert not meta.is_symlink() and meta.stat().st_uid==os.getuid()
assert hashlib.sha256(meta.read_bytes()).hexdigest()==EXPECTED_BUNDLE_SHA
assert json.loads(meta.read_text())==EXPECTED_BUNDLE
artifacts={}
for name,digest in EXPECTED_BUNDLE['artifacts'].items():
 p=bundle/name;assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(bundle) and p.stat().st_uid==os.getuid()
 with p.open('rb') as stream:actual=hashlib.file_digest(stream,'sha256').hexdigest()
 assert actual==digest,name
 artifacts[name]={'bytes':p.stat().st_size,'sha256':actual}
r['verified_bundle_artifacts']=artifacts;r['verified_bundle_sha256']=EXPECTED_BUNDLE_SHA
valid=free and not foreign and not listeners and not guarded_hot and r['exclusive_campaign_destination_absent'] and r['bundle_present']
valid=valid and image_run.returncode==0 and image['id']==EXPECTED_BUNDLE['image']
r['suitable_for_separate_in_lease_admission']=valid
print(json.dumps(r))
assert valid
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8','pop@192.168.5.161','python3 -B -']
run=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':run.returncode,
        'program_sha256':hashlib.sha256(program.encode()).hexdigest(),
        'stdout':run.stdout,'stderr':run.stderr}
try:record['result']=json.loads(run.stdout)
except ValueError:pass
out=Path('evidence/context-r44-fresh-161-r1.json')
with out.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
if 'result' in record:
    r=record['result']
    print(json.dumps({k:r[k] for k in ('state','at_utc','boot_id','service','original_lease',
        'foreign_compute_clients','guarded_hot','http8000_listeners','pinned_image',
        'free_disk_bytes','exclusive_campaign_destination_absent','bundle_present','sealed_source_present')}))
else:print(json.dumps(record))
raise SystemExit(run.returncode)
