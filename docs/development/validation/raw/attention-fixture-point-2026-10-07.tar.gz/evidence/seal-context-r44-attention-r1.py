# SPDX-License-Identifier: MIT
"""Archive verified generated component evidence, without remote/test work."""
from pathlib import Path
import datetime, gzip, hashlib, io, json, tarfile

base=Path('evidence/context-r44-attention-r1')
out=Path('docs/development/validation/attention-fixture-point-2026-10-07.json')
archive=Path('docs/development/validation/raw/attention-fixture-point-2026-10-07.tar.gz')
assert not out.exists() and not archive.exists()
def read(p): return json.loads(Path(p).read_text())
def bound(p):
    p=Path(p);assert p.is_file() and not p.is_symlink()
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
job=read(base/'result.json'); controller=read(base/'controller-result.json')
verification=read(base/'offline-verification-r1/result.json')
closure=read('evidence/context-r44-attention-closure-r1.json')
build_path=Path('docs/development/validation/integrated-point-attention-hip-build-2026-10-07.json')
build=read(build_path); host_path=Path('docs/development/validation/attention-fixture-host-2026-10-07.json')
assert job['state']=='PASSED' and job['exit_code']==job['child_exit_code']==controller['exit_code']==0
assert not job['model_attempted'] and not job['cleanup_failures'] and job['lease_released_at']
assert verification['exit_code']==0 and verification['collected_files_verified']==73
assert verification['cases']==13 and verification['compared_values']==270336
assert verification['compiled_receipt_sha256']==bound(build_path)['sha256']
assert verification['source_commit']==build['source_commit']
assert closure['actual_exit_code']==0 and closure['result']['owned_supervisor_identity_absent']
assert closure['result']['owned_container_init_identity_absent'] and closure['result']['original_lease']['released']
assert not closure['result']['standing_lease_waiter_reservation']
cases=[json.loads(line) for line in (base/'attention/attention.jsonl').read_text().splitlines()][1:-1]
assert all(c['gpu_execution'] and c['exact'] and c['passed'] and not c['primary_error'] and not c['cleanup_error'] for c in cases)
rows=[json.loads(line) for line in (base/'telemetry.jsonl').read_text().splitlines()]
peaks={}
for row in rows:
    for sensor in row['temperatures']:
        peaks[sensor['name']]=max(peaks.get(sensor['name'],-100),sensor['value_c'])
        if sensor['guarded']: assert sensor['value_c']<sensor['limit_c']
members={}
def capture(p):
    item=bound(p);assert item['path'] not in members;members[item['path']]=item
for folder in (base,Path('evidence/context-r44-offline-review-r1')):
    for p in sorted(folder.rglob('*')):
        if p.is_file(): capture(p)
for name in ('context-r44-attention-manifest.json','context-r44-peer-coordination.json',
             'context-r44-fresh-161-r1.py','context-r44-fresh-161-r1-preparation-failure.json',
             'context-r44-fresh-161-r2.py','context-r44-fresh-161-r2.json',
             'context-r44-attention-closure-r1.py','context-r44-attention-closure-r1.json',
             'verify-context-r44-attention-r1.py','seal-context-r44-attention-r1.py'):
    capture(Path('evidence')/name)
for path in (build_path,host_path,Path('CMakeLists.txt'),Path('cmake/point/Build.cmake'),
             Path('tools/qualification/attention.h'),Path('tools/qualification/attention_main.c'),
             Path('tools/qualification/attention_plan.c'),Path('adapters/attention_fixture.hip'),
             Path('adapters/gufo-state/attention-dispatch-edits.json'),Path('src/dispatch.c'),
             Path('include/lie/dispatch.h'),Path('tools/strix-point-launch.py'),
             Path('tools/strix-point-bench-collect.py')):
    capture(path)
inventory=(json.dumps(members,indent=2)+'\n').encode()
with archive.open('xb') as stream:
    with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,compresslevel=3) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name,item in sorted(members.items()):
                assert bound(name)==item
                info=tarfile.TarInfo(name);info.mode=0o644;info.size=item['bytes']
                with Path(name).open('rb') as f: tar.addfile(info,f)
            info=tarfile.TarInfo('raw-inventory.json');info.mode=0o644;info.size=len(inventory)
            tar.addfile(info,io.BytesIO(inventory))
receipt={
    'schema':'synapse-lie.attention-component-point-qualification.v1',
    'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state':verification['state'],
    'scope':'Generated sparse-attention component only, original pinned short kernel versus current long specialization; no weights, indexer selection/scoring, HTTP, model quality, performance or GPU fault acceptance.',
    'source_commit':build['source_commit'],'native_client_source_commit':build['native_attention_source_commit'],
    'numerical_provider_source_commit':build['numerical_provider_source_commit'],
    'compiled_runtime':bound(build_path),'host_qualification':bound(host_path),
    'runtime_build_id':'rocm10-point-modern-r43-runtime','long_context_wmma':True,
    'attention_binary_sha256':verification['attention_binary_sha256'],
    'image':build['image'],'architecture':'gfx1150','host':'192.168.5.161',
    'GPU_execution':True,'host_fixture':False,'model_inference':False,
    'cases':13,'maximum_visible_tokens':1048576,'full_output_values_compared':270336,
    'complete_finite_outputs_bitwise_identical':True,'complete_masks_and_key_order_verified':True,
    'uniform_oracle_predeclared_max_abs_error':1e-6,
    'uniform_oracle_saved_values_reviewed':verification['uniform_oracle_values'],
    'uniform_oracle_exact_max_abs_error':verification['uniform_oracle_exact_max_abs_error'],
    'offline_review':verification,
    'cases_geometry':[{k:c[k] for k in ('index','end','rows','selections','zero_mask','zero_query','deep_pitch','short_pitch','requested_device_bytes','uniform_max_abs_error')} for c in cases],
    'maximum_requested_component_device_bytes':max(c['requested_device_bytes'] for c in cases),
    'maximum_sampled_system_GTT_used_bytes':max(r['gpu']['mem_info_gtt_used'] or 0 for r in rows),
    'resource_scope':'Requested component allocations and sampled system GTT; samples may miss actual peak. Not original-weight memory fit or serving-resource acceptance.',
    'maximum_observed_CPU_C':peaks['k10temp'],'maximum_observed_GPU_C_observe_only':peaks['amdgpu'],
    'maximum_observed_NVMe_C':peaks['nvme'],'telemetry_samples':len(rows),
    'thermal_policy':'CPU98/NVMe85/lower limits; GPU observed only; no tuning',
    'supervisor_exit_code':job['exit_code'],'container_child_exit_code':job['child_exit_code'],
    'controller_exit_code':controller['exit_code'],'collection_exit_code':read(base/'collection.json')['exit_code'],
    'collected_files_verified':73,'raw_attention_artifacts':66,
    'supervisor_identity':{'pid':job['pid'],'start_ticks':job['start_ticks']},
    'container_init_identity':{'pid':job['container_host_pid'],'start_ticks':job['container_start_ticks']},
    'container':job['container'],'lease':job['lease'],'lease_released_at_utc':job['lease_released_at'],
    'strict_fresh_closure':closure['result'],'current_root_remote_job_lease_window_waiter_reservation_handle':False,
    'preserved_local_observer_failure':{'actual_exit_code':1,'error':'NameError before SSH; corrected read-only observer r2 exits0','remote_process_created':False},
    'original_weight_acceptance':False,'indexer_acceptance':False,'performance_acceptance':False,
    'GPU_fault_acceptance':False,'disabled_long_workspace_GPU_control':False,
    'public_ABI_state_reactive_scheduler_changes':False,'new_model_hash_conversion_installation':False,
    'native_product_default_tests_require_Python':False,'repeated_GPU_run':False,
    'open_task_numbers':[2,3,4,5,6,7],'all_six_acceptance_items_remain_open':True,
    'next_gate':'Original-weight numerical/quality/fault/resource qualification; matched benchmark campaigns afterward; Terminal Bench last. Indexer changes need their own numerical and measured gates.',
    'publication':False,'goal_complete':False,
    'portable_raw_archive':{**bound(archive),'members':len(members)+1},'raw_artifacts':members}
with out.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'receipt':str(out),'archive':bound(archive),'archive_members':len(members)+1,
                  'cases':13,'compared_values':270336,'GPU_repeated':False,'model_inference':False}))
