# SPDX-License-Identifier: MIT
"""Review collected generated GPU outputs; no remote call or inference."""
from pathlib import Path
from fractions import Fraction
import datetime, hashlib, importlib.util, json, math, os, struct

root = Path('evidence/context-r44-attention-r1').resolve()
out = root / 'offline-verification-r1'
out.mkdir(exist_ok=False)
record = {'scope':'Collected generated component only; no model forward or repeat GPU run',
          'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'exit_code':1, 'remote_call':False, 'new_GPU_run':False}
target = out / 'result.json'
def save(): target.write_text(json.dumps(record,indent=2)+'\n')
def load(path): return json.loads(Path(path).read_text())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
save()
job=load(root/'result.json'); controller=load(root/'controller-result.json')
collection=load(root/'collection.json'); closure=load('evidence/context-r44-attention-closure-r1.json')
build=load('docs/development/validation/integrated-point-attention-hip-build-2026-10-07.json')
assert job['state']=='PASSED' and job['exit_code']==job['child_exit_code']==controller['exit_code']==0
assert not job['model_attempted'] and not job['cleanup_failures']
assert collection['exit_code']==0 and all(c['exit_code']==0 for c in collection['commands'])
files=collection['inventory']['files']; assert len(files)==73
for name,identity in files.items():
    p=root/name; assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(root)
    assert p.stat().st_size==identity['bytes'] and sha(p)==identity['sha256'],name
assert closure['actual_exit_code']==0
closed=closure['result']
assert closed['owned_supervisor_identity_absent'] and closed['owned_container_init_identity_absent']
assert closed['original_lease']['free_briefly'] and closed['original_lease']['released']
assert not closed['foreign_compute_clients'] and not closed['http8000_listeners'] and not closed['guarded_hot']
assert closed['service']['ActiveState']=='active' and job['lease_released_at']
assert (job['lease']['device'],job['lease']['inode'])==(66307,105946405)
manifest=load(root/'manifest.json')
assert manifest['artifacts']==build['bundle']['metadata']['artifacts']
assert manifest['source_commit']==build['source_commit']
assert all(k not in manifest for k in ('model_plan','predictor_plan','projector_plan'))
assert sha(root/'runner.py')==sha('tools/strix-point-campaign.py')==job['runner_sha256']
spec=importlib.util.spec_from_file_location('saved_component_verifier',root/'runner.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
# Only rebind the private filesystem root for an offline review. All bounded
# regular-file, uid, geometry, finite-output, mask and byte-equality checks stay.
module.BASE=root.parent
full=module.validate_attention_fixture(root,'rocm10-point-modern-r43-runtime',True)
assert full==job['attention_result']==load(root/'attention-artifacts.json')
assert full['cases']==13 and full['compared_values']==270336 and full['expected_refusals']==0
records=[json.loads(line) for line in (root/'attention/attention.jsonl').read_text().splitlines()]

# Independent rational uniform-softmax oracle from saved block positions and
# masks, not the C fixture's reported error. This is scalar generated data only.
maximum=Fraction(0); oracle_values=0; witness=[]
for case in records[1:-1]:
    if not case['zero_query']: continue
    n=case['index']; prefix=f'attention/case-{n:02d}.'
    blocks=[x[0] for x in struct.iter_unpack('<I',(root/(prefix+'blocks.u32')).read_bytes())]
    modes=[('deep',case['deep_start'],case['deep_pitch'],blocks),
           ('short',case['short_start'],case['short_pitch'],
            [case['short_base']+i for i in range(len(blocks))])]
    for mode,start,pitch,positions in modes:
        mask=[x[0] for x in struct.iter_unpack('<I',(root/(prefix+mode+'-mask.u32')).read_bytes())]
        output=[x[0] for x in struct.iter_unpack('<f',(root/(prefix+mode+'.f32')).read_bytes())]
        for row in range(case['rows']):
            query=start+row; keys=[]
            for rank,block in enumerate(positions):
                selected=bool(mask[row*pitch+block//32] & (1<<(block%32)))
                if not selected and block<(query+1)//4: continue
                keys.extend(rank*4+t for t in range(4) if block*4+t<=query)
            assert keys
            numerator=sum((key%31)-15 for key in keys)
            base=Fraction(numerator,16*len(keys))
            row_max=Fraction(0)
            for head in range(24):
                for dim in range(256):
                    expected=(base+Fraction((head//12)*3+dim%11,32))/2
                    actual=output[row*6144+head*256+dim]
                    assert math.isfinite(actual)
                    error=abs(Fraction.from_float(actual)-expected)
                    assert error<=Fraction(1,10**6)
                    row_max=max(row_max,error); oracle_values+=1
            maximum=max(maximum,row_max)
            witness.append({'case':n,'mode':mode,'row':row,'selected_causal_values':len(keys),
                            'base_exact':str(base),'max_error_exact':str(row_max)})
record.update(exit_code=0,state='GENERATED_COMPONENT_GPU_PARITY_COLLECTED_VERIFIED_CLOSED',
              collected_files_verified=73,raw_attention_artifacts=66,cases=13,
              compared_values=270336,uniform_oracle_values=oracle_values,
              uniform_oracle_exact_max_abs_error=str(maximum),
              uniform_oracle_max_abs_error=float(maximum),predeclared_uniform_limit=1e-6,
              uniform_witness=witness,source_commit=build['source_commit'],
              compiled_receipt_sha256=sha('docs/development/validation/integrated-point-attention-hip-build-2026-10-07.json'),
              attention_binary_sha256=manifest['artifacts']['runtime/bin/lie-attention-qualify'],
              full_outputs_bitwise_equal=True,all_masks_and_ordered_positions_verified=True,
              long_context_wmma=True,model_inference=False,indexer_qualification=False,
              performance_acceptance=False,GPU_fault_acceptance=False,
              final_closure_at_utc=closed['at_utc'])
save()
print(json.dumps({k:record[k] for k in ('state','exit_code','collected_files_verified','cases',
      'compared_values','uniform_oracle_values','uniform_oracle_max_abs_error','model_inference')}))
