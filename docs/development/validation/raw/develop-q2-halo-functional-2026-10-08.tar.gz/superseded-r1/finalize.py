# SPDX-License-Identifier: MIT
from pathlib import Path
import ast,hashlib,json
here=Path(__file__).resolve().parent;root=here.parents[1];old=root/'evidence/halo-r70-functional-20261008-r2'
plan=json.loads((here/'draft-manifest.json').read_text());discovery=json.loads((here/'discovery-r1.json').read_text())
assert discovery['boot_id']==plan['boot_id'] and discovery['filesystem_uuid']==plan['filesystem_uuid']
assert discovery['registry_last_event']['receipt_sha256']==plan['previous_release_sha256'] and not discovery['kfd_clients']
plan['previous_registry_event']=discovery['registry_last_event'];del plan['previous_registry_event_pending_authoritative_timestamp']
(here/'manifest.json').open('x').write(json.dumps(plan,indent=2)+'\n')
digest=hashlib.sha256((here/'manifest.json').read_bytes()).hexdigest()
s=(old/'control.py').read_text();previous='5be814797c2b21ee4e3de80e1026432570b08db344090da523a531498d987dfa';assert s.count(previous)==1
s=s.replace(previous,digest).replace("for name in ('window.py','q2_process.py','manifest.json'):","for name in ('window.py','q2_process.py','promessi_sposi.txt','manifest.json'):")
(here/'control.py').open('x').write(s)
s=(old/'review.py').read_text().replace('CURRENT_R70','CURRENT_DEVELOP_Q2').replace("len(native['commands'])==7","len(native['commands'])==14")
needle="result={'state':"
assert s.count(needle)==1
extra='''walk_quality={};walk_data={};phase_records={}
for name,restore in [('q2-walk-auto','snapshot'),('q2-walk-replay','replay'),('q2-walk-reference','replay'),('ud-walk-auto','snapshot'),('ud-walk-reference','replay')]:
    rr=rows(name+'.jsonl');identity=one(rr,'identity');corpus=one(rr,'corpus')
    assert not identity['synthetic'] and identity['measurement_contract']=='ds4-walk-v1'
    assert corpus['source_text_sha256']=='f53e0d80cb2d4492d24ebd63c7000c397b16ae70f9bf09b3763e5d8323ec209f'
    assert corpus['prompt_tokens']==8192 and len(corpus['physical_ids'])==8192
    assert one(rr,'complete')['exit_code']==0
    samples=[r for r in rr if r.get('event')=='sample'];restores=[r for r in rr if r.get('event')=='walk_restore']
    assert len(samples)==4 and len(restores)==3
    for point,row in enumerate(samples):
        assert row['point']==point and row['depth']==point*2048 and row['prompt_tokens_per_user']==(point+1)*2048
        assert row['prefill_tokens_per_user']==2048 and 0<len(row['output_ids'])<=128
        assert row['output_tokens_per_user']==len(row['output_ids']) and row['full_output_budget']==(len(row['output_ids'])==128)
        ppb,ppe=row['prefill_begin_monotonic_ns'],row['prefill_end_monotonic_ns']
        tgb,tge=row['decode_begin_monotonic_ns'],row['decode_end_monotonic_ns']
        assert 0<ppb<ppe<=tgb<tge and row['prefill_ns']==ppe-ppb and row['decode_ns']==tge-tgb
        if point<3:
            assert row['checkpoint_method']==restore
            if restore=='snapshot':
                assert 0<row['checkpoint_bytes']<=1073741824
                assert ppe<=row['checkpoint_begin_monotonic_ns']<row['checkpoint_end_monotonic_ns']<=tgb
        else:assert row['checkpoint_method']=='none'
    for point,row in enumerate(restores,1):
        assert row['point']==point and row['tokens']==point*2048 and row['method']==restore
        assert row['prefill_logits_sha256']==samples[point-1]['prefill_logits_sha256']
        assert samples[point-1]['decode_end_monotonic_ns']<=row['begin_monotonic_ns']<row['end_monotonic_ns']<=samples[point]['prefill_begin_monotonic_ns']
        assert row['elapsed_ns']==row['end_monotonic_ns']-row['begin_monotonic_ns']
    walk_data[name]=(corpus,samples)
    phase_records[name]={'restore_methods':[r['method'] for r in restores],'checkpoint_bytes':[r['checkpoint_bytes'] for r in samples],'output_counts':[len(r['output_ids']) for r in samples]}
for left,right in [('q2-walk-auto','q2-walk-replay'),('q2-walk-auto','q2-walk-reference'),('ud-walk-auto','ud-walk-reference')]:
    ca,sa=walk_data[left];cb,sb=walk_data[right]
    walk_quality[left+'_'+right+'_inputs_equal']=ca['physical_ids']==cb['physical_ids']
    for point,(a,b) in enumerate(zip(sa,sb)):
        walk_quality[left+'_'+right+'_point'+str(point)+'_equal']=all(a[k]==b[k] for k in ('prefill_logits_sha256','decode_logits_sha256','output_ids','output_tokens_per_user'))
mtp=rows('core-mtp.jsonl');mj=[r for r in mtp if r.get('event')=='job'];ms=one(mtp,'sample')
assert one(mtp,'identity')['mode']=='mtp' and one(mtp,'complete')['exit_code']==0 and len(mj)==1
assert mj[0]['mtp_drafted_tokens']>0 and mj[0]['mtp_accepted_tokens']>0
quality['greedy_mtp_equals_ar']=mj[0]['output_ids']==pp['output_ids']
q2c=rows('q2-core-c2.jsonl');qj=[r for r in q2c if r.get('event')=='job'];qs=one(q2c,'sample')
assert one(q2c,'complete')['exit_code']==0 and len(qj)==2 and qs['decode_batches']>0 and qs['decode_batch_rows']>=2*qs['decode_batches']
assert one(q2c,'input')['physical_ids']==walk_data['q2-walk-auto'][0]['physical_ids']
quality['q2_c2_equals_walk_c1']=all(j['output_ids']==walk_data['q2-walk-auto'][1][-1]['output_ids'] for j in qj)
quality.update(walk_quality)
'''
s=s.replace(needle,extra+needle)
s=s.replace("'quality':quality,'actual_core':actual,","'quality':quality,'actual_core':actual,'walk_phases':phase_records,'mtp_drafted':mj[0]['mtp_drafted_tokens'],'mtp_accepted':mj[0]['mtp_accepted_tokens'],'q2_batch_calls':qs['decode_batches'],")
(here/'review.py').open('x').write(s)
for name in ('window.py','q2_process.py','control.py','review.py'):ast.parse((here/name).read_text(),filename=name)
record={'state':'EXACT_LOCAL_FUNCTIONAL_PROPOSAL_NOT_STAGED_OR_ADMITTED','manifest_sha256':digest,'commands':14,'source_commit':plan['source_commit'],'original_corpus_bytes':(here/'promessi_sposi.txt').stat().st_size,'no_GPU_model_build_lease_or_future_grant':True}
(here/'manifest-preparation.json').open('x').write(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
