# SPDX-License-Identifier: MIT
from pathlib import Path
import ast,hashlib,json,subprocess
here=Path(__file__).resolve().parent;root=here.parents[1]
old=root/'evidence/halo-r70-functional-20261008-r2'
built=root/'evidence/halo-develop-q2-build-20261008-r1'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='2dc999f6eb4aa13d851d6d4fc624a0e3ecb05170'
assert subprocess.run(['git','diff','--quiet','9e95e4c4','HEAD','--','CMakeLists.txt','Makefile','cmake','src','include','adapters','tools','tests','third_party','patches/gufo-q2.patch'],cwd=root).returncode==0
plan=json.loads((old/'manifest.json').read_text());strong=json.loads((built/'strong-closure.json').read_text());release=json.loads((built/'collected/release.json').read_text())
name=here.name;remote='/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run/'+name
buildremote='/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run/'+built.name
text=(old/'window.py').read_text().replace('current-r70','current-develop-Q2').replace('CURRENT_R70','CURRENT_DEVELOP_Q2')
needle="prior=read(Path(plan['previous_release_path']))\n        absent(prior['retired_identities'],set(prior['retired_groups']))"
replacement="prior=read(Path(plan['previous_strong_path']))\n        absent(prior['identities_checked'],set(prior['original_groups_checked']))"
assert text.count(needle)==1;text=text.replace(needle,replacement)
# Bind the already-compiled complete current source inventory, not a historical capsule.
needle="for row in plan['binaries'].values():"
replacement="""inventory=read(Path(plan['compiled_source_inventory_path']))
    assert sha(Path(plan['compiled_source_inventory_path']))==plan['compiled_source_inventory_sha256']
    for name,row in inventory.items():
        p=Path(plan['compiled_source_root'])/name
        assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
    for row in plan['binaries'].values():"""
assert text.count(needle)==1;text=text.replace(needle,replacement)
needle="if command['name']=='reference-direct':"
replacement="""if command['name']=='q2-core-c2':
                    corpus=[r for r in rows('q2-walk-auto.jsonl') if r.get('event')=='corpus']
                    assert len(corpus)==1 and len(corpus[0]['physical_ids'])==8192
                    save(HERE/'q2-tokens.json',corpus[0]['physical_ids'],True)
                if command['name']=='reference-direct':"""
assert text.count(needle)==1;text=text.replace(needle,replacement)
(here/'window.py').open('x').write(text)
(here/'q2_process.py').open('xb').write((root/'tools/q2_process.py').read_bytes())
corpus=root.parent/'antirez-compat-audit/evidence/q2-exact-bench128-r1/promessi_sposi.txt'
assert corpus.resolve()==corpus and corpus.is_file() and not corpus.is_symlink()
data=corpus.read_bytes();assert 0<len(data)<8*1024**2 and hashlib.sha256(data).hexdigest()=='f53e0d80cb2d4492d24ebd63c7000c397b16ae70f9bf09b3763e5d8323ec209f'
data.decode('utf-8');assert b'\x00' not in data
(here/'promessi_sposi.txt').open('xb').write(data)
commands=plan['commands']
for c in commands:
 c['argv']=[a.replace('/halo-r70-build-20261008-r1/source/build/halo-r70-linked-r1/','/'+built.name+'/source/build/halo-develop-q2-linked-r1/').replace('/halo-r70-functional-20261008-r2/','/'+name+'/') for a in c['argv']]
primary=strong['compiled_binary_checks']['synapse-lie-bench']['path'];ref=strong['compiled_binary_checks']['synapse-lie-bench-gufo-reference']['path']
q2=plan['models'][0]['path'];ud=plan['models'][1]['path'];predictor=plan['models'][5]['path']
for tag,model,binary,restore in [('q2-walk-auto',q2,primary,'auto'),('q2-walk-replay',q2,primary,'replay'),('q2-walk-reference',q2,ref,'replay'),('ud-walk-auto',ud,primary,'auto'),('ud-walk-reference',ud,ref,'replay')]:
 commands.append({'name':tag,'argv':[binary,'--suite','ds4-walk','--model',model,'--corpus',remote+'/promessi_sposi.txt','--pp','2048','--sizes','2048,4096,6144,8192','--context','133760','--rope-scaling','native','--prefill-chunk','2048','--tg','128','--warmups','0','--repetitions','1','--restore',restore,'--output',remote+'/'+tag+'.jsonl'],'timeout_seconds':600})
mtp=list(next(c['argv'] for c in commands if c['name']=='core-c1'))
mtp[mtp.index('--output')+1]=remote+'/core-mtp.jsonl';mtp+=['--model-mtp',predictor,'--mtp-draft-tokens','2']
commands.append({'name':'core-mtp','argv':mtp,'timeout_seconds':600})
commands.append({'name':'q2-core-c2','argv':[primary,'--suite','core','--model',q2,'--tokens-file',remote+'/q2-tokens.json','--context','133760','--prefill-chunk','2048','--users','2','--tg','128','--warmups','0','--repetitions','1','--kv-cache-ram-mb','0','--timeout-ms','540000','--output',remote+'/q2-core-c2.jsonl'],'timeout_seconds':600})
assert len(commands)==14
plan.update(label=name,source_commit='9e95e4c49e1aa71e71f50003760ac14d96a3232e',documentation_checkpoint='2dc999f6eb4aa13d851d6d4fc624a0e3ecb05170',
 source_qualified_from='f902ad45',binaries=strong['compiled_binary_checks'],
 compiled_source_root=buildremote+'/source',compiled_source_inventory_path=buildremote+'/source-inventory.json',compiled_source_inventory_sha256=hashlib.sha256((built/'source-inventory.json').read_bytes()).hexdigest(),
 previous_release_path=buildremote+'/release.json',previous_release_sha256=hashlib.sha256((built/'collected/release.json').read_bytes()).hexdigest(),
 previous_strong_path=buildremote+'/strong-closure.json',previous_strong_sha256=hashlib.sha256((built/'strong-closure.json').read_bytes()).hexdigest(),
 previous_registry_event={'event':'window_release','owner':'synapse-lie-root','label':built.name,'at':'2026-10-08T19:23:23.743726+00:00','boot_id':plan['boot_id'],'receipt':buildremote+'/release.json','receipt_sha256':hashlib.sha256((built/'collected/release.json').read_bytes()).hexdigest()},
 whole_window_seconds=3600,
 scope='One 14-command native gfx1151 functional window. HIP/13 generated WMMA cases; UD-Q4 C1 primary/reference, production AR C1/C2, reactive output-loan/cancel and greedy MTP; original Q2/IQ2 and UD raw Promessi advancing walks at 2048/4096/6144/8192, PP2048/TG128/chunk2048/cap133760/native, Q2 snapshot/replay/reference parity and physical8192 Q2 C2 vs C1. No build/install/tuning/conversion/heavy model hash/HTTP/TB or performance campaign. Complete collection/hash/independent output+phase review/whole groups/original five lease release/four notices. CPU98/NVMe85 or lower, GPU observe-only; fresh exact admission, no future grant.')
# The exact predecessor event timestamp must come from authoritative remote metadata before proposal.
plan['previous_registry_event_pending_authoritative_timestamp']=True
plan['inputs']={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (here/'window.py',here/'q2_process.py',here/'promessi_sposi.txt')}
(here/'draft-manifest.json').open('x').write(json.dumps(plan,indent=2)+'\n')
for p in (here/'window.py',here/'q2_process.py'):ast.parse(p.read_text())
record={'state':'LOCAL_FUNCTIONAL_DRAFT_NO_GPU_STAGE_ADMISSION_OR_FUTURE_GRANT','command_count':len(commands),'corpus_bytes':len(data),'corpus_sha256':hashlib.sha256(data).hexdigest(),'source_files_bound':strong['source_input_files_verified_unchanged'],'binaries_bound':len(strong['compiled_binary_checks']),'predecessor_timestamp_pending':True}
(here/'preparation-r1.json').open('x').write(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
