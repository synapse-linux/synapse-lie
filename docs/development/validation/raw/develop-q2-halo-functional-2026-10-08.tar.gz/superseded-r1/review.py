# SPDX-License-Identifier: MIT
"""Offline original native outputs and complete generated component byte review."""
import hashlib
import json
import math
from pathlib import Path
import struct

HERE=Path(__file__).resolve().parent
ROOT=HERE/'collected'
def read(name):return json.loads((ROOT/name).read_text())
def rows(name):return [json.loads(l) for l in (ROOT/name).read_text().splitlines()]
def one(values,kind):
    matching=[r for r in values if r.get('event')==kind];assert len(matching)==1
    return matching[0]
strong=json.loads((HERE/'strong-closure.json').read_text())
assert strong['state']=='CURRENT_DEVELOP_Q2_FUNCTIONAL_WINDOW_CLOSED_REVIEW_PENDING'
assert strong['kfd_empty'] and not strong['gpu_reserved'] and not strong['future_grant']
for name,row in strong['files'].items():
    p=ROOT/name;assert p.stat().st_size==row['bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
native=read('result.json')
assert len(native['commands'])==14 and all(c['exit_code']==0 for c in native['commands'])
assert native['actual_exit_code']==0 and native['model_stats_unchanged']
assert native['observed_gpu_identities']
for scan in strong['two_complete_process_scans']:
    assert scan['exact_identities_absent'] and scan['whole_groups_absent']
probe=json.loads((ROOT/'hip-probe.log').read_text())
assert probe['scope']=='GPU_RUNTIME_PROBE_NOT_MODEL_INFERENCE' and probe['sgemm_elements_verified']==4
components=rows('attention/attention.jsonl')
identity=one(components,'identity');cases=[r for r in components if r.get('event')=='case']
assert len(cases)==13 and identity['component_only'] and not identity['host_fixture'] and not identity['model_inference']
assert one(components,'complete')['completed_cases']==13
for row in cases:
    assert row['gpu_execution'] and row['passed'] and row['exact'] and row['numerical']
    assert row['artifacts_complete'] and not row['primary_error'] and not row['cleanup_error']
    a=(ROOT/'attention'/row['deep_output']['file']).read_bytes()
    b=(ROOT/'attention'/row['short_output']['file']).read_bytes()
    assert a==b and len(a)==row['values']*4
    assert all(math.isfinite(x[0]) for x in struct.iter_unpack('<f',a))
    for key in ['deep_output','short_output','blocks','deep_mask','short_mask']:
        v=row[key];data=(ROOT/'attention'/v['file']).read_bytes()
        assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
primary=rows('primary-direct.jsonl');reference=rows('reference-direct.jsonl')
for rr in (primary,reference):
    assert one(rr,'identity')['synthetic'] is False
    assert one(rr,'complete')['exit_code']==0
    assert one(rr,'sample')['output_tokens_per_user']==32
    assert len(one(rr,'sample')['output_ids'])==32
physical=one(primary,'input')['physical_ids']
assert physical==one(reference,'input')['physical_ids']==read('tokens.json')
pp=one(primary,'sample');ref=one(reference,'sample')
quality={'direct_primary_reference_output_ids_equal':pp['output_ids']==ref['output_ids'],
         'direct_primary_reference_prefill_logits_equal':pp['prefill_logits_sha256']==ref['prefill_logits_sha256'],
         'direct_primary_reference_decode_logits_equal':pp['decode_logits_sha256']==ref['decode_logits_sha256']}
actual={}
for name,users in [('core-c1',1),('core-c2',2)]:
    rr=rows(name+'.jsonl');identity=one(rr,'identity');jobs=[r for r in rr if r.get('event')=='job'];s=one(rr,'sample')
    assert not identity['synthetic'] and identity['execution']=='shared-reactive-core'
    assert one(rr,'complete')['exit_code']==0 and len(jobs)==users
    assert one(rr,'input')['physical_ids']==physical
    assert all(len(j['output_ids'])==j['output_tokens']==32 and j['prompt_tokens']==len(physical) and
      not j['cached_tokens'] and not j['ssd_cached_tokens'] and j['prefill_calls']>0 and j['decode_calls']>0 for j in jobs)
    quality[name+'_equals_direct']=all(j['output_ids']==pp['output_ids'] for j in jobs)
    view=s['prefill_attention_dispatch']
    assert view['supported'] and view['exact'] and not view['pending'] and not view['overflowed']
    assert view['confirmed_batches']>0 and view['confirmed']['attention_rows']>0
    if users==2:assert s['decode_batches']>0 and s['decode_batch_rows']>=2*s['decode_batches']
    else:assert s['decode_single_calls']>0 and s['decode_batches']==0
    actual[name]={'decode_single_calls':s['decode_single_calls'],'decode_batches':s['decode_batches'],
                 'decode_batch_rows':s['decode_batch_rows'],'attention_dispatch':view,
                 'output_ids':jobs[0]['output_ids']}
reactive=rows('reactive-probe.jsonl');assert one(reactive,'complete')['exit_code']==0
assert not one(reactive,'identity')['synthetic']
walk_quality={};walk_data={};phase_records={}
for name,restore in [('q2-walk-auto','snapshot'),('q2-walk-replay','replay'),('q2-walk-reference','replay'),('ud-walk-auto','snapshot'),('ud-walk-reference','replay')]:
    rr=rows(name+'.jsonl');identity=one(rr,'identity');corpus=one(rr,'corpus')
    assert not identity['synthetic'] and identity['measurement_contract']=='ds4-walk-v1'
    assert corpus['source_text_sha256']=='f53e0d80cb2d4492d24ebd63c7000c397b16ae70f9bf09b3763e5d8323ec209f'
    assert corpus['prompt_tokens']==8192 and len(corpus['physical_ids'])==8192
    assert one(rr,'complete')['exit_code']==0
    samples=[r for r in rr if r.get('event')=='sample'];restores=[r for r in rr if r.get('event')=='walk_restore']
    assert len(samples)==4 and len(restores)==3
    for point,row in enumerate(samples):
        assert row['point']==point and row['depth']==point*2048 and row['prompt_tokens_per_user']==(point+1)*2048
        assert row['prefill_tokens_per_user']==2048 and 0<len(row['output_ids'])<=128
        assert row['output_tokens_per_user']==len(row['output_ids']) and row['full_output_budget']==(len(row['output_ids'])==128)
        ppb,ppe=row['prefill_begin_monotonic_ns'],row['prefill_end_monotonic_ns']
        tgb,tge=row['decode_begin_monotonic_ns'],row['decode_end_monotonic_ns']
        assert 0<ppb<ppe<=tgb<tge and row['prefill_ns']==ppe-ppb and row['decode_ns']==tge-tgb
        if point<3:
            assert row['checkpoint_method']==restore
            if restore=='snapshot':
                assert 0<row['checkpoint_bytes']<=1073741824
                assert ppe<=row['checkpoint_begin_monotonic_ns']<row['checkpoint_end_monotonic_ns']<=tgb
        else:assert row['checkpoint_method']=='none'
    for point,row in enumerate(restores,1):
        assert row['point']==point and row['tokens']==point*2048 and row['method']==restore
        assert row['prefill_logits_sha256']==samples[point-1]['prefill_logits_sha256']
        assert samples[point-1]['decode_end_monotonic_ns']<=row['begin_monotonic_ns']<row['end_monotonic_ns']<=samples[point]['prefill_begin_monotonic_ns']
        assert row['elapsed_ns']==row['end_monotonic_ns']-row['begin_monotonic_ns']
    walk_data[name]=(corpus,samples)
    phase_records[name]={'restore_methods':[r['method'] for r in restores],'checkpoint_bytes':[r['checkpoint_bytes'] for r in samples],'output_counts':[len(r['output_ids']) for r in samples]}
for left,right in [('q2-walk-auto','q2-walk-replay'),('q2-walk-auto','q2-walk-reference'),('ud-walk-auto','ud-walk-reference')]:
    ca,sa=walk_data[left];cb,sb=walk_data[right]
    walk_quality[left+'_'+right+'_inputs_equal']=ca['physical_ids']==cb['physical_ids']
    for point,(a,b) in enumerate(zip(sa,sb)):
        walk_quality[left+'_'+right+'_point'+str(point)+'_equal']=all(a[k]==b[k] for k in ('prefill_logits_sha256','decode_logits_sha256','output_ids','output_tokens_per_user'))
mtp=rows('core-mtp.jsonl');mj=[r for r in mtp if r.get('event')=='job'];ms=one(mtp,'sample')
assert one(mtp,'identity')['mode']=='mtp' and one(mtp,'complete')['exit_code']==0 and len(mj)==1
assert mj[0]['mtp_drafted_tokens']>0 and mj[0]['mtp_accepted_tokens']>0
quality['greedy_mtp_equals_ar']=mj[0]['output_ids']==pp['output_ids']
q2c=rows('q2-core-c2.jsonl');qj=[r for r in q2c if r.get('event')=='job'];qs=one(q2c,'sample')
assert one(q2c,'complete')['exit_code']==0 and len(qj)==2 and qs['decode_batches']>0 and qs['decode_batch_rows']>=2*qs['decode_batches']
assert one(q2c,'input')['physical_ids']==walk_data['q2-walk-auto'][0]['physical_ids']
quality['q2_c2_equals_walk_c1']=all(j['output_ids']==walk_data['q2-walk-auto'][1][-1]['output_ids'] for j in qj)
quality.update(walk_quality)
result={'state':'CURRENT_DEVELOP_Q2_HALO_FUNCTIONAL_AND_PARITY_PASSED' if all(quality.values()) else 'CURRENT_DEVELOP_Q2_HALO_FUNCTIONAL_COMPLETE_PARITY_FAILED',
        'manifest_sha256':strong['manifest_sha256'],'original_commands':len(native['commands']),
        'generated_cases_verified':len(cases),'original_physical_prompt_tokens':len(physical),'outputs_per_job':32,
        'quality':quality,'actual_core':actual,'walk_phases':phase_records,'mtp_drafted':mj[0]['mtp_drafted_tokens'],'mtp_accepted':mj[0]['mtp_accepted_tokens'],'q2_batch_calls':qs['decode_batches'],'reactive_probe_events':[r.get('event') for r in reactive],
        'complete_group_and_five_lease_closure_verified':True,'matched_performance_qualified':False,
        'long_context_or_task_quality_or_all_feature_qualification':False}
with (HERE/'review-result.json').open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['actual_core','reactive_probe_events']}))
raise SystemExit(0 if all(quality.values()) else 1)
