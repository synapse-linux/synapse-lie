# SPDX-License-Identifier: MIT
"""One native current-develop-Q2 functional window, original leases and owned children."""
import argparse
import base64
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
BASE = Path('/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run')
PLAN = HERE/'manifest.json'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(p):
    before=p.stat()
    assert p.resolve()==p and not p.is_symlink() and stat.S_ISREG(before.st_mode)
    assert before.st_uid==1000 and before.st_size<=64*1024**2
    with p.open('rb') as stream: result=hashlib.file_digest(stream,'sha256').hexdigest()
    after=p.stat()
    assert all(getattr(before,k)==getattr(after,k) for k in ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns'))
    return result

def save(p,value,exclusive=False):
    with p.open('x' if exclusive else 'w') as stream:
        json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())

def read(p):
    assert p.stat().st_size<32*1024**2 and p.resolve()==p and not p.is_symlink()
    return json.loads(p.read_text())

def registry(plan):
    p=BASE/'gpu-coordination/epochs'/plan['boot_id']/'runs.jsonl'
    assert p.stat().st_size<2*1024**2 and not p.is_symlink()
    return p,json.loads(p.read_text().splitlines()[-1])

def kfd():
    p=Path('/sys/class/kfd/kfd/proc');assert p.is_dir()
    return [int(v.name) for v in p.iterdir() if v.name.isdecimal()]

def models(plan):
    for row in plan['models']:
        p=Path(row['path']);s=p.stat()
        assert p.resolve()==p and not p.is_symlink() and stat.S_ISREG(s.st_mode)
        assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==tuple(row[k] for k in ('device','inode','bytes','mtime_ns','ctime_ns'))
    row=plan['glm_model'];p=Path(row['path']);s=p.stat()
    assert p.resolve()==p and not p.is_symlink()
    assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==tuple(row[k] for k in ('device','inode','bytes','mtime_ns','ctime_ns'))

def sensors():
    rows=[]
    for folder in sorted(Path('/sys/class/hwmon').glob('hwmon*')):
        name=(folder/'name').read_text().strip()
        if name not in ('k10temp','coretemp','amdgpu','nvme'):continue
        for p in sorted(folder.glob('temp*_input')):
            limit=None if name=='amdgpu' else 85.0 if name=='nvme' else 98.0
            if limit is not None:
                for suffix in ('max','crit'):
                    bound=p.with_name(p.name[:-6]+'_'+suffix)
                    if bound.exists():
                        v=int(bound.read_text())/1000
                        if 30<=v<=150:limit=min(limit,v)
            value=int(p.read_text())/1000
            rows.append({'name':name,'path':str(p),'limit_c':limit,'value_c':value})
    assert any(r['name']=='k10temp' for r in rows)
    assert all(r['limit_c'] is None or r['value_c']<r['limit_c'] for r in rows)
    return rows

def leases(plan):
    fds=[]
    try:
        for row in plan['leases']:
            p=Path(row['path']);assert p.resolve()==p and not p.is_symlink()
            fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW);fds.append(fd);s=os.fstat(fd)
            assert stat.S_ISREG(s.st_mode) and s.st_uid==1000
            assert (s.st_dev,s.st_ino)==(row['device'],row['inode'])
            fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        return fds
    except BaseException:
        for fd in reversed(fds):os.close(fd)
        raise

def absent(identities,groups):
    scans=[]
    for pass_index in range(2):
        checked=0
        for p in Path('/proc').glob('[0-9]*'):
            try:fields=(p/'stat').read_text().rsplit(') ',1)[1].split()
            except FileNotFoundError:continue
            checked+=1;pid=int(p.name);start=int(fields[19]);group=int(fields[2])
            assert not any(pid==r['pid'] and start==r['start_ticks'] for r in identities)
            assert group not in groups
        scans.append({'pass':pass_index,'processes_checked':checked,'exact_identities_absent':True,'whole_groups_absent':True})
    return scans

def check(plan,previous=True):
    assert os.getuid()==1000 and HERE==BASE/plan['label'] and HERE.resolve()==HERE
    assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==plan['boot_id']
    fs=subprocess.run(['findmnt','--json','--target',str(BASE),'--output','UUID'],capture_output=True,text=True,timeout=10)
    assert fs.returncode==0 and json.loads(fs.stdout)['filesystems'][0]['uuid']==plan['filesystem_uuid']
    assert 'ryzen ai max+ 395' in Path('/proc/cpuinfo').read_text().lower()
    assert sha(Path(plan['previous_release_path']))==plan['previous_release_sha256']
    assert sha(Path(plan['previous_strong_path']))==plan['previous_strong_sha256']
    if previous:
        assert registry(plan)[1]==plan['previous_registry_event'] and not kfd()
        prior=read(Path(plan['previous_strong_path']))
        absent(prior['identities_checked'],set(prior['original_groups_checked']))
    models(plan)
    for name,row in plan['inputs'].items():
        p=HERE/name;assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
    inventory=read(Path(plan['compiled_source_inventory_path']))
    assert sha(Path(plan['compiled_source_inventory_path']))==plan['compiled_source_inventory_sha256']
    for name,row in inventory.items():
        p=Path(plan['compiled_source_root'])/name
        assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
    for row in plan['binaries'].values():
        p=Path(row['path']);assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
    m={l.split(':',1)[0]:l.split(':',1)[1].strip() for l in Path('/proc/meminfo').read_text().splitlines()}
    assert int(m['MemAvailable'].split()[0])*1024>=plan['minimum_available_bytes']
    assert os.statvfs(HERE).f_bavail*os.statvfs(HERE).f_frsize>=1024**3
    declaration=read(HERE/'peer-declarations.json')
    assert declaration['manifest_sha256']==sha(PLAN)
    assert set(declaration['specific_nonuse_peer_ids'])==set(plan['peer_ids'])
    return {'memory':{k:m[k] for k in ('MemTotal','MemAvailable')},'temperatures':sensors()}

def event(plan,kind,receipt):
    p=registry(plan)[0]
    with p.open('a') as stream:
        stream.write(json.dumps({'event':kind,'owner':'synapse-lie-root','label':HERE.name,
          'at':now(),'boot_id':plan['boot_id'],'receipt':str(receipt),'receipt_sha256':sha(receipt)})+'\n')
        stream.flush();os.fsync(stream.fileno())

def rows(name):
    p=HERE/name;assert p.stat().st_size<=16*1024**2
    return [json.loads(l) for l in p.read_text().splitlines()]

def run(plan):
    import q2_process
    held=[];admitted=False;observed=[];peaks={}
    result={'state':'PREPARING_NOT_ADMITTED','commands':[],'manifest_sha256':sha(PLAN),
            'gpu_reserved':False,'future_grant':False,'model_stats_unchanged':False}
    try:
        check(plan)
        fresh=read(HERE/'fresh.json')
        assert fresh['manifest_sha256']==sha(PLAN)
        age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(fresh['at_utc'])).total_seconds()
        assert 0<=age<=120
        held=leases(plan);preflight=check(plan)
        result.update(state='ADMITTED_CURRENT_DEVELOP_Q2_FUNCTIONAL',admitted_at=now(),
                      supervisor=q2_process.identity(os.getpid()),original_lease_fds=[{'fd':fd,**r} for fd,r in zip(held,plan['leases'])],preflight=preflight)
        save(HERE/'admission.json',result,True);event(plan,'window_admit',HERE/'admission.json');admitted=True
        with (HERE/'telemetry.jsonl').open('x') as telemetry:
            def observe(pid):
                client_ids=[q2_process.identity(v) for v in kfd()]
                for r in client_ids:
                    if r and not any((r['pid'],r['start_ticks'])==(v['pid'],v['start_ticks']) for v in observed):observed.append(r)
                values=sensors()
                for r in values:peaks[r['path']]=max(peaks.get(r['path'],r['value_c']),r['value_c'])
                telemetry.write(json.dumps({'at_utc':now(),'owned_child_pid':pid,'kfd':client_ids,'temperatures':values})+'\n');telemetry.flush()
            env=dict(os.environ,LC_ALL='C',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
            env.pop('HIP_VISIBLE_DEVICES',None);env.pop('ROCR_VISIBLE_DEVICES',None);env.pop('CUDA_VISIBLE_DEVICES',None)
            for index,command in enumerate(plan['commands']):
                if command['name']=='q2-core-c2':
                    corpus=[r for r in rows('q2-walk-auto.jsonl') if r.get('event')=='corpus']
                    assert len(corpus)==1 and len(corpus[0]['physical_ids'])==8192
                    save(HERE/'q2-tokens.json',corpus[0]['physical_ids'],True)
                if command['name']=='reference-direct':
                    inputs=[r for r in rows('primary-direct.jsonl') if r.get('event')=='input']
                    assert len(inputs)==1 and 2016<=len(inputs[0]['physical_ids'])<=2048
                    save(HERE/'tokens.json',inputs[0]['physical_ids'],True)
                row={'name':command['name'],'argv':command['argv'],'started_at':now()}
                result['commands'].append(row);save(HERE/'result.json',result)
                with (HERE/(command['name']+'.log')).open('xb') as log:
                    q2_process.supervise(row['argv'],cwd=HERE,env=env,log=log,row=row,
                        timeout=command['timeout_seconds'],save=lambda:save(HERE/'result.json',result),clients=kfd,observe=observe)
                row['ended_at']=now()
                assert not kfd() and not q2_process.members(row['pid'],row['start_ticks'])
                assert time.monotonic()-started<=plan['whole_window_seconds']
            result['state']='FUNCTIONAL_COMMANDS_COMPLETE_REVIEW_PENDING';result['actual_exit_code']=0
    except BaseException as error:
        result.update(state='FUNCTIONAL_FAILED' if admitted else 'ADMISSION_REFUSED',actual_exit_code=1,error=repr(error))
    finally:
        models(plan);result['model_stats_unchanged']=True
        result['observed_gpu_identities']=observed;result['peak_C_by_sensor']=peaks
        result['models']=plan['models'];result['glm_model']=plan['glm_model'];result['leases']=plan['leases']
        if admitted:
            result['retired_identities']=[result['supervisor'],*[{'pid':r['pid'],'start_ticks':r['start_ticks']} for r in result['commands'] if 'pid' in r],*observed]
            result['retired_groups']=sorted({result['supervisor']['group'],*[r['pid'] for r in result['commands'] if 'pid' in r]})
        for fd in reversed(held):os.close(fd)
        result['lease_released_at']=now();result['gpu_reserved']=False
        save(HERE/'result.json',result)
        if admitted:save(HERE/'release.json',result,True);event(plan,'window_release',HERE/'release.json')
    print(json.dumps({'state':result['state'],'actual_exit_code':result['actual_exit_code'],'error':result.get('error'),'lease_released_at':result['lease_released_at']}))
    raise SystemExit(result['actual_exit_code'])

def collect(plan):
    check(plan,previous=False)
    release=read(HERE/'release.json');assert not release['gpu_reserved']
    assert release['model_stats_unchanged'] and not kfd()
    last=registry(plan)[1];assert last['event']=='window_release' and last['label']==HERE.name and last['receipt_sha256']==sha(HERE/'release.json')
    scans=absent(release['retired_identities'],set(release['retired_groups']))
    held=leases(plan)
    try:
        models(plan);files={}
        for p in sorted(HERE.rglob('*')):
            if not p.is_file():continue
            relative=str(p.relative_to(HERE))
            assert p.stat().st_size<=32*1024**2
            data=p.read_bytes();digest=sha(p);assert hashlib.sha256(data).hexdigest()==digest
            files[relative]={'bytes':len(data),'sha256':digest,'base64':base64.b64encode(data).decode()}
        strong={'state':'CURRENT_DEVELOP_Q2_FUNCTIONAL_WINDOW_CLOSED_REVIEW_PENDING','at_utc':now(),
          'manifest_sha256':sha(PLAN),'release_sha256':sha(HERE/'release.json'),'two_complete_process_scans':scans,
          'retired_identities':release['retired_identities'],'retired_groups':release['retired_groups'],
          'models_unchanged':True,'kfd_empty':True,'original_five_leases_verified_free_and_released':plan['leases'],
          'gpu_reserved':False,'future_grant':False,'files':{k:{x:v[x] for x in ('bytes','sha256')} for k,v in files.items()}}
    finally:
        for fd in reversed(held):os.close(fd)
    save(HERE/'strong-closure.json',strong,True)
    print(json.dumps({'strong':strong,'files':files}))

parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=('fresh','run','collect'),required=True)
args=parser.parse_args();plan=read(PLAN);started=time.monotonic()
if args.mode=='fresh':
    observation=check(plan);held=leases(plan)
    for fd in reversed(held):os.close(fd)
    value={'state':'FRESH_GLOBAL_FUNCTIONAL_OBSERVED_NOT_ADMITTED','at_utc':now(),'manifest_sha256':sha(PLAN),
           'kfd_empty':True,'five_original_leases_free_and_released':True,**observation}
    save(HERE/'fresh.json',value,True);print(json.dumps(value))
elif args.mode=='run':run(plan)
else:collect(plan)
