# SPDX-License-Identifier: MIT
"""Preserve actual native exits, closed GPU evidence and independent review."""
from pathlib import Path
import datetime, hashlib, io, json, tarfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PUBLIC=ROOT/'docs/development/validation/develop-q2-halo-functional-2026-10-08.json'
ARCHIVE=PUBLIC.parent/'raw/develop-q2-halo-functional-2026-10-08.tar.gz'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(name):return [json.loads(l) for l in (HERE/'collected'/name).read_text().splitlines()]
def one(values,kind):
 found=[r for r in values if r.get('event')==kind]
 assert len(found)==1
 return found[0]
assert not PUBLIC.exists() and not ARCHIVE.exists()
plan=read(HERE/'manifest.json');strong=read(HERE/'strong-closure.json')
native=read(HERE/'collected/result.json')
assert sha(HERE/'manifest.json')==strong['manifest_sha256']==native['manifest_sha256']=='49cea499c4a9421fb2cdce0773dff7e660a0e2f4b4a33946aa7590f31fe57e3d'
assert strong['kfd_empty'] and not strong['gpu_reserved'] and not strong['future_grant']
assert all(r['exact_identities_absent'] and r['whole_groups_absent'] for r in strong['two_complete_process_scans'])
assert len(strong['original_five_leases_verified_free_and_released'])==5
assert native['model_stats_unchanged'] and strong['models_unchanged']
assert read(HERE/'collect-controller-result.json')['actual_exit_code']==0
controller=read(HERE/'run-controller-result.json')
guard=read(HERE/'offline-review-guard-r1/result.json')
review_path=HERE/'review-result.json'
review=read(review_path) if review_path.exists() else None
notices=read(HERE/'release-notifications-r1.json')
assert notices['manifest_sha256']==strong['manifest_sha256']
assert {r['threadId'] for r in notices['notifications']}==set(plan['peer_ids'])
assert len(notices['notifications'])==4 and all(not r['result'].get('isError',False) for r in notices['notifications'])
reactive=None
if (HERE/'collected/reactive-probe.jsonl').exists():
 rr=rows('reactive-probe.jsonl')
 matched=[r for r in rr if r.get('event')=='reactive']
 if matched:
  reactive=one(rr,'reactive')
  assert reactive['scope']=='direct-c-core-held-loan-peer-cancel' and not reactive['synthetic']
  assert reactive['peer_output_tokens']==32 and reactive['held_output_blocked']==1
  assert reactive['held_borrowed_tokens']>=1 and reactive['completed_delta']==reactive['cancelled_delta']==1
  assert reactive['decode_batches_delta']>0
passed=bool(review and guard['exit_code']==guard['child_exit_code']==0 and
            controller['actual_exit_code']==native['actual_exit_code']==0 and
            review['state']=='CURRENT_DEVELOP_Q2_HALO_FUNCTIONAL_AND_PARITY_PASSED')
if passed:assert len(native['commands'])==14 and reactive
members={}
def add(name,path):
 assert name not in members and path.is_file() and not path.is_symlink() and path.stat().st_size<=32*1024**2
 members[name]=path
for name,row in strong['files'].items():
 p=HERE/'collected'/name
 assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
 add('native/'+name,p)
for p in sorted(HERE.iterdir()):
 if p.is_file():add('control/'+p.name,p)
for relative in ('offline-review-guard-r1/result.json','offline-review-guard-r1/command.log','offline-review-guard-r1/plan.json','offline-review-guard-r1/temperatures.jsonl'):
 add('control/'+relative,HERE/relative)
old=ROOT/'evidence/halo-develop-q2-functional-20261008-r1'
for p in sorted(old.iterdir()):
 if p.is_file():add('superseded-r1/'+p.name,p)
build=ROOT/'evidence/halo-develop-q2-build-20261008-r1'
for relative in ('manifest.json','source-inventory.json','strong-closure.json','local-closure-review.json','controller-result.json','collect-close-result-r1.json','release-notifications-r1.json'):
 add('build/'+relative,build/relative)
for relative in ('release.json','compiler-result.json','source/build/halo-develop-q2-provider-r1/BUILD-RECEIPT.json','source/build/halo-develop-q2-reference-r1/BUILD-RECEIPT.json','source/build/halo-develop-q2-linked-r1/CMakeCache.txt'):
 add('build/native/'+relative,build/'collected'/relative)
for relative in ('LICENSE','tools/lie-bench.c','tools/walk-bench.inc','tools/core-bench.c','tools/hip-probe.c','adapters/gufo_reference_bench.cpp','adapters/gufo-state/qwen-q2-format-edits.json','patches/gufo-q2.patch'):
 add('source/'+relative,ROOT/relative)
inventory={name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in sorted(members.items())}
ARCHIVE.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(ARCHIVE,'x:gz',compresslevel=6) as archive:
 for name,p in sorted(members.items()):
  data=p.read_bytes()
  assert len(data)==inventory[name]['bytes'] and hashlib.sha256(data).hexdigest()==inventory[name]['sha256']
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
  archive.addfile(info,io.BytesIO(data))
with tarfile.open(ARCHIVE,'r:gz') as archive:
 entries=archive.getmembers()
 assert len(entries)==len(inventory) and {r.name for r in entries}==set(inventory)
 for entry in entries:
  assert entry.isfile()
  data=archive.extractfile(entry).read()
  assert len(data)==inventory[entry.name]['bytes'] and hashlib.sha256(data).hexdigest()==inventory[entry.name]['sha256']
measurements={}
for command in native['commands']:
 p=HERE/'collected'/(command['name']+'.jsonl')
 if p.exists():
  rr=rows(p.name)
  measurements[command['name']]={'identity':[r for r in rr if r.get('event')=='identity'],
   'samples':[r for r in rr if r.get('event')=='sample'],'jobs':[r for r in rr if r.get('event')=='job'],
   'restores':[r for r in rr if r.get('event')=='walk_restore'],
   'completion':[r for r in rr if r.get('event')=='complete']}
peaks={};telemetry=rows('telemetry.jsonl')
for row in telemetry:
 for sensor in row['temperatures']:
  if sensor['limit_c'] is not None:assert sensor['value_c']<sensor['limit_c']
  peaks[sensor['name']]=max(peaks.get(sensor['name'],sensor['value_c']),sensor['value_c'])
receipt={'schema':'synapse-lie.develop-q2-halo-functional.v1',
 'state':'CURRENT_DEVELOP_Q2_HALO_FUNCTIONAL_AND_PARITY_PASSED' if passed else 'CLOSED_FUNCTIONAL_EVIDENCE_ACCEPTANCE_FAILED',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'host':'paperboy@192.168.5.157','target':plan['hip_architecture'],'sdk':plan['sdk'],
 'source_commit':plan['source_commit'],'runtime_source':plan['runtime_source'],
 'source_qualified_from':plan['source_qualified_from'],'production_runtime_parent':plan['production_runtime_parent'],
 'manifest_sha256':strong['manifest_sha256'],'binaries':plan['binaries'],'commands':native['commands'],
 'original_controller_actual_exit':controller['actual_exit_code'],'native_actual_exit':native['actual_exit_code'],
 'independent_offline_review_actual_exit':guard['exit_code'],'independent_review':review,
 'collection_actual_exit':0,'measurements':measurements,'reactive_probe':reactive,
 'peak_C':peaks,'thermal_samples':len(telemetry),'cpu_guard_C':98,'GPU_temperature_observe_only':True,
 'models_stat_only':plan['models'],'glm_model_stat_only':plan['glm_model'],
 'closure':{'lease_release_at':native['lease_released_at'],'release_sha256':strong['release_sha256'],
  'strong_at_utc':strong['at_utc'],'strong_sha256':sha(HERE/'strong-closure.json'),
  'two_complete_process_scans':strong['two_complete_process_scans'],'retired_identities':strong['retired_identities'],
  'retired_groups':strong['retired_groups'],'five_original_leases_verified_free_and_released':strong['original_five_leases_verified_free_and_released'],
  'kfd_empty':True,'all_eight_model_stats_unchanged':True,'four_final_notices_delivered':True},
 'raw':{'path':'raw/'+ARCHIVE.name,'bytes':ARCHIVE.stat().st_size,'sha256':sha(ARCHIVE),'member_count':len(inventory),'inventory':inventory},
 'scope':{'generated_GPU_component_cases':13,'original_models':['Qwen3.8-Flash-Next-Q2','Qwen3.8-Flash-Next-UD-Q4_K_XL'],
  'walk_physical_frontiers':[2048,4096,6144,8192],'walk_physical_append_per_point':2048,'walk_TG_limit':128,
  'core_users':[1,2],'core_physical_input':'same captured UD 2K or Q2 8K token IDs','greedy':True,
  'mtp_predictor':'original shared Q8_0','full_model_or_long_context_or_task_quality':False,
  'matched_performance_or_reactive_speedup_qualified':False,'model_conversion_or_payload_hash':False,
  'installation_tuning_or_service':False,'terminal_bench':False},
 'limitations':['One serial sample per arm, zero warmup; diagnostic timings cannot establish performance parity or speedup.',
  'Walk measures appended PP only; snapshot/restore/replay are separately timed and excluded. It is not a full cold-prefill curve.',
  'Natural EOS can shorten walk TG; complete counts and IDs remain in every sample.',
  'Primary/reference use the same pinned embedded provider with C17 sampler ON/OFF, not independent Gufo/Halogen services.',
  'Selected Q2 and UD functional scope does not qualify all context, sampling, vision, steering, fault or resource campaigns.'],
 'current_root_remote_job_handle_lease_waiter_reservation':False,'future_grant':False,
 'all_six_root_roadmap_tasks_remain_open':True}
PUBLIC.open('x').write(json.dumps(receipt,indent=2)+'\n')
summary={'actual_exit_code':0,'acceptance_passed':passed,'receipt':str(PUBLIC.relative_to(ROOT)),
 'receipt_sha256':sha(PUBLIC),'archive_bytes':ARCHIVE.stat().st_size,'members_verified':len(inventory),'peak_C':peaks}
(HERE/'seal-result.json').open('x').write(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))

