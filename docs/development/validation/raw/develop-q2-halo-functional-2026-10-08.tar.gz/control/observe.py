# SPDX-License-Identifier: MIT
"""Read-only observation of the original functional controller, never restart it."""
from pathlib import Path
import hashlib, json, subprocess, sys

HERE=Path(__file__).resolve().parent
suffix=sys.argv[1]
assert suffix.isdecimal() and int(suffix)>0
program=r'''
from pathlib import Path
import datetime,hashlib,json,os
root=Path('/home/paperboy/workspace/projects/synapse-linux/synapse-lie/run/halo-develop-q2-functional-20261008-r2')
assert os.getuid()==1000 and root.resolve()==root
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='be3e89fd-955b-47a4-a385-11c3ad98bb78'
assert hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()=='49cea499c4a9421fb2cdce0773dff7e660a0e2f4b4a33946aa7590f31fe57e3d'
result=json.loads((root/'result.json').read_text())
def identity(pid):
 try:
  fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
  return {'pid':pid,'state':fields[0],'group':int(fields[2]),'session':int(fields[3]),'start_ticks':int(fields[19])}
 except FileNotFoundError:return None
supervisor=result.get('supervisor');observed=None;fds=[]
if supervisor:
 observed=identity(supervisor['pid'])
 if observed and observed['start_ticks']==supervisor['start_ticks']:
  for row in result['original_lease_fds']:
   path=Path('/proc',str(supervisor['pid']),'fd',str(row['fd']))
   try:s=path.stat()
   except FileNotFoundError:
    fds.append({'fd':row['fd'],'absent_at_observation':True});continue
   assert (s.st_dev,s.st_ino)==(row['device'],row['inode'])
   fds.append({'fd':row['fd'],'path':os.readlink(path),'device':s.st_dev,'inode':s.st_ino})
telemetry=root/'telemetry.jsonl';last=None
if telemetry.exists():
 with telemetry.open('rb') as stream:
  stream.seek(max(0,telemetry.stat().st_size-16000));lines=stream.read().splitlines()
 if lines:last=json.loads(lines[-1])
commands=[{k:r.get(k) for k in ('name','pid','start_ticks','exit_code','started_at','ended_at')} for r in result.get('commands',[])]
clients=[identity(int(p.name)) for p in Path('/sys/class/kfd/kfd/proc').iterdir() if p.name.isdecimal()]
registry=root.parent/'gpu-coordination/epochs/be3e89fd-955b-47a4-a385-11c3ad98bb78/runs.jsonl'
registry_last=json.loads(registry.read_text().splitlines()[-1])
print(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':result['state'],'observed_supervisor':observed,'original_lease_fds':fds,
 'commands':commands,'latest_telemetry':last,'kfd_registered_identities':clients,
 'error':result.get('error'),'lease_released_at':result.get('lease_released_at'),
 'peak_C_by_sensor':result.get('peak_C_by_sensor'),'registry_last':registry_last,'no_control_or_gpu_command':True}))
'''
argv=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=8',
      'paperboy@192.168.5.157','python3 -B -']
r=subprocess.run(argv,input=program,text=True,capture_output=True,timeout=45)
record={'argv':argv,'actual_exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,
        'program_sha256':hashlib.sha256(program.encode()).hexdigest()}
try:record['result']=json.loads(r.stdout)
except ValueError:pass
(HERE/('live-'+suffix+'.json')).open('x').write(json.dumps(record,indent=2)+'\n')
v=record.get('result',{})
latest=v.get('latest_telemetry') or {}
print(json.dumps({'actual_exit_code':r.returncode,'at_utc':v.get('at_utc'),'state':v.get('state'),
 'supervisor':v.get('observed_supervisor'),'lease_FDs_observed':len(v.get('original_lease_fds',[])),
 'commands':[(row['name'],row['exit_code']) for row in v.get('commands',[])],
 'GPU_identities':v.get('kfd_registered_identities'),
 'latest_temperatures_C':{s['name']:s['value_c'] for s in latest.get('temperatures',[])},
 'peak_C_by_sensor':v.get('peak_C_by_sensor'),'error':v.get('error'),
 'lease_released_at':v.get('lease_released_at')}))
raise SystemExit(r.returncode)
