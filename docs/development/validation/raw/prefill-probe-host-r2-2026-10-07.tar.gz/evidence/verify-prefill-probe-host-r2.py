# SPDX-License-Identifier: MIT
"""Independently verify the completed archive/current bindings; no tests/GPU."""
from pathlib import Path
import datetime,hashlib,json,tarfile
root=Path.cwd();p=root/'docs/development/validation/prefill-probe-host-r2-2026-10-07.json'
r=json.loads(p.read_text());a=r['portable_raw_archive'];path=p.parent/a['path']
assert path.stat().st_size==a['bytes']
assert hashlib.sha256(path.read_bytes()).hexdigest()==a['sha256']
assert r['live_packaging_guard_excluded'] is True
with tarfile.open(path,'r:gz') as tar:
    assert len(tar.getmembers())==a['members']==len(r['raw_artifacts'])
    for member in tar.getmembers():
        assert not member.name.startswith('evidence/prefill-probe-host-r2-sealing-guard/')
        assert not member.name.startswith('evidence/prefill-probe-host-r2-postseal-guard/')
        info=r['raw_artifacts'][member.name];data=tar.extractfile(member).read()
        assert len(data)==info['bytes'] and hashlib.sha256(data).hexdigest()==info['sha256']
        live=root/member.name
        assert live.stat().st_size==info['bytes'] and hashlib.sha256(live.read_bytes()).hexdigest()==info['sha256']
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit_code':0,
        'classification':'LOCAL_PACKAGING_ONLY_NO_TEST_GPU_OR_MODEL_RUN',
        'all_archived_and_current_members_match':True,'members':a['members'],
        'portable_archive_sha256':a['sha256'],'live_guard_members_excluded':True}
(root/'evidence/prefill-probe-host-r2-postseal.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
