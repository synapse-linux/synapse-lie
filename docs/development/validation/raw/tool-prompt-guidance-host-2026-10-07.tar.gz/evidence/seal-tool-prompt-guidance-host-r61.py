#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Seal completed CPU formatter/grammar checks; no model or GPU operations."""
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path

B = Path(__file__).resolve().parents[1]
OUT = B / 'docs/development/validation/tool-prompt-guidance-host-2026-10-07.json'
RAW = B / 'docs/development/validation/raw/tool-prompt-guidance-host-2026-10-07.tar.gz'


def read(p):
    return json.loads(p.read_text())


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def record(p):
    return {'bytes': p.stat().st_size, 'sha256': sha(p)}


assert not OUT.exists() and not RAW.exists()
files = set()
sources = [
    'adapters/gufo.cpp', 'adapters/gufo_chat.hpp', 'tests/test_gufo_chat.cpp',
    'tests/model_prompt/CMakeLists.txt', 'tests/sampling/CMakeLists.txt',
    'tests/sampling/parallel_tools.cpp', 'tests/sampling/compare.cmake',
    'CMakeLists.txt', 'cmake/provider/Source.cmake', 'tools/thermal-run.py',
    'third_party/gufo-source.json', 'third_party/README.md',
    'README.md', 'CHANGELOG.md', 'docs/reference/ABI.md', 'docs/BACKEND.md',
    'docs/PROGRESS.md', 'docs/COORDINATION.md',
    'docs/development/protocols/TOOL-TRANSITIONS-GPU-PROTOCOL.md',
    'tools/strix-point-tool-transition-gate.py',
]
files.update(B / n for n in sources)
groups = {
    'context-r61-prompt-release-build': (0, 0),
    'context-r61-prompt-release-checks': (0, 5),
    'context-r61-prompt-asan': (0, 5),
    'context-r61-exact-grammar-release': (8, 0),
    'context-r61-exact-grammar-release-r2': (0, 1),
    'context-r61-exact-grammar-asan': (0, 1),
}
commands = []
peaks = {'CPU': 0., 'GPU': 0., 'NVMe': 0.}
for name, (code, count) in groups.items():
    directory = B / 'evidence' / name
    result = read(directory / 'result.json')
    assert result['exit_code'] == result['child_exit_code'] == code and result['reason'] is None
    log = (directory / 'command.log').read_text()
    if count:
        assert (f'100% tests passed out of {count}' in log or
                f'100% tests passed, 0 tests failed out of {count}' in log)
    elif code == 8:
        assert 'REFERENCE host probe exit Subprocess aborted' in log
    commands.append({'guard': str(directory.relative_to(B)), 'actual_exit_code': code,
                     'completed_CTest_count': count, 'argv': result['argv']})
    for row in (directory / 'temperatures.jsonl').read_text().splitlines():
        for t in json.loads(row)['temperatures']:
            kind = 'CPU' if t['name'] in ('k10temp', 'coretemp') else 'GPU' if t['name'] == 'amdgpu' else 'NVMe'
            peaks[kind] = max(peaks[kind], t['value_c'])
            assert t['limit_c'] is None or t['value_c'] < t['limit_c']
    files.update(p for p in directory.iterdir() if p.is_file())
assert peaks['CPU'] == 78.5
witnesses = []
binary_identities = {}
for mode in ['release', 'asan']:
    directory = B / ('build/context-r61-exact-grammar-' + mode)
    for arm in ['REFERENCE', 'CANDIDATE', 'FALLBACK']:
        p = directory / 'parallel-tools-parity' / (arm + '.txt')
        assert p.stat().st_size == 245421
        assert sha(p) == '5c6ac6a06a6b5b4fc5abb785b7b3c50549fc8cd0410b5428ceec103de0f9617a'
        lines = p.read_text().splitlines()
        assert len(lines) == 861
        assert lines[-1] == 'CASES=8 PREFIXES=848 EXACT_SCHEMA_AND_STOP_MASK_HOST_NOT_INFERENCE'
        assert sum(x.startswith('prefix=') for x in lines) == 848
        assert sum(x.startswith('plain=') for x in lines) == 8
        for line in lines:
            if line.startswith('prefix='):
                mask = line.split('mask=')[1]
                assert len(mask) == 261 and set(mask) <= {'0', '1'}
        assert p.with_suffix('.exit').read_text().strip() == '0'
        assert p.with_suffix('.stderr').stat().st_size == 0
        witnesses.append({'mode': mode, 'arm': arm, 'path': str(p.relative_to(B)), **record(p)})
        files.update([p, p.with_suffix('.exit'), p.with_suffix('.stderr')])
        binary = directory / (arm.lower() + '-parallel-tools-probe')
        binary_identities[str(binary.relative_to(B))] = record(binary)
        for extra in ['flags.make', 'link.txt']:
            files.add(directory / 'CMakeFiles' / (arm.lower() + '-parallel-tools-probe.dir') / extra)
    files.add(directory / 'CMakeCache.txt')
    files.add(directory / 'Testing/Temporary/LastTest.log')
    prompt_dir = B / ('build/context-r61-prompt-' + mode)
    prompt = prompt_dir / 'test-model-prompt'
    binary_identities[str(prompt.relative_to(B))] = record(prompt)
    files.update([prompt_dir / 'CMakeCache.txt', prompt_dir / 'Testing/Temporary/LastTest.log',
                  prompt_dir / 'CMakeFiles/test-model-prompt.dir/flags.make',
                  prompt_dir / 'CMakeFiles/test-model-prompt.dir/link.txt'])
pin = read(B / 'third_party/gufo-source.json')
assert pin['commit'] == 'f783fedb9bea2ec7de941f6da4e02f4a4596b29e'
assert len(pin['files']) == 1019
for name, digest in pin['files'].items():
    assert sha(B / '.deps/gufo-f783fedb' / name) == digest
host_path = B / 'docs/development/validation/tool-transitions-host-2026-10-07.json'
host = read(host_path)
assert len(host['current_unchanged_owned_provider_sources']) == 130
for name, digest in host['current_unchanged_owned_provider_sources'].items():
    assert sha(B / name) == digest, name
failed_path = B / 'docs/development/validation/tool-transitions-ar-point-r2-2026-10-07.json'
failed = read(failed_path)
assert failed['state'] == 'FAILED_MODEL_QUALITY_COLLECTED_AND_CLOSED'
assert (failed['new_checks_passed'], failed['new_checks_failed'], failed['new_checks_unexecuted']) == (4, 1, 66)
diff = subprocess.run(['git', 'diff', '--name-only', '52aca0a9'], cwd=B,
                      text=True, capture_output=True, check=True).stdout.splitlines()
assert set(n for n in diff if not n.endswith('.md')) <= {
    'adapters/gufo.cpp', 'adapters/gufo_chat.hpp', 'tests/test_gufo_chat.cpp', 'tests/sampling/CMakeLists.txt'}
failure_path = B / 'evidence/context-r61-preserved-preparation-failures.json'
failures = read(failure_path)
files.update([host_path, failed_path, failure_path,
    B / 'evidence/context-r61-parallel-tools-incomplete-vocabulary-r1.cpp',
    B / 'evidence/context-r61-unsealed-sealer-header-r1.py',
    B / 'evidence/context-r61-unsealed-sealer-error-r1.json',
    B / 'evidence/context-r61-goal-source-audit.json', Path(__file__).resolve()])
inventory = {str(p.relative_to(B)): record(p) for p in sorted(files)}
with RAW.open('xb') as dest:
    with gzip.GzipFile(fileobj=dest, mode='wb', mtime=0, filename='') as gz:
        with tarfile.open(fileobj=gz, mode='w') as archive:
            for name in inventory:
                data = (B / name).read_bytes()
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                archive.addfile(info, io.BytesIO(data))
receipt = {
    'schema': 'synapse-lie.tool-prompt-guidance-host.v1',
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'state': 'HOST_PROMPT_GUIDANCE_AND_PARALLEL_LANGUAGE_PASSED_NOT_GPU_ACCEPTANCE',
    'classification': 'CPU_FORMATTER_SYNTHETIC_GRAMMAR_AND_CACHE_FIXTURES_NOT_INFERENCE',
    'base_checkpoint': '52aca0a9', 'current_turn_classification': 'PROGRESS',
    'problem': 'Strict sampling uses JSON tool frames while pinned Qwen template describes XML; missing upstream syntax guidance',
    'fix': 'Model binding adds generic JSON syntax guidance for strict functions, after original-index image attachment',
    'upstream_behavior_reference': {'pin': pin['commit'], 'path': 'src/cli/serve/inference_backend.cpp',
        'source_sha256': pin['files']['src/cli/serve/inference_backend.cpp']},
    'original_renderer_preserved': True, 'plain_and_non_strict_format_preserved': True,
    'public_ABI_reactive_scheduler_worker_counts_unchanged': True,
    'numerical_algorithms_unchanged': True, 'cache_format_unchanged': True,
    'image_attachment_index_offset_content_ownership_checked': True,
    'fixed_question_schema_or_acceptance_changed': False,
    'observed_model_quality_failure_resolved': False,
    'diagnosis': 'Exact schema allows second call with parallel=true and natural EOS after first; flag does not enforce requested two calls',
    'CTest_count': {'Release': 6, 'ASan_UBSan_LSan': 6}, 'commands': commands,
    'full_witnesses': witnesses, 'grammar_modes_per_program': 8, 'byte_prefixes_per_program': 848,
    'mask_bytes_per_prefix': 261, 'mask_bits_verified_per_program': 221328,
    'owned_provider_files_unchanged': host['current_unchanged_owned_provider_sources'],
    'pinned_upstream_files_verified': 1019,
    'fixture_binary_identities_not_model_binaries': binary_identities,
    'implementation_and_contract_sources': {n: record(B / n) for n in sources},
    'sampled_peak_C': peaks, 'preserved_preparation_failures': failures,
    'preserved_initial_sealer_failure': read(B / 'evidence/context-r61-unsealed-sealer-error-r1.json'),
    'sanitizer_suppression_options': None,
    'production_adapter_HIP_compilation': 'New coherent build required; HOST formatter does not compile full HIP adapter',
    'GPU_model_or_remote_operation': False, 'heavyweight_model_hash_or_conversion': False,
    'product_Python_dependency': False, 'performance_comparison': False, 'Terminal_Bench_run': False,
    'standing_remote_job_handle_lease_window_waiter_reservation': False,
    'original_weight_full_gate_passed': False, 'goal_complete': False,
    'open_task_numbers': [2, 3, 4, 5, 6, 7],
    'prior_failed_AR_receipt': {'path': str(failed_path.relative_to(B)), **record(failed_path)},
    'portable_raw_archive': {'path': str(RAW.relative_to(B)), **record(RAW), 'regular_members': len(inventory)},
    'raw_artifacts': inventory,
}
OUT.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'state': receipt['state'], 'CTest_count': receipt['CTest_count'],
                  'peak_C': peaks, 'receipt': record(OUT), 'raw': receipt['portable_raw_archive']}))
