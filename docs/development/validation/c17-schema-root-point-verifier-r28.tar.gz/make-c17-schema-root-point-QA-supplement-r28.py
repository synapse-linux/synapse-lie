# SPDX-License-Identifier: MIT
"""Retain offline verifier corrections separately from immutable GPU raw data."""
from pathlib import Path
import gzip,hashlib,json,tarfile

def bound(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
files=[Path('evidence')/n for n in ['validate-c17-schema-root-point-r28-r1.py','validate-c17-schema-root-point-r28-r2.py','validate-c17-schema-root-point-r28-r3.py','c17-schema-root-point-final-validation-r28-r3.json','context-r28-offline-validator-ignored-fixture-failure-r1.json','context-r28-offline-validator-ninja-helper-failure-r2.json','make-c17-schema-root-point-QA-supplement-r28.py']]
assert json.loads(files[3].read_text())['actual_exit_code']==0
for p in files[4:6]:assert json.loads(p.read_text())['actual_exit_code']==1
archive=Path('docs/development/validation/c17-schema-root-point-verifier-r28.tar.gz')
with archive.open('xb') as out:
 with gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as t:
   for p in sorted(files):
    assert p.is_file() and not p.is_symlink()
    info=t.gettarinfo(str(p),arcname=p.relative_to('evidence').as_posix());info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with p.open('rb') as f:t.addfile(info,f)
path=Path('docs/development/validation/c17-schema-root-point-gpu-2026-10-06.json');r=json.loads(path.read_text());assert 'offline_QA_correction_archive' not in r
r['offline_QA_correction_archive']=bound(archive)
r['offline_QA_correction_archive_members']=len(files)
r['offline_QA_correction_files']=[bound(p) for p in files]
r['offline_QA_correction_scope']='Actual offline validator exits1,1,0 preserved; correction distinguishes frozen173 Git sources from11 unchanged ignored HOST fixtures and restores actual Ninja block reader. Original GPU raw archive unchanged. No inference/source/build/remote mutation or repeated GPU run.'
path.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'archive':str(archive),'files':len(files),'archive_sha256':bound(archive)['sha256'],'receipt_sha256':bound(path)['sha256']}))
