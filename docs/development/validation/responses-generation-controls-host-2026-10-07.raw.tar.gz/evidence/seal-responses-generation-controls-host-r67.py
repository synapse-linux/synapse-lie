# SPDX-License-Identifier: MIT
"""One-shot optional HOST evidence packer; no model or remote operations."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[1]
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def record(path):
    return {"path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size,
            "sha256": sha(path)}
def read(path):
    return json.loads(path.read_text())

receipt_path = ROOT / "docs/development/validation/responses-generation-controls-host-2026-10-07.json"
archive_path = ROOT / "docs/development/validation/responses-generation-controls-host-2026-10-07.raw.tar.gz"
assert not receipt_path.exists() and not archive_path.exists(), "Frozen outputs must not be overwritten"
prior = read(ROOT / "docs/development/validation/tool-prompt-guidance-host-2026-10-07.json")
unchanged = prior["owned_provider_files_unchanged"]
assert len(unchanged) == 130
for name, expected in unchanged.items():
    assert sha(ROOT / name) == expected, name
upstream = read(ROOT / "third_party/gufo-source.json")["files"]
assert len(upstream) == 1019
for name, expected in upstream.items():
    assert sha(ROOT / ".deps/gufo-f783fedb" / name) == expected, name

names = {"chat-tool-result-order-core", "model-constrained-tool-prompt-host",
         "chat-parser-wire", "tool-protocol", "vision-semantic-cache",
         "vision-semantic-cache-aligned", "openai-generation-state-http", "openai-generation-state-mtp-http"}
commands, raw, binaries, peaks = [], set(), [], {}
targets = ["lie/test-chat-history", "test-model-prompt", "lie/test-chat",
           "lie/test-tools", "lie/test-vision-cache", "lie/test-vision-cache-aligned",
           "lie/test-openai-http", "lie/test-synthetic-server"]
for mode in ("release", "asan"):
    guard = ROOT / (f"evidence/context-r67-responses-controls-{mode}" + ("-r2" if mode == "release" else ""))
    plan, result = read(guard / "plan.json"), read(guard / "result.json")
    assert result["exit_code"] == result["child_exit_code"] == 0 and result["reason"] is None
    assert plan["argv"] == result["argv"]
    log = (guard / "command.log").read_text()
    passed = set(re.findall(r"Test\s+#\d+:\s+(\S+)\s+\.+\s+Passed", log))
    expected = {"chat-tool-result-order-core"} if mode == "core" else names
    assert passed == expected, (mode, passed)
    assert f"100% tests passed out of {len(expected)}" in log
    commands.append({"guard": str(guard.relative_to(ROOT)), "mode": mode,
                     "argv": result["argv"], "actual_exit_code": 0,
                     "completed_CTest_count": len(passed), "test_names": sorted(passed)})
    for sensor in plan["sensors"]:
        peak = result["peak_c"][sensor["path"]]
        label = sensor["name"]
        peaks[label] = max(peaks.get(label, peak), peak)
        if sensor["limit_c"] is not None:
            assert peak < sensor["limit_c"]
    raw.update(guard.iterdir())
    build = ROOT / f"build/context-r67-responses-controls-{mode}"
    cache = build / "CMakeCache.txt"
    raw.add(cache)
    raw.add(build / "Testing/Temporary/LastTest.log")
    if mode == "core":
        assert "LIE_CORE_ONLY:BOOL=ON" in cache.read_text()
        assert "CMAKE_CXX_COMPILER:" not in cache.read_text()
        assert "JSONC_" not in cache.read_text() and "LIBCURL_" not in cache.read_text()
        binary_targets = ["test-chat-history"]
    else:
        binary_targets = targets
        raw.add(build / "lie/CMakeFiles/lie_runtime.dir/flags.make")
    for target in binary_targets:
        path = build / target
        binaries.append({"mode": mode, **record(path)})
        raw.add(path)
    if mode == "asan":
        flags = (build / "lie/CMakeFiles/lie_runtime.dir/flags.make").read_text()
        assert "-fsanitize=address,undefined" in flags
        assert "-std=c17" in flags
        assert result["argv"][:7] == ["env", "-u", "ASAN_OPTIONS", "-u", "UBSAN_OPTIONS", "-u", "LSAN_OPTIONS"]

tracked = subprocess.check_output(["git", "ls-files", "-z", "CMakeLists.txt",
    "include", "src", "adapters", "cmake", "tests", "tools/thermal-run.py",
    "third_party/gufo-source.json", "LICENSE"], cwd=ROOT).decode().split("\0")
source = {ROOT / p for p in tracked if p}
source.update(ROOT / p for p in ("include/lie/chat_history.h", "src/chat_history.c", "tests/test_chat_history.c"))
source_records = [record(p) for p in sorted(source)]
raw.update(source)
raw.update(ROOT / p for p in ("README.md", "CHANGELOG.md", "docs/BACKEND.md",
    "docs/PROGRESS.md", "docs/reference/ABI.md", "docs/COORDINATION.md", "third_party/README.md"))
raw.update(ROOT / ".deps/gufo-f783fedb" / p for p in (
    "src/models/qwen/chat_template.cpp", "src/models/qwen/chat_template.hpp", "src/core/json.hpp"))
failure = ROOT / "evidence/context-r67-failed-checking-fixture-r1/record.json"
assert read(failure)["actual_guard_and_CTest_exit_code"] == 8
raw.update(p for p in failure.parent.rglob('*') if p.is_file())
raw.update((ROOT / "evidence/context-r67-responses-controls-release").iterdir())
for name, expected in read(failure)["records"].items():
    path = failure.parent / name
    assert sha(path) == expected["sha256"] and path.stat().st_size == expected["bytes"]
raw.add(ROOT / "docs/guides/USAGE.md")
raw.add(ROOT / "docs/development/validation/tool-transitions-ar-point-r4-2026-10-07.json")
raw.add(Path(__file__).resolve())
raw_records = [record(p) for p in sorted(raw)]
with archive_path.open("xb") as out:
    with gzip.GzipFile(fileobj=out, mode="wb", mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w") as archive:
            for path in sorted(raw):
                assert path.is_file() and not path.is_symlink(), str(path)
                archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)

receipt = {"schema": "synapse-lie.responses-generation-controls-host.v1",
    "at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "state": "HOST_RESPONSES_GENERATION_CONTROLS_PASSED_NOT_GPU_ACCEPTANCE",
    "classification": "CPU_PARSER_FORMATTER_HTTP_AND_CACHE_FIXTURES_NOT_INFERENCE",
    "base_checkpoint": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip(),
    "problem": "Original r66 seeded Responses request refused by the field allowlist; existing sampler controls were not normalized or retained",
    "fix": "Normalize seed and penalties through the existing C17 generation parser; preserve strict null/type/range refusal and stored values; bound seeds to signed 64-bit nonnegative range",
    "CTest_count": {"Release": 8, "ASan_UBSan_LSan": 8},
    "commands": commands, "sampled_peak_C": peaks,
    "sanitizer_suppression_options": [],
    "upstream_source_pin": "f783fedb9bea2ec7de941f6da4e02f4a4596b29e",
    "pinned_upstream_files_verified": len(upstream),
    "owned_numerical_files_unchanged": unchanged,
    "implementation_and_test_sources": source_records,
    "fixture_binary_identities_not_model_binaries": binaries,
    "public_layouts_reactive_threads_metrics_state_formats_unchanged": True,
    "fixed_question_schema_or_acceptance_changed": False,
    "original_weight_new_runtime_acceptance": "OPEN",
    "supplied_seed_range": "integer 0..INT64_MAX; omitted uses existing -1 internal default",
    "frequency_presence_penalty_range": "finite number -2..2",
    "explicit_null_and_type_range_refusals_checked": True,
    "unchanged_original_failed_request_checked_locally": True,
    "string_and_array_Responses_inputs_checked": True,
    "completed_and_stored_HTTP_controls_verified": True,
    "native_AR_MTP_HTTP_checks_are_synthetic_only": True,
    "production_adapter_HIP_compilation": "PENDING_NEW_COHERENT_BUILD",
    "GPU_model_or_remote_operation": False, "performance_comparison": False,
    "product_Python_dependency": False, "Terminal_Bench_run": False,
    "prepared_r66_MTP_manifest": "STALE_UNADMITTED_UNLAUNCHED",
    "standing_remote_job_handle_lease_window_waiter_reservation": False,
    "open_task_numbers": [2, 3, 4, 5, 6, 7], "goal_complete": False,
    "prior_failed_AR_receipt": "docs/development/validation/tool-transitions-ar-point-r4-2026-10-07.json",
    "preserved_checking_fixture_failure": record(failure),
    "portable_raw_archive": {**record(archive_path), "regular_members": len(raw)},
    "raw_artifacts": raw_records}
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"exit_code": 0, "receipt": record(receipt_path),
                  "archive": record(archive_path), "members": len(raw),
                  "source_files": len(source_records), "CTest_count": receipt["CTest_count"]}))
